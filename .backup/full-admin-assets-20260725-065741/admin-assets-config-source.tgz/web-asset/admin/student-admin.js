      const STUDENT_NEWS_REVIEW_STATUS_SUBMITTED = "submitted";
      const STUDENT_NEWS_REVIEW_STATUS_APPROVED = "approved";
      const STUDENT_NEWS_REVIEW_STATUS_REVISION_REQUESTED = "revision-requested";

      const state = {
        authUser: null,
        authRolePolicy: null,
        rolePermissions: null,
        uiSettings: null,
        sisConfig: null,
        sisConfigMeta: null,
        adminUsers: [],
        currentAdminUser: null,
        students: [],
        dashboardStudents: [],
        dashboardSummary: null,
        dashboardLevelCompletionRows: [],
        systemLevels: [],
        activeLevelDetail: null,
        runtimeHealth: null,
        runtimeHealthFetchedAt: 0,
        runtimeHealthRequest: null,
        sisConfigRepairBusy: false,
        hubConnection: {
          state: "pending",
          endpoint: "",
          checkedAt: "",
          latencyMs: null,
          detail: "waiting for first probe...",
        },
        hubProbeMode: "healthz",
        hubProbeFallbackReason: "",
        serviceControl: {
          available: false,
          enabled: true,
          service: "exercise-mailer.service",
          status: "pending",
          detail: "waiting for first probe...",
          checkedAt: "",
          busy: false,
        },
        systemHealthReady: {
          hub: false,
          service: false,
        },
        hubPollTimer: null,
        globalTextZoomPercent: 100,
        currentStudent: null,
        selectedEnrollmentPeriodId: "",
        uiSettingsMeta: null,
        profileFormConfig: null,
        profileActiveTab: "profile",
        profileMode: "info",
        profileLayoutExpanded: false,
        assignmentTemplates: [],
        exerciseTitles: [],
        exerciseCatalog: [],
        assignmentDraft: {
          id: "",
          items: [],
        },
        levelTileStyleEditor: {
          selectedLevel: "",
          pendingImageDataUrl: "",
        },
        activePage: "overview",
        attendanceLanding: {
          selectedLevel: "",
          selectionsByStudentId: {},
          studentDetailsByStudentId: {},
          tileConfigByLevel: {},
          saveBusy: false,
        },
        parentTracking: {
          selectedLevel: "",
          selectedStudentId: "",
          manualMetricsTouched: false,
          activeRecommendationFieldName: "",
          teacherNames: [],
          lessonSummaryByLevelDate: {},
          studentDetailsByStudentId: {},
          outstandingByRecordId: {},
        },
        incomingExerciseQueue: {
          items: [],
          total: 0,
          hasMore: false,
          showAll: false,
          statuses: [],
          pendingActionById: {},
        },
        parentReportQueue: {
          items: [],
          queuedReportIds: {},
          total: 0,
          hasMore: false,
          showAll: false,
          modalIndex: -1,
          savedReportCountHint: 0,
          sourceRows: [],
          stagedRows: [],
          selectedIds: {},
          pendingStageQueueById: {},
        },
        newsReview: {
          sourceReports: [],
          allItems: [],
          items: [],
          total: 0,
          hasMore: false,
          statusSummary: {
            completed: 0,
            incomplete: 0,
            pending: 0,
            submitted: 0,
            approved: 0,
            waiting: 0,
            revise: 0,
            checked: 0,
          },
          bulkApprovePending: false,
          pendingById: {},
          viewerReportId: "",
          viewerWeekSetId: "",
          viewerItems: [],
          viewerIndex: -1,
          viewerStudentKey: "",
          viewerEditMode: false,
          filters: {
            status: "all",
            setAction: "all",
            level: "",
            studentRefId: "",
            dateFrom: "",
            dateTo: "",
            query: "",
            take: 200,
          },
        },
        queueHub: {
          loaded: false,
          overviewNewsQueueShowAll: false,
          generatedAt: "",
          panelOrder: [
            "queued-performance-reports",
            "unmatched-exercise-submissions",
            "current-assignments-pending",
            "overdue-homework",
            "attendance-risk",
            "news-report-review",
            "pending-profile-submissions",
          ],
          panelsById: {},
          draggingPanelId: "",
          hasUnsavedOrder: false,
        },
        studentDetailCacheById: {},
        adminDataLoading: {
          attendance: false,
          performance: false,
          grades: false,
          reports: false,
        },
        tableRows: {
          attendance: [],
          performance: [],
          grades: [],
          reports: [],
        },
        tableColumnVisibility: null,
        attendanceColumnVisibility: null,
        tableSort: {
          attendance: { field: "attendanceDate", dir: "desc" },
          assignments: { field: "dueAt", dir: "desc" },
          performance: { field: "generatedAt", dir: "desc" },
          grades: { field: "dueAt", dir: "desc" },
          reports: { field: "generatedAt", dir: "desc" },
          newsReview: { field: "weekSet", dir: "desc" },
          assignmentEngagement: { field: "assignment", dir: "asc" },
        },
        tableSearch: {
          attendance: "",
          assignments: "",
          performance: "",
          grades: "",
          reports: "",
        },
        tableFilters: {
          attendance: { level: "", studentRefId: "", dateFrom: "", dateTo: "", weekNumber: "" },
          assignments: { level: "", studentRefId: "", dateFrom: "", dateTo: "", weekNumber: "" },
          performance: { level: "", studentRefId: "", dateFrom: "", dateTo: "", weekNumber: "" },
          grades: { level: "", studentRefId: "", dateFrom: "", dateTo: "", weekNumber: "" },
          reports: { level: "", studentRefId: "", dateFrom: "", dateTo: "", weekNumber: "" },
        },
        tableShowArchived: {
          attendance: false,
          assignments: false,
          performance: false,
          grades: false,
          reports: false,
        },
        tableArchiveIndex: {
          attendance: {},
          assignments: {},
          performance: {},
          grades: {},
          reports: {},
        },
        performanceHoldIndex: {},
        performanceEngagement: {
          loaded: false,
          loading: false,
          generatedAt: "",
          days: [],
          rows: [],
          selectedDayKey: "",
          selectedReportId: "",
          search: "",
          sortField: "classDate",
          sortDir: "desc",
          role: "",
          level: "",
          delivery: "",
        },
        assignmentEngagement: {
          loaded: false,
          loading: false,
          rows: [],
          search: "",
          reminderKind: "",
          status: "",
          selectedDayKey: "",
        },
        visibleTableRows: {
          attendance: [],
          assignments: [],
          performance: [],
          grades: [],
          reports: [],
        },
        eaglesIdSearchHistory: [],
        topSearchOptionMap: {},
        topStudentScope: {
          query: "",
          level: "",
          school: "",
          includeUnenrolled: false,
        },
        topSearch: {
          expanded: false,
          sortField: "fullName",
          sortDir: "asc",
          collapsedRows: 12,
          rows: [],
        },
        gradeChart: {
          period: "custom",
          groupBy: "class",
          quarter: "",
          schoolYear: "",
          customFrom: "",
          customTo: "",
        },
        gradeChartLaneSnapshotByKey: {},
        gradeChartModalOpen: false,
        gradeChartModalLaneKey: "",
      };
      let activeButtonTooltip = null;
      let buttonTooltipRoot = null;
      let buttonTooltipBound = false;
      const BUTTON_TOOLTIP_SELECTOR = 'button:not([data-button-tooltip="off"])';

      function tooltipTextForButton(buttonEl) {
        if (!(buttonEl instanceof HTMLButtonElement)) return "";
        const explicit = normalizeText(buttonEl.dataset.buttonTooltip || "");
        if (explicit && explicit.toLowerCase() !== "auto") return explicit;
        const storedTitle = normalizeText(buttonEl.dataset.buttonTooltipTitle || "");
        if (storedTitle) return storedTitle;
        const ariaLabel = normalizeText(buttonEl.getAttribute("aria-label") || "");
        if (ariaLabel) return ariaLabel;
        return normalizeText(buttonEl.textContent || "");
      }

      function ensureButtonTooltipRoot() {
        if (buttonTooltipRoot instanceof HTMLElement) return buttonTooltipRoot;
        const tooltipEl = document.createElement("div");
        tooltipEl.className = "admin-button-tooltip hidden";
        tooltipEl.setAttribute("role", "tooltip");
        (document.querySelector("main#appMain") || document.body).appendChild(tooltipEl);
        buttonTooltipRoot = tooltipEl;
        return tooltipEl;
      }

      function suppressNativeButtonTitles(scope = document) {
        if (!(scope instanceof Document || scope instanceof HTMLElement)) return;
        Array.from(scope.querySelectorAll(BUTTON_TOOLTIP_SELECTOR)).forEach((buttonEl) => {
          if (!(buttonEl instanceof HTMLButtonElement)) return;
          if (buttonEl.dataset.buttonTooltipTitle) return;
          const nativeTitle = normalizeText(buttonEl.getAttribute("title") || "");
          if (!nativeTitle) return;
          buttonEl.dataset.buttonTooltipTitle = nativeTitle;
          buttonEl.removeAttribute("title");
        });
      }

      function hideButtonTooltip() {
        activeButtonTooltip = null;
        const tooltipEl = ensureButtonTooltipRoot();
        tooltipEl.classList.add("hidden");
        tooltipEl.textContent = "";
      }

      function positionButtonTooltip(buttonEl) {
        const tooltipEl = ensureButtonTooltipRoot();
        if (!(buttonEl instanceof HTMLButtonElement) || tooltipEl.classList.contains("hidden"))
          return;
        const rect = buttonEl.getBoundingClientRect();
        const margin = 12;
        const gap = 10;
        const tooltipWidth = tooltipEl.offsetWidth;
        const tooltipHeight = tooltipEl.offsetHeight;
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        const fitsAbove = rect.top >= tooltipHeight + gap + margin;
        const top = fitsAbove
          ? rect.top - tooltipHeight - gap
          : Math.min(viewportHeight - tooltipHeight - margin, rect.bottom + gap);
        const centeredLeft = rect.left + rect.width / 2 - tooltipWidth / 2;
        const left = Math.max(
          margin,
          Math.min(centeredLeft, viewportWidth - tooltipWidth - margin),
        );
        tooltipEl.style.left = `${Math.round(left + window.scrollX)}px`;
        tooltipEl.style.top = `${Math.round(top + window.scrollY)}px`;
      }

      function showButtonTooltip(buttonEl) {
        if (!(buttonEl instanceof HTMLButtonElement)) return;
        const text = tooltipTextForButton(buttonEl);
        if (!text) {
          hideButtonTooltip();
          return;
        }
        activeButtonTooltip = buttonEl;
        const tooltipEl = ensureButtonTooltipRoot();
        tooltipEl.textContent = text;
        tooltipEl.classList.remove("hidden");
        positionButtonTooltip(buttonEl);
      }

      function initializeButtonTooltips() {
        suppressNativeButtonTitles();
        ensureButtonTooltipRoot();
        if (buttonTooltipBound) return;
        document.addEventListener("mouseover", (event) => {
          const target = event.target;
          if (!(target instanceof Element)) return;
          const buttonEl = target.closest(BUTTON_TOOLTIP_SELECTOR);
          if (!(buttonEl instanceof HTMLButtonElement)) {
            if (activeButtonTooltip && !target.closest(".admin-button-tooltip")) {
              hideButtonTooltip();
            }
            return;
          }
          showButtonTooltip(buttonEl);
        });
        document.addEventListener("mouseout", (event) => {
          const target = event.target;
          if (!(target instanceof Element)) return;
          if (!target.closest(BUTTON_TOOLTIP_SELECTOR)) return;
          const related = event.relatedTarget;
          if (related instanceof Element && related.closest(BUTTON_TOOLTIP_SELECTOR)) return;
          hideButtonTooltip();
        });
        document.addEventListener("focusin", (event) => {
          const target = event.target;
          if (!(target instanceof Element)) return;
          const buttonEl = target.closest(BUTTON_TOOLTIP_SELECTOR);
          if (buttonEl instanceof HTMLButtonElement) showButtonTooltip(buttonEl);
        });
        document.addEventListener("focusout", (event) => {
          const target = event.target;
          if (!(target instanceof Element)) return;
          if (!target.closest(BUTTON_TOOLTIP_SELECTOR)) return;
          hideButtonTooltip();
        });
        window.addEventListener("scroll", () => {
          if (activeButtonTooltip) positionButtonTooltip(activeButtonTooltip);
        });
        window.addEventListener("resize", () => {
          if (activeButtonTooltip) positionButtonTooltip(activeButtonTooltip);
        });
        buttonTooltipBound = true;
      }

      const SHARED_BUTTON_COPY_BY_ID = new Map([
        ["overviewNewsQueueOpenBtn", ["Open Reports", "Open Reports"]],
        ["attendanceLandingSaveAllBtn", ["Save All", "Save Level Attendance"]],
        ["assignmentAddItemBtn", ["Add Item", "Add Assignment Item"]],
        ["assignmentLoadTitlesBtn", ["Refresh Titles", "Refresh Exercise Titles"]],
        ["assignmentSendBtn", ["Send Email", "Send Assignment Email"]],
        ["newsReviewApproveQueueBtn", ["Approve All", "Approve All in Queue"]],
        ["pt_actionInsertBtn", ["Insert Field", "Insert to Focused Field"]],
        ["pt_saveBtn", ["Save Report", "Save Performance Report"]],
        ["pt_queueSendBtn", ["Submit", "Save for Admin Review"]],
        ["openTabulatorGradesBtn", ["Open Grades", "Open Tabulator Grades Admin"]],
        ["reportGenerateBtn", ["Generate PDF", "Generate from Grade Records"]],
        ["reportCardBtn", ["Report PDF", "Download PDF Report Card"]],
        ["profileFieldLayoutApplyBtn", ["Apply Layout", "Apply Layout Changes"]],
        ["profileFieldLayoutResetBtn", ["Reset Layout", "Reset Layout to Default"]],
        ["attendancePrintPdfBtn", ["Print PDF", "Print Attendance PDF"]],
        ["assignmentPrintPdfBtn", ["Print PDF", "Print Assignment PDF"]],
        ["performancePrintPdfBtn", ["Print PDF", "Print Performance PDF"]],
        ["gradePrintPdfBtn", ["Print PDF", "Print Grade PDF"]],
        ["reportPrintPdfBtn", ["Print PDF", "Print Report PDF"]],
        ["settingsResetBtn", ["Reset Settings", "Reset Settings"]],
        ["schoolSetupAutoFillBtn", ["Auto Fill", "Auto Fill School Setup"]],
        ["schoolSetupResetBtn", ["Reset Setup", "Reset School Setup"]],
        ["parentQueueCloseBtn", ["Close", "Close the parent report review window"]],
        ["parentQueueHoldBtn", ["Hold", "Hold this parent report for later review"]],
        ["parentQueueEditBtn", ["Edit", "Edit this parent report before sending"]],
        ["parentQueueRequeueBtn", ["Requeue", "Return this report to the sending queue"]],
        ["parentQueueSendAllBtn", ["Send All", "Send all queued parent reports"]],
        ["newsReviewViewerCloseBtn", ["Close", "Close the news report review window"]],
        ["newsReviewViewerEditBtn", ["Edit", "Edit the selected news report"]],
        ["newsReviewViewerSaveBtn", ["Save", "Save changes to the selected news report"]],
        ["newsReviewViewerApproveBtn", ["Approve", "Approve the selected news report"]],
        ["newsReviewViewerRevisionBtn", ["Request Revision", "Send the selected news report back for revision"]],
        ["gradeChartModalCloseBtn", ["Close", "Close the grade chart window"]],
      ]);

      function applySharedButtonCopy(button) {
        if (!(button instanceof HTMLButtonElement)) return;
        const id = normalizeText(button.id || "");
        const copy = SHARED_BUTTON_COPY_BY_ID.get(id);
        if (!copy) return;
        const [faceText, tooltipText] = copy;
        const tooltip = normalizeText(tooltipText || faceText);
        const face = normalizeText(faceText);
        if (!button.dataset.sharedButtonCopyApplied) {
          if (face) button.textContent = face;
          button.dataset.sharedButtonCopyApplied = "1";
        }
        if (tooltip) {
          button.dataset.buttonTooltipTitle = tooltip;
          button.setAttribute("aria-label", tooltip);
        }
      }

      function decorateSharedButtons(scope = document) {
        if (!(scope instanceof Document || scope instanceof HTMLElement)) return;
        const buttons = scope.querySelectorAll("button");
        buttons.forEach((button) => {
          if (!(button instanceof HTMLButtonElement)) return;
          applySharedButtonCopy(button);
          if (button.classList.contains("portal-button")) return;
          if (button.dataset.newsReviewOpenWeekSet !== undefined) {
            button.classList.add("portal-button", "portal-button-info", "portal-button-open-week-set");
            return;
          }
          if (button.classList.contains("queue-row-btn")) {
            button.classList.add("portal-button", "portal-button-info");
            return;
          }
          if (
            button.classList.contains("pt-score-legend-btn") ||
            button.classList.contains("bar-detail-action-btn")
          ) {
            button.classList.add("portal-button", "portal-button-info");
            return;
          }
          if (button.classList.contains("grade-chart-period-btn")) {
            button.classList.add("portal-button", "portal-button-alt");
          }
        });
      }

      const ROW_OPTIONS_VIEWPORT_MARGIN = 12;
      const ROW_OPTIONS_MENU_GAP = 4;
      const ROW_OPTIONS_FLOATING_Z_INDEX = 1200;
      let rowOptionsLayoutFrame = 0;

      function clearRowOptionsDropdownLayout(menuEl) {
        if (!(menuEl instanceof HTMLDetailsElement)) return;
        const dropdownEl = menuEl.querySelector(".row-options-dropdown");
        if (!(dropdownEl instanceof HTMLElement)) return;
        dropdownEl.style.position = "";
        dropdownEl.style.inset = "";
        dropdownEl.style.top = "";
        dropdownEl.style.left = "";
        dropdownEl.style.right = "";
        dropdownEl.style.bottom = "";
        dropdownEl.style.maxWidth = "";
        dropdownEl.style.maxHeight = "";
        dropdownEl.style.overflowY = "";
        dropdownEl.style.zIndex = "";
        dropdownEl.style.transformOrigin = "";
      }

      function positionRowOptionsDropdown(menuEl) {
        if (!(menuEl instanceof HTMLDetailsElement) || !menuEl.open) {
          clearRowOptionsDropdownLayout(menuEl);
          return;
        }

        const triggerEl = menuEl.querySelector(".row-options-trigger");
        const dropdownEl = menuEl.querySelector(".row-options-dropdown");
        if (!(triggerEl instanceof HTMLElement) || !(dropdownEl instanceof HTMLElement)) return;

        const triggerRect = triggerEl.getBoundingClientRect();
        const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
        const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;

        dropdownEl.style.position = "fixed";
        dropdownEl.style.inset = "auto";
        dropdownEl.style.zIndex = String(ROW_OPTIONS_FLOATING_Z_INDEX);
        dropdownEl.style.maxWidth = `${Math.max(0, viewportWidth - ROW_OPTIONS_VIEWPORT_MARGIN * 2)}px`;
        dropdownEl.style.maxHeight = `${Math.max(0, viewportHeight - ROW_OPTIONS_VIEWPORT_MARGIN * 2)}px`;
        dropdownEl.style.overflowY = "auto";
        dropdownEl.style.transformOrigin = "top right";

        const dropdownRect = dropdownEl.getBoundingClientRect();
        const dropdownWidth = Math.min(
          dropdownRect.width || dropdownEl.offsetWidth || 116,
          Math.max(0, viewportWidth - ROW_OPTIONS_VIEWPORT_MARGIN * 2),
        );
        const dropdownHeight = Math.min(
          dropdownRect.height || dropdownEl.offsetHeight || 0,
          Math.max(0, viewportHeight - ROW_OPTIONS_VIEWPORT_MARGIN * 2),
        );
        const spaceAbove = Math.max(0, triggerRect.top - ROW_OPTIONS_VIEWPORT_MARGIN);
        const spaceBelow = Math.max(0, viewportHeight - triggerRect.bottom - ROW_OPTIONS_VIEWPORT_MARGIN);
        const openAbove = dropdownHeight > spaceBelow && spaceAbove > spaceBelow;
        const preferredTop = openAbove ?
          triggerRect.top - dropdownHeight - ROW_OPTIONS_MENU_GAP
          : triggerRect.bottom + ROW_OPTIONS_MENU_GAP;
        const top = Math.max(
          ROW_OPTIONS_VIEWPORT_MARGIN,
          Math.min(preferredTop, viewportHeight - dropdownHeight - ROW_OPTIONS_VIEWPORT_MARGIN),
        );
        const preferredLeft = triggerRect.right - dropdownWidth;
        const left = Math.max(
          ROW_OPTIONS_VIEWPORT_MARGIN,
          Math.min(preferredLeft, viewportWidth - dropdownWidth - ROW_OPTIONS_VIEWPORT_MARGIN),
        );

        dropdownEl.style.top = `${Math.round(top)}px`;
        dropdownEl.style.left = `${Math.round(left)}px`;
        dropdownEl.style.right = "auto";
        dropdownEl.style.bottom = "auto";
        dropdownEl.style.transformOrigin = openAbove ? "bottom right" : "top right";
      }

      function scheduleRowOptionsDropdownLayout() {
        if (rowOptionsLayoutFrame) return;
        rowOptionsLayoutFrame = window.requestAnimationFrame(() => {
          rowOptionsLayoutFrame = 0;
          document.querySelectorAll(".row-options-menu").forEach((menuEl) => {
            positionRowOptionsDropdown(menuEl);
          });
        });
      }

      function wireRowOptionsDropdownLayout() {
        if (window.__SIS_ADMIN_ROW_OPTIONS_LAYOUT_BOUND__) return;
        document.addEventListener(
          "toggle",
          (event) => {
            const target = event.target;
            if (!(target instanceof HTMLDetailsElement)) return;
            if (!target.classList.contains("row-options-menu")) return;
            if (target.open) {
              scheduleRowOptionsDropdownLayout();
            } else {
              clearRowOptionsDropdownLayout(target);
            }
          },
          true,
        );
        document.addEventListener("scroll", scheduleRowOptionsDropdownLayout, true);
        window.addEventListener("resize", scheduleRowOptionsDropdownLayout);
        window.__SIS_ADMIN_ROW_OPTIONS_LAYOUT_BOUND__ = true;
      }

      function wireSharedButtonDecoration() {
        if (!hasLiveDom()) return;
        decorateSharedButtons();
        if (window.__SIS_ADMIN_SHARED_BUTTONS_BOUND__) return;
        const observer = new MutationObserver((mutations) => {
          mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
              if (!(node instanceof Element)) return;
              if (node.matches?.("button")) applySharedButtonCopy(node);
              else node.querySelectorAll?.("button").forEach(applySharedButtonCopy);
              if (node.matches?.("button")) decorateSharedButtons(node.parentElement || document);
              else decorateSharedButtons(node);
            });
          });
        });
        observer.observe(document.body, { childList: true, subtree: true });
        window.__SIS_ADMIN_SHARED_BUTTONS_BOUND__ = true;
      }

      const statusEl = document.getElementById("status");
      const authStatusEl = document.getElementById("authStatus");
      const loginBtnEl = document.getElementById("loginBtn");
      function bindById(id, eventName, listener, options) {
        const el = document.getElementById(id);
        if (!el) return null;
        el.addEventListener(eventName, listener, options);
        return el;
      }
      function setAuthBootstrapping(isBooting) {
        document.body?.classList.toggle("admin-auth-booting", Boolean(isBooting));
      }
      const DEFAULT_LEVEL_REMINDER_TEMPLATE = normalizeText(
        document.getElementById("levelReminderTemplate")?.value,
      );
      const STUDENT_NUMBER_START = 100;

      const PROFILE_FORM_STORAGE_KEY = "sis.admin.profileFormLayout.v1";
      const PROFILE_INPUT_TYPES = [
        "text",
        "email",
        "number",
        "textarea",
        "select",
        "checkbox",
        "radio",
        "url",
        "password",
        "file",
        "level-select",
      ];
      const PROFILE_FORM_TABS = [
        { id: "profile", label: "Profile", sequence: 10 },
        { id: "medical", label: "Medical", sequence: 20 },
        { id: "covid", label: "COVID", sequence: 30 },
        { id: "submission", label: "Submission", sequence: 40 },
      ];
      const PROFILE_ARRAY_PROFILE_KEYS = new Set([
        "genderSelections",
        "languagesAtHome",
        "learningDisorders",
        "covidShotHistory",
        "feverMedicineAllowed",
      ]);
      const PROFILE_LOCKED_FIELD_KEYS = new Set(["eaglesId"]);
      const PROFILE_INFO_PRIMARY_ID_SUFFIXES = new Set([
        "studentPhoto",
        "fullName",
        "englishName",
        "currentGrade",
        "eaglesId",
        "studentNumber",
        "parentsId",
        "schoolName",
        "studentEmail",
        "studentPhone",
        "motherName",
        "motherPhone",
        "motherEmail",
        "fatherName",
        "fatherPhone",
        "fatherEmail",
      ]);
      const PROFILE_FORM_FIELD_ROWS = [
        [
          "studentPhoto",
          "photoUrl",
          "Tải ảnh học sinh lên",
          "Upload student photo",
          "profile",
          "Thông tin của người học",
          "file",
          "Tải ảnh học sinh lên",
          "",
          "photoUrl",
          "",
          12,
        ],
        [
          "fullNameStudent",
          "fullName",
          "Họ tên của người học",
          "Full name of the learner",
          "profile",
          "Thông tin của người học",
          "text",
          "Họ tên",
          "",
          "fullName",
          "",
          8,
        ],
        [
          "englishName",
          "englishName",
          "Tên tiếng Anh",
          "English name",
          "profile",
          "Thông tin của người học",
          "text",
          "Tên tiếng anh nếu bạn có",
          "",
          "englishName",
          "",
          4,
        ],
        [
          "gender",
          "genderSelections",
          "Giới tính",
          "Gender",
          "profile",
          "Thông tin của người học",
          "checkbox",
          "",
          "nam | nữ",
          "genderSelections",
          "",
          6,
        ],
        [
          "memberSince",
          "memberSince",
          "Member since",
          "Member since",
          "profile",
          "Thông tin của người học",
          "text",
          "",
          "",
          "memberSince",
          "",
          3,
        ],
        [
          "studentNumber",
          "studentNumber",
          "Student number",
          "Student number",
          "profile",
          "Thông tin của người học",
          "number",
          "",
          "",
          "",
          "studentNumber",
          3,
        ],
        [
          "eaglesId",
          "eaglesId",
          "Eagles ID",
          "Eagles ID",
          "profile",
          "Thông tin của người học",
          "text",
          "",
          "",
          "",
          "eaglesId",
          3,
        ],
        [
          "password",
          "password",
          "Password",
          "Password",
          "profile",
          "Thông tin của người học",
          "text",
          "",
          "",
          "",
          "",
          3,
        ],
        [
          "parentsId",
          "parentsId",
          "ChaMe ID",
          "Parents id",
          "profile",
          "Thông tin của người học",
          "text",
          "ChaMe ID",
          "",
          "parentsId",
          "",
          4,
        ],
        [
          "studentPhone",
          "studentPhone",
          "Số điện thoại của học sinh",
          "Student phone number",
          "profile",
          "Thông tin của người học",
          "text",
          "",
          "",
          "studentPhone",
          "",
          4,
        ],
        [
          "studentEmail",
          "studentEmail",
          "Email của học sinh",
          "Student email",
          "profile",
          "Thông tin của người học",
          "text",
          "ten@vidu.com",
          "",
          "studentEmail",
          "",
          4,
        ],
        [
          "classLevel",
          "currentGrade",
          "Cấp lớp",
          "Class level",
          "profile",
          "Thông tin của người học",
          "level-select",
          "Chọn cấp lớp",
          "",
          "currentGrade",
          "",
          4,
        ],
        [
          "exercisePoints",
          "exercisePoints",
          "Eagle Points",
          "Eagle Points",
          "profile",
          "Thông tin của người học",
          "number",
          "",
          "",
          "exercisePoints",
          "",
          3,
        ],
        [
          "hobbies",
          "hobbies",
          "Sở thích, thú vui và nhạc cụ",
          "Hobbies, interests and musical instruments",
          "profile",
          "Thông tin của người học",
          "textarea",
          "",
          "",
          "hobbies",
          "",
          12,
        ],
        [
          "dob",
          "dobText",
          "Ngày sinh",
          "Date of birth",
          "profile",
          "Thông tin của người học",
          "text",
          "ví dụ: 17/03/11",
          "",
          "dobText",
          "",
          4,
        ],
        [
          "birthOrder",
          "birthOrder",
          "Thứ tự sinh",
          "Birth order",
          "profile",
          "Thông tin của người học",
          "number",
          "",
          "",
          "birthOrder",
          "",
          4,
        ],
        [
          "numberOfSiblingsMale",
          "siblingBrothers",
          "Người học có bao nhiêu anh em?",
          "How many brothers does the learner have?",
          "profile",
          "Thông tin của người học",
          "number",
          "Số anh em",
          "",
          "siblingBrothers",
          "",
          4,
        ],
        [
          "numberOfSiblingsFemale",
          "siblingSisters",
          "Người học có bao nhiêu chị em?",
          "How many sisters does the learner have?",
          "profile",
          "Thông tin của người học",
          "number",
          "Số chị em",
          "",
          "siblingSisters",
          "",
          4,
        ],
        [
          "ethnicity",
          "ethnicity",
          "Dân tộc",
          "Nation",
          "profile",
          "Thông tin của người học",
          "select",
          "",
          "Người Việt Nam | Viet Hoa (Chinese-Vietnamese) | Người dân tộc (Hmông, Tày, Khmer, v.v.) | Người Thái | Người Campuchia | Người Lào | Người Hàn Quốc | Người Nhật | Người Trung Quốc",
          "ethnicity",
          "",
          4,
        ],
        [
          "languagesHome",
          "languagesAtHome",
          "Các ngôn ngữ được nói ở nhà",
          "Languages spoken at home",
          "profile",
          "Thông tin của người học",
          "select",
          "Chọn ngôn ngữ tại nhà",
          "Tiếng Việt | Tiếng Anh | Tiếng Phổ thông Trung Quốc | Tiếng Quảng Đông | Tiếng dân tộc (H'mông, Tày, Khmer, v.v.) | Tiếng Thái | Tiếng Campuchia | Tiếng Lào | Tiếng Hàn Quốc | Tiếng Nhật | Tiếng Khác...",
          "languagesAtHome",
          "",
          12,
        ],
        [
          "describeOtherLanguage",
          "otherLanguage",
          "Vui lòng cho biết ngôn ngữ khác",
          "Please indicate other languages",
          "profile",
          "Thông tin của người học",
          "text",
          "ngôn ngữ khác",
          "",
          "otherLanguage",
          "",
          4,
        ],
        [
          "studentSchool",
          "schoolName",
          "Đang học ở trường",
          "Studying at school",
          "profile",
          "Thông tin của người học",
          "text",
          "",
          "",
          "schoolName",
          "",
          4,
        ],
        [
          "studentCurrentGrade",
          "currentSchoolGrade",
          "Hiện tại đang học lớp",
          "Currently taking class",
          "profile",
          "Thông tin của người học",
          "text",
          "Số lớp của học sinh",
          "",
          "currentSchoolGrade",
          "",
          4,
        ],
        [
          "fullNameMother",
          "motherName",
          "Họ tên của mẹ hoặc học sinh trưởng thành",
          "Full name of mother or adult student",
          "profile",
          "Liên hệ của mẹ hoặc học sinh trưởng thành",
          "text",
          "Họ tên của mẹ hoặc học sinh trưởng thành",
          "",
          "motherName",
          "",
          4,
        ],
        [
          "emailMa",
          "motherEmail",
          "Email của mẹ hoặc học sinh trưởng thành",
          "Email from mother or adult student",
          "profile",
          "Liên hệ của mẹ hoặc học sinh trưởng thành",
          "text",
          "ten@vidu.com",
          "",
          "motherEmail",
          "",
          4,
        ],
        [
          "maIsHomeworkProctor",
          "maIsHomeworkProctor",
          "Người mẹ hoặc học sinh trưởng thành sẽ có trách nhiệm đảm bảo rằng bài tập về nhà được hoàn thành đúng hạn và chính xác và các bài học được ôn tập 2-3 lần mỗi tuần.",
          "It will be the responsibility of the mother or adult student to ensure that homework is completed on time and accurately and that lessons are reviewed 2-3 times per week.",
          "profile",
          "Liên hệ của mẹ hoặc học sinh trưởng thành",
          "checkbox",
          "",
          "có | không",
          "maIsHomeworkProctor",
          "",
          6,
        ],
        [
          "mothersPhone",
          "motherPhone",
          "Số điện thoại của mẹ hoặc học sinh trưởng thành",
          "Phone number of parent or adult student",
          "profile",
          "Liên hệ của mẹ hoặc học sinh trưởng thành",
          "text",
          "",
          "",
          "motherPhone",
          "",
          4,
        ],
        [
          "emergencyContactMother",
          "motherEmergencyContact",
          "Khi khẩn cấp, sẽ gọi mẹ trước *",
          "In an emergency, I will call my mother first *",
          "profile",
          "Liên hệ của mẹ hoặc học sinh trưởng thành",
          "checkbox",
          "",
          "Có | Không",
          "motherEmergencyContact",
          "",
          6,
        ],
        [
          "zaloImIdMother",
          "motherMessenger",
          "Số Zalo hoặc cách khác để nhắn tin nhanh cho mẹ hoặc học sinh trưởng thành",
          "Zalo number or another way to quickly text your mother or adult student",
          "profile",
          "Liên hệ của mẹ hoặc học sinh trưởng thành",
          "text",
          "Số Zalo hoặc cách khác để nhắn tin nhanh",
          "",
          "motherMessenger",
          "",
          4,
        ],
        [
          "fullNameFather",
          "fatherName",
          "Họ tên của ba",
          "Dad's full name",
          "profile",
          "Liên hệ của ba",
          "text",
          "",
          "",
          "fatherName",
          "",
          4,
        ],
        [
          "emailBa",
          "fatherEmail",
          "Email của ba",
          "Dad's email",
          "profile",
          "Liên hệ của ba",
          "text",
          "ten@vidu.com",
          "",
          "fatherEmail",
          "",
          4,
        ],
        [
          "baIsHomeworkProctor",
          "baIsHomeworkProctor",
          "Ba sẽ có trách nhiệm đảm bảo hoàn thành bài tập về nhà và việc học ở n",
          "Dad will be responsible for ensuring homework and schoolwork is completed",
          "profile",
          "Liên hệ của ba",
          "radio",
          "",
          "có | không",
          "baIsHomeworkProctor",
          "",
          6,
        ],
        [
          "fathersPhone",
          "fatherPhone",
          "Số điện thoại của ba",
          "Dad's phone number",
          "profile",
          "Liên hệ của ba",
          "text",
          "",
          "",
          "fatherPhone",
          "",
          4,
        ],
        [
          "emergencyContactFather",
          "fatherEmergencyContact",
          "Khi khẩn cấp, sẽ gọi ba trước",
          "In an emergency, I will call you first",
          "profile",
          "Liên hệ của ba",
          "radio",
          "",
          "có | không",
          "fatherEmergencyContact",
          "",
          6,
        ],
        [
          "zaloImIdBa",
          "fatherMessenger",
          "Số Zalo hoặc cách khác để nhắn tin nhanh cho ba",
          "Zalo number or another way to quickly text dad",
          "profile",
          "Liên hệ của ba",
          "text",
          "Số Zalo hoặc cách khác để nhắn tin nhanh",
          "",
          "fatherMessenger",
          "",
          4,
        ],
        [
          "streetAddress",
          "streetAddress",
          "Số nhà và tên đường",
          "House number and street name",
          "profile",
          "Địa chỉ",
          "text",
          "",
          "",
          "streetAddress",
          "",
          4,
        ],
        [
          "newAddress",
          "newAddress",
          "Địa chỉ mới",
          "New style address replacement of 2026",
          "profile",
          "Địa chỉ",
          "text",
          "",
          "",
          "newAddress",
          "",
          4,
        ],
        [
          "wardDistrict",
          "wardDistrict",
          "Phường và Quận",
          "Ward and District",
          "profile",
          "Địa chỉ",
          "text",
          "",
          "",
          "wardDistrict",
          "",
          4,
        ],
        [
          "city",
          "city",
          "Thành phố",
          "City",
          "profile",
          "Địa chỉ",
          "text",
          "",
          "",
          "city",
          "",
          4,
        ],
        [
          "postCode",
          "postCode",
          "Mã bưu điện",
          "Post code",
          "profile",
          "Địa chỉ",
          "text",
          "Mã bưu điện",
          "",
          "postCode",
          "",
          4,
        ],
        [
          "wearGlasses",
          "hasGlasses",
          "Người học có dùng kính cận không?",
          "Does the learner use glasses?",
          "medical",
          "Thị giác",
          "radio",
          "",
          "có | không",
          "hasGlasses",
          "",
          6,
        ],
        [
          "lastEyeExam",
          "hadEyeExam",
          "Người học đã bao giờ đi khám mắt chưa?",
          "Has the learner ever had an eye examination?",
          "medical",
          "Thị giác",
          "radio",
          "",
          "có | không",
          "hadEyeExam",
          "",
          6,
        ],
        [
          "dateLastEyeExam",
          "lastEyeExamDateText",
          "Ngày khám mắt gần đây nhất",
          "Date of most recent eye exam",
          "medical",
          "Thuốc uống",
          "text",
          "ví dụ: 17/03/11",
          "",
          "lastEyeExamDateText",
          "",
          4,
        ],
        [
          "prescriptionMedicine",
          "prescriptionMedicine",
          "Người học có uống thuốc theo đơn không?",
          "Does the learner take medication as prescribed?",
          "medical",
          "Thuốc uống",
          "radio",
          "",
          "có | không",
          "prescriptionMedicine",
          "",
          6,
        ],
        [
          "explainListRxMeds",
          "prescriptionDetails",
          "Vui lòng nêu tên thuốc theo toa và lý do dùng",
          "Please state the name of the prescription medication and reason for taking it",
          "medical",
          "Những khó khăn khi học",
          "textarea",
          "Thông tin này được bảo mật",
          "",
          "prescriptionDetails",
          "",
          12,
        ],
        [
          "learningDisorders",
          "learningDisorders",
          "Học sinh có bất kỳ rối loạn hoặc triệu chứng nào sau đây không?",
          "Does the student have any of the following disorders or symptoms?",
          "medical",
          "Những khó khăn khi học",
          "checkbox",
          "",
          "Rối loạn lời nói | Nhược thị (hội chứng mắt lười) | Rối loạn tăng động giảm chú ý | Hội chứng Asperger / phổ tự kỷ | Rối loạn học tập (vui lòng giải thích bên dưới) | Chứng khó đọc | Rối loạn hành vi (vui lòng giải thích bên dưới) | Không có | Khác (vui lòng giải thích bên dưới)",
          "learningDisorders",
          "",
          12,
        ],
        [
          "explainLdBd",
          "learningDisorderDetails",
          "Giải thích tất cả rối loạn học tập, rối loạn hành vi, hoặc những thách thức khác đối với việc học",
          "Explains any learning disorders, behavioral disorders, or other challenges to learning",
          "medical",
          "Dị ứng",
          "textarea",
          "Thông tin này được bảo mật",
          "",
          "learningDisorderDetails",
          "",
          12,
        ],
        [
          "drugAllergiesList",
          "drugAllergies",
          "Liệt kê tất cả các trường hợp dị ứng với các loại thuốc:",
          "List all allergies to drugs:",
          "medical",
          "Dị ứng",
          "textarea",
          'vui lòng nhập "không," nếu không có dị ứng',
          "",
          "drugAllergies",
          "",
          12,
        ],
        [
          "foodEnvironmentalAllergiesList",
          "foodEnvironmentalAllergies",
          "Liệt kê các dị ứng do thực phẩm và môi trường",
          "List food and environmental allergies",
          "medical",
          "Tiêm chủng",
          "textarea",
          'vui lòng nhập "không," nếu không có',
          "",
          "foodEnvironmentalAllergies",
          "",
          12,
        ],
        [
          "childhoodVaccinesUtd",
          "vaccinesChildhoodUpToDate",
          "Tất cả các loại vắc xin bắt buộc dành cho trẻ nhỏ có phải là loại mới nhất không?",
          "Are all required childhood vaccines up to date?",
          "medical",
          "Tiêm chủng",
          "radio",
          "",
          "Có | Không",
          "vaccinesChildhoodUpToDate",
          "",
          6,
        ],
        [
          "childhoodVaccineRecord",
          "childhoodVaccineRecord",
          "Tải lên bản sao hồ sơ vắc xin khi còn nhỏ",
          "Upload a copy of your childhood vaccine records",
          "medical",
          "Tiêm chủng",
          "file",
          "",
          "",
          "",
          "",
          12,
        ],
        [
          "covid19PositiveOrHadIt",
          "hadCovidPositive",
          "Người học đã từng có COVID-19 chưa hoặc kết quả dương tính với COVID-19?",
          "Has the learner ever had COVID-19 or tested positive for COVID-19?",
          "covid",
          "COVID",
          "radio",
          "",
          "có | không",
          "hadCovidPositive",
          "",
          6,
        ],
        [
          "dateNegativeAfterInfections",
          "covidNegativeDateText",
          "Bắt buộc: Nếu bạn đã xét nghiệm dương tính với COVID, thì vui lòng cung cấp ngày bạn xét nghiệm âm tính với COVID bên dưới. **Nếu bạn trả lời",
          "Required: If you tested positive for COVID, please provide the date you tested negative for COVID below. **If you reply",
          "covid",
          "COVID",
          "text",
          "ví dụ: 17/03/11 - ngày bạn xét nghiệm âm tính sau khi bị nhiễm bệnh",
          "",
          "covidNegativeDateText",
          "",
          4,
        ],
        [
          "hadCovidShotAlready",
          "covidShotAlready",
          "Người học đã được chủng ngừa COVID-19 chưa?",
          "Has the learner been vaccinated against COVID-19?",
          "covid",
          "COVID",
          "radio",
          "",
          "có | không",
          "covidShotAlready",
          "",
          6,
        ],
        [
          "covid19VaccineUtd",
          "covidVaccinesUpToDate",
          "Vắc xin COVID-19 có được cập nhật không?",
          "Are COVID-19 vaccines up to date?",
          "covid",
          "COVID",
          "radio",
          "",
          "có | không",
          "covidVaccinesUpToDate",
          "",
          6,
        ],
        [
          "mostRecentCovidShot",
          "mostRecentCovidShotDate",
          "Ngày tiêm phòng COVID gần đây nhất của học sinh",
          "Student's most recent COVID vaccination date",
          "covid",
          "COVID",
          "text",
          "ví dụ: 2023-03-17",
          "",
          "mostRecentCovidShotDate",
          "",
          4,
        ],
        [
          "comments",
          "extraComments",
          "Bình luận",
          "Comment",
          "covid",
          "COVID",
          "textarea",
          "",
          "",
          "extraComments",
          "",
          12,
        ],
        [
          "checkEachCovidInjectionStudentHasHad",
          "covidShotHistory",
          "Vui lòng cho biết các loại chủng ngừa COVID-19 mà người học đã được nhận:",
          "Please indicate which COVID-19 vaccinations the learner has received:",
          "covid",
          "COVID",
          "checkbox",
          "",
          "Chưa | Tiêm chủng COVID lần đầu tiên | Tiêm chủng COVID thứ hai | Tiêm chủng COVID thứ ba | Tiêm chủng COVID thứ tư | Tiêm chủng COVID thứ năm | Tiêm chủng COVID thứ sáu",
          "covidShotHistory",
          "",
          12,
        ],
        [
          "covidVaccineRecords",
          "covidVaccineRecords",
          "Hồ sơ tiêm phòng COVID",
          "COVID vaccination records",
          "covid",
          "COVID",
          "file",
          "",
          "",
          "",
          "",
          12,
        ],
        [
          "feverMedicine",
          "feverMedicineAllowed",
          "Trẻ có thể dùng một liều thuốc uống bằng một trong các loại thuốc sau đây khi cần thiết để hạ sốt.",
          "Children can take an oral dose of one of the following medications as needed to reduce fever.",
          "medical",
          "Chăm sóc trong giờ học (nếu người học là trẻ em)",
          "checkbox",
          "",
          "Axit salicylic trẻ em | Ibuprofen trẻ em | Paracetamol trẻ em | Không cho | Tôi 18 tuổi trở lên",
          "feverMedicineAllowed",
          "",
          12,
        ],
        [
          "dauTrangDuoc",
          "whiteOilAllowed",
          "Trẻ có thể dùng dầu trắng nếu muốn",
          "Children can use white oil if they want",
          "medical",
          "Chăm sóc trong giờ học (nếu người học là trẻ em)",
          "radio",
          "",
          "Cho | Không cho | Tôi 18 tuổi trở lên",
          "whiteOilAllowed",
          "",
          6,
        ],
        [
          "signature",
          "signatureFullName",
          "Tôi xác nhận rằng tất cả thông tin tôi đã cung cấp; là sự thật được chứng minh; theo hiểu biết tốt nhất của tôi; chịu sự trừng phạt của pháp luật; tại nước Cộng hòa xã hội chủ nghĩa Việt Nam.",
          "I confirm that all information I have provided; is a proven fact; to the best of my knowledge; subject to legal punishment; in the Socialist Republic of Vietnam.",
          "submission",
          "Chăm sóc trong giờ học (nếu người học là trẻ em)",
          "text",
          "họ tên của người điền đơn",
          "",
          "signatureFullName",
          "",
          8,
        ],
        [
          "emailFormSig",
          "signatureEmail",
          "email của bạn",
          "your email",
          "submission",
          "Chăm sóc trong giờ học (nếu người học là trẻ em)",
          "email",
          "ten@vidu.com",
          "",
          "signatureEmail",
          "",
          4,
        ],
      ];

      function profileTabLabel(tabId = "") {
        const tab = PROFILE_FORM_TABS.find(
          (entry) => normalizeLower(entry.id) === normalizeLower(tabId),
        );
        return normalizeText(tab?.label);
      }

      function normalizeProfileInputType(inputType = "text", fieldKey = "") {
        let normalized = normalizeLower(inputType);
        if (!PROFILE_INPUT_TYPES.includes(normalized)) normalized = "text";
        if (normalizeLower(fieldKey) === "classlevel") return "level-select";
        if (normalizeLower(fieldKey) === "eaglesid" && normalized === "number")
          return "text";
        if (normalizeLower(fieldKey) === "password" && normalized === "text")
          return "password";
        return normalized;
      }

      function toProfileFieldIdSuffix(value = "") {
        const text = normalizeText(value).replace(/[^a-zA-Z0-9_-]+/g, "-");
        if (!text) return "field";
        if (/^[a-z][A-Za-z0-9]*$/.test(text)) return text;
        if (/^[A-Z][A-Za-z0-9]*$/.test(text))
          return text.charAt(0).toLowerCase() + text.slice(1);
        const parts = text.split(/[-_]+/).filter(Boolean);
        const first = normalizeLower(parts[0]);
        const rest = parts
          .slice(1)
          .map((part) => normalizeLower(part))
          .map((part) => part.charAt(0).toUpperCase() + part.slice(1));
        return `${first}${rest.join("")}`;
      }

      function parseProfileOptions(value = "") {
        if (Array.isArray(value))
          return value.map((entry) => normalizeText(entry)).filter(Boolean);
        return normalizeText(value)
          .split("|")
          .map((entry) => normalizeText(entry))
          .filter(Boolean);
      }

      function nextProfileFieldSequence(fields = []) {
        const max = fields.reduce((highest, field) => {
          const sequence = Number(field?.sequence || 0);
          return sequence > highest ? sequence : highest;
        }, 0);
        return max + 10;
      }

      function normalizeProfileFieldDefinition(field = {}, fallbackSequence = 10) {
        const key = toProfileFieldIdSuffix(field.key || field.idSuffix);
        const idSuffix = toProfileFieldIdSuffix(field.idSuffix || key);
        const tabIdRaw = normalizeLower(field.tabId);
        const tabId =
          PROFILE_FORM_TABS.some((tab) => tab.id === tabIdRaw) ? tabIdRaw : "profile";
        const sequence =
          Number.isFinite(Number(field.sequence)) ?
            Number(field.sequence)
          : fallbackSequence;
        const widthRaw = Number(field.width);
        const width =
          Number.isFinite(widthRaw) ?
            Math.max(1, Math.min(12, Math.round(widthRaw)))
          : 4;
        const profileKey = normalizeText(field.profileKey);
        const topLevelKey = normalizeText(field.topLevelKey);
        const inputType = normalizeProfileInputType(field.inputType, key);
        return {
          key,
          idSuffix,
          labelVi: normalizeText(field.labelVi),
          labelEn: normalizeText(field.labelEn),
          tabId,
          sectionVi: normalizeText(field.sectionVi),
          sectionEn: normalizeText(field.sectionEn),
          inputType,
          placeholderVi: normalizeText(field.placeholderVi),
          placeholderEn: normalizeText(field.placeholderEn),
          options: parseProfileOptions(field.options),
          profileKey: profileKey || "",
          topLevelKey: topLevelKey || "",
          sequence,
          width,
          enabled: field.enabled !== false,
          locked: PROFILE_LOCKED_FIELD_KEYS.has(key) || Boolean(field.locked),
          isCustom: Boolean(field.isCustom),
        };
      }

      function buildDefaultProfileFormConfig() {
        const fields = PROFILE_FORM_FIELD_ROWS.map((row, index) =>
          normalizeProfileFieldDefinition(
            {
              key: row[0],
              idSuffix: row[1],
              labelVi: row[2],
              labelEn: row[3],
              tabId: row[4],
              sectionVi: row[5],
              inputType: row[6],
              placeholderVi: row[7],
              options: parseProfileOptions(row[8]),
              profileKey: row[9],
              topLevelKey: row[10],
              width: row[11],
              sequence: (index + 1) * 10,
            },
            (index + 1) * 10,
          ),
        );
        return {
          tabs: PROFILE_FORM_TABS.map((tab) => ({ ...tab })),
          fields,
        };
      }

      function normalizeProfileFormConfig(source = null) {
        const defaultConfig = buildDefaultProfileFormConfig();
        if (!source || typeof source !== "object") return defaultConfig;
        const rawFields = Array.isArray(source.fields) ? source.fields : [];
        const seenByKey = new Set();
        const fields = [];
        rawFields.forEach((rawField, index) => {
          const normalized = normalizeProfileFieldDefinition(
            rawField,
            (index + 1) * 10,
          );
          if (!normalized.key || seenByKey.has(normalized.key)) return;
          seenByKey.add(normalized.key);
          fields.push(normalized);
        });
        if (!fields.length) return defaultConfig;
        const byDefaultKey = new Map(
          defaultConfig.fields.map((field) => [field.key, field]),
        );
        fields.forEach((field) => {
          const fallback = byDefaultKey.get(field.key);
          if (!fallback) return;
          if (fallback.locked) field.locked = true;
        });
        return {
          tabs: PROFILE_FORM_TABS.map((tab) => ({ ...tab })),
          fields,
        };
      }

      function loadProfileFormConfigFromStorage() {
        const stored = window.SIS_PORTAL_PREFERENCES?.get(PROFILE_FORM_STORAGE_KEY, null);
        return stored && typeof stored === "object" ? normalizeProfileFormConfig(stored) : buildDefaultProfileFormConfig();
      }

      function persistProfileFormConfig(config = null) {
        const normalized = normalizeProfileFormConfig(config);
        state.profileFormConfig = normalized;
        state.uiSettings.profileFormConfig = normalized;
        void window.SIS_PORTAL_PREFERENCES?.save(PROFILE_FORM_STORAGE_KEY, normalized);
        void persistUiSettingsToServer(state.uiSettings);
        return normalized;
      }

      function sortedProfileFields(includeDisabled = false) {
        const fields =
          Array.isArray(state.profileFormConfig?.fields) ?
            state.profileFormConfig.fields
          : [];
        return fields
          .filter((field) => includeDisabled || field.enabled !== false)
          .slice()
          .sort((left, right) => {
            const leftSeq = Number(left?.sequence || 0);
            const rightSeq = Number(right?.sequence || 0);
            if (leftSeq === rightSeq)
              return normalizeText(left?.key).localeCompare(normalizeText(right?.key));
            return leftSeq - rightSeq;
          });
      }

      function profileFieldByIdSuffix(idSuffix = "") {
        const target = normalizeText(idSuffix);
        if (!target) return null;
        const fields =
          Array.isArray(state.profileFormConfig?.fields) ?
            state.profileFormConfig.fields
          : [];
        return (
          fields.find((field) => normalizeText(field?.idSuffix) === target) || null
        );
      }

      function profileFieldByKey(key = "") {
        const target = normalizeText(key);
        if (!target) return null;
        const fields =
          Array.isArray(state.profileFormConfig?.fields) ?
            state.profileFormConfig.fields
          : [];
        return fields.find((field) => normalizeText(field?.key) === target) || null;
      }

      function profileFieldIdList(includeDisabled = true) {
        return sortedProfileFields(includeDisabled)
          .map((field) => field.idSuffix)
          .filter(Boolean);
      }

      function setStatus(message, isError = false) {
        const text = normalizeText(message);
        window.SIS_ACTION_FEEDBACK?.status(text, isError);
        if (statusEl) {
          statusEl.style.color = isError ? "#bd2f2f" : "var(--portal-status-muted-text)";
          statusEl.textContent = text;
        }
        const authPanelEl = document.getElementById("authPanel");
        const authVisible = Boolean(
          authPanelEl && !authPanelEl.classList.contains("hidden"),
        );
        if (authStatusEl) {
          authStatusEl.style.color = isError ? "#bd2f2f" : "var(--portal-status-muted-text)";
          authStatusEl.textContent = authVisible ? text : "";
        }
      }

      function setLoginPending(isPending) {
        if (!loginBtnEl) return;
        loginBtnEl.disabled = Boolean(isPending);
        loginBtnEl.textContent = isPending ? "Logging in..." : "Login";
      }

      function hasLiveDom() {
        return (
          typeof document !== "undefined" &&
          Boolean(document && typeof document.getElementById === "function")
        );
      }

      function installButtonPressFeedback() {
        if (!hasLiveDom()) return;
        const pressClass = "btn-press-feedback";
        const timerByButton = new WeakMap();

        const triggerPressFeedback = (button) => {
          if (!(button instanceof HTMLButtonElement) || button.disabled) return;
          const existingTimer = timerByButton.get(button);
          if (existingTimer) window.clearTimeout(existingTimer);
          button.classList.remove(pressClass);
          void button.offsetWidth;
          button.classList.add(pressClass);
          const nextTimer = window.setTimeout(() => {
            button.classList.remove(pressClass);
            timerByButton.delete(button);
          }, 320);
          timerByButton.set(button, nextTimer);
        };

        document.addEventListener(
          "pointerdown",
          (event) => {
            const target = event.target;
            if (!(target instanceof Element)) return;
            const button = target.closest("button:not(.portal-button)");
            if (!(button instanceof HTMLButtonElement)) return;
            triggerPressFeedback(button);
          },
          true,
        );

        document.addEventListener(
          "keydown",
          (event) => {
            if (event.key !== "Enter" && event.key !== " ") return;
            const target = event.target;
            if (!(target instanceof Element)) return;
            const button = target.closest("button:not(.portal-button)");
            if (!(button instanceof HTMLButtonElement)) return;
            triggerPressFeedback(button);
          },
          true,
        );
      }

      function clearLoginForm() {
        const userEl = document.getElementById("loginUser");
        const passEl = document.getElementById("loginPass");
        if (userEl) userEl.value = "";
        if (passEl) passEl.value = "";
        if (authStatusEl) authStatusEl.textContent = "";
      }

      function nowClockStamp() {
        return `${new Intl.DateTimeFormat("vi-VN", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: false,
          timeZone: FIXED_TIME_ZONE,
        }).format(new Date())} +07`;
      }

      function monotonicNowMs() {
        if (
          typeof window !== "undefined" &&
          window.performance &&
          typeof window.performance.now === "function"
        ) {
          return window.performance.now();
        }
        return Date.now();
      }

      function healthFlagToState(value) {
        if (value === true) return "ok";
        if (value === false) return "error";
        return "pending";
      }

      function normalizeSystemState(value) {
        const stateText = normalizeLower(value);
        if (
          stateText === "ok" ||
          stateText === "warn" ||
          stateText === "error" ||
          stateText === "pending"
        ) {
          return stateText;
        }
        return "pending";
      }

      function buildSystemHealthChecks() {
        const checks = [];
        const runtimeHealth =
          state.runtimeHealth && typeof state.runtimeHealth === "object" ?
            state.runtimeHealth
          : {};
        const runtime =
          (
            runtimeHealth.studentAdminRuntime &&
            typeof runtimeHealth.studentAdminRuntime === "object"
          ) ?
            runtimeHealth.studentAdminRuntime
          : {};
        const selfHeal =
          (
            runtimeHealth.runtimeSelfHeal &&
            typeof runtimeHealth.runtimeSelfHeal === "object"
          ) ?
            runtimeHealth.runtimeSelfHeal
          : {};
        const filterCache =
          runtime.filterCache && typeof runtime.filterCache === "object" ?
            runtime.filterCache
          : {};
        const sisConfigMirrorHealth =
          runtimeHealth.sisConfigMirrorHealth &&
          typeof runtimeHealth.sisConfigMirrorHealth === "object" ?
            runtimeHealth.sisConfigMirrorHealth
          : null;

        const hubState = normalizeLower(state.hubConnection?.state);
        const hubSystemState =
          hubState === "connected" ? "ok"
          : hubState === "disconnected" ? "error"
          : "pending";
        checks.push({
          key: "hub",
          label: "Hub API",
          state: hubSystemState,
          detail: state.hubConnection?.detail || "health probe pending",
        });

        let runtimeState = "pending";
        let runtimeDetail = "admin runtime config unavailable";
        if (normalizeText(runtime.pagePath) || normalizeText(runtime.apiPrefix)) {
          runtimeState = "ok";
          runtimeDetail = `page=${runtime.pagePath || "n/a"} | api=${runtime.apiPrefix || "n/a"}`;
        } else if (hubSystemState === "ok") {
          runtimeState = "warn";
        }
        checks.push({
          key: "adminRuntime",
          label: "Admin Runtime",
          state: runtimeState,
          detail: runtimeDetail,
        });

        const sessionDriver = normalizeLower(runtime.sessionDriver);
        let sessionState = "pending";
        if (sessionDriver === "redis") sessionState = "ok";
        else if (sessionDriver === "memory") sessionState = "warn";
        else if (sessionDriver) sessionState = "warn";
        checks.push({
          key: "sessionStore",
          label: "Session Store",
          state: sessionState,
          detail: `driver=${runtime.sessionDriver || "n/a"} | ttl=${Number(runtime.sessionTtlSeconds || 0)}s`,
        });

        const filterBackend = normalizeLower(filterCache.backend);
        let filterState = "pending";
        const hasFilterError = Boolean(normalizeText(filterCache.lastError));
        if (filterBackend === "redis") {
          // Keep redis cache visible as non-fatal even if an old transient error string exists.
          filterState = hasFilterError ? "warn" : "ok";
        } else if (filterBackend === "memory") {
          filterState = hasFilterError ? "error" : "warn";
        } else if (filterBackend) {
          filterState = hasFilterError ? "error" : "warn";
        } else if (hasFilterError) {
          filterState = "error";
        }
        checks.push({
          key: "filterCache",
          label: "Filter Cache",
          state: filterState,
          detail: `backend=${filterCache.backend || "n/a"} | hit/miss=${Number(filterCache.hits || 0)}/${Number(filterCache.misses || 0)}`,
        });

        let selfHealState = "pending";
        let selfHealDetail = "self-heal status unavailable";
        if (Object.keys(selfHeal).length) {
          if (selfHeal.enabled === false) {
            selfHealState = "warn";
            selfHealDetail = "configured=no | state=disabled | syncs=0";
          } else {
            const result = normalizeLower(selfHeal.lastResult);
            if (result === "error") selfHealState = "error";
            else if (result === "synced" || result === "in-sync") selfHealState = "ok";
            else if (result === "pending") selfHealState = "pending";
            else selfHealState = "warn";
            const stateLabel =
              result === "in-sync" ? "already latest"
              : result === "synced" ? "synced"
              : "out of date";
            selfHealDetail = `configured=yes | state=${stateLabel} | syncs=${Number(selfHeal.syncCount || 0)}`;
          }
        }
        const selfHealAction =
          selfHealDetail.includes("configured=no") || selfHealDetail.includes("state=out of date") ?
            {
              label: "Open Self-Heal",
              page: "overview",
              targetId: "overviewRuntimeRestartBtn",
            }
          : null;
        checks.push({
          key: "selfHeal",
          label: "Self-Heal",
          state: selfHealState,
          detail: selfHealDetail,
          action: selfHealAction,
        });

        const smtpState = healthFlagToState(runtimeHealth.lastVerifyOk);
        checks.push({
          key: "smtp",
          label: "SMTP Verify",
          state: smtpState === "pending" ? "warn" : smtpState,
          detail:
            runtimeHealth.lastVerifyAt ?
              `last verify ${runtimeHealth.lastVerifyAt}`
            : "no verify recorded yet",
        });

        const pipelineFlags = [
          runtimeHealth.lastStoreOk,
          runtimeHealth.lastIntakeStoreOk,
          runtimeHealth.lastSendOk,
        ];
        const decidedFlags = pipelineFlags.filter(
          (flag) => flag === true || flag === false,
        );
        let pipelineState = "pending";
        if (decidedFlags.includes(false)) pipelineState = "error";
        else if (decidedFlags.length && decidedFlags.every((flag) => flag === true))
          pipelineState = "ok";
        else if (decidedFlags.length) pipelineState = "warn";
        const describeFlag = (value) =>
          value === true ? "ok"
          : value === false ? "error"
          : "n/a";
        checks.push({
          key: "pipeline",
          label: "Recent Pipeline",
          state: pipelineState,
          detail: `exercise=${describeFlag(runtimeHealth.lastStoreOk)} | intake=${describeFlag(runtimeHealth.lastIntakeStoreOk)} | send=${describeFlag(runtimeHealth.lastSendOk)}`,
        });

        if (sisConfigMirrorHealth) {
          const filePresent = Boolean(sisConfigMirrorHealth.file?.present);
          const dbPresent = Boolean(sisConfigMirrorHealth.db?.present);
          const synced = Boolean(sisConfigMirrorHealth.synced);
          let mirrorState = "pending";
          if (filePresent && dbPresent) mirrorState = synced ? "ok" : "error";
          else if (filePresent || dbPresent) mirrorState = "warn";
          else mirrorState = "error";
          checks.push({
            key: "sisConfigMirror",
            label: "System Config",
            state: mirrorState,
            detail: sisConfigMirrorHealth.detail || "",
            mirror: {
              filePresent,
              dbPresent,
              synced,
              fileLabel: "JSON",
              dbLabel: "DB",
              syncLabel: synced ? "IN SYNC" : "OUT OF SYNC",
            },
          });
        }

        return checks;
      }

      function renderSystemHealthPanel() {
        if (!hasLiveDom()) return;
        const sectionEl = document.getElementById("systemHealthSection");
        const shellEl = document.getElementById("systemHealthShell");
        const loadingEl = document.getElementById("systemHealthLoading");
        const rowsEl = document.getElementById("systemHealthRows");
        const summaryEl = document.getElementById("systemHealthSummary");
        if (!sectionEl || !shellEl || !loadingEl || !rowsEl || !summaryEl) return;

        const serviceReady = !canManageUsers() || Boolean(state.systemHealthReady.service);
        const ready = Boolean(state.systemHealthReady.hub) && serviceReady;
        sectionEl.setAttribute("aria-busy", ready ? "false" : "true");
        shellEl.classList.toggle("is-loading", !ready);
        loadingEl.classList.toggle("hidden", ready);
        if (!ready) {
          summaryEl.textContent = "Waiting for hub and service status.";
          return;
        }

        const checks = buildSystemHealthChecks();
        const counts = { ok: 0, warn: 0, error: 0, pending: 0 };
        const gridEl = rowsEl.parentElement;
        const buildCheckCard = (check) => {
          const stateClass = normalizeSystemState(check.state);
          const mirror = check.mirror && typeof check.mirror === "object" ? check.mirror : null;

          const item = document.createElement("div");
          item.className = `system-health-item ${stateClass}`;
          if (mirror) item.classList.add("system-health-mirror-card");
          item.setAttribute("data-system-key", normalizeText(check.key));

          const labelEl = document.createElement("div");
          labelEl.className = "system-health-label";
          if (!mirror) {
            const ledEl = document.createElement("span");
            ledEl.className = `led ${stateClass}`;
            ledEl.setAttribute("aria-hidden", "true");
            labelEl.appendChild(ledEl);
          }
          const textEl = document.createElement("span");
          textEl.textContent = normalizeText(check.label) || "System";
          labelEl.appendChild(textEl);

          const detailEl = document.createElement("div");
          detailEl.className = "system-health-detail";
          if (mirror) {
            detailEl.classList.add("system-health-mirror");

            const rail = document.createElement("div");
            rail.className = "system-health-mirror-rail";

            const buildToken = (label, ledState, tokenState) => {
              const token = document.createElement("span");
              token.className = "system-health-mirror-token";
              if (tokenState) token.classList.add(tokenState);
              token.title = label;
              token.setAttribute("aria-label", label);

              const led = document.createElement("span");
              led.className = `led ${ledState}`;
              led.setAttribute("aria-hidden", "true");
              token.appendChild(led);

              const text = document.createElement("span");
              text.className = "system-health-mirror-token-label";
              text.textContent = label;
              token.appendChild(text);
              return token;
            };

            const buildOp = (symbol) => {
              const op = document.createElement("span");
              op.className = "system-health-mirror-op";
              op.textContent = symbol;
              return op;
            };

            rail.appendChild(buildToken(mirror.fileLabel || "JSON", mirror.filePresent ? "ok" : "missing", mirror.filePresent ? "present" : "missing"));
            rail.appendChild(buildOp("+"));
            rail.appendChild(buildToken(mirror.dbLabel || "DB", mirror.dbPresent ? "ok" : "missing", mirror.dbPresent ? "present" : "missing"));
            rail.appendChild(buildOp("="));
            rail.appendChild(buildToken(
              "SYNC",
              mirror.synced ? "ok" : "error",
              mirror.synced ? "synced" : "out-of-sync",
            ));

            detailEl.appendChild(rail);

            if (check.key === "sisConfigMirror" && canManageUsers()) {
              const actions = document.createElement("div");
              actions.className = "system-health-mirror-actions";
              actions.style.display = "flex";
              actions.style.flexWrap = "wrap";
              actions.style.gap = "8px";
              actions.style.marginTop = "6px";

              const repairBtn = document.createElement("button");
              repairBtn.type = "button";
              repairBtn.className = "portal-button portal-button-compact portal-button-primary system-health-action-btn";
              repairBtn.setAttribute("data-system-sync-action", "sis-config-repair");
              repairBtn.setAttribute("aria-label", "Run SIS config sync cron job");
              const repairLabel = document.createElement("span");
              repairLabel.className = "portal-button__label";
              repairLabel.textContent =
                state.sisConfigRepairBusy ? "Syncing..." : "Sync";
              repairBtn.replaceChildren(repairLabel);
              repairBtn.disabled = Boolean(state.sisConfigRepairBusy);
              repairBtn.addEventListener("click", () => {
                runSisConfigRepair().catch(handleError);
              });
              actions.appendChild(repairBtn);
              detailEl.appendChild(actions);
            }
          } else {
            detailEl.textContent = normalizeText(check.detail) || "n/a";
          }

          item.appendChild(labelEl);
          item.appendChild(detailEl);

          const action =
            check.action && typeof check.action === "object" ? check.action : null;
          if (action?.label && action?.targetId) {
            const actionBtn = document.createElement("button");
            actionBtn.type = "button";
            actionBtn.className = "portal-button portal-button-primary system-health-action-btn";
            const actionLabel = document.createElement("span");
            actionLabel.className = "portal-button__label";
            actionLabel.textContent = action.label;
            actionBtn.replaceChildren(actionLabel);
            actionBtn.setAttribute("data-system-action", normalizeText(check.key));
            actionBtn.setAttribute("data-system-action-target", normalizeText(action.targetId));
            actionBtn.addEventListener("click", () => {
              if (action.page) setActivePage(action.page);
              window.setTimeout(() => {
                const target = document.getElementById(action.targetId);
                target?.scrollIntoView({ behavior: "smooth", block: "center" });
                target?.focus?.();
              }, 0);
            });
            item.appendChild(actionBtn);
          }

          return item;
        };

        rowsEl.innerHTML = "";

        checks.forEach((check) => {
          const stateClass = normalizeSystemState(check.state);
          counts[stateClass] = Number(counts[stateClass] || 0) + 1;
          rowsEl.appendChild(buildCheckCard(check));
        });

        summaryEl.textContent = `OK ${counts.ok} | Warning ${counts.warn} | Error ${counts.error} | Pending ${counts.pending}`;
      }

      function renderHubConnectionStatus() {
        if (!hasLiveDom()) return;
        const badge = document.getElementById("hubStatusBadge");
        const meta = document.getElementById("hubStatusMeta");
        const card = document.getElementById("hubConnectionCard");
        const led = document.getElementById("hubStatusLed");
        if (!badge || !meta || !card || !led) {
          renderSystemHealthPanel();
          return;
        }
        const status = state.hubConnection || {};
        const statusClass = normalizeText(status.state) || "pending";
        const cardState =
          statusClass === "connected" ? "ok"
          : statusClass === "disconnected" ? "error"
          : "pending";
        card.className = `system-health-item system-health-hub-card ${cardState}`;
        led.className = `led ${cardState}`;
        badge.className = `hub-pill ${statusClass}`;
        if (statusClass === "connected") badge.textContent = "Connected";
        else if (statusClass === "disconnected") badge.textContent = "Disconnected";
        else badge.textContent = "Checking...";
        const parts = [
          status.endpoint ? `endpoint=${status.endpoint}` : "",
          Number.isFinite(status.latencyMs) ?
            `latency=${Math.round(status.latencyMs)}ms`
          : "",
          status.checkedAt ? `checked=${status.checkedAt}` : "",
          status.detail ? `detail=${status.detail}` : "",
        ].filter(Boolean);
        meta.textContent = parts.join(" | ") || "waiting for first probe...";
        state.systemHealthReady.hub = Boolean(state.hubConnection.checkedAt);
        renderSystemHealthPanel();
      }

      function serviceControlCardState(statusValue) {
        const status = normalizeLower(statusValue);
        if (status === "active") return "ok";
        if (status === "inactive" || status === "disabled") return "warn";
        if (status === "unknown" || status === "unsupported" || status === "failed")
          return "error";
        return "pending";
      }

      function renderOverviewRuntimeRestartButton() {
        if (!hasLiveDom()) return;
        const restartBtn = document.getElementById("overviewRuntimeRestartBtn");
        if (!restartBtn) return;

        const runtimeSelfHeal =
          state.runtimeHealth?.runtimeSelfHeal &&
          typeof state.runtimeHealth.runtimeSelfHeal === "object" ?
            state.runtimeHealth.runtimeSelfHeal
          : null;
        const selfHealResult = normalizeLower(runtimeSelfHeal?.lastResult);
        const showButton =
          canManageUsers() &&
          runtimeSelfHeal &&
          runtimeSelfHeal.enabled !== false &&
          selfHealResult !== "in-sync" &&
          selfHealResult !== "synced";
        restartBtn.classList.toggle("hidden", !showButton);
        if (!showButton) return;

        restartBtn.disabled =
          state.serviceControl.busy ||
          state.serviceControl.enabled === false ||
          state.serviceControl.available === false;
        restartBtn.textContent =
          state.serviceControl.busy ? "Healing..." : "Self-Heal Runtime";
      }

      function setServiceControlFromPayload(payload = {}) {
        const command =
          payload?.command && typeof payload.command === "object" ?
            payload.command
          : {};
        const restart =
          payload?.restart && typeof payload.restart === "object" ?
            payload.restart
          : {};
        const rawDetail = normalizeText(payload?.detail || payload?.message);
        const commandDetail = firstNonEmpty(
          normalizeText(restart.stderr),
          normalizeText(command.stderr),
          normalizeText(restart.stdout),
          normalizeText(command.stdout),
        );
        const detail = rawDetail || commandDetail || "Service status unavailable.";

        state.serviceControl = {
          available: payload?.available !== false,
          enabled: payload?.enabled !== false,
          service:
            normalizeText(payload?.service) ||
            state.serviceControl.service ||
            "exercise-mailer.service",
          status: normalizeLower(payload?.status) || "pending",
          detail,
          checkedAt: normalizeText(payload?.checkedAt) || nowClockStamp(),
          busy: false,
        };
      }

      function renderServiceControlCard() {
        if (!hasLiveDom()) return;
        const card = document.getElementById("exerciseMailerServiceCard");
        const led = document.getElementById("exerciseMailerServiceLed");
        const meta = document.getElementById("exerciseMailerServiceMeta");
        const restartBtn = document.getElementById("exerciseMailerRestartBtn");
        const refreshBtn = document.getElementById("exerciseMailerServiceRefreshBtn");
        if (!card || !led || !meta || !restartBtn || !refreshBtn) return;

        const showCard = canManageUsers();
        card.classList.toggle("hidden", !showCard);
        if (!showCard) return;

        const nextState = serviceControlCardState(state.serviceControl.status);
        card.className = `system-health-item system-health-service-card ${nextState}`;
        led.className = `led ${nextState}`;
        state.systemHealthReady.service = Boolean(state.serviceControl.checkedAt);
        renderOverviewRuntimeRestartButton();

        const detailParts = [
          `service=${normalizeText(state.serviceControl.service) || "exercise-mailer.service"}`,
          `status=${normalizeText(state.serviceControl.status || "pending").toUpperCase()}`,
          state.serviceControl.checkedAt ?
            `checked=${state.serviceControl.checkedAt}`
          : "",
          normalizeText(state.serviceControl.detail),
        ].filter(Boolean);
        meta.textContent = detailParts.join(" | ") || "Service status unavailable.";

        const disableActions =
          state.serviceControl.busy ||
          state.serviceControl.enabled === false ||
          state.serviceControl.available === false;
        restartBtn.disabled = disableActions;
        refreshBtn.disabled = state.serviceControl.busy;
        restartBtn.textContent =
          state.serviceControl.busy ? "Restarting..." : "Restart";
        renderSystemHealthPanel();
      }

      async function runSisConfigRepair() {
        if (!canManageUsers())
          throw new Error("Only admin can run the SIS config sync cron job.");
        state.sisConfigRepairBusy = true;
        renderSystemHealthPanel();
        try {
          const result = await api(ADMIN_SIS_CONFIG_REPAIR_PATH, {
            method: "POST",
          });
          if (result?.mirrorHealth && state.runtimeHealth && typeof state.runtimeHealth === "object") {
            state.runtimeHealth.sisConfigMirrorHealth = result.mirrorHealth;
          }
          if (result?.ok) {
            const updatedAt = normalizeText(result?.snapshot?.updatedAt);
            setStatus(
              updatedAt ?
                `SIS config sync cron completed at ${updatedAt}.`
              : "SIS config sync cron completed.",
            );
          } else {
            setStatus("SIS config sync cron failed.", true);
          }
        } finally {
          state.sisConfigRepairBusy = false;
          renderSystemHealthPanel();
          await loadRuntimeHealthSnapshotFromAdminApi().catch(() => false);
        }
      }

      async function loadServiceControlStatus({ notify = false, paint = true } = {}) {
        if (!canManageUsers()) {
          if (paint) renderServiceControlCard();
          return;
        }
        let payload = null;
        try {
          payload = await api(ADMIN_SERVICE_CONTROL_PATH);
        } catch (error) {
          if (error && (error.status === 401 || error.status === 403 || error.status === 404)) {
            state.serviceControl = {
              available: false,
              enabled: false,
              service: "exercise-mailer.service",
              status: error.status === 403 ? "forbidden" : error.status === 401 ? "unauthorized" : "unsupported",
              detail:
                error.status === 403 ?
                  "Runtime service-control API is forbidden for this session."
                : error.status === 401 ?
                  "Runtime service-control API requires an authenticated admin session."
                : "Runtime service-control API is unavailable on this server build.",
              checkedAt: nowClockStamp(),
              busy: false,
            };
            renderServiceControlCard();
            if (notify) setStatus(state.serviceControl.detail, true);
            return;
          }
          throw error;
        }
        setServiceControlFromPayload(payload || {});
        renderServiceControlCard();
        if (notify) {
          setStatus(`Service status: ${state.serviceControl.status}.`);
        }
      }

      async function restartServiceControl() {
        if (!canManageUsers())
          throw new Error("Only admin can restart exercise-mailer service.");
        state.serviceControl.busy = true;
        renderServiceControlCard();
        renderOverviewRuntimeRestartButton();
        try {
          const result = await api(ADMIN_SERVICE_CONTROL_PATH, {
            method: "POST",
            body: { action: "restart" },
          });
          setServiceControlFromPayload(result || {});
          if (result?.ok) {
            setStatus(`Restart command completed for ${state.serviceControl.service}.`);
          } else {
            setStatus(state.serviceControl.detail || "Restart failed.", true);
          }
        } finally {
          state.serviceControl.busy = false;
          renderServiceControlCard();
          renderOverviewRuntimeRestartButton();
        }
      }

      async function syncAndRestartServiceControl() {
        if (!canManageUsers())
          throw new Error("Only admin can self-heal exercise-mailer service.");
        state.serviceControl.busy = true;
        renderServiceControlCard();
        renderOverviewRuntimeRestartButton();
        try {
          const result = await api(ADMIN_SERVICE_CONTROL_PATH, {
            method: "POST",
            body: { action: "sync-and-restart" },
          });
          setServiceControlFromPayload(result || {});
          const selfHeal = result?.selfHeal && typeof result.selfHeal === "object" ? result.selfHeal : null;
          const selfHealDetail =
            selfHeal?.alreadyLatest ?
              "Runtime was already latest."
            : selfHeal?.syncedPaths?.length ?
              `Self-healed ${selfHeal.syncedPaths.length} path(s).`
            : "Self-heal check completed.";
          if (result?.ok) {
            setStatus(
              `${selfHealDetail} Restart completed for ${state.serviceControl.service}.`
            );
          } else {
            setStatus(
              result?.detail || state.serviceControl.detail || "Self-heal failed.",
              true,
            );
          }
        } finally {
          state.serviceControl.busy = false;
          renderServiceControlCard();
          renderOverviewRuntimeRestartButton();
        }
      }

      function defaultHubProbeMode() {
        if (isStaticAdminPreviewMode()) return "healthz";
        const host = normalizeLower(window.location.hostname);
        if (!host || host === "localhost" || host === "127.0.0.1" || host === "::1")
          return "healthz";
        return "auth";
      }

      function setHubProbeMode(mode, reason = "") {
        if (mode === "auth") {
          state.hubProbeMode = "auth";
          state.hubProbeFallbackReason = normalizeText(reason);
          return;
        }
        state.hubProbeMode = "healthz";
        state.hubProbeFallbackReason = "";
      }

      function resolveHubProbeConfig() {
        if (state.hubProbeMode === "auth") {
          return {
            mode: "auth",
            path: HUB_AUTH_PROBE_PATH,
            credentials: "include",
          };
        }
        return {
          mode: "healthz",
          path: HUB_HEALTH_PROBE_PATH,
          credentials: "omit",
        };
      }

      async function executeHubProbeRequest(probeConfig, controller) {
        const endpoint = resolveApiUrl(probeConfig.path);
        const response = await fetch(endpoint, {
          method: "GET",
          cache: "no-store",
          credentials: probeConfig.credentials,
          signal: controller?.signal,
        });
        const body = await response.json().catch(() => ({}));
        return { endpoint, response, body };
      }

      async function loadRuntimeHealthSnapshotFromAdminApi(controller, { paint = true } = {}) {
        const now = Date.now();
        if (state.runtimeHealthRequest) return state.runtimeHealthRequest;
        if (state.runtimeHealth && now - state.runtimeHealthFetchedAt < 5000) return true;

        const request = (async () => {
          const endpoint = resolveApiUrl(ADMIN_RUNTIME_HEALTH_PATH);
          const response = await fetch(endpoint, {
            method: "GET",
            cache: "no-store",
            credentials: "include",
            signal: controller?.signal,
          });
          if (!response.ok) return false;
          const body = await response.json().catch(() => null);
          if (!body || typeof body !== "object") return false;
          state.runtimeHealth = body;
          state.runtimeHealthFetchedAt = Date.now();
          renderOverviewRuntimeRestartButton();
          if (paint) renderSystemHealthPanel();
          return true;
        })();
        state.runtimeHealthRequest = request;
        try {
          return await request;
        } finally {
          if (state.runtimeHealthRequest === request) state.runtimeHealthRequest = null;
        }
      }

      async function probeHubConnection({ notify = false, paint = true } = {}) {
        let probeConfig = resolveHubProbeConfig();
        state.hubConnection.endpoint = resolveApiUrl(probeConfig.path);
        if (paint) renderHubConnectionStatus();
        const startedAt = monotonicNowMs();
        const controller =
          typeof AbortController !== "undefined" ? new AbortController() : null;
        const timeout = window.setTimeout(() => controller?.abort(), 5000);
        try {
          let probeResult = await executeHubProbeRequest(probeConfig, controller);
          if (probeConfig.mode === "healthz" && probeResult.response.status === 403) {
            setHubProbeMode("auth", "healthz-403");
            probeConfig = resolveHubProbeConfig();
            probeResult = await executeHubProbeRequest(probeConfig, controller);
          }
          const latencyMs = monotonicNowMs() - startedAt;
          const body =
            probeResult.body && typeof probeResult.body === "object" ?
              probeResult.body
            : {};
          if (probeConfig.mode === "healthz") {
            const hasRuntimeHealthPayload =
              body.runtimeSelfHeal && typeof body.runtimeSelfHeal === "object" ||
              body.studentAdminRuntime && typeof body.studentAdminRuntime === "object";
            if (hasRuntimeHealthPayload) state.runtimeHealth = body;
            renderOverviewRuntimeRestartButton();
            if (paint) renderSystemHealthPanel();
            if (canManageUsers()) {
              await loadRuntimeHealthSnapshotFromAdminApi(controller, { paint }).catch(() => false);
            }
          } else if (probeResult.response.ok) {
            await loadRuntimeHealthSnapshotFromAdminApi(controller, { paint }).catch(() => false);
          }
          const connected =
            probeConfig.mode === "auth" ?
              probeResult.response.ok || probeResult.response.status === 401
            : probeResult.response.ok &&
              (!body?.status || normalizeText(body.status).toLowerCase() === "ok");
          const detail =
            connected ?
              probeConfig.mode === "healthz" ? "healthz ok"
              : probeResult.response.status === 401 ?
                "auth endpoint reachable (login required)"
              : state.hubProbeFallbackReason ? "auth endpoint ok (healthz restricted)"
              : "auth endpoint ok"
            : `http-${probeResult.response.status}`;
          state.hubConnection = {
            state: connected ? "connected" : "disconnected",
            endpoint: probeResult.endpoint,
            checkedAt: nowClockStamp(),
            latencyMs,
            detail,
          };
          if (paint) renderHubConnectionStatus();
          if (notify) {
            setStatus(
              connected ?
                `Hub reachable (${Math.round(latencyMs)}ms).`
              : `Hub probe failed (HTTP ${probeResult.response.status}).`,
              !connected,
            );
          }
        } catch (error) {
          const endpoint = resolveApiUrl(resolveHubProbeConfig().path);
          state.hubConnection = {
            state: "disconnected",
            endpoint,
            checkedAt: nowClockStamp(),
            latencyMs: null,
            detail: normalizeText(error?.name || error?.message) || "network error",
          };
          if (paint) renderHubConnectionStatus();
          if (notify)
            setStatus(`Hub probe failed: ${state.hubConnection.detail}`, true);
        } finally {
          window.clearTimeout(timeout);
        }
      }

      function startHubPolling() {
        if (state.hubPollTimer) {
          window.clearInterval(state.hubPollTimer);
          state.hubPollTimer = null;
        }
        const runProbe = ({ paint = true } = {}) => {
          if (!state.hubPollTimer) return;
          probeHubConnection({ notify: false, paint }).catch(() => {});
        };
        state.hubPollTimer = window.setInterval(runProbe, 30000);
        // The health card is part of the authenticated shell. Start one
        // visible probe immediately; idle-only probing can leave the card in
        // "Checking systems" indefinitely on busy pages.
        void probeHubConnection({ notify: false, paint: true }).catch(() => {});
        const scheduleProbe = () => {
          const runWhenIdle = () => runProbe({ paint: false });
          if (typeof window.requestIdleCallback === "function") {
            window.requestIdleCallback(runWhenIdle, { timeout: 2000 });
          } else {
            window.setTimeout(runWhenIdle, 0);
          }
        };
        if (IS_JSDOM_ENV || document.readyState === "complete") {
          scheduleProbe();
        } else {
          window.addEventListener("load", scheduleProbe, { once: true });
        }
      }

      function stopHubPolling() {
        if (!state.hubPollTimer) return;
        window.clearInterval(state.hubPollTimer);
        state.hubPollTimer = null;
      }

      function normalizeText(value) {
        if (value === undefined || value === null) return "";
        return String(value).trim();
      }

      function sanitizeDomIdPart(value = "") {
        const normalized = normalizeText(value)
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .replace(/đ/g, "d")
          .replace(/Đ/g, "D")
          .replace(/[^a-zA-Z0-9_-]+/g, "_")
          .replace(/_+/g, "_")
          .replace(/^_+|_+$/g, "");
        return normalized || "field";
      }

      function normalizeLower(value) {
        return normalizeText(value).toLowerCase();
      }

      function extractEaglesIdFromText(text = "") {
        const normalized = normalizeText(text);
        if (!normalized) return "";
        const match = normalized.match(/\bEagles ID:\s*([A-Za-z0-9_-]+)/i);
        return normalizeText(match?.[1] || "");
      }

      function engagementDayHeading(date, weekNumber) {
        const dateText = normalizeText(date) || "Unknown day";
        return weekNumber ? `${dateText} | Week ${weekNumber}` : dateText;
      }

      function normalizeSearchComparable(value) {
        const folded = normalizeText(value)
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .replace(/đ/g, "d")
          .replace(/Đ/g, "D")
          .toLowerCase();
        return folded.replace(/[^a-z0-9]+/g, " ").trim();
      }

      function normalizeTextArray(values = []) {
        const list = Array.isArray(values) ? values : [values];
        return list.map((entry) => normalizeText(entry)).filter(Boolean);
      }

      function firstNonEmpty(...values) {
        for (let i = 0; i < values.length; i += 1) {
          const text = normalizeText(values[i]);
          if (text) return text;
        }
        return "";
      }

      function escapeHtml(value) {
        return normalizeText(value)
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#39;");
      }

      const DEFAULT_LEVEL_CATALOG = [
        "Eggs & Chicks",
        "Pre-A1 Starters",
        "A1 Movers",
        "A2 Flyers",
        "A2 KET",
        "B1 PET",
        "B2+ IELTS",
        "C1+ TAYK",
        "Private",
      ];

      const LEVEL_SHORTCUT_LABELS = new Map(
        [
          ["Eggs & Chicks", "Eggs & Chicks"],
          ["Pre-A1 Starters", "Starters"],
          ["A1 Movers", "Movers"],
          ["A2 Flyers", "Flyers"],
          ["A2 KET", "KET"],
          ["B1 PET", "PET"],
          ["B2+ IELTS", "IELTS"],
          ["Private", "Private"],
          ["C1+ TAYK", "TAYK"],
        ].map(([canonical, display]) => [
          normalizeLower(canonical).replace(/[^a-z0-9]/g, ""),
          display,
        ]),
      );

      const LEVEL_CODE_DISPLAY_LABELS = new Map([
        ["g4", "Starters"],
        ["g5", "Movers"],
        ["g6", "Flyers"],
        ["g7", "KET"],
        ["g8", "PET"],
        ["g9", "IELTS"],
        ["g10", "TAYK"],
      ]);

      const LEVEL_FULL_LABELS = new Map([
        ["eggchic", "Eggs & Chicks"],
        ["eggchicks", "Eggs & Chicks"],
        ["prea1starters", "Pre-A1 Starters"],
        ["starters", "Pre-A1 Starters"],
        ["a1movers", "A1 Movers"],
        ["movers", "A1 Movers"],
        ["a2flyers", "A2 Flyers"],
        ["flyers", "A2 Flyers"],
        ["a2ket", "A2 KET"],
        ["ket", "A2 KET"],
        ["b1pet", "B1 PET"],
        ["pet", "B1 PET"],
        ["b2ielts", "B2+ IELTS"],
        ["ielts", "B2+ IELTS"],
        ["private", "Private"],
        ["c1tayk", "C1+ TAYK"],
        ["tayk", "C1+ TAYK"],
        ["g4", "Pre-A1 Starters"],
        ["g5", "A1 Movers"],
        ["g6", "A2 Flyers"],
        ["g7", "A2 KET"],
        ["g8", "B1 PET"],
        ["g9", "B2+ IELTS"],
        ["g10", "C1+ TAYK"],
        ["grade4", "Pre-A1 Starters"],
        ["grade5", "A1 Movers"],
        ["grade6", "A2 Flyers"],
        ["grade7", "A2 KET"],
        ["grade8", "B1 PET"],
        ["grade9", "B2+ IELTS"],
        ["grade10", "C1+ TAYK"],
        ["level4", "Pre-A1 Starters"],
        ["level5", "A1 Movers"],
        ["level6", "A2 Flyers"],
        ["level7", "A2 KET"],
        ["level8", "B1 PET"],
        ["level9", "B2+ IELTS"],
        ["level10", "C1+ TAYK"],
      ]);

      const LEVEL_THEME_LOOKUP = new Map(
        [
          ["Eggs & Chicks", { color: "#e0162b", className: "panelbg-eggs-chicks" }],
          ["Pre-A1 Starters", { color: "#FCAB15", className: "panelbg-starters" }],
          ["A1 Movers", { color: "#913198", className: "panelbg-mov" }],
          ["A2 Flyers", { color: "#b5d570", className: "panelbg-fly" }],
          ["A2 KET", { color: "#038e9f", className: "panelbg-key", textColor: "#001a24" }],
          ["B1 PET", { color: "#cd1637", className: "panelbg-pet" }],
          ["B2+ IELTS", { color: "#b10128", className: "panelbg-ielts" }],
          ["C1+ TAYK", { color: "#980001", className: "panelbg-tayk" }],
          ["Private", { color: "#002786", className: "panelbg-private" }],
        ].map(([canonical, theme]) => [levelNameKey(canonical), theme]),
      );

      const LEVEL_ACCENTED_PAGE_SET = new Set([
        "profile",
        "attendance",
        "assignments",
        "parent-tracking",
        "grades",
        "reports",
        "family",
      ]);

      const LEVEL_ORDER_INDEX = new Map(
        DEFAULT_LEVEL_CATALOG.map((level, index) => [levelNameKey(level), index]),
      );

      function defaultSchoolLetterGradeRanges() {
        return [
          { letter: "A", minPercent: 90, maxPercent: 100 },
          { letter: "B", minPercent: 80, maxPercent: 89.99 },
          { letter: "C", minPercent: 70, maxPercent: 79.99 },
          { letter: "D", minPercent: 60, maxPercent: 69.99 },
          { letter: "F", minPercent: 0, maxPercent: 59.99 },
        ];
      }

      function normalizeSchoolLetterCode(value) {
        const text = normalizeText(value).toUpperCase();
        if (!text) return "";
        if (!/^[A-Z][A-Z0-9+-]{0,3}$/u.test(text)) return "";
        return text;
      }

      function parseSchoolPercentValue(value) {
        const parsed = Number.parseFloat(String(value));
        if (!Number.isFinite(parsed)) return null;
        if (parsed < 0) return 0;
        if (parsed > 100) return 100;
        return parsed;
      }

      function formatSchoolPercentValue(value) {
        if (!Number.isFinite(value)) return "";
        const rounded = Math.round(value * 100) / 100;
        return Number.isInteger(rounded) ? String(rounded) : String(rounded);
      }

      function normalizeSchoolLetterGradeRanges(values = []) {
        const source = Array.isArray(values) ? values : [];
        const mapped = source
          .map((entry) => {
            const letter = normalizeSchoolLetterCode(entry?.letter);
            const minPercent = parseSchoolPercentValue(entry?.minPercent);
            const maxPercent = parseSchoolPercentValue(entry?.maxPercent);
            if (!letter) return null;
            if (!Number.isFinite(minPercent) || !Number.isFinite(maxPercent))
              return null;
            return {
              letter,
              minPercent: Math.min(minPercent, maxPercent),
              maxPercent: Math.max(minPercent, maxPercent),
            };
          })
          .filter((entry) => entry && typeof entry === "object")
          .sort((left, right) => right.minPercent - left.minPercent);
        if (!mapped.length) return defaultSchoolLetterGradeRanges();
        return mapped;
      }

      function parseSchoolLetterGradeRangesText(value = "") {
        const text = normalizeText(value);
        if (!text) return defaultSchoolLetterGradeRanges();
        const lines = text
          .split(/\r?\n/)
          .map((entry) => normalizeText(entry))
          .filter(Boolean);
        if (!lines.length) return defaultSchoolLetterGradeRanges();
        const parsed = lines.map((line) => {
          const match = line.match(
            /^([A-Za-z][A-Za-z0-9+\-]{0,3})\s*:\s*(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)$/u,
          );
          if (!match) {
            throw new Error("Grade mapping format is LETTER:min-max (one per line).");
          }
          return {
            letter: normalizeSchoolLetterCode(match[1]),
            minPercent: parseSchoolPercentValue(match[2]),
            maxPercent: parseSchoolPercentValue(match[3]),
          };
        });
        return normalizeSchoolLetterGradeRanges(parsed);
      }

      function schoolLetterGradeRangesText(value = []) {
        const ranges = normalizeSchoolLetterGradeRanges(value);
        return ranges
          .map(
            (entry) =>
              `${entry.letter}:${formatSchoolPercentValue(entry.minPercent)}-${formatSchoolPercentValue(entry.maxPercent)}`,
          )
          .join("\n");
      }

      function defaultSchoolProfile() {
        return {
          schoolName: "",
          bilingualTextVi: "",
          bilingualTextEn: "",
          motto: "",
          mission: "",
          values: "",
          address: "",
          phone: "",
          publicSite: "",
          privateLessonSite: "",
          webPresence: "",
          socialIm: "",
          businessTaxId: "",
          timeFormat: "",
          timeZone: "",
          googleMapsEmbedIframe: "",
          logoDataUrl: "",
        };
      }

      function defaultNewsReportValidationSettings() {
        return {
          vocabularyMinimumWords: 5,
          defaultSources: {
            cnn: true,
            bbc: true,
          },
          customSources: Array.from({ length: 8 }, () => ({
            enabled: false,
            domain: "",
          })),
        };
      }

      function normalizeNewsSourceDomain(value = "") {
        const token = normalizeLower(value)
          .replace(/^https?:\/\//, "")
          .replace(/\/.*$/, "")
          .replace(/[#?].*$/, "")
          .replace(/^www\./, "")
          .trim();
        if (!token) return "";
        if (!token.includes(".")) return "";
        if (!/^[a-z0-9.-]+$/i.test(token)) return "";
        return token;
      }

      function normalizeNewsReportValidationSettings(source = {}) {
        const fallback = defaultNewsReportValidationSettings();
        const defaults =
          source?.defaultSources && typeof source.defaultSources === "object" ?
            source.defaultSources
          : {};
        const custom =
          Array.isArray(source?.customSources) ? source.customSources : [];
        const customSources = Array.from({ length: 8 }, (_, index) => {
          const row = custom[index] && typeof custom[index] === "object" ?
            custom[index]
          : {};
          return {
            enabled: row.enabled === true,
            domain: normalizeNewsSourceDomain(row.domain),
          };
        });
        return {
          vocabularyMinimumWords: Number.isFinite(Number(source?.vocabularyMinimumWords))
            ? Math.max(1, Math.min(100, Math.trunc(Number(source.vocabularyMinimumWords))))
            : fallback.vocabularyMinimumWords,
          defaultSources: {
            cnn: defaults.cnn !== false,
            bbc: defaults.bbc !== false,
          },
          customSources: customSources.length ? customSources : fallback.customSources,
        };
      }

      const SCHOOL_LOGO_ALLOWED_MIME = [
        "image/svg+xml",
        "image/jpeg",
        "image/png",
        "image/webp",
      ];
      const SCHOOL_LOGO_ALLOWED_EXTENSIONS = [".svg", ".jpg", ".jpeg", ".png", ".webp"];
      const SCHOOL_LOGO_MAX_PX = 650;

      const DEFAULT_UI_SETTINGS = {
        multiSchool: false,
        schoolSetup: {
          startDate: "",
          endDate: "",
          schoolYear: "",
          quarters: [],
        },
        schoolProfile: defaultSchoolProfile(),
        newsReportValidation: defaultNewsReportValidationSettings(),
        levelTileStylesByLevel: {},
        profileFormConfig: null,
        globalAssets: {},
        queueHub: {
          panelOrder: [
            "queued-performance-reports",
            "unmatched-exercise-submissions",
            "current-assignments-pending",
            "overdue-homework",
            "attendance-risk",
            "news-report-review",
            "pending-profile-submissions",
          ],
        },
      };
      const DEFAULT_SIS_CONFIG = {
        runtime: {
          databaseUrl: "",
          redisUrl: "",
          sessionDriver: "auto",
          adminSessionTtlSeconds: 28800,
          parentSessionTtlSeconds: 28800,
          studentSessionTtlSeconds: 86400,
          redisConnectTimeoutMs: 5000,
        },
        newsReports: {
          weeklyMinimumReports: 5,
          autoApproveEnabled: true,
          autoApproveDelayHours: 16,
        },
      };
      const QUEUE_HUB_PANEL_IDS = Object.freeze([
        ...DEFAULT_UI_SETTINGS.queueHub.panelOrder,
      ]);

      const ASSIGNMENT_TEMPLATE_STORAGE_KEY = "sis.admin.assignmentTemplates";
      const PARENT_TRACKING_TEACHER_STORAGE_KEY =
        "sis.admin.parentTracking.teacherNames";
      const PARENT_TRACKING_SUMMARY_STORAGE_KEY =
        "sis.admin.parentTracking.lessonSummaryByLevelDate";
      const PARENT_TRACKING_DIGITAL_SKILL_MIN_LEVEL = "A2 Flyers";
      const DESKTOP_MENU_COLLAPSED_STORAGE_KEY = "sis.admin.menuCollapsed.desktop";
      const TABLE_ARCHIVE_STORAGE_KEY = "sis.admin.tableArchiveIndex.v1";
      const PERFORMANCE_HOLD_STORAGE_KEY =
        "sis.admin.performanceHoldIndex.v1";
      const STUDENT_ID_SEARCH_STORAGE_KEY = "sis.admin.eaglesIdSearchHistory.v1";
      const ATTENDANCE_COLUMN_VISIBILITY_STORAGE_KEY =
        "sis.admin.attendance.columnVisibility.v1";
      const ASSIGNMENT_COLUMN_VISIBILITY_STORAGE_KEY =
        "sis.admin.assignments.columnVisibility.v1";
      const PERFORMANCE_COLUMN_VISIBILITY_STORAGE_KEY =
        "sis.admin.performance.columnVisibility.v1";
      const GRADE_COLUMN_VISIBILITY_STORAGE_KEY =
        "sis.admin.grades.columnVisibility.v1";
      const REPORT_COLUMN_VISIBILITY_STORAGE_KEY =
        "sis.admin.reports.columnVisibility.v1";
      const GLOBAL_TEXT_ZOOM_STORAGE_KEY = "sis.admin.globalTextZoomPercent.v1";
      const TEXT_ZOOM_MIN = 80;
      const TEXT_ZOOM_MAX = 140;
      const TEXT_ZOOM_STEP = 5;
      const TEXT_ZOOM_DEFAULT = 100;
      const TABLE_COLUMN_VISIBILITY_STORAGE_KEYS = Object.freeze({
        attendance: ATTENDANCE_COLUMN_VISIBILITY_STORAGE_KEY,
        assignments: ASSIGNMENT_COLUMN_VISIBILITY_STORAGE_KEY,
        performance: PERFORMANCE_COLUMN_VISIBILITY_STORAGE_KEY,
        grades: GRADE_COLUMN_VISIBILITY_STORAGE_KEY,
        reports: REPORT_COLUMN_VISIBILITY_STORAGE_KEY,
      });
      const TABLE_COLUMN_DEFAULT_VISIBILITY = Object.freeze({
        attendance: Object.freeze({
          studentNumber: true,
          eaglesId: true,
          fullName: false,
          englishName: false,
          attendanceDate: true,
          className: true,
          quarter: true,
          status: true,
          comments: true,
          weekNumber: true,
        }),
        assignments: Object.freeze({
          studentNumber: true,
          assignmentTitle: true,
          level: true,
          student: true,
          assignedAt: true,
          dueAt: true,
          items: true,
          completion: true,
          weekNumber: true,
        }),
        performance: Object.freeze({
          studentNumber: true,
          eaglesId: true,
          fullName: false,
          englishName: false,
          generatedAt: true,
          className: true,
          quarter: true,
          homeworkCompletionRate: true,
          homeworkOnTimeRate: true,
          behaviorScore: true,
          participationScore: true,
          inClassScore: true,
          weekNumber: true,
        }),
        grades: Object.freeze({
          studentNumber: true,
          eaglesId: true,
          fullName: false,
          englishName: false,
          dueAt: true,
          className: true,
          assignmentName: true,
          score: true,
          homeworkCompleted: true,
          behaviorScore: true,
          participationScore: true,
          inClassScore: true,
          weekNumber: true,
        }),
        reports: Object.freeze({
          studentNumber: true,
          eaglesId: true,
          fullName: false,
          englishName: false,
          generatedAt: true,
          className: true,
          quarter: true,
          homeworkCompletionRate: true,
          homeworkOnTimeRate: true,
          behaviorScore: true,
          participationScore: true,
          inClassScore: true,
          weekNumber: true,
        }),
      });
      const STUDENT_ID_SEARCH_PATTERN = /^(?:[a-z]{1,10}\d{3}|\d{1,12})$/;
      const DATA_TABLE_KEYS = [
        "attendance",
        "assignments",
        "performance",
        "grades",
        "reports",
      ];
      const TABLE_KEY_TO_PAGE_SLUG = {
        attendance: "attendance-admin",
        assignments: "assignments-data",
        performance: "performance-data",
        grades: "grades-data",
        reports: "reports",
      };
      const PAGE_SLUG_TO_ADMIN_DATA_TABLE_KEY = {
        "attendance-admin": "attendance",
        "performance-data": "performance",
        "grades-data": "grades",
        reports: "reports",
      };
      const TOP_SCOPE_PAGE_SET = new Set([
        "student-admin",
        "profile",
        "attendance",
        "attendance-admin",
        "assignments",
        "assignments-data",
        "parent-tracking",
        "performance-data",
        "news-reports",
        "grades",
        "grades-data",
        "reports",
        "family",
      ]);
      const TABLE_SEARCH_FILTER_FIELD_IDS = {
        attendance: {
          level: "attendanceDataLevel",
          student: "attendanceDataStudent",
          dateFrom: "attendanceDataDateFrom",
          dateTo: "attendanceDataDateTo",
          weekNumber: "attendanceDataWeek",
        },
        assignments: {
          level: "assignmentDataLevel",
          student: "assignmentDataStudent",
          dateFrom: "assignmentDataDateFrom",
          dateTo: "assignmentDataDateTo",
          weekNumber: "assignmentDataWeek",
        },
        performance: {
          level: "performanceDataLevel",
          student: "performanceDataStudent",
          dateFrom: "performanceDataDateFrom",
          dateTo: "performanceDataDateTo",
          weekNumber: "performanceDataWeek",
        },
        grades: {
          level: "gradeDataLevel",
          student: "gradeDataStudent",
          dateFrom: "gradeDataDateFrom",
          dateTo: "gradeDataDateTo",
          weekNumber: "gradeDataWeek",
        },
        reports: {
          level: "reportDataLevel",
          student: "reportDataStudent",
          dateFrom: "reportDataDateFrom",
          dateTo: "reportDataDateTo",
          weekNumber: "reportDataWeek",
        },
      };
      const ADMIN_DATA_SUMMARY_IDS = {
        attendance: "attendanceDataSummary",
        assignments: "assignmentDataSummary",
        grades: "gradeDataSummary",
        performance: "performanceDataSummary",
        reports: "reportDataSummary",
      };
      const SEARCH_INPUT_DEBOUNCE_MS = 240;
      const FIXED_TIME_ZONE = "Asia/Ho_Chi_Minh";
      const FIXED_TIME_ZONE_OFFSET_MS = 7 * 60 * 60 * 1000;

      function shiftToFixedTimeZone(value) {
        return new Date(value.getTime() + FIXED_TIME_ZONE_OFFSET_MS);
      }

      function shiftFromFixedTimeZone(value) {
        return new Date(value.getTime() - FIXED_TIME_ZONE_OFFSET_MS);
      }

      function localIsoDate(value = new Date()) {
        const date =
          value instanceof Date ? new Date(value.getTime()) : new Date(value);
        if (Number.isNaN(date.valueOf())) return "";
        const shifted = shiftToFixedTimeZone(date);
        const year = String(shifted.getUTCFullYear()).padStart(4, "0");
        const month = String(shifted.getUTCMonth() + 1).padStart(2, "0");
        const day = String(shifted.getUTCDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
      }

      function parseIsoDateLocal(value) {
        const text = normalizeText(value);
        const match = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
        if (!match) return null;
        const year = Number.parseInt(match[1], 10);
        const month = Number.parseInt(match[2], 10);
        const day = Number.parseInt(match[3], 10);
        if (!Number.isFinite(year) || !Number.isFinite(month) || !Number.isFinite(day))
          return null;
        const parsed = new Date(
          Date.UTC(year, month - 1, day, 0, 0, 0, 0) - FIXED_TIME_ZONE_OFFSET_MS,
        );
        if (Number.isNaN(parsed.valueOf())) return null;
        if (localIsoDate(parsed) !== text) return null;
        return parsed;
      }

      function nextSundayIsoDate(value = "") {
        const source = parseIsoDateLocal(value) || new Date();
        if (Number.isNaN(source.valueOf())) return "";
        const date = shiftToFixedTimeZone(source);
        date.setUTCHours(0, 0, 0, 0);
        const weekday = date.getUTCDay();
        let offset = (7 - weekday) % 7;
        if (offset === 0) offset = 7;
        date.setUTCDate(date.getUTCDate() + offset);
        return localIsoDate(shiftFromFixedTimeZone(date));
      }

      function recentWeekendDateRange(referenceValue = new Date()) {
        const source = referenceValue instanceof Date ? referenceValue : new Date(referenceValue);
        if (Number.isNaN(source.valueOf())) return { dateFrom: "", dateTo: "" };
        const anchor = shiftToFixedTimeZone(source);
        anchor.setUTCHours(0, 0, 0, 0);
        const weekendDates = [];
        [6, 0].forEach((targetWeekday) => {
          const delta = (anchor.getUTCDay() - targetWeekday + 7) % 7;
          const current = new Date(anchor.getTime());
          current.setUTCDate(current.getUTCDate() - delta);
          const previous = new Date(current.getTime());
          previous.setUTCDate(previous.getUTCDate() - 7);
          weekendDates.push(localIsoDate(shiftFromFixedTimeZone(current)));
          weekendDates.push(localIsoDate(shiftFromFixedTimeZone(previous)));
        });
        const dates = Array.from(new Set(weekendDates.filter(Boolean))).sort();
        return {
          dateFrom: dates[0] || "",
          dateTo: dates[dates.length - 1] || "",
        };
      }

      function ensureDefaultAttendanceDateRange() {
        const hasFrom = Boolean(tableFilterValue("attendance", "dateFrom"));
        const hasTo = Boolean(tableFilterValue("attendance", "dateTo"));
        if (hasFrom || hasTo) return;
        const { dateFrom, dateTo } = recentWeekendDateRange();
        if (!dateFrom && !dateTo) return;
        setTableFilterValue("attendance", "dateFrom", dateFrom);
        setTableFilterValue("attendance", "dateTo", dateTo);
        syncTableFilterInputValues("attendance");
      }

      function createLocalId(prefix = "id") {
        const head = normalizeLower(prefix).replace(/[^a-z0-9]/g, "") || "id";
        const stamp = Date.now().toString(36);
        const random = Math.random().toString(36).slice(2, 9);
        return `${head}-${stamp}-${random}`;
      }

      function emptyTableArchiveIndex() {
        return {
          attendance: {},
          assignments: {},
          performance: {},
          grades: {},
          reports: {},
        };
      }

      function normalizeTableArchiveIndex(source) {
        const input = source && typeof source === "object" ? source : {};
        const normalized = emptyTableArchiveIndex();
        DATA_TABLE_KEYS.forEach((tableKey) => {
          const section = input[tableKey];
          if (!section || typeof section !== "object") return;
          Object.keys(section).forEach((rawId) => {
            const recordId = normalizeText(rawId);
            if (!recordId) return;
            if (!section[rawId]) return;
            normalized[tableKey][recordId] = true;
          });
        });
        return normalized;
      }

      function loadTableArchiveIndexFromStorage() {
        const stored = window.SIS_PORTAL_PREFERENCES?.get(TABLE_ARCHIVE_STORAGE_KEY, null);
        if (!stored) return emptyTableArchiveIndex();
        try {
          return normalizeTableArchiveIndex(typeof stored === "string" ? JSON.parse(stored) : stored);
        } catch (error) {
          void error;
          return emptyTableArchiveIndex();
        }
      }

      function normalizePerformanceHoldIndex(source) {
        const input = source && typeof source === "object" ? source : {};
        const normalized = {};
        Object.keys(input).forEach((rawId) => {
          const recordId = normalizeText(rawId);
          if (!recordId) return;
          if (!input[rawId]) return;
          normalized[recordId] = true;
        });
        return normalized;
      }

      function loadPerformanceHoldIndexFromStorage() {
        const stored = window.SIS_PORTAL_PREFERENCES?.get(PERFORMANCE_HOLD_STORAGE_KEY, null);
        if (!stored) return {};
        try {
          return normalizePerformanceHoldIndex(typeof stored === "string" ? JSON.parse(stored) : stored);
        } catch (error) {
          void error;
          return {};
        }
      }

      function persistPerformanceHoldIndex(index = state.performanceHoldIndex) {
        const normalized = normalizePerformanceHoldIndex(index);
        state.performanceHoldIndex = normalized;
        void window.SIS_PORTAL_PREFERENCES?.save(PERFORMANCE_HOLD_STORAGE_KEY, normalized);
        return normalized;
      }

      function persistTableArchiveIndex(index = state.tableArchiveIndex) {
        const normalized = normalizeTableArchiveIndex(index);
        state.tableArchiveIndex = normalized;
        void window.SIS_PORTAL_PREFERENCES?.save(TABLE_ARCHIVE_STORAGE_KEY, normalized);
        return normalized;
      }

      function isPerformanceReportHeld(recordId = "") {
        const id = normalizeText(recordId);
        if (!id) return false;
        if (state.performanceHoldIndex?.[id] === true) return true;
        return Boolean(state.tableArchiveIndex?.performance?.[id]);
      }

      function setPerformanceReportHeld(recordId = "", held = true) {
        const id = normalizeText(recordId);
        if (!id) return false;
        const next = normalizePerformanceHoldIndex(state.performanceHoldIndex);
        if (held) next[id] = true;
        else delete next[id];
        persistPerformanceHoldIndex(next);
        if (state.tableArchiveIndex?.performance?.[id]) {
          const archiveNext = normalizeTableArchiveIndex(state.tableArchiveIndex);
          delete archiveNext.performance[id];
          persistTableArchiveIndex(archiveNext);
        }
        return true;
      }

      function tableColumnVisibilityDefaults(tableKey = "") {
        const defaults = TABLE_COLUMN_DEFAULT_VISIBILITY[normalizeText(tableKey)] || {};
        return defaults && typeof defaults === "object" ? defaults : {};
      }

      function normalizeTableColumnVisibility(tableKey = "", source = null) {
        const defaults = tableColumnVisibilityDefaults(tableKey);
        const input = source && typeof source === "object" ? source : {};
        const normalized = { ...defaults };
        Object.keys(defaults).forEach((columnKey) => {
          if (!Object.prototype.hasOwnProperty.call(input, columnKey)) return;
          normalized[columnKey] = Boolean(input[columnKey]);
        });
        return normalized;
      }

      function loadTableColumnVisibilityFromStorage(tableKey = "") {
        const storageKey =
          TABLE_COLUMN_VISIBILITY_STORAGE_KEYS[normalizeText(tableKey)];
        if (!storageKey) return normalizeTableColumnVisibility(tableKey);
        const stored = window.SIS_PORTAL_PREFERENCES?.get(storageKey, null);
        if (!stored) return normalizeTableColumnVisibility(tableKey);
        try {
          return normalizeTableColumnVisibility(tableKey, typeof stored === "string" ? JSON.parse(stored) : stored);
        } catch (error) {
          void error;
          return normalizeTableColumnVisibility(tableKey);
        }
      }

      function loadAllTableColumnVisibilityFromStorage() {
        const visibility = {};
        Object.keys(TABLE_COLUMN_DEFAULT_VISIBILITY).forEach((tableKey) => {
          visibility[tableKey] = loadTableColumnVisibilityFromStorage(tableKey);
        });
        return visibility;
      }

      function persistTableColumnVisibility(tableKey = "", visibility = null) {
        const key = normalizeText(tableKey);
        if (!TABLE_COLUMN_VISIBILITY_STORAGE_KEYS[key]) return {};
        if (
          !state.tableColumnVisibility ||
          typeof state.tableColumnVisibility !== "object"
        ) {
          state.tableColumnVisibility = loadAllTableColumnVisibilityFromStorage();
        }
        const normalized = normalizeTableColumnVisibility(
          key,
          visibility || state.tableColumnVisibility[key],
        );
        state.tableColumnVisibility[key] = normalized;
        if (key === "attendance") state.attendanceColumnVisibility = normalized;
        void window.SIS_PORTAL_PREFERENCES?.save(TABLE_COLUMN_VISIBILITY_STORAGE_KEYS[key], normalized);
        return normalized;
      }

      function tableColumnVisibilityState(tableKey = "") {
        const key = normalizeText(tableKey);
        if (!key) return {};
        if (
          !state.tableColumnVisibility ||
          typeof state.tableColumnVisibility !== "object"
        ) {
          state.tableColumnVisibility = loadAllTableColumnVisibilityFromStorage();
        }
        const current = state.tableColumnVisibility[key];
        const normalized = normalizeTableColumnVisibility(key, current);
        state.tableColumnVisibility[key] = normalized;
        if (key === "attendance") state.attendanceColumnVisibility = normalized;
        return normalized;
      }

      function isTableColumnVisible(tableKey = "", columnKey = "") {
        const key = normalizeText(columnKey);
        if (!key) return true;
        const visibility = tableColumnVisibilityState(tableKey);
        if (!Object.prototype.hasOwnProperty.call(visibility, key)) return true;
        return visibility[key] === true;
      }

      function applyTableColumnVisibility(tableKey = "") {
        const key = normalizeText(tableKey);
        if (!key) return;
        const visibility = tableColumnVisibilityState(key);
        Object.entries(visibility).forEach(([columnKey, visible]) => {
          document
            .querySelectorAll(`[data-${key}-col="${columnKey}"]`)
            .forEach((cellEl) => {
              cellEl.classList.toggle("attendance-col-hidden", !visible);
            });
          const toggleEl = document.querySelector(
            `[data-${key}-col-toggle="${columnKey}"]`,
          );
          if (toggleEl instanceof HTMLInputElement) toggleEl.checked = visible;
        });
      }

      function applyAllTableColumnVisibility() {
        Object.keys(TABLE_COLUMN_DEFAULT_VISIBILITY).forEach((tableKey) =>
          applyTableColumnVisibility(tableKey),
        );
      }

      function bindTableColumnVisibilityControls(tableKey = "") {
        const key = normalizeText(tableKey);
        if (!key) return;
        document.querySelectorAll(`[data-${key}-col-toggle]`).forEach((inputEl) => {
          if (!(inputEl instanceof HTMLInputElement)) return;
          if (inputEl.dataset.bound === "1") return;
          inputEl.dataset.bound = "1";
          inputEl.addEventListener("change", () => {
            const columnKey = normalizeText(
              inputEl.getAttribute(`data-${key}-col-toggle`),
            );
            if (!columnKey) return;
            const next = { ...tableColumnVisibilityState(key) };
            if (!Object.prototype.hasOwnProperty.call(next, columnKey)) return;
            next[columnKey] = inputEl.checked;
            persistTableColumnVisibility(key, next);
            applyTableColumnVisibility(key);
          });
        });
      }

      function bindAllTableColumnVisibilityControls() {
        Object.keys(TABLE_COLUMN_DEFAULT_VISIBILITY).forEach((tableKey) =>
          bindTableColumnVisibilityControls(tableKey),
        );
      }

      function normalizeAttendanceColumnVisibility(source = null) {
        return normalizeTableColumnVisibility("attendance", source);
      }

      function loadAttendanceColumnVisibilityFromStorage() {
        return loadTableColumnVisibilityFromStorage("attendance");
      }

      function persistAttendanceColumnVisibility(
        visibility = state.attendanceColumnVisibility,
      ) {
        return persistTableColumnVisibility("attendance", visibility);
      }

      function isAttendanceColumnVisible(columnKey = "") {
        return isTableColumnVisible("attendance", columnKey);
      }

      function applyAttendanceColumnVisibility() {
        applyTableColumnVisibility("attendance");
      }

      function bindAttendanceColumnVisibilityControls() {
        bindTableColumnVisibilityControls("attendance");
      }

      function normalizeTextZoomPercent(value = TEXT_ZOOM_DEFAULT) {
        const parsed = Number.parseInt(String(value), 10);
        if (!Number.isFinite(parsed)) return TEXT_ZOOM_DEFAULT;
        const clamped = Math.max(TEXT_ZOOM_MIN, Math.min(TEXT_ZOOM_MAX, parsed));
        const offset = clamped - TEXT_ZOOM_MIN;
        return TEXT_ZOOM_MIN + Math.round(offset / TEXT_ZOOM_STEP) * TEXT_ZOOM_STEP;
      }

      function loadGlobalTextZoomFromStorage() {
        const stored = normalizeText(window.SIS_PORTAL_PREFERENCES?.get(GLOBAL_TEXT_ZOOM_STORAGE_KEY, ""));
        return normalizeTextZoomPercent(stored || TEXT_ZOOM_DEFAULT);
      }

      function persistGlobalTextZoomToStorage(value = state.globalTextZoomPercent) {
        const normalized = normalizeTextZoomPercent(value);
        state.globalTextZoomPercent = normalized;
        void window.SIS_PORTAL_PREFERENCES?.save(GLOBAL_TEXT_ZOOM_STORAGE_KEY, String(normalized));
        return normalized;
      }

      function applyGlobalTextZoom() {
        const percent = normalizeTextZoomPercent(state.globalTextZoomPercent);
        state.globalTextZoomPercent = percent;
        document.documentElement.style.setProperty(
          "--sis-global-text-zoom",
          String(percent / 100),
        );
        const label = `${percent}%`;
        document.querySelectorAll("[data-text-zoom-label]").forEach((labelEl) => {
          labelEl.textContent = label;
        });
        document
          .querySelectorAll('#studentTextZoomDownBtn')
          .forEach((buttonEl) => {
            if (!(buttonEl instanceof HTMLButtonElement)) return;
            buttonEl.disabled = percent <= TEXT_ZOOM_MIN;
          });
        document
          .querySelectorAll('#studentTextZoomUpBtn')
          .forEach((buttonEl) => {
            if (!(buttonEl instanceof HTMLButtonElement)) return;
            buttonEl.disabled = percent >= TEXT_ZOOM_MAX;
          });
      }

      function updateGlobalTextZoom(action = "") {
        const mode = normalizeLower(action);
        let next = normalizeTextZoomPercent(state.globalTextZoomPercent);
        if (mode === "decrease") next -= TEXT_ZOOM_STEP;
        else if (mode === "increase") next += TEXT_ZOOM_STEP;
        else next = TEXT_ZOOM_DEFAULT;
        next = normalizeTextZoomPercent(next);
        persistGlobalTextZoomToStorage(next);
        applyGlobalTextZoom();
        setStatus(`Global text size: ${next}%`);
      }

      function normalizeStudentIdSearchValue(value = "") {
        return normalizeLower(normalizeText(value)).replace(/\s+/g, "");
      }

      function isValidStudentIdSearchValue(value = "") {
        return STUDENT_ID_SEARCH_PATTERN.test(normalizeStudentIdSearchValue(value));
      }

      function normalizeStudentIdSearchHistory(values = []) {
        return Array.from(
          new Set(
            (Array.isArray(values) ? values : [])
              .map((entry) => normalizeStudentIdSearchValue(entry))
              .filter((entry) => isValidStudentIdSearchValue(entry)),
          ),
        );
      }

      function loadStudentIdSearchHistoryFromStorage() {
        const stored = window.SIS_PORTAL_PREFERENCES?.get(STUDENT_ID_SEARCH_STORAGE_KEY, "");
        if (!stored) return [];
        try {
          return normalizeStudentIdSearchHistory(typeof stored === "string" ? JSON.parse(stored) : stored);
        } catch (error) {
          void error;
          return [];
        }
      }

      function persistStudentIdSearchHistory(values = state.eaglesIdSearchHistory) {
        const normalized = normalizeStudentIdSearchHistory(values).slice(0, 80);
        state.eaglesIdSearchHistory = normalized;
        void window.SIS_PORTAL_PREFERENCES?.save(STUDENT_ID_SEARCH_STORAGE_KEY, normalized);
        return normalized;
      }

      function rememberStudentIdSearchValue(value = "") {
        const normalized = normalizeStudentIdSearchValue(value);
        if (!isValidStudentIdSearchValue(normalized)) return false;
        const next = [
          normalized,
          ...(state.eaglesIdSearchHistory || []).filter(
            (entry) => entry !== normalized,
          ),
        ];
        persistStudentIdSearchHistory(next);
        return true;
      }

      function assignmentItemIdFromFields(item = {}) {
        const title = normalizeLower(item.title || item.exerciseTitle || "");
        const url = normalizeLower(item.url || item.link || item.href || "");
        if (!title && !url) return "";
        return [title, url].join("|");
      }

      function normalizeAssignmentItem(source = {}) {
        const title = normalizeText(
          source.title || source.exerciseTitle || source.name || source.label,
        );
        const url = normalizeText(
          source.url || source.link || source.href || source.exerciseUrl,
        );
        const done =
          source.done === true ||
          source.completed === true ||
          normalizeLower(source.status) === "done";
        return {
          id: normalizeText(source.id) || assignmentItemIdFromFields({ title, url }),
          title,
          url,
          done,
        };
      }

      function normalizeAssignmentItems(items = []) {
        const source = Array.isArray(items) ? items : [];
        const normalized = source
          .map((entry) => normalizeAssignmentItem(entry))
          .filter((entry) => entry.title)
          .map((entry, index) => {
            if (entry.id) return entry;
            return {
              ...entry,
              id: `item-${index + 1}-${levelNameKey(entry.title || entry.url || String(index + 1))}`,
            };
          });
        return Array.from(
          new Map(normalized.map((entry) => [entry.id, entry])).values(),
        );
      }

      function assignmentCompletionFromItems(items = []) {
        const normalized = normalizeAssignmentItems(items);
        const total = normalized.length;
        const done = normalized.filter((entry) => entry.done).length;
        return {
          total,
          done,
          completed: total > 0 && done >= total,
        };
      }

      function assignmentTemplateIdFromFields(template = {}) {
        const level = normalizeLower(template.level || "");
        const assignmentTitle = normalizeLower(
          template.assignmentTitle || template.title || "",
        );
        const assignedAt = normalizeText(
          template.assignedAt || template.dateAssigned || "",
        );
        const dueAt = normalizeText(template.dueAt || template.dueDate || "");
        const firstItemTitle = normalizeLower(
          Array.isArray(template.items) && template.items.length ?
            template.items[0]?.title || template.items[0]?.exerciseTitle || ""
          : "",
        );
        const exerciseTitle = normalizeLower(template.exerciseTitle || firstItemTitle);
        if (!level && !exerciseTitle && !assignmentTitle && !assignedAt && !dueAt)
          return "";
        return [level, assignmentTitle || exerciseTitle, assignedAt, dueAt].join("|");
      }

      function normalizeAssignmentTemplate(source = {}) {
        const assignmentTitle = normalizeText(source.assignmentTitle || source.title);
        const assignedAt = normalizeText(source.assignedAt || source.dateAssigned);
        const dueAt = normalizeText(source.dueAt || source.dueDate);
        const exerciseTitle = normalizeText(source.exerciseTitle);
        const level = normalizeLevelName(source.level);
        const eaglesId = normalizeText(source.eaglesId);
        const message = normalizeText(source.message);
        const baseItems = normalizeAssignmentItems(source.items);
        const normalizedItems =
          baseItems.length ? baseItems
          : exerciseTitle ?
            [
              normalizeAssignmentItem({
                id: assignmentItemIdFromFields({
                  title: exerciseTitle,
                  url: normalizeText(source.exerciseUrl || source.link || source.href),
                }),
                title: exerciseTitle,
                url: normalizeText(source.exerciseUrl || source.link || source.href),
                done: source.completed === true,
              }),
            ].filter((entry) => entry.title)
          : [];
        const completion = assignmentCompletionFromItems(normalizedItems);
        const completed = source.completed === true || completion.completed;
        const completedAt = completed ? normalizeText(source.completedAt) : "";
        return {
          id: normalizeText(source.id) || assignmentTemplateIdFromFields(source),
          assignmentTitle,
          exerciseTitle: exerciseTitle || normalizedItems[0]?.title || "",
          assignedAt,
          dueAt,
          level,
          eaglesId,
          message,
          items: normalizedItems,
          completed,
          completedAt,
          createdAt: normalizeText(source.createdAt),
          updatedAt: normalizeText(source.updatedAt),
        };
      }

      function loadLegacyAssignmentTemplatesFromStorage() {
        const stored = window.SIS_PORTAL_PREFERENCES?.get(ASSIGNMENT_TEMPLATE_STORAGE_KEY, "");
        if (!stored) return [];
        try {
          const parsed = typeof stored === "string" ? JSON.parse(stored) : stored;
          if (!Array.isArray(parsed)) return [];
          return parsed
            .map((entry) => normalizeAssignmentTemplate(entry))
            .filter((entry) => entry.assignmentTitle || entry.items.length);
        } catch (error) {
          void error;
          return [];
        }
      }

      function clearLegacyAssignmentTemplateStorage() {
        void window.SIS_PORTAL_PREFERENCES?.save(ASSIGNMENT_TEMPLATE_STORAGE_KEY, []);
      }

      function normalizeAssignmentTemplateList(templates = []) {
        return Array.from(
          new Map(
            (Array.isArray(templates) ? templates : [])
              .map((entry) => normalizeAssignmentTemplate(entry))
              .filter(
                (entry) => entry.id && (entry.assignmentTitle || entry.items.length),
              )
              .map((entry) => [entry.id, entry]),
          ).values(),
        ).sort((left, right) =>
          normalizeText(
            right.updatedAt || right.assignedAt || right.dueAt,
          ).localeCompare(
            normalizeText(left.updatedAt || left.assignedAt || left.dueAt),
          ),
        );
      }

      async function migrateLegacyAssignmentTemplatesToServer() {
        const legacyTemplates = loadLegacyAssignmentTemplatesFromStorage();
        if (!legacyTemplates.length) return { total: 0, saved: 0, items: [] };
        const result = await api(ADMIN_ASSIGNMENT_TEMPLATES_IMPORT_PATH, {
          method: "POST",
          body: {
            templates: legacyTemplates,
          },
        });
        clearLegacyAssignmentTemplateStorage();
        return result;
      }

      let assignmentTemplatesLoadGeneration = 0;
      let assignmentTemplatesLastWriteAt = 0;

      async function loadAssignmentTemplatesFromServer({
        migrateLegacy = false,
      } = {}) {
        const loadGeneration = ++assignmentTemplatesLoadGeneration;
        const loadStartedAt = Date.now();
        if (migrateLegacy) {
          try {
            await migrateLegacyAssignmentTemplatesToServer();
          } catch (error) {
            if (!(error && (error.status === 404 || error.status === 503))) {
              throw error;
            }
          }
        }

        try {
          const result = await api(ADMIN_ASSIGNMENT_TEMPLATES_PATH);
          const normalized = normalizeAssignmentTemplateList(
            Array.isArray(result?.items) ? result.items : [],
          );
          if (loadGeneration !== assignmentTemplatesLoadGeneration) return state.assignmentTemplates;
          if (!normalized.length && assignmentTemplatesLastWriteAt > 0) {
            return state.assignmentTemplates;
          }
          state.assignmentTemplates = normalized;
          if (state.dashboardSummary) renderDashboardSummary(state.dashboardSummary);
          return normalized;
        } catch (error) {
          if (error && (error.status === 404 || error.status === 503)) {
            if (loadGeneration !== assignmentTemplatesLoadGeneration) return state.assignmentTemplates;
            state.assignmentTemplates = [];
            if (state.dashboardSummary) renderDashboardSummary(state.dashboardSummary);
            return [];
          }
          throw error;
        }
      }

      function normalizeTeacherNameList(values = []) {
        return Array.from(
          new Set(
            (Array.isArray(values) ? values : [])
              .map((entry) => normalizeText(entry))
              .filter(Boolean),
          ),
        );
      }

      function loadParentTrackingTeacherNamesFromStorage() {
        const stored = window.SIS_PORTAL_PREFERENCES?.get(PARENT_TRACKING_TEACHER_STORAGE_KEY, "");
        if (!stored) return [];
        try {
          const parsed = typeof stored === "string" ? JSON.parse(stored) : stored;
          return normalizeTeacherNameList(parsed);
        } catch (error) {
          void error;
          return [];
        }
      }

      function persistParentTrackingTeacherNames(values = []) {
        const normalized = normalizeTeacherNameList(values);
        state.parentTracking.teacherNames = normalized;
        void window.SIS_PORTAL_PREFERENCES?.save(PARENT_TRACKING_TEACHER_STORAGE_KEY, normalized);
        return normalized;
      }

      function loadParentTrackingLessonSummaryFromStorage() {
        const stored = window.SIS_PORTAL_PREFERENCES?.get(PARENT_TRACKING_SUMMARY_STORAGE_KEY, "");
        if (!stored) return {};
        try {
          const parsed = typeof stored === "string" ? JSON.parse(stored) : stored;
          if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
          const entries = Object.entries(parsed)
            .map(([key, value]) => [normalizeText(key), normalizeText(value)])
            .filter(([key, value]) => key && value);
          return Object.fromEntries(entries);
        } catch (error) {
          void error;
          return {};
        }
      }

      function persistParentTrackingLessonSummary(values = {}) {
        const source =
          values && typeof values === "object" && !Array.isArray(values) ? values : {};
        const normalized = Object.fromEntries(
          Object.entries(source)
            .map(([key, value]) => [normalizeText(key), normalizeText(value)])
            .filter(([key, value]) => key && value),
        );
        state.parentTracking.lessonSummaryByLevelDate = normalized;
        void window.SIS_PORTAL_PREFERENCES?.save(PARENT_TRACKING_SUMMARY_STORAGE_KEY, normalized);
        return normalized;
      }

      function normalizeLevelName(value) {
        const text = normalizeText(value);
        if (!text) return "";
        return text.replace(/\s+/g, " ");
      }

      function levelNameKey(value) {
        return normalizeLower(normalizeLevelName(value)).replace(/[^a-z0-9]/g, "");
      }

      function canonicalLevelDisplayName(value) {
        const normalized = normalizeLevelName(value);
        if (!normalized) return "";
        const compact = normalizeLower(normalized).replace(/[\s._-]+/g, "");
        return LEVEL_FULL_LABELS.get(compact) || normalized;
      }

      function mergeUniqueLevelNames(values = []) {
        const seen = new Set();
        const merged = [];
        (Array.isArray(values) ? values : []).forEach((entry) => {
          const label = canonicalLevelDisplayName(entry);
          if (!label) return;
          const key = levelNameKey(label);
          if (!key || seen.has(key)) return;
          seen.add(key);
          merged.push(label);
        });
        return merged;
      }

      function parseGradeLevelNumber(value) {
        const text = normalizeLevelName(value);
        if (!text) return null;
        const compact = normalizeLower(text).replace(/[\s._-]+/g, "");
        const match = compact.match(/^(?:g|grade|level)(\d{1,2})$/);
        if (!match) return null;
        const parsed = Number.parseInt(match[1], 10);
        if (!Number.isFinite(parsed) || parsed <= 0) return null;
        return parsed;
      }

      function resolveSystemLevelName(value) {
        const normalized = normalizeLevelName(value);
        if (!normalized) return "";
        const key = levelNameKey(normalized);
        if (!key) return normalized;
        const source = Array.isArray(state.systemLevels) ? state.systemLevels : [];
        const matched = source.find((entry) => levelNameKey(entry) === key);
        return canonicalLevelDisplayName(matched || normalized);
      }

      function shortLevelLabel(value) {
        const canonical = resolveSystemLevelName(value);
        const alias = LEVEL_SHORTCUT_LABELS.get(levelNameKey(canonical));
        if (alias) return alias;
        const compact = normalizeLower(canonical).replace(/[\s._-]+/g, "");
        const levelCodeAlias = LEVEL_CODE_DISPLAY_LABELS.get(compact);
        if (levelCodeAlias) return levelCodeAlias;
        const gradeLevel = parseGradeLevelNumber(canonical);
        if (gradeLevel !== null && compact.startsWith("g"))
          return `Grade ${gradeLevel}`;
        return canonical;
      }

      function fullLevelLabel(value) {
        const canonical = resolveSystemLevelName(value);
        const compact = normalizeLower(canonical).replace(/[\s._-]+/g, "");
        const mapped = LEVEL_FULL_LABELS.get(compact);
        if (mapped) return mapped;
        const gradeLevel = parseGradeLevelNumber(canonical);
        if (gradeLevel !== null && compact.startsWith("g"))
          return `Grade ${gradeLevel}`;
        return canonical;
      }

      function levelTileStyleKeys(levelName) {
        const normalized = normalizeLevelName(levelName);
        if (!normalized) return [];
        const canonicalFull = fullLevelLabel(normalized);
        const shortcut = shortLevelLabel(normalized);
        return Array.from(
          new Set(
            [
              levelNameKey(canonicalFull),
              levelNameKey(normalized),
              levelNameKey(shortcut),
            ].filter(Boolean),
          ),
        );
      }

      function compareLevelLabels(left, right) {
        const leftLabel = fullLevelLabel(left);
        const rightLabel = fullLevelLabel(right);
        const leftOrder = LEVEL_ORDER_INDEX.get(levelNameKey(leftLabel));
        const rightOrder = LEVEL_ORDER_INDEX.get(levelNameKey(rightLabel));
        if (Number.isFinite(leftOrder) && Number.isFinite(rightOrder))
          return leftOrder - rightOrder;
        if (Number.isFinite(leftOrder)) return -1;
        if (Number.isFinite(rightOrder)) return 1;
        const leftGrade = parseGradeLevelNumber(leftLabel);
        const rightGrade = parseGradeLevelNumber(rightLabel);
        if (leftGrade !== null && rightGrade !== null) return leftGrade - rightGrade;
        return leftLabel.localeCompare(rightLabel, undefined, {
          numeric: true,
          sensitivity: "base",
        });
      }

      function sortLevelNames(values = []) {
        return mergeUniqueLevelNames(values).sort((left, right) =>
          compareLevelLabels(left, right),
        );
      }

      function sortLevelRows(rows = []) {
        return [...(Array.isArray(rows) ? rows : [])].sort((left, right) =>
          compareLevelLabels(left?.level || "", right?.level || ""),
        );
      }

      function compareTableText(left, right) {
        return normalizeText(left).localeCompare(normalizeText(right), undefined, {
          numeric: true,
          sensitivity: "base",
        });
      }

      function compareTableNumber(left, right) {
        const a = Number.parseFloat(String(left));
        const b = Number.parseFloat(String(right));
        const aValid = Number.isFinite(a);
        const bValid = Number.isFinite(b);
        if (aValid && bValid) return a - b;
        if (aValid) return 1;
        if (bValid) return -1;
        return 0;
      }

      function compareTableIsoDate(left, right) {
        const a = normalizeText(left).slice(0, 10);
        const b = normalizeText(right).slice(0, 10);
        if (a && b) return a.localeCompare(b);
        if (a) return 1;
        if (b) return -1;
        return 0;
      }

      function compareTableIsoDateTime(left, right) {
        const a = normalizeText(left);
        const b = normalizeText(right);
        if (a && b) return a.localeCompare(b);
        if (a) return 1;
        if (b) return -1;
        return 0;
      }

      function applySortDirection(compareValue, dir = "desc") {
        return normalizeLower(dir) === "asc" ? compareValue : -compareValue;
      }

      function toggledSortDirection(dir = "desc") {
        return normalizeLower(dir) === "asc" ? "desc" : "asc";
      }

      function assignmentCompletionPercent(template = {}) {
        const completion = assignmentCompletionFromItems(template?.items);
        if (!completion.total) return 0;
        return (completion.done / completion.total) * 100;
      }

      function gradeSortScoreValue(row = {}) {
        const score = Number.parseFloat(String(row?.score));
        const maxScore = Number.parseFloat(String(row?.maxScore));
        if (Number.isFinite(score) && Number.isFinite(maxScore) && maxScore > 0) {
          return (score / maxScore) * 100;
        }
        return Number.isFinite(score) ? score : null;
      }

      function sortedAttendanceRows(rows = []) {
        const list = [...(Array.isArray(rows) ? rows : [])];
        const sortField =
          normalizeText(state.tableSort?.attendance?.field) || "attendanceDate";
        const sortDir =
          normalizeLower(state.tableSort?.attendance?.dir) === "asc" ? "asc" : "desc";
        return list.sort((left, right) => {
          const leftFullName = normalizeText(left?.fullName);
          const rightFullName = normalizeText(right?.fullName);
          let compareValue = 0;
          if (sortField === "studentNumber")
            compareValue = compareTableNumber(
              left?.studentNumber,
              right?.studentNumber,
            );
          else if (sortField === "fullName")
            compareValue = compareTableText(leftFullName, rightFullName);
          else if (sortField === "eaglesId")
            compareValue = compareTableText(left?.eaglesId, right?.eaglesId);
          else if (sortField === "className")
            compareValue = compareTableText(left?.className, right?.className);
          else if (sortField === "quarter")
            compareValue = compareTableText(left?.quarter, right?.quarter);
          else if (sortField === "status")
            compareValue = compareTableText(left?.status, right?.status);
          else if (sortField === "weekNumber")
            compareValue = compareTableNumber(rowWeekNumber("attendance", left), rowWeekNumber("attendance", right));
          else
            compareValue = compareTableIsoDate(
              left?.attendanceDate,
              right?.attendanceDate,
            );
          if (compareValue === 0)
            compareValue = compareTableIsoDate(
              left?.attendanceDate,
              right?.attendanceDate,
            );
          if (compareValue === 0)
            compareValue = compareTableText(leftFullName, rightFullName);
          if (compareValue === 0)
            compareValue = compareTableText(left?.eaglesId, right?.eaglesId);
          if (compareValue === 0) compareValue = compareTableText(left?.id, right?.id);
          return applySortDirection(compareValue, sortDir);
        });
      }

      function sortedAssignmentTemplates(rows = []) {
        const list = [...(Array.isArray(rows) ? rows : [])];
        const sortField = normalizeText(state.tableSort?.assignments?.field) || "dueAt";
        const sortDir =
          normalizeLower(state.tableSort?.assignments?.dir) === "asc" ? "asc" : "desc";
        return list.sort((left, right) => {
          let compareValue = 0;
          if (sortField === "assignedAt")
            compareValue = compareTableIsoDate(left?.assignedAt, right?.assignedAt);
          else if (sortField === "assignmentTitle")
            compareValue = compareTableText(
              left?.assignmentTitle || left?.exerciseTitle,
              right?.assignmentTitle || right?.exerciseTitle,
            );
          else if (sortField === "level")
            compareValue = compareLevelLabels(left?.level || "", right?.level || "");
          else if (sortField === "student")
            compareValue = compareTableText(left?.eaglesId, right?.eaglesId);
          else if (sortField === "completion")
            compareValue = compareTableNumber(
              assignmentCompletionPercent(left),
              assignmentCompletionPercent(right),
            );
          else if (sortField === "weekNumber")
            compareValue = compareTableNumber(rowWeekNumber("assignments", left), rowWeekNumber("assignments", right));
          else compareValue = compareTableIsoDate(left?.dueAt, right?.dueAt);
          if (compareValue === 0)
            compareValue = compareTableIsoDate(left?.dueAt, right?.dueAt);
          if (compareValue === 0)
            compareValue = compareTableText(left?.eaglesId, right?.eaglesId);
          if (compareValue === 0)
            compareValue = compareTableText(
              left?.assignmentTitle || left?.exerciseTitle,
              right?.assignmentTitle || right?.exerciseTitle,
            );
          return applySortDirection(compareValue, sortDir);
        });
      }

      function sortedGradeRows(rows = []) {
        const list = [...(Array.isArray(rows) ? rows : [])];
        const sortField = normalizeText(state.tableSort?.grades?.field) || "dueAt";
        const sortDir =
          normalizeLower(state.tableSort?.grades?.dir) === "asc" ? "asc" : "desc";
        return list.sort((left, right) => {
          const leftFullName = normalizeText(left?.fullName);
          const rightFullName = normalizeText(right?.fullName);
          let compareValue = 0;
          if (sortField === "studentNumber")
            compareValue = compareTableNumber(
              left?.studentNumber,
              right?.studentNumber,
            );
          else if (sortField === "fullName")
            compareValue = compareTableText(leftFullName, rightFullName);
          else if (sortField === "eaglesId")
            compareValue = compareTableText(left?.eaglesId, right?.eaglesId);
          else if (sortField === "assignmentName")
            compareValue = compareTableText(
              left?.assignmentName,
              right?.assignmentName,
            );
          else if (sortField === "score")
            compareValue = compareTableNumber(
              gradeSortScoreValue(left),
              gradeSortScoreValue(right),
            );
          else if (sortField === "className")
            compareValue = compareTableText(left?.className, right?.className);
          else if (sortField === "weekNumber")
            compareValue = compareTableNumber(rowWeekNumber("grades", left), rowWeekNumber("grades", right));
          else compareValue = compareTableIsoDate(left?.dueAt, right?.dueAt);
          if (compareValue === 0)
            compareValue = compareTableIsoDate(left?.dueAt, right?.dueAt);
          if (compareValue === 0)
            compareValue = compareTableText(leftFullName, rightFullName);
          if (compareValue === 0)
            compareValue = compareTableText(left?.eaglesId, right?.eaglesId);
          if (compareValue === 0)
            compareValue = compareTableText(
              left?.assignmentName,
              right?.assignmentName,
            );
          return applySortDirection(compareValue, sortDir);
        });
      }

      function sortedReportRows(rows = []) {
        const list = [...(Array.isArray(rows) ? rows : [])];
        const sortField =
          normalizeText(state.tableSort?.reports?.field) || "generatedAt";
        const sortDir =
          normalizeLower(state.tableSort?.reports?.dir) === "asc" ? "asc" : "desc";
        return list.sort((left, right) => {
          const leftFullName = normalizeText(left?.fullName);
          const rightFullName = normalizeText(right?.fullName);
          let compareValue = 0;
          if (sortField === "studentNumber")
            compareValue = compareTableNumber(
              left?.studentNumber,
              right?.studentNumber,
            );
          else if (sortField === "fullName")
            compareValue = compareTableText(leftFullName, rightFullName);
          else if (sortField === "eaglesId")
            compareValue = compareTableText(left?.eaglesId, right?.eaglesId);
          else if (sortField === "className")
            compareValue = compareTableText(left?.className, right?.className);
          else if (sortField === "homeworkCompletionRate")
            compareValue = compareTableNumber(
              left?.homeworkCompletionRate,
              right?.homeworkCompletionRate,
            );
          else if (sortField === "homeworkOnTimeRate")
            compareValue = compareTableNumber(
              left?.homeworkOnTimeRate,
              right?.homeworkOnTimeRate,
            );
          else if (sortField === "behaviorScore")
            compareValue = compareTableNumber(
              left?.behaviorScore,
              right?.behaviorScore,
            );
          else if (sortField === "weekNumber")
            compareValue = compareTableNumber(rowWeekNumber("reports", left), rowWeekNumber("reports", right));
          else
            compareValue = compareTableIsoDate(left?.generatedAt, right?.generatedAt);
          if (compareValue === 0)
            compareValue = compareTableIsoDate(left?.generatedAt, right?.generatedAt);
          if (compareValue === 0)
            compareValue = compareTableText(leftFullName, rightFullName);
          if (compareValue === 0)
            compareValue = compareTableText(left?.eaglesId, right?.eaglesId);
          if (compareValue === 0) compareValue = compareTableText(left?.id, right?.id);
          return applySortDirection(compareValue, sortDir);
        });
      }

      function sortedPerformanceRows(rows = []) {
        const list = [...(Array.isArray(rows) ? rows : [])];
        const sortField =
          normalizeText(state.tableSort?.performance?.field) || "generatedAt";
        const sortDir =
          normalizeLower(state.tableSort?.performance?.dir) === "asc" ? "asc" : "desc";
        return list.sort((left, right) => {
          const leftFullName = normalizeText(left?.fullName);
          const rightFullName = normalizeText(right?.fullName);
          let compareValue = 0;
          if (sortField === "studentNumber")
            compareValue = compareTableNumber(
              left?.studentNumber,
              right?.studentNumber,
            );
          else if (sortField === "fullName")
            compareValue = compareTableText(leftFullName, rightFullName);
          else if (sortField === "eaglesId")
            compareValue = compareTableText(left?.eaglesId, right?.eaglesId);
          else if (sortField === "className")
            compareValue = compareTableText(left?.className, right?.className);
          else if (sortField === "homeworkCompletionRate")
            compareValue = compareTableNumber(
              left?.homeworkCompletionRate,
              right?.homeworkCompletionRate,
            );
          else if (sortField === "homeworkOnTimeRate")
            compareValue = compareTableNumber(
              left?.homeworkOnTimeRate,
              right?.homeworkOnTimeRate,
            );
          else if (sortField === "behaviorScore")
            compareValue = compareTableNumber(
              left?.behaviorScore,
              right?.behaviorScore,
            );
          else if (sortField === "weekNumber")
            compareValue = compareTableNumber(rowWeekNumber("performance", left), rowWeekNumber("performance", right));
          else
            compareValue = compareTableIsoDate(left?.generatedAt, right?.generatedAt);
          if (compareValue === 0)
            compareValue = compareTableIsoDate(left?.generatedAt, right?.generatedAt);
          if (compareValue === 0)
            compareValue = compareTableText(leftFullName, rightFullName);
          if (compareValue === 0)
            compareValue = compareTableText(left?.eaglesId, right?.eaglesId);
          if (compareValue === 0) compareValue = compareTableText(left?.id, right?.id);
          return applySortDirection(compareValue, sortDir);
        });
      }

      function normalizedNewsReviewSortField(field = "") {
        const normalized = normalizeText(field);
        if (
          [
            "weekSet",
            "student",
            "level",
            "reports",
            "setStatus",
            "setAction",
            "latestSubmittedAt",
          ].includes(normalized)
        ) {
          return normalized;
        }
        return "weekSet";
      }

      function newsReviewSetStatusSortRank(status = "") {
        const normalized = normalizeLower(status);
        if (normalized === "approved") return 0;
        if (normalized === "waiting") return 1;
        if (normalized === "checked") return 2;
        if (normalized === "submitted") return 3;
        if (normalized === "revise") return 4;
        if (normalized === "open") return 5;
        if (normalized === "none-submitted") return 6;
        return 7;
      }

      function newsReviewActionSortRank(action = "") {
        const normalized = normalizeLower(action);
        if (normalized === "completed") return 0;
        if (normalized === "incomplete") return 1;
        if (normalized.startsWith("pending-")) return 2;
        return 3;
      }

      function newsReviewActionSortCount(action = "") {
        const normalized = normalizeLower(action);
        if (normalized.startsWith("pending-")) {
          const value = Number.parseInt(normalized.slice("pending-".length), 10);
          return Number.isFinite(value) ? value : 0;
        }
        return 0;
      }

      function compareNewsReviewAction(leftAction = "", rightAction = "") {
        const byRank = compareTableNumber(
          newsReviewActionSortRank(leftAction),
          newsReviewActionSortRank(rightAction),
        );
        if (byRank !== 0) return byRank;
        return compareTableNumber(
          newsReviewActionSortCount(leftAction),
          newsReviewActionSortCount(rightAction),
        );
      }

      function sortedNewsReviewWeekSets(rows = []) {
        const list = [...(Array.isArray(rows) ? rows : [])];
        const sortField = normalizedNewsReviewSortField(
          state.tableSort?.newsReview?.field,
        );
        const sortDir =
          normalizeLower(state.tableSort?.newsReview?.dir) === "asc" ? "asc" : "desc";
        return list.sort((left, right) => {
          const leftStudentLabel = normalizeText(
            left?.student?.fullName ||
              left?.student?.englishName ||
              left?.student?.eaglesId ||
              left?.student?.studentRefId,
          );
          const rightStudentLabel = normalizeText(
            right?.student?.fullName ||
              right?.student?.englishName ||
              right?.student?.eaglesId ||
              right?.student?.studentRefId,
          );
          let compareValue = 0;
          if (sortField === "student")
            compareValue = compareTableText(leftStudentLabel, rightStudentLabel);
          else if (sortField === "level")
            compareValue = compareLevelLabels(
              left?.student?.level || "",
              right?.student?.level || "",
            );
          else if (sortField === "reports")
            compareValue = compareTableNumber(left?.reportCount, right?.reportCount);
          else if (sortField === "setStatus")
            compareValue = compareTableNumber(
              newsReviewSetStatusSortRank(left?.setStatus),
              newsReviewSetStatusSortRank(right?.setStatus),
            );
          else if (sortField === "setAction")
            compareValue = compareNewsReviewAction(
              left?.setAction,
              right?.setAction,
            );
          else if (sortField === "latestSubmittedAt") {
            compareValue = compareTableIsoDateTime(
              left?.latestSubmittedAt,
              right?.latestSubmittedAt,
            );
          } else compareValue = compareTableIsoDate(left?.weekStart, right?.weekStart);
          if (compareValue === 0)
            compareValue = compareTableIsoDate(left?.weekStart, right?.weekStart);
          if (compareValue === 0)
            compareValue = compareTableIsoDateTime(
              left?.latestSubmittedAt,
              right?.latestSubmittedAt,
            );
          if (compareValue === 0)
            compareValue = compareTableText(leftStudentLabel, rightStudentLabel);
          if (compareValue === 0) compareValue = compareTableText(left?.id, right?.id);
          return applySortDirection(compareValue, sortDir);
        });
      }

      function tableLabelForKey(tableKey = "") {
        if (tableKey === "attendance") return "Attendance";
        if (tableKey === "assignments") return "Assignments";
        if (tableKey === "performance") return "Performance";
        if (tableKey === "grades") return "Grades";
        if (tableKey === "reports") return "All Reports";
        return "Data";
      }

      function archiveToggleButtonId(tableKey = "") {
        if (tableKey === "attendance") return "attendanceArchiveToggleBtn";
        if (tableKey === "assignments") return "assignmentArchiveToggleBtn";
        if (tableKey === "performance") return "performanceArchiveToggleBtn";
        if (tableKey === "grades") return "gradeArchiveToggleBtn";
        if (tableKey === "reports") return "reportArchiveToggleBtn";
        return "";
      }

      function isTableRecordArchived(tableKey = "", recordId = "") {
        const id = normalizeText(recordId);
        if (!id) return false;
        const section = state.tableArchiveIndex?.[tableKey];
        if (!section || typeof section !== "object") return false;
        return section[id] === true;
      }

      function setTableRecordArchived(tableKey = "", recordId = "", archived = true) {
        const id = normalizeText(recordId);
        if (!DATA_TABLE_KEYS.includes(tableKey) || !id) return false;
        const next = normalizeTableArchiveIndex(state.tableArchiveIndex);
        if (archived) next[tableKey][id] = true;
        else delete next[tableKey][id];
        persistTableArchiveIndex(next);
        updateArchiveToggleButton(tableKey);
        return true;
      }

      function archivedRecordCount(tableKey = "") {
        if (!DATA_TABLE_KEYS.includes(tableKey)) return 0;
        const section = state.tableArchiveIndex?.[tableKey];
        if (!section || typeof section !== "object") return 0;
        return Object.keys(section).length;
      }

      function updateArchiveToggleButton(tableKey = "") {
        const buttonId = archiveToggleButtonId(tableKey);
        if (!buttonId) return;
        const buttonEl = document.getElementById(buttonId);
        if (!buttonEl) return;
        const showingArchived = Boolean(state.tableShowArchived?.[tableKey]);
        const archiveCount = archivedRecordCount(tableKey);
        if (showingArchived) {
          buttonEl.textContent = "Active";
        } else if (archiveCount > 0) {
          buttonEl.textContent = `Archived (${archiveCount})`;
        } else {
          buttonEl.textContent = "Archived";
        }
      }

      function updateArchiveToggleButtons() {
        DATA_TABLE_KEYS.forEach((tableKey) => updateArchiveToggleButton(tableKey));
      }

      function setTableSearchTerm(tableKey = "", value = "") {
        if (!DATA_TABLE_KEYS.includes(tableKey)) return;
        state.tableSearch[tableKey] = normalizeText(value);
      }

      function tableSearchTerm(tableKey = "") {
        return normalizeSearchComparable(state.tableSearch?.[tableKey] || "");
      }

      function tableFilterFieldConfig(tableKey = "") {
        return TABLE_SEARCH_FILTER_FIELD_IDS[tableKey] || null;
      }

      function setTableFilterValue(tableKey = "", field = "", value = "") {
        if (!DATA_TABLE_KEYS.includes(tableKey)) return;
        if (!["level", "studentRefId", "dateFrom", "dateTo", "weekNumber"].includes(field)) return;
        if (!state.tableFilters || typeof state.tableFilters !== "object") return;
        if (
          !state.tableFilters[tableKey] ||
          typeof state.tableFilters[tableKey] !== "object"
        ) {
          state.tableFilters[tableKey] = {
            level: "",
            studentRefId: "",
            dateFrom: "",
            dateTo: "",
            weekNumber: "",
          };
        }
        let normalized = normalizeText(value);
        if (field === "level") normalized = resolveSystemLevelName(normalized);
        if (field === "studentRefId") normalized = normalizeText(normalized);
        if (field === "dateFrom" || field === "dateTo")
          normalized = normalizeText(normalized).slice(0, 10);
        if (field === "weekNumber") normalized = normalizeText(normalized).replace(/[^0-9]/g, "");
        state.tableFilters[tableKey][field] = normalized;
      }

      function tableFilterValue(tableKey = "", field = "") {
        if (!DATA_TABLE_KEYS.includes(tableKey)) return "";
        if (!["level", "studentRefId", "dateFrom", "dateTo", "weekNumber"].includes(field)) return "";
        return normalizeText(state.tableFilters?.[tableKey]?.[field] || "");
      }

      function topStudentScopeState() {
        const scope =
          state.topStudentScope && typeof state.topStudentScope === "object" ?
            state.topStudentScope
          : {};
        return {
          query: normalizeText(scope.query),
          level: resolveSystemLevelName(scope.level),
          school: normalizeText(scope.school),
        };
      }

      function hasTopStudentScope(scope = topStudentScopeState()) {
        return Boolean(scope.query || scope.level || scope.school);
      }

      function pageUsesTopStudentScope(pageSlug = state.activePage) {
        return TOP_SCOPE_PAGE_SET.has(normalizePageSlug(pageSlug));
      }

      function baseStudentSource() {
        if (Array.isArray(state.dashboardStudents) && state.dashboardStudents.length)
          return state.dashboardStudents;
        if (Array.isArray(state.students) && state.students.length)
          return state.students;
        return [];
      }

      function studentSourceForPage(pageSlug = state.activePage) {
        if (hasTopStudentScope() && pageUsesTopStudentScope(pageSlug)) {
          return Array.isArray(state.students) ? state.students : [];
        }
        return baseStudentSource();
      }

      function tableFilterStudentSource(tableKey = "") {
        if (
          ["attendance", "assignments", "performance", "grades", "reports"].includes(
            tableKey,
          )
        ) {
          return baseStudentSource();
        }
        const pageSlug = TABLE_KEY_TO_PAGE_SLUG[tableKey] || state.activePage;
        return studentSourceForPage(pageSlug);
      }

      function adminDataTableKeyForPage(pageSlug = state.activePage) {
        return PAGE_SLUG_TO_ADMIN_DATA_TABLE_KEY[normalizePageSlug(pageSlug)] || "";
      }

      function setAdminDataLoading(tableKey = "", loading = false) {
        if (
          !Object.prototype.hasOwnProperty.call(state.adminDataLoading || {}, tableKey)
        )
          return;
        state.adminDataLoading[tableKey] = Boolean(loading);
        updateTableFilterSummary(tableKey);
      }

      function recordCountFieldForTable(tableKey = "") {
        if (tableKey === "attendance") return "attendanceRecords";
        if (tableKey === "grades") return "gradeRecords";
        if (tableKey === "performance" || tableKey === "reports")
          return "parentReports";
        return "";
      }

      function studentRecordCountForTable(student = {}, tableKey = "") {
        const countField = recordCountFieldForTable(tableKey);
        if (!countField) return 0;
        const counts = student?.counts;
        if (
          !counts ||
          typeof counts !== "object" ||
          !Object.prototype.hasOwnProperty.call(counts, countField)
        ) {
          return 1;
        }
        return Math.max(0, Number(student?.counts?.[countField] || 0) || 0);
      }

      function cacheStudentDetail(student = null) {
        const id = normalizeText(student?.id);
        if (!id) return null;
        state.studentDetailCacheById[id] = student;
        return student;
      }

      async function ensureStudentDetailCached(studentRefId = "") {
        const id = normalizeText(studentRefId);
        if (!id) return null;
        const cached = state.studentDetailCacheById?.[id];
        if (cached && typeof cached === "object") return cached;
        const detail = await api(`/api/admin/students/${encodeURIComponent(id)}`);
        cacheStudentDetail(detail);
        if (detail?.id)
          state.parentTracking.studentDetailsByStudentId[detail.id] = detail;
        return detail;
      }

      async function mapWithConcurrency(
        items = [],
        worker = async () => null,
        concurrency = 6,
      ) {
        const source = Array.isArray(items) ? items : [];
        if (!source.length) return [];
        const results = new Array(source.length);
        const limit = Math.max(1, Math.min(20, Number(concurrency) || 6));
        let cursor = 0;
        const runner = async () => {
          while (cursor < source.length) {
            const currentIndex = cursor;
            cursor += 1;
            results[currentIndex] = await worker(source[currentIndex], currentIndex);
          }
        };
        await Promise.all(
          new Array(Math.min(limit, source.length)).fill(null).map(() => runner()),
        );
        return results;
      }

      function studentsForAdminDataHydration(tableKey = "") {
        const source = tableFilterStudentSource(tableKey);
        if (!Array.isArray(source) || !source.length) return [];
        const deduped = Array.from(
          new Map(
            source
              .map((student) => [normalizeText(student?.id), student])
              .filter(([id]) => Boolean(id)),
          ).values(),
        );
        return deduped.filter(
          (student) => studentRecordCountForTable(student, tableKey) > 0,
        );
      }

      function canonicalStudentFullNameFromProfile(profile = {}) {
        return normalizeText(profile?.fullName);
      }

      function canonicalStudentEnglishNameFromProfile(profile = {}) {
        return normalizeText(profile?.englishName);
      }

      function canonicalStudentFullNameFromRow(row = {}) {
        return normalizeText(row?.fullName);
      }

      function canonicalStudentEnglishNameFromRow(row = {}) {
        return normalizeText(row?.englishName);
      }

      function hasStudentNumberKey(student = {}) {
        if (Object.prototype.hasOwnProperty.call(student || {}, "studentNumber"))
          return true;
        const profile =
          student?.profile && typeof student.profile === "object" ?
            student.profile
          : {};
        return Object.prototype.hasOwnProperty.call(profile, "studentNumber");
      }

      function attendanceRecordWithStudent(record = {}, student = {}) {
        const eaglesId = normalizeText(student?.eaglesId);
        if (!eaglesId) return null;
        const studentNumber = parsePositiveInteger(student?.studentNumber);
        if (hasStudentNumberKey(student) && !studentNumber) return null;
        const fullName = canonicalStudentFullNameFromProfile(student?.profile);
        const englishName = canonicalStudentEnglishNameFromProfile(student?.profile);
        return {
          ...record,
          studentRefId: normalizeText(student?.id),
          eaglesId,
          studentNumber: studentNumber || null,
          fullName,
          englishName,
          classLevel: resolveSystemLevelName(
            record?.classLevel || student?.profile?.currentGrade || "",
          ),
          profile: student?.profile || {},
        };
      }

      function gradeRecordWithStudent(record = {}, student = {}) {
        const eaglesId = normalizeText(student?.eaglesId);
        if (!eaglesId) return null;
        const studentNumber = parsePositiveInteger(student?.studentNumber);
        if (hasStudentNumberKey(student) && !studentNumber) return null;
        const fullName = canonicalStudentFullNameFromProfile(student?.profile);
        const englishName = canonicalStudentEnglishNameFromProfile(student?.profile);
        const resolvedClassLevel = resolveSystemLevelName(
          record?.level || record?.classLevel || student?.profile?.currentGrade || "",
        );
        const normalizedClassName = normalizeText(record?.className);
        return {
          ...record,
          studentRefId: normalizeText(student?.id),
          eaglesId,
          studentNumber: studentNumber || null,
          fullName,
          englishName,
          className:
            resolvedClassLevel ?
              fullLevelLabel(resolvedClassLevel)
            : normalizedClassName,
          classLevel: resolvedClassLevel,
          profile: student?.profile || {},
        };
      }

      function reportRecordWithStudent(record = {}, student = {}) {
        const eaglesId = normalizeText(student?.eaglesId);
        if (!eaglesId) return null;
        const studentNumber = parsePositiveInteger(student?.studentNumber);
        if (hasStudentNumberKey(student) && !studentNumber) return null;
        const fullName = canonicalStudentFullNameFromProfile(student?.profile);
        const englishName = canonicalStudentEnglishNameFromProfile(student?.profile);
        const resolvedClassLevel = resolveSystemLevelName(
          record?.level || record?.classLevel || student?.profile?.currentGrade || "",
        );
        const normalizedClassName = normalizeText(record?.className);
        return {
          ...record,
          studentRefId: normalizeText(student?.id),
          eaglesId,
          studentNumber: studentNumber || null,
          fullName,
          englishName,
          className:
            resolvedClassLevel ?
              fullLevelLabel(resolvedClassLevel)
            : normalizedClassName,
          classLevel: resolvedClassLevel,
          profile: student?.profile || {},
        };
      }

      function tableRowsFromStudentDetails(tableKey = "", students = []) {
        const source = Array.isArray(students) ? students : [];
        if (tableKey === "attendance") {
          return source
            .flatMap((student) =>
              (Array.isArray(student?.attendanceRecords) ?
                student.attendanceRecords
              : []
              ).map((row) => attendanceRecordWithStudent(row, student)),
            )
            .filter(Boolean);
        }
        if (tableKey === "grades") {
          return source
            .flatMap((student) =>
              (Array.isArray(student?.gradeRecords) ? student.gradeRecords : []).map(
                (row) => gradeRecordWithStudent(row, student),
              ),
            )
            .filter(Boolean);
        }
        if (tableKey === "performance" || tableKey === "reports") {
          return source
            .flatMap((student) =>
              (Array.isArray(student?.parentReports) ? student.parentReports : []).map(
                (row) => reportRecordWithStudent(row, student),
              ),
            )
            .filter(Boolean);
        }
        return [];
      }

      async function loadAdminDataRowsForTable(tableKey = "") {
        if (!["attendance", "performance", "grades", "reports"].includes(tableKey))
          return;
        if (tableKey === "attendance") ensureDefaultAttendanceDateRange();
        const candidates = studentsForAdminDataHydration(tableKey);
        if (!candidates.length) {
          state.tableRows[tableKey] = [];
          rerenderSortedTable(tableKey);
          return;
        }
        setAdminDataLoading(tableKey, true);
        try {
          const details = await mapWithConcurrency(
            candidates,
            async (student) => {
              try {
                return await ensureStudentDetailCached(student.id);
              } catch (error) {
                void error;
                return null;
              }
            },
            6,
          );
          state.tableRows[tableKey] = tableRowsFromStudentDetails(
            tableKey,
            details.filter((entry) => entry && typeof entry === "object"),
          );
        } finally {
          setAdminDataLoading(tableKey, false);
        }
        rerenderSortedTable(tableKey);
      }

      function tableFilterSelectedStudent(tableKey = "") {
        const source = tableFilterStudentSource(tableKey);
        if (!Array.isArray(source) || !source.length) return null;
        const selectedRefId = normalizeLower(
          tableFilterValue(tableKey, "studentRefId"),
        );
        if (!selectedRefId) return null;
        const match = source.find((student) => {
          const internalId = normalizeLower(student?.id);
          const publicStudentId = normalizeLower(student?.eaglesId);
          return internalId === selectedRefId || publicStudentId === selectedRefId;
        });
        if (match) return match;
        return null;
      }

      function updateTableFilterSummary(tableKey = "") {
        const summaryId = ADMIN_DATA_SUMMARY_IDS[tableKey];
        if (!summaryId) return;
        const summaryEl = document.getElementById(summaryId);
        if (!summaryEl) return;
        const isLoading = Boolean(state.adminDataLoading?.[tableKey]);
        if (isLoading) {
          summaryEl.textContent = `Loading ${tableLabelForKey(tableKey)} data...`;
          return;
        }
        const rowCount =
          Array.isArray(state.visibleTableRows?.[tableKey]) ?
            state.visibleTableRows[tableKey].length
          : 0;
        const summaryParts = [`${tableLabelForKey(tableKey)} rows: ${rowCount}`];
        const levelValue = tableFilterValue(tableKey, "level");
        summaryParts.push(
          levelValue ? `Level: ${fullLevelLabel(levelValue)}` : "Level: All",
        );
        const selectedStudent = tableFilterSelectedStudent(tableKey);
        if (selectedStudent) {
          const labelId = normalizeText(selectedStudent?.eaglesId);
          const labelNumber = studentDisplayNumber(selectedStudent);
          const labelFullName =
            normalizeText(studentFullName(selectedStudent)) || "(not set)";
          const labelEnglishName =
            normalizeText(studentEnglishName(selectedStudent)) || "(not set)";
          summaryParts.push(`Student: ${labelId || "(not set)"}`);
          if (labelNumber) summaryParts.push(`Student Number: ${labelNumber}`);
          summaryParts.push(`Full Name: ${labelFullName}`);
          summaryParts.push(`English Name: ${labelEnglishName}`);
        }
        const dateFrom = tableFilterValue(tableKey, "dateFrom");
        const dateTo = tableFilterValue(tableKey, "dateTo");
        if (dateFrom || dateTo)
          summaryParts.push(`Date: ${dateFrom || "..."} to ${dateTo || "..."}`);
        const searchValue = tableSearchTerm(tableKey);
        if (searchValue) summaryParts.push(`Search: "${searchValue}"`);
        summaryEl.textContent = summaryParts.join(" | ");
      }

      function allKnownStudentsForTopSearchOptions() {
        const source = baseStudentSource();
        const selectedLevel = resolveSystemLevelName(
          document.getElementById("filterLevel")?.value || "",
        );
        const selectedSchool = normalizeLower(
          document.getElementById("filterSchool")?.value || "",
        );
        const deduped = Array.from(
          new Map(
            source
              .filter((student) => {
                if (
                  selectedLevel &&
                  !levelNamesMatch(student?.profile?.currentGrade || "", selectedLevel)
                )
                  return false;
                if (selectedSchool) {
                  const schoolName = normalizeLower(student?.profile?.schoolName || "");
                  if (schoolName !== selectedSchool) return false;
                }
                return true;
              })
              .map((student) => [normalizeText(student?.id), student])
              .filter(([id]) => Boolean(id)),
          ).values(),
        );
        deduped.sort((left, right) =>
          studentDisplayName(left, { preferEnglish: true }).localeCompare(
            studentDisplayName(right, { preferEnglish: true }),
            undefined,
            { sensitivity: "base" },
          ),
        );
        return deduped;
      }

      function topSearchStudentOptionLabel(student = {}) {
        return normalizeText(student?.eaglesId);
      }

      function topSearchStudentOptionSummary(student = {}) {
        const eaglesId = normalizeText(student?.eaglesId);
        const studentNumber = studentDisplayNumber(student);
        const level =
          shortLevelLabel(student?.profile?.currentGrade || "") || "no level";
        return `${eaglesId}${studentNumber ? ` <${studentNumber}>` : ""} | ${level}`;
      }

      function rememberTopSearchOption(map, key, value) {
        const normalizedKey = normalizeLower(key);
        if (!normalizedKey) return;
        if (Object.prototype.hasOwnProperty.call(map, normalizedKey)) return;
        map[normalizedKey] = value;
      }

      function renderTopSearchStudentOptions() {
        const listEl = document.getElementById("searchStudentOptions");
        if (!(listEl instanceof HTMLDataListElement)) return;
        const source = allKnownStudentsForTopSearchOptions();
        const map = Object.create(null);
        const maxOptions = 1000;
        listEl.innerHTML = "";
        source.slice(0, maxOptions).forEach((student) => {
          const option = document.createElement("option");
          const value = topSearchStudentOptionLabel(student);
          option.value = value;
          option.label = topSearchStudentOptionSummary(student);
          listEl.appendChild(option);
          const mapped = {
            id: normalizeText(student?.id),
            eaglesId: normalizeText(student?.eaglesId),
            fullName: studentFullName(student),
            englishName: studentEnglishName(student),
            studentNumber: studentDisplayNumber(student),
            level: resolveSystemLevelName(student?.profile?.currentGrade || ""),
            school: normalizeText(student?.profile?.schoolName),
          };
          rememberTopSearchOption(map, value, mapped);
          rememberTopSearchOption(map, mapped.eaglesId, mapped);
          rememberTopSearchOption(map, mapped.fullName, mapped);
          rememberTopSearchOption(map, mapped.englishName, mapped);
        });
        state.topSearchOptionMap = map;
      }

      function resolveTopSearchStudentSelection(rawValue = "") {
        const query = normalizeText(rawValue);
        if (!query) return null;
        const key = normalizeLower(query);
        const optionMap =
          state.topSearchOptionMap && typeof state.topSearchOptionMap === "object" ?
            state.topSearchOptionMap
          : {};
        if (Object.prototype.hasOwnProperty.call(optionMap, key)) return optionMap[key];

        const source = allKnownStudentsForTopSearchOptions();
        const match = source.find((student) => {
          if (normalizeLower(student?.eaglesId) === key) return true;
          if (normalizeLower(studentFullName(student)) === key) return true;
          if (normalizeLower(studentEnglishName(student)) === key) return true;
          return normalizeLower(topSearchStudentOptionLabel(student)) === key;
        });
        if (!match) return null;
        return {
          id: normalizeText(match?.id),
          eaglesId: normalizeText(match?.eaglesId),
          fullName: studentFullName(match),
          englishName: studentEnglishName(match),
          studentNumber: studentDisplayNumber(match),
          level: resolveSystemLevelName(match?.profile?.currentGrade || ""),
          school: normalizeText(match?.profile?.schoolName),
        };
      }

      function normalizeTopSearchQuery(rawValue = "") {
        const selected = resolveTopSearchStudentSelection(rawValue);
        if (selected?.eaglesId) return selected.eaglesId;
        return normalizeText(rawValue);
      }

      function updateTopSearchScopeHint() {
        const hintEl = document.getElementById("topSearchScopeHint");
        if (!hintEl) return;
        const scope = topStudentScopeState();
        const activePage = normalizePageSlug(state.activePage);
        const source = studentSourceForPage(activePage);
        const pageLabel = normalizeText(
          document.querySelector(`[data-page-link="${activePage}"]`)?.textContent ||
            activePage ||
            "current page",
        );
        if (!pageUsesTopStudentScope(activePage)) {
          hintEl.textContent = `Top search is ready. Student-centric pages can use the scoped result set.`;
          return;
        }
        if (!hasTopStudentScope(scope)) {
          hintEl.textContent = `${pageLabel}: top search scope is inactive. Using all students.`;
          return;
        }
        const filters = [];
        if (scope.query) filters.push(`query="${scope.query}"`);
        if (scope.level) filters.push(`level=${fullLevelLabel(scope.level)}`);
        if (scope.school) filters.push(`school=${scope.school}`);
        const count = Array.isArray(source) ? source.length : 0;
        hintEl.textContent = `${pageLabel}: scoped ${count} student${count === 1 ? "" : "s"}${filters.length ? ` (${filters.join(", ")})` : ""}.`;
      }

      function tableFilterStudentsForLevel(tableKey = "") {
        const selectedLevel = resolveSystemLevelName(
          tableFilterValue(tableKey, "level"),
        );
        const source = tableFilterStudentSource(tableKey);
        if (!selectedLevel) return source;
        return source.filter((student) =>
          levelNamesMatch(student?.profile?.currentGrade || "", selectedLevel),
        );
      }

      function tableRowFilterContext(tableKey = "", row = {}) {
        const rowProfile = row?.profile || {};
        return {
          levels: [
            normalizeText(row?.level),
            normalizeText(row?.classLevel),
            normalizeText(row?.className),
            normalizeText(row?.currentGrade),
            normalizeText(rowProfile?.currentGrade),
          ].filter(Boolean),
          studentRefIds: [
            normalizeText(row?.studentRefId),
            normalizeText(row?.eaglesId),
            normalizeText(row?.studentCode),
            normalizeText(rowProfile?.eaglesId),
            normalizeText(rowProfile?.studentRefId),
          ]
            .map((entry) => normalizeLower(entry))
            .filter(Boolean),
        };
      }

      function tableRowDateValue(tableKey = "", row = {}) {
        if (tableKey === "attendance")
          return normalizeText(row?.attendanceDate).slice(0, 10);
        if (tableKey === "assignments") {
          const dueAt = normalizeText(row?.dueAt).slice(0, 10);
          if (dueAt) return dueAt;
          return normalizeText(row?.assignedAt).slice(0, 10);
        }
        if (tableKey === "grades") {
          const dueAt = normalizeText(row?.dueAt).slice(0, 10);
          if (dueAt) return dueAt;
          return normalizeText(row?.submittedAt).slice(0, 10);
        }
        return normalizeText(row?.generatedAt).slice(0, 10);
      }

      function rowWeekNumber(tableKey = "", row = {}) {
        const persisted = Number.parseInt(String(row?.weekNumber ?? ""), 10);
        if (Number.isInteger(persisted) && persisted >= 1 && persisted <= 52) return persisted;
        const setup = state.uiSettings?.schoolSetup || {};
        const schoolYear = normalizeText(row?.schoolYear || setup?.schoolYear);
        const calendar = (Array.isArray(setup?.courseWeekCalendars) ? setup.courseWeekCalendars : [])
          .find((entry) => normalizeText(entry?.schoolYear) === schoolYear);
        const date = tableRowDateValue(tableKey, row);
        const week = (Array.isArray(calendar?.weeks) ? calendar.weeks : [])
          .find((entry) => date && date >= entry.startDate && date <= entry.endDate);
        return Number.isInteger(Number(week?.weekNumber)) ? Number(week.weekNumber) : null;
      }

      function weekSearchLabel(tableKey = "", row = {}) {
        const week = rowWeekNumber(tableKey, row);
        return week ? `Week ${week} W${week}` : "";
      }

      function rowMatchesTableFilters(tableKey = "", row = {}) {
        if (!DATA_TABLE_KEYS.includes(tableKey)) return true;
        const context = tableRowFilterContext(tableKey, row);

        const levelFilter = resolveSystemLevelName(tableFilterValue(tableKey, "level"));
        if (levelFilter) {
          const levelFull = normalizeLower(fullLevelLabel(levelFilter));
          const levelShort = normalizeLower(shortLevelLabel(levelFilter));
          const levelMatched = context.levels.some((entry) => {
            if (levelNamesMatch(entry, levelFilter)) return true;
            const raw = normalizeLower(entry);
            if (!raw) return false;
            return raw.includes(levelFull) || raw.includes(levelShort);
          });
          if (!levelMatched) return false;
        }

        const studentRefFilter = normalizeLower(
          tableFilterValue(tableKey, "studentRefId"),
        );
        if (studentRefFilter) {
          let matched = context.studentRefIds.some(
            (entry) => entry === studentRefFilter,
          );
          if (!matched && tableKey === "assignments") {
            const selectedStudent = tableFilterSelectedStudent(tableKey);
            const targeted = normalizeLower(normalizeText(row?.eaglesId));
            if (targeted) {
              const selectedPublicId = normalizeLower(selectedStudent?.eaglesId);
              matched =
                targeted === studentRefFilter ||
                (selectedPublicId && targeted === selectedPublicId);
            } else if (selectedStudent) {
              const selectedLevel = resolveSystemLevelName(
                selectedStudent?.profile?.currentGrade || "",
              );
              const rowLevel = resolveSystemLevelName(
                row?.level || row?.classLevel || row?.className || "",
              );
              matched = Boolean(
                selectedLevel && rowLevel && levelNamesMatch(rowLevel, selectedLevel),
              );
            }
          }
          if (!matched) return false;
        }

        const dateFrom = normalizeText(tableFilterValue(tableKey, "dateFrom")).slice(
          0,
          10,
        );
        const dateTo = normalizeText(tableFilterValue(tableKey, "dateTo")).slice(0, 10);
        if (dateFrom || dateTo) {
          const rowDate = tableRowDateValue(tableKey, row);
          if (!rowDate) return false;
          if (dateFrom && compareIsoDateText(rowDate, dateFrom) < 0) return false;
          if (dateTo && compareIsoDateText(rowDate, dateTo) > 0) return false;
        }

        const weekFilter = Number.parseInt(tableFilterValue(tableKey, "weekNumber"), 10);
        if (Number.isInteger(weekFilter) && rowWeekNumber(tableKey, row) !== weekFilter) return false;

        return true;
      }

      function validateStudentIdFilterInput(inputEl, { report = false } = {}) {
        if (!inputEl) return true;
        const normalized = normalizeStudentIdSearchValue(inputEl.value);
        if (inputEl.value !== normalized) inputEl.value = normalized;
        if (!normalized) {
          inputEl.setCustomValidity("");
          return true;
        }
        if (isValidStudentIdSearchValue(normalized)) {
          inputEl.setCustomValidity("");
          return true;
        }
        inputEl.setCustomValidity(
          "Use lowercase letters (max 10) plus 3 digits (e.g. steve001) or numeric ID.",
        );
        if (report) inputEl.reportValidity();
        return false;
      }

      function rowMatchesSearchTerm(tableKey = "", rowSearchText = "") {
        const searchTerm = tableSearchTerm(tableKey);
        if (!searchTerm) return true;
        const haystack = normalizeSearchComparable(rowSearchText);
        return haystack.includes(searchTerm);
      }

      function filterRowsForTable(
        tableKey = "",
        rows = [],
        searchTextResolver = () => "",
      ) {
        const list = Array.isArray(rows) ? rows : [];
        const showArchived =
          tableKey === "performance" ?
            false
          : Boolean(state.tableShowArchived?.[tableKey]);
        return list.filter((row) => {
          const rowId = normalizeText(row?.id);
          const archived = isTableRecordArchived(tableKey, rowId);
          if (tableKey !== "performance") {
            if (showArchived) {
              if (!archived) return false;
            } else if (archived) {
              return false;
            }
          }
          if (!rowMatchesTableFilters(tableKey, row)) return false;
          return rowMatchesSearchTerm(tableKey, searchTextResolver(row));
        });
      }

      function assignmentItemsSummaryText(template = {}) {
        const items = normalizeAssignmentItems(template?.items);
        if (!items.length) return "";
        return items
          .map(
            (entry) =>
              `${entry.done ? "[x]" : "[ ]"} ${entry.title || ""} ${entry.url || ""}`,
          )
          .join(" | ");
      }

      function attendanceRowSearchText(row = {}) {
        return [
          normalizeText(row?.fullName),
          normalizeText(row?.englishName),
          normalizeText(row?.studentNumber),
          normalizeText(row?.eaglesId),
          normalizeText(row?.classLevel),
          normalizeText(row?.attendanceDate),
          normalizeText(row?.className),
          normalizeText(row?.quarter),
          normalizeText(row?.status),
          normalizeText(row?.comments),
          weekSearchLabel("attendance", row),
        ].join(" ");
      }

      function assignmentRowSearchText(row = {}) {
        return [
          normalizeText(row?.assignmentTitle || row?.exerciseTitle),
          normalizeText(row?.level),
          normalizeText(row?.eaglesId),
          normalizeText(row?.assignedAt),
          normalizeText(row?.dueAt),
          assignmentItemsSummaryText(row),
          weekSearchLabel("assignments", row),
        ].join(" ");
      }

      function gradeRowSearchText(row = {}) {
        return [
          normalizeText(row?.fullName),
          normalizeText(row?.englishName),
          normalizeText(row?.studentNumber),
          normalizeText(row?.eaglesId),
          normalizeText(row?.classLevel),
          normalizeText(row?.dueAt),
          normalizeText(row?.className),
          normalizeText(row?.assignmentName),
          normalizeText(row?.score),
          normalizeText(row?.maxScore),
          normalizeText(row?.comments),
          weekSearchLabel("grades", row),
        ].join(" ");
      }

      function reportRowSearchText(row = {}) {
        return [
          normalizeText(row?.fullName),
          normalizeText(row?.englishName),
          normalizeText(row?.studentNumber),
          normalizeText(row?.eaglesId),
          normalizeText(row?.classLevel),
          normalizeText(row?.generatedAt),
          normalizeText(row?.className),
          normalizeText(row?.quarter),
          normalizeText(row?.homeworkCompletionRate),
          normalizeText(row?.homeworkOnTimeRate),
          normalizeText(row?.behaviorScore),
          normalizeText(row?.participationScore),
          normalizeText(row?.inClassScore),
          normalizeText(row?.comments),
          weekSearchLabel("reports", row),
        ].join(" ");
      }

      function assertAdminDataActionsAllowed() {
        if (currentRoleName() !== "admin") {
          const error = new Error(
            "Admin role required for data archive/export/print actions.",
          );
          error.status = 403;
          throw error;
        }
      }

      function requiredEaglesId(value = "", contextLabel = "") {
        const eaglesId = normalizeText(value);
        if (eaglesId) return eaglesId;
        const context = normalizeText(contextLabel);
        throw new Error(`eaglesId is required${context ? ` (${context})` : ""}`);
      }

      function requiredStudentNumber(value = "", contextLabel = "") {
        const studentNumber = parsePositiveInteger(value);
        if (studentNumber) return studentNumber;
        const context = normalizeText(contextLabel);
        throw new Error(`studentNumber is required${context ? ` (${context})` : ""}`);
      }

      function tableExportColumns(tableKey = "") {
        if (tableKey === "attendance") {
          return [
            { key: "eaglesId", label: "Eagles ID" },
            { key: "studentNumber", label: "Student Number" },
            { key: "fullName", label: "Full Name" },
            { key: "englishName", label: "English Name" },
            { key: "date", label: "Date" },
            { key: "weekNumber", label: "Week" },
            { key: "className", label: "Class" },
            { key: "quarter", label: "Quarter" },
            { key: "status", label: "Status" },
            { key: "comments", label: "Comments" },
          ];
        }
        if (tableKey === "assignments") {
          return [
            { key: "assignment", label: "Assignment" },
            { key: "level", label: "Level" },
            { key: "eaglesId", label: "Eagles ID" },
            { key: "studentNumber", label: "Student Number" },
            { key: "fullName", label: "Full Name" },
            { key: "englishName", label: "English Name" },
            { key: "assignedAt", label: "Assigned" },
            { key: "dueAt", label: "Due" },
            { key: "weekNumber", label: "Week" },
            { key: "completion", label: "Completion" },
            { key: "items", label: "Items" },
          ];
        }
        if (tableKey === "grades") {
          return [
            { key: "eaglesId", label: "Eagles ID" },
            { key: "studentNumber", label: "Student Number" },
            { key: "fullName", label: "Full Name" },
            { key: "englishName", label: "English Name" },
            { key: "dueAt", label: "Due" },
            { key: "weekNumber", label: "Week" },
            { key: "className", label: "Class" },
            { key: "assignmentName", label: "Assignment" },
            { key: "score", label: "Score" },
            { key: "homework", label: "HW" },
            { key: "behavior", label: "Behavior" },
            { key: "participation", label: "Participation" },
            { key: "inClass", label: "In Class" },
            { key: "comments", label: "Comments" },
          ];
        }
        return [
          { key: "eaglesId", label: "Eagles ID" },
          { key: "studentNumber", label: "Student Number" },
          { key: "fullName", label: "Full Name" },
          { key: "englishName", label: "English Name" },
          { key: "generatedAt", label: "Generated" },
          { key: "weekNumber", label: "Week" },
          { key: "className", label: "Class" },
          { key: "quarter", label: "Quarter" },
          { key: "homeworkCompletionRate", label: "HW %" },
          { key: "homeworkOnTimeRate", label: "On-Time %" },
          { key: "behaviorScore", label: "Behavior" },
          { key: "participationScore", label: "Participation" },
          { key: "inClassScore", label: "In Class" },
          { key: "comments", label: "Comments" },
        ];
      }

      function mapTableExportRow(tableKey = "", row = {}) {
        if (tableKey === "attendance") {
          const eaglesId = requiredEaglesId(row?.eaglesId, "attendance export row");
          const studentNumber = requiredStudentNumber(
            row?.studentNumber,
            "attendance export row",
          );
          return {
            eaglesId,
            studentNumber,
            fullName: canonicalStudentFullNameFromRow(row),
            englishName: canonicalStudentEnglishNameFromRow(row),
            date: normalizeText(row?.attendanceDate).slice(0, 10),
            weekNumber: rowWeekNumber("attendance", row) || "",
            className: normalizeText(row?.className),
            quarter: normalizeText(row?.quarter),
            status: normalizeText(row?.status),
            comments: normalizeText(row?.comments),
          };
        }
        if (tableKey === "assignments") {
          const completion = assignmentCompletionFromItems(row?.items);
          const completionText =
            completion.total ? `${completion.done}/${completion.total}` : "0/0";
          const rowEaglesId = requiredEaglesId(row?.eaglesId, "assignment export row");
          const assignmentStudent = tableFilterStudentSource("assignments").find(
            (student) => {
              const optionValue = tableFilterStudentOptionValue(student);
              if (!optionValue) return false;
              if (normalizeLower(optionValue) === normalizeLower(rowEaglesId))
                return true;
              return normalizeLower(student?.eaglesId) === normalizeLower(rowEaglesId);
            },
          );
          const fullName = canonicalStudentFullNameFromProfile(
            assignmentStudent?.profile,
          );
          const englishName = canonicalStudentEnglishNameFromProfile(
            assignmentStudent?.profile,
          );
          const eaglesId = rowEaglesId;
          const studentNumber = requiredStudentNumber(
            assignmentStudent?.studentNumber,
            "assignment export row",
          );
          return {
            assignment: normalizeText(row?.assignmentTitle || row?.exerciseTitle),
            level: fullLevelLabel(row?.level || ""),
            eaglesId,
            studentNumber,
            fullName,
            englishName,
            assignedAt: normalizeText(row?.assignedAt),
            dueAt: normalizeText(row?.dueAt),
            weekNumber: rowWeekNumber("assignments", row) || "",
            completion: completionText,
            items: assignmentItemsSummaryText(row),
          };
        }
        if (tableKey === "grades") {
          const eaglesId = requiredEaglesId(row?.eaglesId, "grade export row");
          const studentNumber = requiredStudentNumber(
            row?.studentNumber,
            "grade export row",
          );
          return {
            eaglesId,
            studentNumber,
            fullName: canonicalStudentFullNameFromRow(row),
            englishName: canonicalStudentEnglishNameFromRow(row),
            dueAt: normalizeText(row?.dueAt).slice(0, 10),
            weekNumber: rowWeekNumber("grades", row) || "",
            className: normalizeText(row?.className),
            assignmentName: normalizeText(row?.assignmentName),
            score: `${normalizeText(row?.score)}/${normalizeText(row?.maxScore)}`,
            homework:
              row?.homeworkCompleted === true ? "Yes"
              : row?.homeworkCompleted === false ? "No"
              : "",
            behavior: normalizeText(row?.behaviorScore),
            participation: normalizeText(row?.participationScore),
            inClass: normalizeText(row?.inClassScore),
            comments: normalizeText(row?.comments),
          };
        }
        const eaglesId = requiredEaglesId(row?.eaglesId, "report export row");
        const studentNumber = requiredStudentNumber(
          row?.studentNumber,
          "report export row",
        );
        return {
          eaglesId,
          studentNumber,
          fullName: canonicalStudentFullNameFromRow(row),
          englishName: canonicalStudentEnglishNameFromRow(row),
          generatedAt: normalizeText(row?.generatedAt).slice(0, 10),
          weekNumber: rowWeekNumber("reports", row) || "",
          className: normalizeText(row?.className),
          quarter: normalizeText(row?.quarter),
          homeworkCompletionRate: normalizeText(row?.homeworkCompletionRate),
          homeworkOnTimeRate: normalizeText(row?.homeworkOnTimeRate),
          behaviorScore: normalizeText(row?.behaviorScore),
          participationScore: normalizeText(row?.participationScore),
          inClassScore: normalizeText(row?.inClassScore),
          comments: normalizeText(row?.comments),
        };
      }

      function visibleRowsForTable(tableKey = "") {
        const rows = state.visibleTableRows?.[tableKey];
        return Array.isArray(rows) ? rows : [];
      }

      function tableExportFilename(tableKey = "") {
        const safeTable =
          normalizeLower(tableKey).replace(/[^a-z0-9]+/g, "-") || "data";
        const studentPart = normalizeText(state.currentStudent?.eaglesId || "student")
          .replace(/[^a-zA-Z0-9]+/g, "-")
          .replace(/^-+|-+$/g, "");
        const datePart = localIsoDate() || "export";
        const stem = studentPart ? `${studentPart}-${safeTable}` : safeTable;
        return `${stem}-${datePart}.xlsx`;
      }

      async function exportVisibleTableRowsToXlsx(tableKey = "") {
        assertAdminDataActionsAllowed();
        if (!DATA_TABLE_KEYS.includes(tableKey))
          throw new Error("Unsupported data table for XLSX export.");
        const sourceRows = visibleRowsForTable(tableKey);
        if (!sourceRows.length)
          throw new Error(`No ${tableLabelForKey(tableKey)} rows to export.`);
        const columns = tableExportColumns(tableKey);
        const rows = sourceRows.map((row) => mapTableExportRow(tableKey, row));
        const payload = {
          filename: tableExportFilename(tableKey),
          sheetName: tableLabelForKey(tableKey),
          columns,
          rows,
        };
        const response = await fetch(resolveApiUrl("/api/admin/exports/xlsx"), {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        });
        if (!response.ok) {
          let message = `HTTP ${response.status}`;
          try {
            const apiError = await response.json();
            if (apiError?.error) message = apiError.error;
          } catch (error) {
            void error;
          }
          const err = new Error(message);
          err.status = response.status;
          throw err;
        }
        const blob = await response.blob();
        const disposition = response.headers.get("content-disposition") || "";
        const suggestedName = parseFilenameFromDisposition(disposition);
        const downloadUrl = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = downloadUrl;
        link.download = suggestedName || payload.filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(downloadUrl);
        setStatus(`${tableLabelForKey(tableKey)} XLSX export downloaded.`);
      }

      function printVisibleTableRowsPdf(tableKey = "") {
        assertAdminDataActionsAllowed();
        if (!DATA_TABLE_KEYS.includes(tableKey))
          throw new Error("Unsupported data table for print.");
        const sourceRows = visibleRowsForTable(tableKey);
        if (!sourceRows.length)
          throw new Error(`No ${tableLabelForKey(tableKey)} rows to print.`);
        const columns = tableExportColumns(tableKey);
        const rows = sourceRows.map((row) => mapTableExportRow(tableKey, row));
        const headerHtml = columns
          .map((column) => `<th>${escapeHtml(column.label)}</th>`)
          .join("");
        const bodyHtml = rows
          .map(
            (row) =>
              `<tr>${columns.map((column) => `<td>${escapeHtml(row[column.key] ?? "")}</td>`).join("")}</tr>`,
          )
          .join("");
        const filterSummaryId = ADMIN_DATA_SUMMARY_IDS[tableKey];
        const filterSummary = normalizeText(
          document.getElementById(filterSummaryId)?.textContent || "",
        );
        const popup = window.open(
          "",
          "_blank",
          "noopener,noreferrer,width=1024,height=768",
        );
        if (!popup) throw new Error("Popup blocked. Allow popups to print PDF.");
        popup.document.open();
        popup.document.write(`<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>${escapeHtml(tableLabelForKey(tableKey))} Data Export</title>
    <style>
      body { font-family:  var(--font-base, system-ui, -apple-system, sans-serif); margin: 20px; color: #222; }
      h1 { margin: 0 0 8px; font-size: 20px; }
      p { margin: 0 0 14px; font-size: 12px; color: #555; }
      table { width: 100%; border-collapse: collapse; font-size: 12px; }
      th, td { border: 1px solid #ccc; padding: 6px; text-align: left; vertical-align: top; }
      th { background: #f5f7fb; }
    </style>
  </head>
  <body>
    <h1>${escapeHtml(tableLabelForKey(tableKey))} Data</h1>
    <p>Printed: ${escapeHtml(formatDateTime(new Date()))}</p>
    ${filterSummary ? `<p>Filters: ${escapeHtml(filterSummary)}</p>` : ""}
    <table>
      <thead><tr>${headerHtml}</tr></thead>
      <tbody>${bodyHtml}</tbody>
    </table>
`)
        popup.document.write("</bo" + "dy></ht" + "ml>");
        popup.document.close();
        popup.focus();
        popup.print();
        setStatus(`${tableLabelForKey(tableKey)} opened for PDF print.`);
      }

      function toggleTableArchivedView(tableKey = "") {
        assertAdminDataActionsAllowed();
        if (!DATA_TABLE_KEYS.includes(tableKey)) return;
        state.tableShowArchived[tableKey] = !Boolean(
          state.tableShowArchived?.[tableKey],
        );
        updateArchiveToggleButton(tableKey);
        rerenderSortedTable(tableKey);
      }

      function applySortState(sortKey, field, options = {}) {
        const { toggleIfSame = false, resetDirOnFieldChange = false } = options;
        if (!sortKey || !field) return;
        const current = state.tableSort?.[sortKey] || { field: "", dir: "desc" };
        const sameField = normalizeText(current.field) === normalizeText(field);
        if (sameField && toggleIfSame) {
          current.dir = toggledSortDirection(current.dir);
        } else {
          current.field = normalizeText(field);
          if (!sameField && resetDirOnFieldChange) current.dir = "desc";
        }
        if (normalizeLower(current.dir) !== "asc") current.dir = "desc";
        state.tableSort[sortKey] = current;
        updateTableSortButtonLabels();
        updateTableHeaderSortIndicators();
      }

      function rerenderSortedTable(sortKey = "") {
        if (sortKey === "attendance") renderAttendanceRows(state.tableRows.attendance);
        else if (sortKey === "assignments") renderAssignmentTemplates();
        else if (sortKey === "performance")
          renderParentTrackingReportRows(
            state.tableRows.performance,
            state.currentStudent,
          );
        else if (sortKey === "grades") renderGradeRows(state.tableRows.grades);
        else if (sortKey === "reports") renderReportRows(state.tableRows.reports);
        else if (sortKey === "newsReview") renderNewsReviewRows();
        else if (sortKey === "assignmentEngagement") assignmentEngagementIsland?.render();
      }

      function bindColumnSortHeaderEvents() {
        document
          .querySelectorAll("th[data-table-sort][data-sort-field]")
          .forEach((thEl) => {
            if (thEl.dataset.sortBound === "1") return;
            thEl.dataset.sortBound = "1";
            const onSort = () => {
              const sortKey = normalizeText(thEl.getAttribute("data-table-sort"));
              const field = normalizeText(thEl.getAttribute("data-sort-field"));
              if (!sortKey || !field) return;
              applySortState(sortKey, field, {
                toggleIfSame: true,
                resetDirOnFieldChange: true,
              });
              rerenderSortedTable(sortKey);
            };
            thEl.addEventListener("click", onSort);
            thEl.addEventListener("keydown", (event) => {
              if (event.key !== "Enter" && event.key !== " ") return;
              event.preventDefault();
              onSort();
            });
          });
      }

      function updateTableHeaderSortIndicators() {
        document
          .querySelectorAll("th[data-table-sort][data-sort-field]")
          .forEach((thEl) => {
            const sortKey = normalizeText(thEl.getAttribute("data-table-sort"));
            const field = normalizeText(thEl.getAttribute("data-sort-field"));
            const activeState = state.tableSort?.[sortKey] || {
              field: "",
              dir: "desc",
            };
            const active = normalizeText(activeState.field) === field;
            const ascending = normalizeLower(activeState.dir) === "asc";
            thEl.classList.toggle("sort-active-asc", active && ascending);
            thEl.classList.toggle("sort-active-desc", active && !ascending);
            thEl.setAttribute(
              "aria-sort",
              active ?
                ascending ? "ascending"
                : "descending"
              : "none",
            );
          });
      }

      function updateTableSortButtonLabels() {
        const attendanceSelect = document.getElementById("attendanceSortField");
        if (attendanceSelect)
          attendanceSelect.value =
            normalizeText(state.tableSort?.attendance?.field) || "attendanceDate";
        const attendanceBtn = document.getElementById("attendanceSortDirBtn");
        if (attendanceBtn)
          attendanceBtn.textContent =
            normalizeLower(state.tableSort?.attendance?.dir) === "asc" ? "Oldest First"
            : "Newest First";
        const assignmentSelect = document.getElementById("assignmentSortField");
        if (assignmentSelect)
          assignmentSelect.value =
            normalizeText(state.tableSort?.assignments?.field) || "dueAt";
        const assignmentBtn = document.getElementById("assignmentSortDirBtn");
        if (assignmentBtn)
          assignmentBtn.textContent =
            normalizeLower(state.tableSort?.assignments?.dir) === "asc" ?
              "Oldest Due First"
            : "Newest Due First";
        const performanceSelect = document.getElementById("performanceSortField");
        if (performanceSelect)
          performanceSelect.value =
            normalizeText(state.tableSort?.performance?.field) || "generatedAt";
        const performanceBtn = document.getElementById("performanceSortDirBtn");
        if (performanceBtn)
          performanceBtn.textContent =
            normalizeLower(state.tableSort?.performance?.dir) === "asc" ? "Oldest First"
            : "Newest First";
        const gradeSelect = document.getElementById("gradeSortField");
        if (gradeSelect)
          gradeSelect.value = normalizeText(state.tableSort?.grades?.field) || "dueAt";
        const gradeBtn = document.getElementById("gradeSortDirBtn");
        if (gradeBtn)
          gradeBtn.textContent =
            normalizeLower(state.tableSort?.grades?.dir) === "asc" ?
              "Earliest Due First"
            : "Latest Due First";
        const reportSelect = document.getElementById("reportSortField");
        if (reportSelect)
          reportSelect.value =
            normalizeText(state.tableSort?.reports?.field) || "generatedAt";
        const reportBtn = document.getElementById("reportSortDirBtn");
        if (reportBtn)
          reportBtn.textContent =
            normalizeLower(state.tableSort?.reports?.dir) === "asc" ? "Oldest First" : (
              "Newest First"
            );
      }

      function levelNamesMatch(left, right) {
        const leftKey = levelNameKey(resolveSystemLevelName(left));
        const rightKey = levelNameKey(resolveSystemLevelName(right));
        if (!leftKey || !rightKey) return false;
        return leftKey === rightKey;
      }

      function parseHexRgb(value) {
        const text = normalizeText(value);
        const short = text.match(/^#([a-fA-F0-9]{3})$/);
        if (short) {
          const digits = short[1];
          return {
            r: Number.parseInt(digits[0] + digits[0], 16),
            g: Number.parseInt(digits[1] + digits[1], 16),
            b: Number.parseInt(digits[2] + digits[2], 16),
          };
        }
        const full = text.match(/^#([a-fA-F0-9]{6})$/);
        if (!full) return null;
        const digits = full[1];
        return {
          r: Number.parseInt(digits.slice(0, 2), 16),
          g: Number.parseInt(digits.slice(2, 4), 16),
          b: Number.parseInt(digits.slice(4, 6), 16),
        };
      }

      function clampColorByte(value) {
        const parsed = Number(value);
        if (!Number.isFinite(parsed)) return 0;
        return Math.max(0, Math.min(255, Math.round(parsed)));
      }

      function rgbToHex(r, g, b) {
        const toHex = (value) => clampColorByte(value).toString(16).padStart(2, "0");
        return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
      }

      function shiftHexColor(hexColor, delta = 0) {
        const rgb = parseHexRgb(hexColor);
        if (!rgb) return hexColor;
        return rgbToHex(rgb.r + delta, rgb.g + delta, rgb.b + delta);
      }

      function toRgba(hexColor, alpha = 1) {
        const rgb = parseHexRgb(hexColor);
        if (!rgb) return hexColor;
        const a = Math.max(0, Math.min(1, Number(alpha)));
        return `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${a})`;
      }

      function preferredContrastText(hexColor) {
        const rgb = parseHexRgb(hexColor);
        if (!rgb) return "#f5f8ff";
        const contrastRatio = (left, right) => {
          const normalize = (value) => {
            const channel = value / 255;
            return channel <= 0.03928 ?
                channel / 12.92
              : ((channel + 0.055) / 1.055) ** 2.4;
          };
          const luminance =
            0.2126 * normalize(left.r) +
            0.7152 * normalize(left.g) +
            0.0722 * normalize(left.b);
          const reference =
            0.2126 * normalize(right.r) +
            0.7152 * normalize(right.g) +
            0.0722 * normalize(right.b);
          const light = Math.max(luminance, reference);
          const dark = Math.min(luminance, reference);
          return (light + 0.05) / (dark + 0.05);
        };
        const darkText = { r: 11, g: 18, b: 32 };
        const lightText = { r: 245, g: 248, b: 255 };
        return contrastRatio(rgb, darkText) >= contrastRatio(rgb, lightText) ?
            "#0b1220"
          : "#f5f8ff";
      }

      function levelSurfaceStyle(theme = {}, { includeDot = false } = {}) {
        const bgColor = normalizeText(theme?.color || "#002786");
        const borderColor = normalizeText(theme?.borderColor || shiftHexColor(bgColor, -42));
        const textColor = normalizeText(theme?.textColor || preferredContrastText(bgColor));
        const tokens = [
          `--chip-bg:${bgColor}`,
          `--chip-border:${borderColor}`,
          `--chip-text:${textColor}`,
        ];
        if (includeDot) {
          tokens.push(`--chip-dot:${toRgba(textColor, 0.95)}`);
        }
        return tokens.join(";");
      }

      function tileTitleBackground(theme = {}) {
        const textColor = normalizeLower(theme?.textColor);
        return textColor === "#0b1220" ?
            "rgba(255, 255, 255, 0.28)"
          : "rgba(0, 0, 0, 0.24)";
      }

      function getLevelTheme(levelName) {
        const canonical = resolveSystemLevelName(levelName);
        const canonicalKey = levelNameKey(canonical);
        const fullKey = levelNameKey(fullLevelLabel(canonical));
        const matched =
          LEVEL_THEME_LOOKUP.get(canonicalKey) || LEVEL_THEME_LOOKUP.get(fullKey);
        const color = matched?.color || "#002786";
        return {
          color,
          className: matched?.className || "",
          borderColor: shiftHexColor(color, -42),
          softColor: toRgba(color, 0.18),
          textColor: normalizeText(matched?.textColor) || preferredContrastText(color),
        };
      }

      function levelChipClass(levelName) {
        const theme = getLevelTheme(levelName);
        return theme.className || "";
      }

      function studentDisplayLevel(student = {}) {
        return resolveSystemLevelName(
          student?.profile?.currentGrade ||
            student?.currentEnrollment?.level ||
            student?.currentGrade ||
            student?.classLevel ||
            student?.level ||
            "",
        );
      }

      function studentNeedsEnrollment(student = {}) {
        const currentEnrollment =
          student?.currentEnrollment && typeof student.currentEnrollment === "object" ?
            student.currentEnrollment
          : null;
        if (!currentEnrollment) return true;
        return normalizeLower(currentEnrollment.status) === "unenrolled";
      }

      function studentEnrollmentWarningHtml(student = {}) {
        if (!studentNeedsEnrollment(student)) return "";
        return '<span class="student-enrollment-warning" role="status" title="No enrollment or class is assigned. Use Include unenrolled to find this student.">Warning: no enrollment</span>';
      }

      function levelBadgeHtml(levelName, { full = false, variant = "" } = {}) {
        const label = full ? fullLevelLabel(levelName) : shortLevelLabel(levelName);
        const variantToken = normalizeText(variant)
          .toLowerCase()
          .replace(/[^a-z0-9_-]/g, "");
        const theme = getLevelTheme(levelName);
        const chipClass = theme.className || "";
        const classes = ["level-chip", chipClass, "level-chip-standard"].filter(Boolean).join(" ");
        const style = levelSurfaceStyle(theme);
        if (variantToken === "standard") {
          return `<span class="${classes}" style="${style}">${escapeHtml(label)}</span>`;
        }
        return `<span class="${classes.replace(/\blevel-chip-standard\b/, "").trim()}" style="${style}">${escapeHtml(label)}</span>`;
      }

      function resetSectionLevelAccents() {
        document.querySelectorAll(".page-section.level-accent").forEach((section) => {
          section.classList.remove("level-accent");
          section.style.removeProperty("--level-page-border");
          section.style.removeProperty("--level-page-shadow");
          section.style.removeProperty("--level-page-title");
        });
      }

      function applyLevelThemeToSections(levelName) {
        const normalized = normalizeLevelName(levelName);
        if (!normalized) {
          resetSectionLevelAccents();
          return;
        }
        const theme = getLevelTheme(normalized);
        document.querySelectorAll(".page-section[data-page]").forEach((section) => {
          const page = normalizeLower(section?.dataset?.page || "");
          const themed = LEVEL_ACCENTED_PAGE_SET.has(page);
          if (!themed) {
            section.classList.remove("level-accent");
            section.style.removeProperty("--level-page-border");
            section.style.removeProperty("--level-page-shadow");
            section.style.removeProperty("--level-page-title");
            return;
          }
          section.classList.add("level-accent");
          section.style.setProperty("--level-page-border", theme.borderColor);
          section.style.setProperty("--level-page-shadow", theme.softColor);
          section.style.setProperty(
            "--level-page-title",
            shiftHexColor(theme.color, -52),
          );
        });
      }

      function applyLevelThemeToDetailPanel(levelName) {
        const panel = document.getElementById("levelDetailPanel");
        if (!panel) return;
        if (!normalizeLevelName(levelName)) {
          panel.style.removeProperty("--level-panel-border");
          panel.style.removeProperty("--level-panel-shadow");
          panel.style.removeProperty("--level-panel-title");
          panel.style.removeProperty("--level-panel-accent");
          return;
        }
        const theme = getLevelTheme(levelName);
        panel.style.setProperty("--level-panel-border", theme.borderColor);
        panel.style.setProperty("--level-panel-shadow", theme.softColor);
        panel.style.setProperty("--level-panel-title", shiftHexColor(theme.color, -56));
        panel.style.setProperty("--level-panel-accent", theme.color);
      }

      function collectKnownLevelNames(extraValues = []) {
        const studentLevels = (Array.isArray(state.students) ? state.students : []).map(
          (student) => normalizeLevelName(student?.profile?.currentGrade || ""),
        );
        const dashboardStudentLevels = (
          Array.isArray(state.dashboardStudents) ?
            state.dashboardStudents
          : []).map((student) =>
          normalizeLevelName(student?.profile?.currentGrade || ""),
        );
        const completionLevels = (
          (
            Array.isArray(state.dashboardLevelCompletionRows) &&
            state.dashboardLevelCompletionRows.length
          ) ?
            state.dashboardLevelCompletionRows
          : Array.isArray(state.dashboardSummary?.levelCompletion) ?
            state.dashboardSummary.levelCompletion
          : []).map((entry) => normalizeLevelName(entry?.level || ""));
        const classLevels = (
          Array.isArray(state.dashboardSummary?.classEnrollmentAttendance) ?
            state.dashboardSummary.classEnrollmentAttendance
          : []).map((entry) => normalizeLevelName(entry?.level || ""));
        const currentLevel = normalizeLevelName(
          state.currentStudent?.profile?.currentGrade || "",
        );

        const known = sortLevelNames([
          ...(Array.isArray(extraValues) ? extraValues : []),
          ...(Array.isArray(state.systemLevels) ? state.systemLevels : []),
          ...studentLevels,
          ...dashboardStudentLevels,
          ...completionLevels,
          ...classLevels,
          currentLevel,
        ]);
        if (known.length) return known;
        return sortLevelNames(DEFAULT_LEVEL_CATALOG);
      }

      function collectAttendanceLevelNames(extraValues = []) {
        const attendanceLevels = [
          ...(Array.isArray(extraValues) ? extraValues : []),
          ...((Array.isArray(state.students) ? state.students : []).flatMap((student) => [
            student?.profile?.currentGrade,
            student?.profile?.classLevel,
            student?.profile?.level,
            student?.currentGrade,
            student?.classLevel,
            student?.level,
            student?.className,
          ])),
          ...((Array.isArray(state.dashboardStudents) ? state.dashboardStudents : []).flatMap(
            (student) => [
              student?.profile?.currentGrade,
              student?.profile?.classLevel,
              student?.profile?.level,
              student?.currentGrade,
              student?.classLevel,
              student?.level,
              student?.className,
            ],
          )),
          ...((Array.isArray(state.dashboardSummary?.classEnrollmentAttendance) ?
            state.dashboardSummary.classEnrollmentAttendance
          : []).map((entry) => entry?.level)),
          ...((Array.isArray(state.dashboardLevelCompletionRows) &&
            state.dashboardLevelCompletionRows.length) ?
            state.dashboardLevelCompletionRows
          : Array.isArray(state.dashboardSummary?.levelCompletion) ?
            state.dashboardSummary.levelCompletion
          : []).map((entry) => entry?.level),
          ...(Array.isArray(state.systemLevels) ? state.systemLevels : []),
        ];
        const knownLevels = sortLevelNames(
          attendanceLevels.filter((value) => Boolean(normalizeLevelName(value || ""))),
        );
        return knownLevels.length ? knownLevels : sortLevelNames(DEFAULT_LEVEL_CATALOG);
      }

      function syncSystemLevelNames(extraValues = []) {
        state.systemLevels = sortLevelNames([
          ...(Array.isArray(state.systemLevels) ? state.systemLevels : []),
          ...(Array.isArray(extraValues) ? extraValues : []),
        ]);
        return state.systemLevels;
      }

      function createSelectOption(value = "", text = "", selected = false) {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = text;
        if (selected) option.selected = true;
        return option;
      }

      function populateProfileLevelOptions() {
        const select = document.getElementById("f_currentGrade");
        if (!(select instanceof HTMLSelectElement)) return;
        const current = resolveSystemLevelName(select.value);
        const values = collectKnownLevelNames([current]);
        const options = [createSelectOption("", "Select level")];
        values.forEach((levelName) => {
          if (!levelName) return;
          options.push(
            createSelectOption(
              levelName,
              shortLevelLabel(levelName),
              levelNamesMatch(levelName, current),
            ),
          );
        });
        select.replaceChildren(...options);
      }

      function populateTableFilterLevelOptions(tableKey = "") {
        const config = tableFilterFieldConfig(tableKey);
        if (!config) return;
        const selectEl = document.getElementById(config.level);
        if (!selectEl) return;
        const selectedLevel = resolveSystemLevelName(
          tableFilterValue(tableKey, "level"),
        );
        const levelValues = collectAttendanceLevelNames([selectedLevel]);
        const options = [createSelectOption("", "Any")];
        levelValues.forEach((levelName) => {
          if (!levelName) return;
          const value = resolveSystemLevelName(levelName);
          options.push(
            createSelectOption(
              value,
              fullLevelLabel(levelName),
              Boolean(selectedLevel && levelNamesMatch(value, selectedLevel)),
            ),
          );
        });
        selectEl.replaceChildren(...options);
        if (!selectedLevel) selectEl.value = "";
      }

      function tableFilterStudentOptionValue(student = {}) {
        const internalId = normalizeText(student?.id);
        if (internalId) return internalId;
        return normalizeText(student?.eaglesId);
      }

      function populateTableFilterStudentOptions(tableKey = "") {
        const config = tableFilterFieldConfig(tableKey);
        if (!config) return;
        const selectEl = document.getElementById(config.student);
        if (!selectEl) return;
        const selectedRef = normalizeText(tableFilterValue(tableKey, "studentRefId"));
        const selectedRefLower = normalizeLower(selectedRef);
        const students = Array.from(
          new Map(
            tableFilterStudentsForLevel(tableKey)
              .map((student) => [tableFilterStudentOptionValue(student), student])
              .filter(([value]) => Boolean(value)),
          ).values(),
        ).sort((left, right) => {
          const leftFullName = studentFullName(left);
          const rightFullName = studentFullName(right);
          const byName = leftFullName.localeCompare(rightFullName, undefined, {
            sensitivity: "base",
          });
          if (byName !== 0) return byName;
          return normalizeText(left?.eaglesId).localeCompare(
            normalizeText(right?.eaglesId),
            undefined,
            { sensitivity: "base" },
          );
        });

        const options = [createSelectOption("", "All students")];
        let hasSelection = false;
        students.forEach((student) => {
          const value = tableFilterStudentOptionValue(student);
          const optionLower = normalizeLower(value);
          const publicIdLower = normalizeLower(student?.eaglesId);
          const selected =
            selectedRef &&
            (value === selectedRef ||
              optionLower === selectedRefLower ||
              publicIdLower === selectedRefLower);
          if (
            selected
          ) {
            if (value && value !== selectedRef)
              setTableFilterValue(tableKey, "studentRefId", value);
            hasSelection = true;
          }
          options.push(
            createSelectOption(
              value,
              studentIdentityLabel(student, {
                preferEnglish: true,
                wrapName: true,
                includeStudentNumber: true,
              }),
              Boolean(selected),
            ),
          );
        });
        selectEl.replaceChildren(...options);

        if (!selectedRef) {
          selectEl.value = "";
        } else if (!hasSelection) {
          setTableFilterValue(tableKey, "studentRefId", "");
          selectEl.value = "";
        }
      }

      function syncTableFilterInputValues(tableKey = "") {
        const config = tableFilterFieldConfig(tableKey);
        if (!config) return;
        const levelEl = document.getElementById(config.level);
        const studentEl = document.getElementById(config.student);
        const fromEl = document.getElementById(config.dateFrom);
        const toEl = document.getElementById(config.dateTo);
        const weekEl = document.getElementById(config.weekNumber);
        if (levelEl)
          levelEl.value = resolveSystemLevelName(tableFilterValue(tableKey, "level"));
        if (studentEl) studentEl.value = tableFilterValue(tableKey, "studentRefId");
        if (fromEl) fromEl.value = tableFilterValue(tableKey, "dateFrom");
        if (toEl) toEl.value = tableFilterValue(tableKey, "dateTo");
        if (weekEl) weekEl.value = tableFilterValue(tableKey, "weekNumber");
      }

      function refreshTableSearchFilterControls(tableKey = "") {
        if (!DATA_TABLE_KEYS.includes(tableKey)) return;
        populateTableFilterLevelOptions(tableKey);
        populateTableFilterStudentOptions(tableKey);
        syncTableFilterInputValues(tableKey);
      }

      function refreshAllTableSearchFilterControls() {
        DATA_TABLE_KEYS.forEach((tableKey) =>
          refreshTableSearchFilterControls(tableKey),
        );
        refreshNewsReviewFilterControls();
      }

      function normalizeNewsReviewFilters(filters = {}) {
        const source = filters && typeof filters === "object" ? filters : {};
        const status = normalizeLower(source.status || "all");
        const normalizedStatus =
          (["all", "approved", "waiting", "checked", "draft"].includes(status)) ?
            status
          : ["submitted", "revise", "revision-requested", "open", "none-submitted"].includes(status) ?
            "waiting"
          : "all";
        const setAction = normalizeLower(source.setAction || source.reviewCheck || "all");
        const normalizedSetAction =
          setAction === "unapproved" ?
            "pending"
          : (["all", "completed", "incomplete", "pending"].includes(
              setAction,
            )) ?
              setAction
            : "all";
        return {
          status: normalizedStatus,
          setAction: normalizedSetAction,
          level: resolveSystemLevelName(source.level || ""),
          studentRefId: normalizeText(source.studentRefId),
          dateFrom: normalizeText(source.dateFrom).slice(0, 10),
          dateTo: normalizeText(source.dateTo).slice(0, 10),
          query: normalizeText(source.query),
          take: Math.max(
            1,
            Math.min(Number.parseInt(String(source.take || 200), 10) || 200, 500),
          ),
        };
      }

      function newsReviewFilters() {
        const normalized = normalizeNewsReviewFilters(state.newsReview?.filters || {});
        state.newsReview.filters = normalized;
        return normalized;
      }

      function setNewsReviewFilterValues(patch = {}) {
        state.newsReview.filters = normalizeNewsReviewFilters({
          ...newsReviewFilters(),
          ...(patch && typeof patch === "object" ? patch : {}),
        });
        refreshNewsReviewFilterControls();
      }

      function newsReviewStudentOptionValue(student = {}) {
        const id = normalizeText(student?.id);
        if (id) return id;
        return normalizeText(student?.eaglesId);
      }

      function populateNewsReviewLevelOptions() {
        const selectEl = document.getElementById("newsReviewLevelFilter");
        if (!selectEl) return;
        const selectedLevel = resolveSystemLevelName(newsReviewFilters().level);
        const levelValues = collectKnownLevelNames([selectedLevel]);
        selectEl.innerHTML = '<option value="">Any</option>';
        levelValues.forEach((levelName) => {
          if (!levelName) return;
          const option = document.createElement("option");
          option.value = resolveSystemLevelName(levelName);
          option.textContent = fullLevelLabel(levelName);
          if (selectedLevel && levelNamesMatch(option.value, selectedLevel))
            option.selected = true;
          selectEl.appendChild(option);
        });
        if (!selectedLevel) selectEl.value = "";
      }

      function populateNewsReviewStudentOptions() {
        const selectEl = document.getElementById("newsReviewStudentFilter");
        if (!selectEl) return;
        const selectedRef = normalizeText(newsReviewFilters().studentRefId);
        const selectedRefLower = normalizeLower(selectedRef);
        const selectedLevel = resolveSystemLevelName(newsReviewFilters().level);
        const students = Array.from(
          new Map(
            studentSourceForPage("news-reports")
              .filter((student) => {
                if (!selectedLevel) return true;
                return levelNamesMatch(
                  student?.profile?.currentGrade || "",
                  selectedLevel,
                );
              })
              .map((student) => [newsReviewStudentOptionValue(student), student])
              .filter(([value]) => Boolean(value)),
          ).values(),
        ).sort((left, right) => {
          const leftFullName = studentFullName(left);
          const rightFullName = studentFullName(right);
          const byName = leftFullName.localeCompare(rightFullName, undefined, {
            sensitivity: "base",
          });
          if (byName !== 0) return byName;
          return normalizeText(left?.eaglesId).localeCompare(
            normalizeText(right?.eaglesId),
            undefined,
            { sensitivity: "base" },
          );
        });

        selectEl.innerHTML = '<option value="">All students</option>';
        let hasSelection = false;
        students.forEach((student) => {
          const option = document.createElement("option");
          option.value = newsReviewStudentOptionValue(student);
          option.textContent = studentIdentityLabel(student, {
            preferEnglish: true,
            wrapName: true,
            includeStudentNumber: true,
          });
          const optionLower = normalizeLower(option.value);
          const publicIdLower = normalizeLower(student?.eaglesId);
          if (
            selectedRef &&
            (option.value === selectedRef ||
              optionLower === selectedRefLower ||
              publicIdLower === selectedRefLower)
          ) {
            option.selected = true;
            if (option.value && option.value !== selectedRef) {
              state.newsReview.filters.studentRefId = option.value;
            }
            hasSelection = true;
          }
          selectEl.appendChild(option);
        });
        if (!selectedRef || !hasSelection) {
          if (selectedRef && !hasSelection) state.newsReview.filters.studentRefId = "";
          selectEl.value = "";
        }
      }

      function syncNewsReviewFilterInputValues() {
        const filters = newsReviewFilters();
        const statusEl = document.getElementById("newsReviewStatusFilter");
        const reviewCheckEl = document.getElementById("newsReviewCheckFilter");
        const levelEl = document.getElementById("newsReviewLevelFilter");
        const studentEl = document.getElementById("newsReviewStudentFilter");
        const fromEl = document.getElementById("newsReviewDateFromFilter");
        const toEl = document.getElementById("newsReviewDateToFilter");
        const queryEl = document.getElementById("newsReviewQueryFilter");
        if (statusEl) statusEl.value = filters.status;
        if (reviewCheckEl) reviewCheckEl.value = filters.setAction;
        if (levelEl) levelEl.value = resolveSystemLevelName(filters.level);
        if (studentEl) studentEl.value = filters.studentRefId;
        if (fromEl) fromEl.value = filters.dateFrom;
        if (toEl) toEl.value = filters.dateTo;
        if (queryEl) queryEl.value = filters.query;
      }

      function refreshNewsReviewFilterControls() {
        populateNewsReviewLevelOptions();
        populateNewsReviewStudentOptions();
        syncNewsReviewFilterInputValues();
      }

      function newsReviewStatusLabel(status = "") {
        const normalized = normalizeLower(status);
        if (normalized === "approved") return "Approved";
        if (normalized === "waiting") return "Waiting";
        if (normalized === "checked") return "Checked";
        if (normalized === "draft") return "Saved Drafts";
        if (normalized === "revise" || normalized === "revision-requested")
          return "Revise";
        if (normalized === "open") return "Open";
        if (normalized === "none-submitted") return "None Submitted";
        return "Submitted";
      }

      function newsReviewSetActionCount(setAction = "") {
        const normalized = normalizeLower(setAction);
        if (normalized.startsWith("pending-")) {
          const parsed = Number.parseInt(normalized.slice("pending-".length), 10);
          return Number.isFinite(parsed) ? parsed : 0;
        }
        return 0;
      }

      function newsReviewSetActionLabel(setAction = "") {
        const normalized = normalizeLower(setAction);
        if (normalized === "completed") return "Completed";
        if (normalized === "incomplete") return "Incomplete";
        if (normalized.startsWith("pending-"))
          return `Pending-${newsReviewSetActionCount(normalized)}`;
        return "Incomplete";
      }

      function newsReviewStatusColorToken(status = "") {
        const normalized = normalizeLower(status);
        if (
          normalized === "green" ||
          normalized === "amber" ||
          normalized === "red" ||
          normalized === "purple" ||
          normalized === "blue" ||
          normalized === "teal" ||
          normalized === "turquoise"
        )
          return normalized === "turquoise" ? "teal" : normalized;
        if (normalized === "approved") return "green";
        if (normalized === "waiting") return "purple";
        if (normalized === "checked") return "teal";
        if (normalized === "revise" || normalized === "revision-requested")
          return "purple";
        if (normalized === "none-submitted") return "red";
        if (normalized === "open") return "blue";
        return "amber";
      }

      function newsReviewSetActionColorToken(setAction = "") {
        const normalized = normalizeLower(setAction);
        if (normalized === "completed") return "green";
        if (normalized === "incomplete") return "amber";
        if (normalized.startsWith("pending-")) return "teal";
        return "amber";
      }

      function newsReviewChipClass(status = "") {
        const colorToken = newsReviewStatusColorToken(status);
        if (colorToken === "green") return "portal-chip-green-status";
        if (colorToken === "red") return "portal-chip-red-status";
        if (colorToken === "purple") return "portal-chip-purple-status";
        if (colorToken === "blue") return "portal-chip-blue-status";
        if (colorToken === "teal" || colorToken === "turquoise") return "portal-chip-teal-status";
        if (colorToken === "amber") return "portal-chip-amber-status";
        return "portal-chip-neutral-status";
      }

      function newsReviewStatusChipHtml(status = "") {
        const label = newsReviewStatusLabel(status);
        return `<span class="portal-chip ${newsReviewChipClass(status)}">${escapeHtml(label)}</span>`;
      }

      function newsReviewSetActionChipHtml(setAction = "") {
        const colorToken = newsReviewSetActionColorToken(setAction);
        const chipClass = newsReviewChipClass(colorToken);
        const label = newsReviewSetActionLabel(setAction);
        return `<span class="portal-chip ${chipClass}">${escapeHtml(label)}</span>`;
      }

      const NEWS_REVIEW_COMPLIANCE_NOTE_START = "[[SIS-COMPLIANCE-V1]]";
      const NEWS_REVIEW_COMPLIANCE_NOTE_END = "[[/SIS-COMPLIANCE-V1]]";

      function splitNewsReviewNote(noteText = "") {
        let remaining = normalizeText(noteText);
        const blocks = [];
        while (remaining) {
          const start = remaining.indexOf(NEWS_REVIEW_COMPLIANCE_NOTE_START);
          if (start < 0) break;
          const end = remaining.indexOf(
            NEWS_REVIEW_COMPLIANCE_NOTE_END,
            start + NEWS_REVIEW_COMPLIANCE_NOTE_START.length,
          );
          if (end < 0) break;
          const after = end + NEWS_REVIEW_COMPLIANCE_NOTE_END.length;
          blocks.push(normalizeText(remaining.slice(start, after)));
          remaining = normalizeText(
            `${remaining.slice(0, start)}\n${remaining.slice(after)}`,
          );
        }
        return {
          manual: remaining,
          complianceBlock: blocks.length ? blocks[blocks.length - 1] : "",
        };
      }

      function composeNewsReviewNoteWithCompliance(
        manualNoteText = "",
        existingNoteText = "",
      ) {
        const manual = splitNewsReviewNote(manualNoteText).manual;
        const complianceBlock = splitNewsReviewNote(existingNoteText).complianceBlock;
        if (manual && complianceBlock) return `${manual}\n\n${complianceBlock}`;
        if (complianceBlock) return complianceBlock;
        return manual;
      }

      function newsReviewComplianceNoteHtml(noteText = "") {
        const complianceBlock = splitNewsReviewNote(noteText).complianceBlock;
        if (!complianceBlock) return "-";
        const lines = complianceBlock
          .split(/\r?\n/)
          .map((line) => normalizeText(line))
          .filter(
            (line) =>
              Boolean(line) &&
              line !== NEWS_REVIEW_COMPLIANCE_NOTE_START &&
              line !== NEWS_REVIEW_COMPLIANCE_NOTE_END,
          );
        if (!lines.length) return "-";
        return lines
          .map((line) => {
            const token = normalizeLower(line);
            const cssClass =
              token.includes("[pending]") ? "pending"
              : token.includes("[fixed]") ||
                  token.includes(
                    "fixed per compliance resolution on save",
                  ) ?
                  "fixed"
                : "";
            const className = cssClass ?
              `news-review-note-line ${cssClass}` :
              "news-review-note-line";
            const span = document.createElement("span");
            span.className = className;
            span.textContent = line;
            return span.outerHTML;
          })
          .join("");
      }

      function newsReviewSummaryText() {
        const total = Math.max(
          0,
          Number.parseInt(String(state.newsReview?.total || 0), 10) || 0,
        );
        const showing =
          Array.isArray(state.newsReview?.items) ? state.newsReview.items.length : 0;
        const summary = state.newsReview?.statusSummary || {};
        const approved = Math.max(
          0,
          Number.parseInt(String(summary.approved || 0), 10) || 0,
        );
        const waiting = Math.max(
          0,
          Number.parseInt(String(summary.waiting || 0), 10) || 0,
        );
        const checked = Math.max(
          0,
          Number.parseInt(String(summary.checked || 0), 10) || 0,
        );
        const completed = Math.max(
          0,
          Number.parseInt(String(summary.completed || 0), 10) || 0,
        );
        const incomplete = Math.max(
          0,
          Number.parseInt(String(summary.incomplete || 0), 10) || 0,
        );
        const pending = Math.max(
          0,
          Number.parseInt(String(summary.pending || 0), 10) || 0,
        );
        return `total=${total} | showing=${showing} | status: approved=${approved} waiting=${waiting} checked=${checked} | action: completed=${completed} incomplete=${incomplete} pending=${pending}`;
      }

      function weeklyMinimumNewsReports() {
        return Math.max(
          1,
          Number.parseInt(
            String(
              state.sisConfig?.newsReports?.weeklyMinimumReports ||
                DEFAULT_SIS_CONFIG.newsReports.weeklyMinimumReports,
            ),
            10,
          ) || DEFAULT_SIS_CONFIG.newsReports.weeklyMinimumReports,
        );
      }

      function newsReviewWeekSetStatusToken(set = {}) {
        const drafts = Math.max(
          0,
          Number.parseInt(String(set?.draftCount || 0), 10) || 0,
        );
        const submitted = Math.max(
          0,
          Number.parseInt(String(set?.submittedCount || 0), 10) || 0,
        );
        const approved = Math.max(
          0,
          Number.parseInt(String(set?.approvedCount || 0), 10) || 0,
        );
        const revisionRequested = Math.max(
          0,
          Number.parseInt(String(set?.revisionRequestedCount || 0), 10) || 0,
        );
        const awaitingReReview = Math.max(
          0,
          Math.min(
            submitted,
            Number.parseInt(String(set?.awaitingReReviewCount || 0), 10) || 0,
          ),
        );
        const reportCount = Math.max(
          0,
          Number.parseInt(String(set?.reportCount || 0), 10) || 0,
        );
        const uncheckedInitial = Math.max(0, submitted - awaitingReReview);
        const requiredReports = weeklyMinimumNewsReports();
        if (drafts > 0 && submitted === 0 && approved === 0 && revisionRequested === 0) return "draft";
        if (reportCount >= requiredReports && approved >= requiredReports) return "approved";
        if (
          awaitingReReview > 0 &&
          revisionRequested === 0 &&
          uncheckedInitial === 0
        ) {
          return "waiting";
        }
        if (submitted === 0 && revisionRequested === 0) return "checked";
        if (revisionRequested > 0 || submitted > 0) return "waiting";
        return "checked";
      }

      function newsReviewAdminSetStatusToken(set = {}) {
        const source = set && typeof set === "object" ? set : {};
        const hasCountSignals =
          Object.prototype.hasOwnProperty.call(source, "reportCount") ||
          Object.prototype.hasOwnProperty.call(source, "approvedCount") ||
          Object.prototype.hasOwnProperty.call(source, "draftCount") ||
          Object.prototype.hasOwnProperty.call(source, "submittedCount") ||
          Object.prototype.hasOwnProperty.call(source, "revisionRequestedCount") ||
          Object.prototype.hasOwnProperty.call(source, "awaitingReReviewCount");
        const statusToken = hasCountSignals ?
          newsReviewWeekSetStatusToken(source)
        : normalizeText(source?.setStatus);
        const normalized = normalizeLower(statusToken);
        if (normalized === "approved") return "approved";
        if (normalized === "checked") return "checked";
        if (normalized === "draft") return "draft";
        return "waiting";
      }

      function newsReviewWeekSetActionToken(set = {}) {
        const requiredReports = weeklyMinimumNewsReports();
        const reportCount = Math.max(
          0,
          Number.parseInt(String(set?.reportCount || 0), 10) || 0,
        );
        const approved = Math.max(
          0,
          Number.parseInt(String(set?.approvedCount || 0), 10) || 0,
        );
        const submitted = Math.max(
          0,
          Number.parseInt(String(set?.submittedCount || 0), 10) || 0,
        );
        const pending = Math.max(0, submitted);
        if (reportCount >= requiredReports && approved >= requiredReports) return "completed";
        if (pending === 0) return "incomplete";
        return `pending-${pending}`;
      }

      function newsReviewSetActionFilterToken(setAction = "") {
        const normalized = normalizeLower(setAction);
        if (normalized === "completed" || normalized === "incomplete")
          return normalized;
        if (normalized.startsWith("pending-")) return "pending";
        return "all";
      }

      function newsReviewWeekStartIso(reportDate = "") {
        const parsed = parseIsoDateLocal(reportDate);
        if (!(parsed instanceof Date) || Number.isNaN(parsed.valueOf())) return "";
        const shifted = shiftToFixedTimeZone(parsed);
        shifted.setUTCHours(0, 0, 0, 0);
        const day = shifted.getUTCDay();
        const diffToMonday = (day + 6) % 7;
        shifted.setUTCDate(shifted.getUTCDate() - diffToMonday);
        return localIsoDate(shiftFromFixedTimeZone(shifted));
      }

      function newsReviewWeekEndIso(weekStart = "") {
        return isoDateOffset(weekStart, 6);
      }

      function newsReviewWeekSetId({
        studentRefId = "",
        eaglesId = "",
        weekStart = "",
        latestReportId = "",
      } = {}) {
        const studentToken = normalizeText(
          studentRefId || eaglesId || latestReportId || "unknown",
        );
        const weekToken = normalizeText(weekStart) || "week";
        return `news-week-set:${studentToken}:${weekToken}`;
      }

      function newsReviewReportSortValue(item = {}) {
        const submittedAt = normalizeText(item?.submittedAt);
        if (submittedAt) return submittedAt;
        return normalizeText(item?.reportDate);
      }

      function sortNewsReviewViewerItems(items = []) {
        const source = Array.isArray(items) ? items : [];
        return [...source].sort((left, right) => {
          const submittedCompare = newsReviewReportSortValue(right).localeCompare(
            newsReviewReportSortValue(left),
          );
          if (submittedCompare !== 0) return submittedCompare;
          const reportDateCompare = normalizeText(right?.reportDate).localeCompare(
            normalizeText(left?.reportDate),
          );
          if (reportDateCompare !== 0) return reportDateCompare;
          return normalizeText(right?.id).localeCompare(normalizeText(left?.id));
        });
      }

      function newsReviewWeekSetSearchText(weekSet = {}) {
        const student =
          weekSet?.student && typeof weekSet.student === "object" ?
            weekSet.student
          : {};
        const reports = Array.isArray(weekSet?.reports) ? weekSet.reports : [];
        const reportTokens = reports
          .flatMap((entry) => [
            entry?.articleTitle,
            entry?.sourceLink,
            entry?.leadSynopsis,
            entry?.actionActor,
            entry?.actionAffected,
            entry?.actionWhere,
            entry?.actionWhat,
            entry?.actionWhy,
            entry?.reviewNote,
          ])
          .map((entry) => normalizeText(entry))
          .filter(Boolean);
        return normalizeLower(
          [
            weekSet?.weekStart,
            weekSet?.weekEnd,
            student?.studentRefId,
            student?.eaglesId,
            student?.fullName,
            student?.englishName,
            student?.level,
            ...reportTokens,
          ].join(" "),
        );
      }

      function buildNewsReviewWeekSets(reports = [], filters = {}) {
        const source = Array.isArray(reports) ? reports : [];
        const grouped = new Map();
        source.forEach((entry) => {
          if (!entry || typeof entry !== "object") return;
          const student =
            entry?.student && typeof entry.student === "object" ? entry.student : {};
          const studentRefId = normalizeText(
            student?.studentRefId || entry?.studentRefId,
          );
          const eaglesId = normalizeText(student?.eaglesId || entry?.eaglesId);
          const weekStart = newsReviewWeekStartIso(entry?.reportDate);
          if (!weekStart) return;
          const key = `${studentRefId || eaglesId || normalizeText(entry?.id)}:${weekStart}`;
          if (!key) return;

          const level = resolveSystemLevelName(student?.level || entry?.level || "");
          const reportDate = normalizeText(entry?.reportDate).slice(0, 10);
          const normalizedReport = {
            ...entry,
            reportDate,
            student: {
              studentRefId,
              eaglesId,
              studentNumber:
                Number.parseInt(
                  String(student?.studentNumber || entry?.studentNumber || ""),
                  10,
                ) || null,
              fullName: normalizeText(
                student?.fullName ||
                  entry?.fullName ||
                  student?.englishName ||
                  entry?.englishName,
              ),
              englishName: normalizeText(student?.englishName || entry?.englishName),
              level,
            },
          };

          const existing = grouped.get(key) || {
            id: "",
            weekStart,
            weekEnd: newsReviewWeekEndIso(weekStart),
            student: normalizedReport.student,
            reports: [],
            reportCount: 0,
            draftCount: 0,
            submittedCount: 0,
            approvedCount: 0,
            revisionRequestedCount: 0,
            awaitingReReviewCount: 0,
            latestReportId: "",
            latestReportDate: "",
            latestSubmittedAt: "",
            latestReviewedAt: "",
            latestReviewedByUsername: "",
            setStatus: "submitted",
            setAction: "incomplete",
            _reportDateSet: new Set(),
          };
          existing.reports.push(normalizedReport);
          if (reportDate) existing._reportDateSet.add(reportDate);

          const status = normalizeLower(normalizedReport?.reviewStatus);
          const submissionState = normalizeLower(normalizedReport?.submissionState);
          if (submissionState === "draft") existing.draftCount += 1;
          else if (status === "approved") existing.approvedCount += 1;
          else if (status === "revision-requested")
            existing.revisionRequestedCount += 1;
          else {
            existing.submittedCount += 1;
            if (normalizedReport?.awaitingReReview === true)
              existing.awaitingReReviewCount += 1;
          }

          const submittedAt = normalizeText(normalizedReport?.submittedAt);
          const currentLatest = normalizeText(existing.latestSubmittedAt);
          if (!currentLatest || submittedAt > currentLatest) {
            existing.latestReportId = normalizeText(normalizedReport?.id);
            existing.latestReportDate = reportDate;
            existing.latestSubmittedAt = submittedAt;
            existing.latestReviewedAt = normalizeText(normalizedReport?.reviewedAt);
            existing.latestReviewedByUsername = normalizeText(
              normalizedReport?.reviewedByUsername,
            );
          }
          grouped.set(key, existing);
        });

        const normalizedFilters = normalizeNewsReviewFilters(filters);
        const selectedStatus = normalizeLower(normalizedFilters.status || "all");
        const selectedSetAction = normalizeLower(
          normalizedFilters.setAction || "all",
        );
        const selectedLevel = resolveSystemLevelName(normalizedFilters.level || "");
        const selectedStudentRef = normalizeText(normalizedFilters.studentRefId);
        const selectedStudentRefLower = normalizeLower(selectedStudentRef);
        const fromDate = normalizeText(normalizedFilters.dateFrom).slice(0, 10);
        const toDate = normalizeText(normalizedFilters.dateTo).slice(0, 10);
        const selectedQuery = normalizeLower(normalizedFilters.query || "");

        const sets = Array.from(grouped.values())
          .map((weekSet) => {
            const reportsSorted = sortNewsReviewViewerItems(weekSet.reports);
            const latest = reportsSorted[0] || null;
            const reportCount = Math.max(
              weekSet._reportDateSet?.size || 0,
              reportsSorted.length,
            );
            return {
              id: newsReviewWeekSetId({
                studentRefId: weekSet?.student?.studentRefId,
                eaglesId: weekSet?.student?.eaglesId,
                weekStart: weekSet?.weekStart,
                latestReportId: weekSet?.latestReportId,
              }),
              weekStart: normalizeText(weekSet?.weekStart),
              weekEnd: normalizeText(weekSet?.weekEnd),
              student: weekSet.student,
              reports: reportsSorted,
              reportCount,
              draftCount: weekSet.draftCount,
              submittedCount: weekSet.submittedCount,
              approvedCount: weekSet.approvedCount,
              revisionRequestedCount: weekSet.revisionRequestedCount,
              awaitingReReviewCount: weekSet.awaitingReReviewCount,
              latestReportId: normalizeText(weekSet?.latestReportId || latest?.id),
              latestReportDate: normalizeText(
                weekSet?.latestReportDate || latest?.reportDate,
              ),
              latestSubmittedAt: normalizeText(
                weekSet?.latestSubmittedAt || latest?.submittedAt,
              ),
              latestReviewedAt: normalizeText(
                weekSet?.latestReviewedAt || latest?.reviewedAt,
              ),
              latestReviewedByUsername: normalizeText(
                weekSet?.latestReviewedByUsername || latest?.reviewedByUsername,
              ),
              setStatus: "submitted",
              setAction: "incomplete",
            };
          })
          .map((weekSet) => ({
            ...weekSet,
            setStatus: newsReviewAdminSetStatusToken(weekSet),
            setAction: newsReviewWeekSetActionToken(weekSet),
          }))
          .filter((weekSet) => {
            if (
              selectedLevel &&
              !levelNamesMatch(weekSet?.student?.level || "", selectedLevel)
            )
              return false;
            if (selectedStudentRef) {
              const studentRef = normalizeText(weekSet?.student?.studentRefId);
              const eaglesId = normalizeLower(weekSet?.student?.eaglesId);
              if (
                studentRef !== selectedStudentRef &&
                normalizeLower(studentRef) !== selectedStudentRefLower &&
                eaglesId !== selectedStudentRefLower
              ) {
                return false;
              }
            }
            if (fromDate && compareIsoDateText(weekSet?.weekEnd || "", fromDate) < 0)
              return false;
            if (toDate && compareIsoDateText(weekSet?.weekStart || "", toDate) > 0)
              return false;
            if (
              selectedStatus !== "all" &&
              normalizeLower(newsReviewAdminSetStatusToken(weekSet)) !==
                selectedStatus
            )
              return false;
            if (
              selectedSetAction !== "all" &&
              newsReviewSetActionFilterToken(weekSet?.setAction) !== selectedSetAction
            )
              return false;
            if (
              selectedQuery &&
              !newsReviewWeekSetSearchText(weekSet).includes(selectedQuery)
            )
              return false;
            return true;
          })
          .sort((left, right) => {
            const weekCompare = normalizeText(right?.weekStart).localeCompare(
              normalizeText(left?.weekStart),
            );
            if (weekCompare !== 0) return weekCompare;
            const submittedCompare = normalizeText(
              right?.latestSubmittedAt,
            ).localeCompare(normalizeText(left?.latestSubmittedAt));
            if (submittedCompare !== 0) return submittedCompare;
            return normalizeText(left?.student?.fullName).localeCompare(
              normalizeText(right?.student?.fullName),
              undefined,
              {
                sensitivity: "base",
              },
            );
          });
        return sets;
      }

      function summarizeNewsReviewWeekSets(sets = []) {
        const summary = {
          completed: 0,
          incomplete: 0,
          pending: 0,
          approved: 0,
          waiting: 0,
          checked: 0,
        };
        const source = Array.isArray(sets) ? sets : [];
        source.forEach((entry) => {
          const status = normalizeLower(newsReviewAdminSetStatusToken(entry));
          if (status === "approved") summary.approved += 1;
          else if (status === "waiting") summary.waiting += 1;
          else if (status === "checked") summary.checked += 1;
          const setAction = normalizeLower(entry?.setAction);
          if (setAction === "completed") summary.completed += 1;
          else if (setAction === "incomplete") summary.incomplete += 1;
          else if (setAction.startsWith("pending-"))
            summary.pending += 1;
        });
        return summary;
      }

      function newsReviewBulkApprovableReportIds(sets = null) {
        const source =
          Array.isArray(sets) ? sets
          : Array.isArray(state.newsReview?.allItems) ? state.newsReview.allItems
          : Array.isArray(state.newsReview?.items) ? state.newsReview.items
          : [];
        const ids = [];
        const seen = new Set();
        source.forEach((weekSet) => {
          const reports = Array.isArray(weekSet?.reports) ? weekSet.reports : [];
          reports.forEach((report) => {
            const reportId = normalizeText(report?.id);
            const reviewStatus =
              normalizeLower(normalizeText(report?.reviewStatus)) ||
              STUDENT_NEWS_REVIEW_STATUS_SUBMITTED;
            if (!reportId || reviewStatus !== STUDENT_NEWS_REVIEW_STATUS_SUBMITTED)
              return;
            if (state.newsReview?.pendingById?.[reportId] || seen.has(reportId)) return;
            seen.add(reportId);
            ids.push(reportId);
          });
        });
        return ids;
      }

      function syncNewsReviewBulkApproveButton() {
        const buttonEl = document.getElementById("newsReviewApproveQueueBtn");
        if (!(buttonEl instanceof HTMLButtonElement)) return;
        const pending = Boolean(state.newsReview?.bulkApprovePending);
        const reportIds = newsReviewBulkApprovableReportIds();
        const count = reportIds.length;
        buttonEl.disabled = pending || !canManageUsers() || count < 1;
        buttonEl.textContent =
          pending ? "Approving Queue..."
          : "Approve All";
      }

      function renderNewsReviewRows() {
        const summaryEl = document.getElementById("newsReviewSummary");
        const rowsEl = document.getElementById("newsReviewRows");
        if (!summaryEl || !rowsEl) return;
        syncNewsReviewBulkApproveButton();
        summaryEl.textContent = newsReviewSummaryText();
        const items = sortedNewsReviewWeekSets(state.newsReview?.items);
        rowsEl.innerHTML = "";
        if (!items.length) {
          rowsEl.innerHTML =
            '<tr><td colspan="8">No student week sets found for the current filters.</td></tr>';
          return;
        }

        items.forEach((item) => {
          const weekSetId = normalizeText(item?.id);
          const student =
            item?.student && typeof item.student === "object" ? item.student : {};
          const studentLabel = studentIdentityLabel(
            {
              id: student?.studentRefId,
              studentNumber: student?.studentNumber,
              eaglesId: student?.eaglesId,
              profile: {
                fullName: student?.fullName,
                englishName: student?.englishName,
                currentGrade: student?.level,
              },
            },
            { preferEnglish: true, wrapName: true, includeStudentNumber: true },
          );
          const rowStatus = newsReviewAdminSetStatusToken(item);
          const setAction = normalizeText(
            item?.setAction || newsReviewWeekSetActionToken(item),
          );
          const row = document.createElement("tr");
          const requiredReports = weeklyMinimumNewsReports();
          row.dataset.newsReviewWeekSetId = weekSetId;
          row.innerHTML = `
          <td data-label="Week Set">${escapeHtml(formatPortalWeekRange(item?.weekStart, item?.weekEnd))}</td>
          <td data-label="Student">${escapeHtml(studentLabel)}</td>
          <td data-label="Level">${escapeHtml(fullLevelLabel(student?.level || ""))}</td>
          <td data-label="Reports">${escapeHtml(`${Math.max(0, Number.parseInt(String(item?.reportCount || 0), 10) || 0)}/${requiredReports}`)}</td>
          <td data-label="Action">${newsReviewSetActionChipHtml(setAction)}</td>
          <td data-label="Status">${newsReviewStatusChipHtml(rowStatus)}</td>
          <td data-label="Latest Submission">${escapeHtml(formatDateTime(item?.latestSubmittedAt || ""))}<br><span class="small">${escapeHtml(normalizeText(item?.latestReviewedByUsername || "-"))}</span></td>
          <td data-label="Open"><button type="button" class="queue-row-btn portal-button portal-button-info portal-button-open-week-set" data-button-tooltip="Open the reports belonging to this week set" data-news-review-open-week-set="${escapeHtml(weekSetId)}" data-news-review-open-report="${escapeHtml(normalizeText(item?.latestReportId))}">Open Week Set</button></td>
        `;
          rowsEl.appendChild(row);
        });
      }

      function newsReviewWeekSetById(weekSetId = "", sets = null) {
        const id = normalizeText(weekSetId);
        if (!id) return null;
        const source =
          Array.isArray(sets) ? sets
          : Array.isArray(state.newsReview?.items) ? state.newsReview.items
          : [];
        return source.find((entry) => normalizeText(entry?.id) === id) || null;
      }

      function newsReviewItemById(reportId = "", sets = null) {
        const id = normalizeText(reportId);
        if (!id) return null;
        const source =
          Array.isArray(sets) ? sets
          : Array.isArray(state.newsReview?.items) ? state.newsReview.items
          : [];
        for (const weekSet of source) {
          const reports = Array.isArray(weekSet?.reports) ? weekSet.reports : [];
          const found = reports.find((entry) => normalizeText(entry?.id) === id);
          if (found) return found;
        }
        return null;
      }

      async function loadNewsReviewViewerItems(weekSet = null, options = {}) {
        const selectedWeekSet = weekSet && typeof weekSet === "object" ? weekSet : null;
        if (!selectedWeekSet) return [];
        const fallbackItems = sortNewsReviewViewerItems(selectedWeekSet?.reports);
        const loadSetAll = options && options.loadSetAll === false ? false : true;
        const studentRefId = normalizeText(
          selectedWeekSet?.student?.studentRefId || selectedWeekSet?.studentRefId,
        );
        const weekStart = normalizeText(selectedWeekSet?.weekStart);
        const weekEnd = normalizeText(selectedWeekSet?.weekEnd);
        if (!loadSetAll || !studentRefId || !weekStart || !weekEnd)
          return fallbackItems;

        const params = new URLSearchParams();
        params.set("status", "all");
        params.set("studentRefId", studentRefId);
        params.set("dateFrom", weekStart);
        params.set("dateTo", weekEnd);
        params.set("take", "500");
        const payload = await api(`${ADMIN_NEWS_REPORTS_PATH}?${params.toString()}`);
        const fetchedReports = Array.isArray(payload?.items) ? payload.items : [];
        const fetchedSets = buildNewsReviewWeekSets(fetchedReports, {
          status: "all",
          studentRefId,
          dateFrom: weekStart,
          dateTo: weekEnd,
          query: "",
          take: 500,
        });
        const match =
          newsReviewWeekSetById(selectedWeekSet?.id, fetchedSets) ||
          fetchedSets.find(
            (entry) =>
              normalizeText(entry?.student?.studentRefId) === studentRefId &&
              normalizeText(entry?.weekStart) === weekStart,
          );
        const scopedItems = sortNewsReviewViewerItems(match?.reports);
        return scopedItems.length ? scopedItems : fallbackItems;
      }

      function newsReviewViewerCurrentItem() {
        const items =
          Array.isArray(state.newsReview?.viewerItems) ?
            state.newsReview.viewerItems
          : [];
        if (!items.length) return null;
        const index = Number.parseInt(String(state.newsReview?.viewerIndex), 10);
        const safeIndex =
          Number.isFinite(index) ? Math.max(0, Math.min(items.length - 1, index)) : 0;
        return items[safeIndex] || null;
      }

      function setNewsReviewViewerStatus(message = "", isError = false) {
        const statusEl = document.getElementById("newsReviewViewerStatus");
        if (!statusEl) return;
        statusEl.style.color = isError ? "#b3262d" : "var(--portal-status-muted-text)";
        statusEl.textContent = normalizeText(message) || "Viewer is ready.";
      }

      function setNewsReviewViewerEditMode(shouldEdit = false) {
        state.newsReview.viewerEditMode = Boolean(shouldEdit);
        const activeReport = newsReviewViewerCurrentItem();
        if (activeReport) renderNewsReviewViewer(activeReport);
        syncNewsReviewViewerControls(activeReport);
        setNewsReviewViewerStatus(
          shouldEdit ? "Edit mode enabled. Save to persist changes." : "Viewer is ready."
        );
      }

      function newsReviewViewerDraftPayload() {
        return {
          sourceLink: normalizeText(document.getElementById("newsReviewViewerSourceLink")?.value),
          articleTitle: normalizeText(document.getElementById("newsReviewViewerArticleTitle")?.value),
          byline: normalizeText(document.getElementById("newsReviewViewerByline")?.value),
          articleDateline: normalizeText(document.getElementById("newsReviewViewerArticleDateline")?.value),
          leadSynopsis: normalizeText(document.getElementById("newsReviewViewerLeadSynopsis")?.value),
          actionActor: normalizeText(document.getElementById("newsReviewViewerActionActor")?.value),
          actionAffected: normalizeText(document.getElementById("newsReviewViewerActionAffected")?.value),
          actionWhere: normalizeText(document.getElementById("newsReviewViewerActionWhere")?.value),
          actionWhat: normalizeText(document.getElementById("newsReviewViewerActionWhat")?.value),
          actionWhy: normalizeText(document.getElementById("newsReviewViewerActionWhy")?.value),
          biasAssessment: normalizeText(document.getElementById("newsReviewViewerBiasAssessment")?.value),
          reviewNote: normalizeText(document.getElementById("newsReviewViewerNote")?.value),
        };
      }

      function syncNewsReviewViewerControls(report = null) {
        const items =
          Array.isArray(state.newsReview?.viewerItems) ?
            state.newsReview.viewerItems
          : [];
        const reportId = normalizeText(report?.id);
        const explicitIndex = Number.parseInt(
          String(state.newsReview?.viewerIndex),
          10,
        );
        let index = Number.isFinite(explicitIndex) ? explicitIndex : -1;
        if (reportId) {
          const locatedIndex = items.findIndex(
            (entry) => normalizeText(entry?.id) === reportId,
          );
          if (locatedIndex >= 0) index = locatedIndex;
        }
        if (!items.length) index = -1;
        else if (index < 0) index = 0;
        else if (index >= items.length) index = items.length - 1;
        state.newsReview.viewerIndex = index;
        const activeReport = index >= 0 ? items[index] : null;
        const activeReportId = normalizeText(activeReport?.id);
        if (activeReportId) state.newsReview.viewerReportId = activeReportId;
        const editing = Boolean(state.newsReview?.viewerEditMode);

        const indexEl = document.getElementById("newsReviewViewerIndex");
        if (indexEl)
          indexEl.textContent =
            items.length ? `${index + 1} / ${items.length}` : "0 / 0";

        const prevBtn = document.getElementById("newsReviewViewerPrevBtn");
        if (prevBtn instanceof HTMLButtonElement)
          prevBtn.disabled = editing || !items.length || index <= 0;
        const nextBtn = document.getElementById("newsReviewViewerNextBtn");
        if (nextBtn instanceof HTMLButtonElement)
          nextBtn.disabled = editing || !items.length || index < 0 || index >= items.length - 1;

        const canReview = canManageUsers();
        const pendingAction = normalizeText(
          state.newsReview?.pendingById?.[activeReportId],
        );
        // Admin review is an intervention surface, not a status-limited queue.
        // Keep the role gate, but allow the administrator to edit, comment on,
        // approve, or return any report regardless of its current status.
        const canEditReport = canReview && Boolean(activeReportId);
        const editBtn = document.getElementById("newsReviewViewerEditBtn");
        if (editBtn instanceof HTMLButtonElement) {
          editBtn.disabled = !canEditReport || Boolean(pendingAction);
          editBtn.textContent = editing ? "Cancel" : "Edit";
        }
        const saveBtn = document.getElementById("newsReviewViewerSaveBtn");
        if (saveBtn instanceof HTMLButtonElement) {
          saveBtn.classList.toggle("hidden", !editing);
          saveBtn.hidden = !editing;
          saveBtn.disabled = !canEditReport || Boolean(pendingAction);
          saveBtn.textContent = pendingAction === "save" ? "Saving..." : "Save";
        }
        const noteField = document.getElementById("newsReviewViewerNote");
        if (noteField instanceof HTMLTextAreaElement) {
          if (document.activeElement !== noteField) {
            noteField.value = splitNewsReviewNote(activeReport?.reviewNote).manual;
          }
          noteField.disabled = !canReview || !activeReportId || Boolean(pendingAction);
        }

        const approveBtn = document.getElementById("newsReviewViewerApproveBtn");
        if (approveBtn instanceof HTMLButtonElement) {
          approveBtn.disabled = !canReview || !activeReportId || Boolean(pendingAction) || editing || !canEditReport;
          approveBtn.textContent =
            pendingAction === "approve" ? "Approving..." : "Approve";
        }
        const revisionBtn = document.getElementById("newsReviewViewerRevisionBtn");
        if (revisionBtn instanceof HTMLButtonElement) {
          revisionBtn.disabled =
            !canReview || !activeReportId || Boolean(pendingAction) || editing || !canEditReport;
          revisionBtn.textContent =
            pendingAction === "revision-requested" ? "Saving..." : "Request Revision";
        }
      }

      function renderNewsReviewViewer(report = null) {
        const bodyEl = document.getElementById("newsReviewViewerBody");
        if (!bodyEl) return;
        const editing = Boolean(state.newsReview?.viewerEditMode);
        if (!report || typeof report !== "object") {
          bodyEl.innerHTML = '<p class="small">Report details are unavailable.</p>';
          syncNewsReviewViewerControls(null);
          return;
        }

        const student =
          report?.student && typeof report.student === "object" ? report.student : {};
        const complianceHtml = newsReviewComplianceNoteHtml(report?.reviewNote || "");
        const complianceBlockHtml =
          complianceHtml === "-" ? ""
          : `<div class="news-review-viewer-block card" data-surface-role="card"><strong>Compliance Findings</strong><div class="news-review-viewer-long">${complianceHtml}</div></div>`;
        const studentLabel = studentIdentityLabel(
          {
            id: student?.studentRefId || report?.studentRefId,
            studentNumber: student?.studentNumber,
            eaglesId: student?.eaglesId || report?.eaglesId,
            profile: {
              fullName: student?.fullName || report?.fullName,
              englishName: student?.englishName || report?.englishName,
              currentGrade: student?.level || report?.level,
            },
          },
          { preferEnglish: true, wrapName: true, includeStudentNumber: true },
        );

        const readOnlyAttr = editing ? "" : " readonly";
        const fieldModeHint = editing ? "Editing enabled" : "Read only";
        const renderInput = (id, label, value, type = "text", placeholder = "") => `
          <div class="news-review-viewer-block card" data-surface-role="card">
            <label for="${escapeHtml(id)}">${escapeHtml(label)}</label>
            <input id="${escapeHtml(id)}" class="card" data-surface-role="card" type="${escapeHtml(type)}" value="${escapeHtml(normalizeText(value))}"${placeholder ? ` placeholder="${escapeHtml(placeholder)}"` : ""}${readOnlyAttr}>
          </div>`;
        const renderTextarea = (id, label, value, rows = 3, placeholder = "") => `
          <div class="news-review-viewer-block card" data-surface-role="card">
            <label for="${escapeHtml(id)}">${escapeHtml(label)}</label>
            <textarea id="${escapeHtml(id)}" class="card" data-surface-role="card" rows="${rows}"${placeholder ? ` placeholder="${escapeHtml(placeholder)}"` : ""}${readOnlyAttr}>${escapeHtml(normalizeText(value))}</textarea>
          </div>`;

        bodyEl.innerHTML = `
        <div class="news-review-viewer-grid">
          <div class="news-review-viewer-block card" data-surface-role="card"><strong>Report ID</strong><span>${escapeHtml(normalizeText(report?.id))}</span></div>
          <div class="news-review-viewer-block card" data-surface-role="card"><strong>Status</strong>${newsReviewStatusChipHtml(report?.reviewStatus)}</div>
          <div class="news-review-viewer-block card" data-surface-role="card"><strong>Student</strong><span>${escapeHtml(studentLabel)}</span></div>
          <div class="news-review-viewer-block card" data-surface-role="card"><strong>Level</strong><span>${escapeHtml(fullLevelLabel(student?.level || report?.level || ""))}</span></div>
          <div class="news-review-viewer-block card" data-surface-role="card"><strong>1. Report Date</strong><span>${escapeHtml(formatDate(report?.reportDate))}</span></div>
          <div class="news-review-viewer-block card" data-surface-role="card"><strong>Reviewed</strong><span>${escapeHtml(formatDateTime(report?.reviewedAt || report?.submittedAt || ""))} ${normalizeText(report?.reviewedByUsername) ? `| ${escapeHtml(normalizeText(report?.reviewedByUsername))}` : ""}</span></div>
          <div class="news-review-viewer-block card" data-surface-role="card"><strong>Mode</strong><span>${escapeHtml(fieldModeHint)}</span></div>
        </div>
        <div class="news-review-viewer-grid">
          ${renderInput("newsReviewViewerSourceLink", "2. Source: Full article link", report?.sourceLink || "", "url", "https://...")}
          ${renderInput("newsReviewViewerArticleTitle", "3. Full article title", report?.articleTitle || "")}
          ${renderInput("newsReviewViewerByline", "4. Byline", report?.byline || "")}
          ${renderInput("newsReviewViewerArticleDateline", "5. Article dateline / publication date", report?.articleDateline || "")}
        </div>
        ${renderTextarea("newsReviewViewerLeadSynopsis", "6. Lead synopsis", report?.leadSynopsis || "", 4)}
        <div class="news-review-viewer-grid">
          ${renderInput("newsReviewViewerActionActor", "7. News action actor", report?.actionActor || "")}
          ${renderInput("newsReviewViewerActionAffected", "8. Who or what was affected", report?.actionAffected || "")}
          ${renderInput("newsReviewViewerActionWhere", "9. News action location", report?.actionWhere || "")}
          ${renderTextarea("newsReviewViewerActionWhat", "10. Current news action", report?.actionWhat || "", 3)}
        </div>
        <div class="news-review-viewer-grid">
          ${renderTextarea("newsReviewViewerActionWhy", "11. Why or how the news action happened", report?.actionWhy || "", 3)}
          ${renderTextarea("newsReviewViewerBiasAssessment", "12. Bias, agenda, spin, or prevarication explanation", report?.biasAssessment || "", 3)}
        </div>
        ${complianceBlockHtml}
      `;
        const vocabularySection = document.getElementById("newsReviewViewerVocabulary");
        if (vocabularySection) {
          const vocabulary = Array.isArray(report?.vocabulary) ? report.vocabulary : [];
          vocabularySection.innerHTML = `
            <strong>13. Vocabulary</strong>
            ${vocabulary.length ? vocabulary.map((row) => `
              <article class="new-word-entry">
                <div class="new-word-entry-head">
                  <strong>${escapeHtml(normalizeText(row?.english) || "New word")}</strong>
                  <span class="new-word-entry-pronunciation">/${escapeHtml(normalizeText(row?.syllabication))}/</span>
                  <strong class="new-word-entry-part-of-speech">${escapeHtml(normalizeText(row?.partOfSpeech))}</strong>
                  <span class="new-word-entry-vietnamese">vi: ${escapeHtml(normalizeText(row?.vietnamese))}</span>
                </div>
                <p class="new-word-entry-definition news-review-vocabulary-definition">${escapeHtml(normalizeText(row?.definition))}</p>
              </article>`).join("") : '<p class="small">No vocabulary saved.</p>'}
            <hr>
          `;
        }
      syncNewsReviewViewerControls(report);
      }

      function closeNewsReviewViewer() {
        const modalEl = document.getElementById("newsReviewViewerModal");
        if (!modalEl) return;
        modalEl.classList.add("hidden");
        state.newsReview.viewerReportId = "";
        state.newsReview.viewerWeekSetId = "";
        state.newsReview.viewerItems = [];
        state.newsReview.viewerIndex = -1;
        state.newsReview.viewerStudentKey = "";
        state.newsReview.viewerEditMode = false;
        syncNewsReviewViewerControls(null);
        setNewsReviewViewerStatus("");
      }

      function shiftNewsReviewViewer(offset = 0) {
        const items =
          Array.isArray(state.newsReview?.viewerItems) ?
            state.newsReview.viewerItems
          : [];
        if (!items.length) return;
        const parsedOffset = Number.parseInt(String(offset), 10);
        if (!Number.isFinite(parsedOffset) || parsedOffset === 0) return;
        const currentIndex = Number.parseInt(String(state.newsReview?.viewerIndex), 10);
        const baseIndex = Number.isFinite(currentIndex) ? currentIndex : 0;
        const nextIndex = Math.max(
          0,
          Math.min(items.length - 1, baseIndex + parsedOffset),
        );
        if (nextIndex === baseIndex) return;
        const nextItem = items[nextIndex] || null;
        if (!nextItem) return;
        state.newsReview.viewerIndex = nextIndex;
        state.newsReview.viewerReportId = normalizeText(nextItem?.id);
        renderNewsReviewViewer(nextItem);
        setNewsReviewViewerStatus(
          `Viewing ${nextIndex + 1} / ${items.length} for selected week set.`,
        );
      }

      async function openNewsReviewViewerByWeekSetId(weekSetId = "", options = {}) {
        const id = normalizeText(weekSetId);
        if (!id) throw new Error("Missing news week-set id.");
        const modalEl = document.getElementById("newsReviewViewerModal");
        if (!modalEl) return;
        const preferLoadAll = options && options.loadAll === false ? false : true;

        let weekSet = newsReviewWeekSetById(id);
        if (!weekSet && preferLoadAll) {
          const payload = await api(`${ADMIN_NEWS_REPORTS_PATH}?status=all&take=500`);
          const fetchedReports = Array.isArray(payload?.items) ? payload.items : [];
          const fetchedSets = buildNewsReviewWeekSets(fetchedReports, {
            status: "all",
            take: 500,
          });
          weekSet = newsReviewWeekSetById(id, fetchedSets);
        }
        if (!weekSet) throw new Error("News week set was not found.");

        const viewerItems = await loadNewsReviewViewerItems(weekSet, options);
        const preferredReportId = normalizeText(
          options?.reportId || weekSet?.latestReportId || viewerItems[0]?.id,
        );
        const viewerIndex = viewerItems.findIndex(
          (entry) => normalizeText(entry?.id) === preferredReportId,
        );
        state.newsReview.viewerItems = viewerItems;
        state.newsReview.viewerIndex = viewerIndex >= 0 ? viewerIndex : 0;
        state.newsReview.viewerWeekSetId = id;
        state.newsReview.viewerStudentKey = normalizeText(
          weekSet?.student?.studentRefId || weekSet?.student?.eaglesId,
        );
        state.newsReview.viewerEditMode = false;
        const activeItem = newsReviewViewerCurrentItem() || viewerItems[0] || null;
        state.newsReview.viewerReportId = normalizeText(activeItem?.id);
        renderNewsReviewViewer(activeItem);
        modalEl.classList.remove("hidden");
        if (!(options && options.silentStatus)) {
          setNewsReviewViewerStatus(
            `Opened week set ${normalizeText(weekSet?.weekStart)} to ${normalizeText(weekSet?.weekEnd)}.`,
          );
        }
      }

      async function openNewsReviewViewerById(reportId = "", options = {}) {
        const id = normalizeText(reportId);
        if (!id) throw new Error("Missing news report id.");
        const preferLoadAll = options && options.loadAll === false ? false : true;
        let weekSet = null;
        const inMemorySets =
          Array.isArray(state.newsReview?.items) ? state.newsReview.items : [];
        weekSet =
          inMemorySets.find((entry) => {
            const reports = Array.isArray(entry?.reports) ? entry.reports : [];
            return reports.some((report) => normalizeText(report?.id) === id);
          }) || null;

        if (!weekSet && preferLoadAll) {
          const payload = await api(`${ADMIN_NEWS_REPORTS_PATH}?status=all&take=500`);
          const fetchedReports = Array.isArray(payload?.items) ? payload.items : [];
          const fetchedSets = buildNewsReviewWeekSets(fetchedReports, {
            status: "all",
            take: 500,
          });
          weekSet =
            fetchedSets.find((entry) => {
              const reports = Array.isArray(entry?.reports) ? entry.reports : [];
              return reports.some((report) => normalizeText(report?.id) === id);
            }) || null;
        }
        if (!weekSet) throw new Error("News report details were not found.");

        await openNewsReviewViewerByWeekSetId(weekSet.id, {
          ...options,
          reportId: id,
        });
        state.newsReview.viewerEditMode = false;
        if (!(options && options.silentStatus))
          setNewsReviewViewerStatus(`Opened report ${id}.`);
      }

      async function applyNewsReviewViewerAction(action = "") {
        const item = newsReviewViewerCurrentItem();
        const reportId = normalizeText(item?.id);
        if (!reportId) throw new Error("Select a report first.");
        const noteField = document.getElementById("newsReviewViewerNote");
        const manualReviewNote =
          noteField instanceof HTMLTextAreaElement ?
            normalizeText(noteField.value)
          : "";
        const reviewNote = composeNewsReviewNoteWithCompliance(
          manualReviewNote,
          item?.reviewNote,
        );
        await applyNewsReviewAction(reportId, action, {
          reviewNote,
          keepViewerOpen: true,
        });
      }

      async function loadNewsReviewQueue({ notify = false } = {}) {
        const filters = newsReviewFilters();
        const params = new URLSearchParams();
        params.set("status", "all");
        if (filters.level) params.set("level", filters.level);
        if (filters.studentRefId) params.set("studentRefId", filters.studentRefId);
        params.set("take", "500");
        const payload = await api(`${ADMIN_NEWS_REPORTS_PATH}?${params.toString()}`);
        const sourceReports = Array.isArray(payload?.items) ? payload.items : [];
        const groupedSets = buildNewsReviewWeekSets(sourceReports, filters);
        const limit = Math.max(
          1,
          Math.min(Number.parseInt(String(filters.take || 200), 10) || 200, 500),
        );
        const visibleSets = groupedSets.slice(0, limit);
        state.newsReview.sourceReports = sourceReports;
        state.newsReview.allItems = groupedSets;
        state.newsReview.items = visibleSets;
        state.newsReview.total = groupedSets.length;
        state.newsReview.hasMore = groupedSets.length > visibleSets.length;
        state.newsReview.statusSummary = summarizeNewsReviewWeekSets(groupedSets);
        state.newsReview.filters = normalizeNewsReviewFilters({
          ...(payload?.filters && typeof payload.filters === "object" ?
            payload.filters
          : {}),
          ...filters,
        });
        refreshNewsReviewFilterControls();
        renderNewsReviewRows();
        if (notify)
          setStatus(
            `News review weeks loaded: ${state.newsReview.items.length} rows.`,
          );
      }

      async function applyNewsReviewAction(reportId = "", action = "", options = {}) {
        const id = normalizeText(reportId);
        const normalizedAction = normalizeLower(action);
        if (!id) throw new Error("Missing news report id.");
        if (!["approve", "revision-requested", "save"].includes(normalizedAction)) {
          throw new Error("Unsupported news review action.");
        }
        const hasReviewNoteOverride =
          options && Object.prototype.hasOwnProperty.call(options, "reviewNote");
        const noteField = document.getElementById("newsReviewViewerNote");
        const reviewNote =
          hasReviewNoteOverride ?
            normalizeText(options.reviewNote)
          : normalizeText(
              noteField instanceof HTMLTextAreaElement ? noteField.value : "",
            );
        const editPayload =
          normalizedAction === "save" ? newsReviewViewerDraftPayload() : {};
        state.newsReview.pendingById[id] = normalizedAction;
        renderNewsReviewRows();
        if (
          !document
            .getElementById("newsReviewViewerModal")
            ?.classList.contains("hidden")
        ) {
          renderNewsReviewViewer(newsReviewViewerCurrentItem());
        }
        try {
          await api(`${ADMIN_NEWS_REPORTS_PATH}/${encodeURIComponent(id)}`, {
            method: "POST",
            body: {
              action: normalizedAction,
              reviewNote,
              ...editPayload,
            },
          });
          await loadNewsReviewQueue();
          if (options && options.keepViewerOpen) {
            await openNewsReviewViewerById(id, {
              loadAll: true,
              loadSetAll: true,
              silentStatus: true,
            });
          }
          const actionLabel =
            normalizedAction === "approve" ? "approved"
            : normalizedAction === "save" ? "saved"
            : "marked for revision";
          setStatus(`News report ${id} ${actionLabel}.`);
        } finally {
          delete state.newsReview.pendingById[id];
          renderNewsReviewRows();
          if (
            !document
              .getElementById("newsReviewViewerModal")
              ?.classList.contains("hidden")
          ) {
            renderNewsReviewViewer(newsReviewViewerCurrentItem());
          }
        }
      }

      async function applyNewsReviewBulkApprove() {
        const reportIds = newsReviewBulkApprovableReportIds();
        if (!reportIds.length) {
          throw new Error("No submitted news reports are currently queued.");
        }
        state.newsReview.bulkApprovePending = true;
        renderNewsReviewRows();
        try {
          const result = await api(`${ADMIN_NEWS_REPORTS_PATH}/bulk`, {
            method: "POST",
            body: {
              action: "approve",
              reportIds,
            },
          });
          closeNewsReviewViewer();
          await loadNewsReviewQueue();
          const processedCount = Math.max(
            0,
            Number.parseInt(String(result?.processedCount || reportIds.length), 10) ||
              reportIds.length,
          );
          setStatus(
            `Approved ${processedCount} news report${
              processedCount === 1 ? "" : "s"
            } from the current queue.`,
          );
        } finally {
          state.newsReview.bulkApprovePending = false;
          renderNewsReviewRows();
        }
      }

      function parsePositiveInteger(value) {
        const text = normalizeText(value);
        if (!text) return null;
        const parsed = Number.parseInt(text, 10);
        if (!Number.isFinite(parsed) || parsed < 1) return null;
        return parsed;
      }

      function nextStudentNumericId() {
        const source = [...(state.students || []), ...(state.dashboardStudents || [])];
        const ids = source
          .map((entry) => parsePositiveInteger(entry?.studentNumber))
          .filter((entry) => Number.isFinite(entry) && entry > 0);
        const max = ids.length ? Math.max(...ids) : STUDENT_NUMBER_START - 1;
        return String(Math.max(STUDENT_NUMBER_START, max + 1));
      }

      async function hydrateNextStudentNumberFromApi() {
        if (state.currentStudent?.id) return;
        let response = null;
        try {
          response = await api("/api/admin/students/next-student-number");
        } catch (error) {
          if (error && (error.status === 404 || error.status === 503)) return;
          throw error;
        }

        const nextNumber = parsePositiveInteger(response?.nextStudentNumber);
        if (!nextNumber) return;

        setFormValue("studentNumber", String(nextNumber));
      }

      const DEFAULT_ADMIN_API_PREFIX = "/api/admin";
      const DEFAULT_ADMIN_PAGE_PATH = "/admin";
      const DEFAULT_ADMIN_PAGE_SLUG = "overview";

      function normalizePathPrefix(value, fallback = DEFAULT_ADMIN_API_PREFIX) {
        let normalized = normalizeText(value || fallback);
        if (!normalized) normalized = fallback;
        if (!normalized.startsWith("/")) normalized = `/${normalized}`;
        if (normalized.length > 1) normalized = normalized.replace(/\/+$/, "");
        return normalized;
      }

      function inferApiPrefixFromPathname(pathname) {
        const normalizedPath = normalizeText(pathname);
        const segments = normalizedPath.split("/").filter(Boolean);
        if (segments.length < 2) return "";

        const fileName = normalizeText(segments[segments.length - 1]).toLowerCase();
        const parentSegment = normalizeText(
          segments[segments.length - 2],
        ).toLowerCase();
        if (fileName !== "student-admin.html") return "";
        if (!/^[a-z0-9-]+$/.test(parentSegment)) return "";
        if (parentSegment === "admin" || parentSegment === "web-asset") return "";

        return normalizePathPrefix(`/api/${parentSegment}`, DEFAULT_ADMIN_API_PREFIX);
      }

      function persistApiPrefix(prefix) {
        const normalized = normalizePathPrefix(prefix, DEFAULT_ADMIN_API_PREFIX);
        void window.SIS_PORTAL_PREFERENCES?.save("sis.admin.apiPrefix", normalized);
        return normalized;
      }

      function resolveApiPrefixConfig() {
        const params = new URLSearchParams(window.location.search || "");
        const queryPrefix = normalizeText(params.get("apiPrefix"));
        const injectedPrefix = normalizeText(window.__SIS_ADMIN_API_PREFIX);
        const inferredPrefix = inferApiPrefixFromPathname(window.location.pathname);
        const storedPrefix = normalizeText(window.SIS_PORTAL_PREFERENCES?.get("sis.admin.apiPrefix", ""));
        const hasExplicitOverride = Boolean(queryPrefix || injectedPrefix);
        const resolvedPrefix = normalizePathPrefix(
          queryPrefix || injectedPrefix || storedPrefix || inferredPrefix,
          DEFAULT_ADMIN_API_PREFIX,
        );

        if (queryPrefix) persistApiPrefix(resolvedPrefix);

        return {
          resolvedPrefix,
          inferredPrefix:
            inferredPrefix ?
              normalizePathPrefix(inferredPrefix, DEFAULT_ADMIN_API_PREFIX)
            : "",
          hasExplicitOverride,
        };
      }

      function resolveAdminPagePath() {
        const injectedPath = normalizeText(window.__SIS_ADMIN_PAGE_PATH);
        return normalizePathPrefix(
          injectedPath || DEFAULT_ADMIN_PAGE_PATH,
          DEFAULT_ADMIN_PAGE_PATH,
        );
      }

      function isStaticAdminPreviewPath(pathname) {
        return normalizeText(pathname || window.location.pathname).endsWith(
          "/web-asset/admin/student-admin.html",
        );
      }

      function resolveApiOrigin() {
        const params = new URLSearchParams(window.location.search || "");
        const queryOrigin = normalizeText(params.get("apiOrigin"));
        const injectedOrigin = normalizeText(window.__SIS_ADMIN_API_ORIGIN);
        const isJsdom =
          /\bjsdom\b/i.test(String(window.navigator?.userAgent || ""));
        const sameOriginFallback =
          window.location.protocol.startsWith("http") &&
          !isJsdom &&
          !isStaticAdminPreviewPath(window.location.pathname) ?
            window.location.origin
          : "";
        const selectedOrigin = queryOrigin || injectedOrigin || sameOriginFallback;
        if (!selectedOrigin) {
          return "";
        }
        try {
          return new URL(selectedOrigin, window.location.origin).origin;
        } catch (error) {
          void error;
          return "";
        }
      }

      function shouldPreserveAdminApiOriginParamFor(apiOrigin = "") {
        const normalizedOrigin = normalizeText(apiOrigin);
        if (!normalizedOrigin) return false;
        if (isStaticAdminPreviewMode()) return true;
        if (!window.location.protocol.startsWith("http")) return true;
        if (new URLSearchParams(window.location.search || "").has("apiOrigin"))
          return true;
        try {
          return new URL(normalizedOrigin, window.location.origin).origin !==
            window.location.origin;
        } catch (error) {
          void error;
          return true;
        }
      }

      function shouldPreserveAdminApiOriginParam() {
        return shouldPreserveAdminApiOriginParamFor(ADMIN_API_ORIGIN);
      }

      function buildAdminRuntimeHrefWithOrigin(
        href = DEFAULT_ADMIN_PAGE_PATH,
        apiOrigin = "",
        adminPagePath = DEFAULT_ADMIN_PAGE_PATH,
      ) {
        const targetUrl = new URL(
          normalizeText(href) || normalizeText(adminPagePath) || DEFAULT_ADMIN_PAGE_PATH,
          window.location.origin,
        );
        if (shouldPreserveAdminApiOriginParamFor(apiOrigin)) {
          targetUrl.searchParams.set("apiOrigin", normalizeText(apiOrigin));
        }
        return `${targetUrl.pathname}${targetUrl.search}${targetUrl.hash}`;
      }

      function compareIsoDateText(left = "", right = "") {
        return normalizeText(left)
          .slice(0, 10)
          .localeCompare(normalizeText(right).slice(0, 10));
      }

      function isoDateOffset(value = "", days = 0) {
        const parsed = parseIsoDateLocal(value);
        if (!parsed) return "";
        const date = shiftToFixedTimeZone(parsed);
        date.setUTCHours(0, 0, 0, 0);
        date.setUTCDate(
          date.getUTCDate() + (Number.isFinite(days) ? Math.trunc(days) : 0),
        );
        return localIsoDate(shiftFromFixedTimeZone(date));
      }

      function isoDateDiffDays(startIso = "", endIso = "") {
        const start = parseIsoDateLocal(startIso);
        const end = parseIsoDateLocal(endIso);
        if (!start || !end) return 0;
        const millisPerDay = 24 * 60 * 60 * 1000;
        const shiftedStart = shiftToFixedTimeZone(start);
        const shiftedEnd = shiftToFixedTimeZone(end);
        const utcStart = Date.UTC(
          shiftedStart.getUTCFullYear(),
          shiftedStart.getUTCMonth(),
          shiftedStart.getUTCDate(),
        );
        const utcEnd = Date.UTC(
          shiftedEnd.getUTCFullYear(),
          shiftedEnd.getUTCMonth(),
          shiftedEnd.getUTCDate(),
        );
        return Math.round((utcEnd - utcStart) / millisPerDay);
      }

      function schoolYearLabelFromRange(startDate = "", endDate = "") {
        const start = parseIsoDateLocal(startDate);
        const end = parseIsoDateLocal(endDate);
        if (!start || !end) return "";
        const shiftedStart = shiftToFixedTimeZone(start);
        const shiftedEnd = shiftToFixedTimeZone(end);
        const startYear = shiftedStart.getUTCFullYear();
        const endYear = shiftedEnd.getUTCFullYear();
        if (startYear === endYear) return String(startYear);
        return `${startYear}-${endYear}`;
      }

      function isSchoolYearKey(value = "") {
        return /^\d{4}-\d{4}$/.test(normalizeText(value));
      }

      function splitSchoolYearIntoQuarters(startDate = "", endDate = "") {
        const startIso = normalizeText(startDate).slice(0, 10);
        const endIso = normalizeText(endDate).slice(0, 10);
        if (
          !parseIsoDateLocal(startIso) ||
          !parseIsoDateLocal(endIso) ||
          compareIsoDateText(startIso, endIso) > 0
        )
          return [];

        const ranges = [];
        let cursor = startIso;
        let remainingDays = isoDateDiffDays(startIso, endIso) + 1;

        for (let index = 0; index < 4; index += 1) {
          const quartersLeft = 4 - index;
          const quarterKey = `q${index + 1}`;
          const start = cursor;
          if (!parseIsoDateLocal(start)) break;

          let end = "";
          if (index === 3) {
            end = endIso;
          } else {
            const minimumDaysAfter = quartersLeft - 1;
            const maxLength = Math.max(1, remainingDays - minimumDaysAfter);
            const suggestedLength = Math.max(
              1,
              Math.floor(remainingDays / quartersLeft),
            );
            const pickedLength = Math.min(maxLength, suggestedLength);
            const latestAllowed = isoDateOffset(endIso, -minimumDaysAfter);
            end = isoDateOffset(start, pickedLength - 1);
            if (
              parseIsoDateLocal(latestAllowed) &&
              compareIsoDateText(end, latestAllowed) > 0
            ) {
              end = latestAllowed;
            }
          }

          if (!parseIsoDateLocal(end) || compareIsoDateText(end, start) < 0)
            end = start;
          ranges.push({ quarter: quarterKey, startDate: start, endDate: end });
          cursor = isoDateOffset(end, 1);
          if (!parseIsoDateLocal(cursor) || compareIsoDateText(cursor, endIso) > 0)
            cursor = endIso;
          remainingDays = Math.max(0, isoDateDiffDays(cursor, endIso) + 1);
        }
        return ranges;
      }

      function normalizeSchoolSetupQuarters(source = []) {
        return (Array.isArray(source) ? source : [])
          .map((entry) => {
            const quarter = quarterKey(entry?.quarter);
            const startDate = normalizeText(entry?.startDate).slice(0, 10);
            const endDate = normalizeText(entry?.endDate).slice(0, 10);
            if (!quarter || !parseIsoDateLocal(startDate) || !parseIsoDateLocal(endDate)) return null;
            if (compareIsoDateText(startDate, endDate) > 0) return null;
            return {
              quarter,
              startDate,
              endDate,
            };
          })
          .filter((entry) => entry && typeof entry === "object")
          .sort((left, right) => quarterSortKey(left?.quarter) - quarterSortKey(right?.quarter));
      }

      function normalizeCourseWeekCalendars(source = []) {
        return (Array.isArray(source) ? source : [])
          .map((calendar) => {
            if (!calendar || typeof calendar !== "object" || !Array.isArray(calendar.weeks)) return null;
            const weeks = calendar.weeks
              .map((week) => ({
                weekNumber: Number.parseInt(String(week?.weekNumber || ""), 10),
                saturday: normalizeText(week?.saturday).slice(0, 10),
                sunday: normalizeText(week?.sunday).slice(0, 10),
                startDate: normalizeText(week?.startDate || week?.saturday).slice(0, 10),
                endDate: normalizeText(week?.endDate || week?.sunday).slice(0, 10),
              }))
              .filter((week) => Number.isInteger(week.weekNumber) && week.weekNumber >= 1 && week.weekNumber <= 52);
            if (weeks.length !== 52) return null;
            return {
              schoolYear: normalizeText(calendar.schoolYear),
              q1StartDate: normalizeText(calendar.q1StartDate).slice(0, 10),
              q1EndDate: normalizeText(calendar.q1EndDate).slice(0, 10),
              generatedAt: normalizeText(calendar.generatedAt),
              weeks,
            };
          })
          .filter((calendar) => calendar && calendar.schoolYear);
      }

      function quarterSortKey(value = "") {
        const normalized = quarterKey(value);
        if (normalized === "q1") return 1;
        if (normalized === "q2") return 2;
        if (normalized === "q3") return 3;
        if (normalized === "q4") return 4;
        return 9;
      }

      function normalizeSchoolSetupState(source = {}) {
        const normalizedSource = source && typeof source === "object" ? source : {};
        const startDate = normalizeText(normalizedSource.startDate).slice(0, 10);
        const endDate = normalizeText(normalizedSource.endDate).slice(0, 10);
        const schoolYear = normalizeText(normalizedSource.schoolYear);
        const quarters = normalizeSchoolSetupQuarters(normalizedSource.quarters);
        const letterGradeRanges = normalizeSchoolLetterGradeRanges(
          normalizedSource.letterGradeRanges,
        );
        const validStart = parseIsoDateLocal(startDate);
        const validEnd = parseIsoDateLocal(endDate);
        const hasValidRange =
          Boolean(validStart && validEnd && compareIsoDateText(startDate, endDate) <= 0);
        const derivedSchoolYear = hasValidRange ?
          schoolYearLabelFromRange(startDate, endDate) :
          "";
        const hasValidSchoolYear =
          Boolean(
            isSchoolYearKey(schoolYear) &&
            schoolYear === derivedSchoolYear,
          );
        const hasSequentialQuarters =
          quarters.length === 4 &&
          quarters.every((entry, index) => {
            const expectedQuarter = `q${index + 1}`;
            if (!entry || normalizeText(entry.quarter).toLowerCase() !== expectedQuarter) return false;
            if (!parseIsoDateLocal(entry.startDate) || !parseIsoDateLocal(entry.endDate)) return false;
            if (compareIsoDateText(entry.startDate, entry.endDate) > 0) return false;
            if (index === 0) {
              if (entry.startDate !== startDate) return false;
            } else {
              const previousQuarter = quarters[index - 1];
              if (isoDateOffset(previousQuarter.endDate, 1) !== entry.startDate) return false;
            }
            if (index === quarters.length - 1 && entry.endDate !== endDate) return false;
            return true;
          });
        const schoolSetupState =
          hasValidRange && hasValidSchoolYear && hasSequentialQuarters ?
            "ok" :
            "maintenance";
        return {
          startDate,
          endDate,
          schoolYear,
          quarters,
          courseWeekCalendars: normalizeCourseWeekCalendars(normalizedSource.courseWeekCalendars),
          letterGradeRanges,
          schoolSetupState,
        };
      }

      function normalizeSchoolSetup(source = {}) {
        return normalizeSchoolSetupState(source);
      }

      function normalizeSchoolProfile(source = {}) {
        const fallback = defaultSchoolProfile();
        const normalizedSource = source && typeof source === "object" ? source : {};
        return {
          schoolName: normalizeText(normalizedSource.schoolName || fallback.schoolName),
          bilingualTextVi: normalizeText(
            normalizedSource.bilingualTextVi || fallback.bilingualTextVi,
          ),
          bilingualTextEn: normalizeText(
            normalizedSource.bilingualTextEn || fallback.bilingualTextEn,
          ),
          motto: normalizeText(normalizedSource.motto || fallback.motto),
          mission: normalizeText(normalizedSource.mission || fallback.mission),
          values: normalizeText(normalizedSource.values || fallback.values),
          address: normalizeText(normalizedSource.address || fallback.address),
          phone: normalizeText(normalizedSource.phone || fallback.phone),
          publicSite: normalizeText(normalizedSource.publicSite || fallback.publicSite),
          privateLessonSite: normalizeText(
            normalizedSource.privateLessonSite || fallback.privateLessonSite,
          ),
          webPresence: normalizeText(
            normalizedSource.webPresence || fallback.webPresence,
          ),
          socialIm: normalizeText(normalizedSource.socialIm || fallback.socialIm),
          businessTaxId: normalizeText(
            normalizedSource.businessTaxId || fallback.businessTaxId,
          ),
          timeFormat: normalizeText(normalizedSource.timeFormat || fallback.timeFormat),
          timeZone: normalizeText(normalizedSource.timeZone || fallback.timeZone),
          googleMapsEmbedIframe: normalizeText(
            normalizedSource.googleMapsEmbedIframe || fallback.googleMapsEmbedIframe,
          ),
          logoDataUrl: normalizeText(
            normalizedSource.logoDataUrl || fallback.logoDataUrl,
          ),
        };
      }

      function schoolSetupState() {
        return normalizeSchoolSetup(
          state.uiSettings?.schoolSetup || DEFAULT_UI_SETTINGS.schoolSetup,
        );
      }

      function schoolProfileState() {
        return normalizeSchoolProfile(
          state.uiSettings?.schoolProfile || DEFAULT_UI_SETTINGS.schoolProfile,
        );
      }

      function newsReportValidationState() {
        return normalizeNewsReportValidationSettings(
          state.uiSettings?.newsReportValidation ||
            DEFAULT_UI_SETTINGS.newsReportValidation,
        );
      }

      function normalizeQueueHubPanelOrder(values = []) {
        const source = Array.isArray(values) ? values : [];
        const selected = source
          .map((entry) => normalizeText(entry))
          .filter((entry) => QUEUE_HUB_PANEL_IDS.includes(entry));
        const merged = [...new Set(selected)];
        QUEUE_HUB_PANEL_IDS.forEach((panelId) => {
          if (!merged.includes(panelId)) merged.push(panelId);
        });
        return merged;
      }

      function normalizeQueueHubSettings(source = {}) {
        return {
          panelOrder: normalizeQueueHubPanelOrder(
            source?.panelOrder || DEFAULT_UI_SETTINGS.queueHub.panelOrder,
          ),
        };
      }

      function schoolBrandFallbackToken(name = "") {
        const parts = normalizeText(name).split(/\s+/).filter(Boolean);
        if (!parts.length) return "SIS";
        return (
          parts
            .slice(0, 2)
            .map((part) => normalizeText(part).charAt(0).toUpperCase())
            .join("") || "SIS"
        );
      }

      function renderSchoolBranding() {
        const profile = schoolProfileState();
        const schoolName = profile.schoolName || "The Eagles Club";
        const logoDataUrl = normalizeText(profile.logoDataUrl);
        const fallbackToken = schoolBrandFallbackToken(schoolName);
        const schoolNameEl = document.getElementById("appSchoolName");
        if (schoolNameEl) {
          schoolNameEl.textContent = schoolName;
          schoolNameEl.title = schoolName;
        }

        [
          { imgId: "appBrandLogo", fallbackId: "appBrandLogoFallback" },
          { imgId: "sidebarLogoImg", fallbackId: "sidebarLogoFallback" },
        ].forEach(({ imgId, fallbackId }) => {
          const imageEl = document.getElementById(imgId);
          const fallbackEl = document.getElementById(fallbackId);
          const hasLogo = Boolean(logoDataUrl);
          if (imageEl instanceof HTMLImageElement) {
            imageEl.classList.toggle("hidden", !hasLogo);
            imageEl.src = hasLogo ? logoDataUrl : "data:,";
          }
          if (fallbackEl) {
            fallbackEl.classList.toggle("hidden", hasLogo);
            fallbackEl.textContent = fallbackToken;
            fallbackEl.title = schoolName;
          }
        });
      }

      function normalizeUiSettings(source) {
        return {
          multiSchool: Boolean(source?.multiSchool),
          schoolSetup: normalizeSchoolSetup(
            source?.schoolSetup || DEFAULT_UI_SETTINGS.schoolSetup,
          ),
          schoolProfile: normalizeSchoolProfile(
            source?.schoolProfile || DEFAULT_UI_SETTINGS.schoolProfile,
          ),
          newsReportValidation: normalizeNewsReportValidationSettings(
            source?.newsReportValidation || DEFAULT_UI_SETTINGS.newsReportValidation,
          ),
          levelTileStylesByLevel:
            source?.levelTileStylesByLevel && typeof source.levelTileStylesByLevel === "object" ?
              source.levelTileStylesByLevel : {},
          profileFormConfig:
            source?.profileFormConfig && typeof source.profileFormConfig === "object" ?
              source.profileFormConfig : null,
          globalAssets:
            source?.globalAssets && typeof source.globalAssets === "object" ?
              source.globalAssets : {},
          queueHub: normalizeQueueHubSettings(
            source?.queueHub || DEFAULT_UI_SETTINGS.queueHub,
          ),
        };
      }

      function normalizeSisRuntimeConfig(source = {}) {
        const candidate = source && typeof source === "object" ? source : {};
        return {
          databaseUrl: normalizeText(
            candidate.databaseUrl || DEFAULT_SIS_CONFIG.runtime.databaseUrl,
          ),
          redisUrl: normalizeText(
            candidate.redisUrl || DEFAULT_SIS_CONFIG.runtime.redisUrl,
          ),
          sessionDriver:
            normalizeText(candidate.sessionDriver || DEFAULT_SIS_CONFIG.runtime.sessionDriver) ||
            DEFAULT_SIS_CONFIG.runtime.sessionDriver,
          adminSessionTtlSeconds:
            Math.max(
              60,
              Number.parseInt(
                String(
                  candidate.adminSessionTtlSeconds ||
                    DEFAULT_SIS_CONFIG.runtime.adminSessionTtlSeconds,
                ),
                10,
              ) || DEFAULT_SIS_CONFIG.runtime.adminSessionTtlSeconds,
            ),
          parentSessionTtlSeconds:
            Math.max(
              60,
              Number.parseInt(
                String(
                  candidate.parentSessionTtlSeconds ||
                    DEFAULT_SIS_CONFIG.runtime.parentSessionTtlSeconds,
                ),
                10,
              ) || DEFAULT_SIS_CONFIG.runtime.parentSessionTtlSeconds,
            ),
          studentSessionTtlSeconds:
            Math.max(
              60,
              Number.parseInt(
                String(
                  candidate.studentSessionTtlSeconds ||
                    DEFAULT_SIS_CONFIG.runtime.studentSessionTtlSeconds,
                ),
                10,
              ) || DEFAULT_SIS_CONFIG.runtime.studentSessionTtlSeconds,
            ),
          redisConnectTimeoutMs:
            Math.max(
              100,
              Number.parseInt(
                String(
                  candidate.redisConnectTimeoutMs ||
                    DEFAULT_SIS_CONFIG.runtime.redisConnectTimeoutMs,
                ),
                10,
              ) || DEFAULT_SIS_CONFIG.runtime.redisConnectTimeoutMs,
            ),
        };
      }

      function normalizeSisConfig(source = {}) {
        const candidate = source && typeof source === "object" ? source : {};
        const newsReportsCandidate =
          candidate.newsReports && typeof candidate.newsReports === "object"
            ? candidate.newsReports
            : DEFAULT_SIS_CONFIG.newsReports;
        return {
          runtime: normalizeSisRuntimeConfig(
            candidate.runtime || DEFAULT_SIS_CONFIG.runtime,
          ),
          newsReports: {
            weeklyMinimumReports:
              Math.max(
                1,
                Number.parseInt(
                  String(
                    newsReportsCandidate?.weeklyMinimumReports ||
                      DEFAULT_SIS_CONFIG.newsReports.weeklyMinimumReports,
                  ),
                  10,
                ) || DEFAULT_SIS_CONFIG.newsReports.weeklyMinimumReports,
              ),
            autoApproveEnabled:
              String(
                newsReportsCandidate?.autoApproveEnabled ??
                  DEFAULT_SIS_CONFIG.newsReports.autoApproveEnabled,
              )
                .trim()
                .toLowerCase() !== "false",
            autoApproveDelayHours:
              Math.max(
                1,
                Number.parseInt(
                  String(
                    newsReportsCandidate?.autoApproveDelayHours ||
                      DEFAULT_SIS_CONFIG.newsReports.autoApproveDelayHours,
                  ),
                  10,
                ) || DEFAULT_SIS_CONFIG.newsReports.autoApproveDelayHours,
              ),
          },
        };
      }

      function uiSettingsMetaFromSource(source) {
        const candidate = source && typeof source === "object" ? source : {}
        const schoolSetup = candidate.schoolSetup && typeof candidate.schoolSetup === "object" ?
          candidate.schoolSetup :
          {}
        const normalizedSchoolSetup = normalizeSchoolSetup(schoolSetup)
        const quarters = Array.isArray(normalizedSchoolSetup.quarters) ? normalizedSchoolSetup.quarters : []
        return {
          schoolSetupStoredQuarterCount: quarters.length,
          schoolSetupStoredQuartersPresent: quarters.length > 0,
          schoolSetupStoredQuartersMissing: quarters.length < 4,
          schoolSetupState: normalizedSchoolSetup.schoolSetupState,
          schoolSetupHasIssues: normalizedSchoolSetup.schoolSetupState !== "ok",
        }
      }

      function loadUiSettingsFromStorage() {
        const stored = window.SIS_PORTAL_PREFERENCES?.get("sis.admin.uiSettings", null);
        if (!stored) {
          state.uiSettingsMeta = uiSettingsMetaFromSource(DEFAULT_UI_SETTINGS);
          return normalizeUiSettings(DEFAULT_UI_SETTINGS);
        }
        try {
          const parsed = typeof stored === "string" ? JSON.parse(stored) : stored;
          state.uiSettingsMeta = uiSettingsMetaFromSource(parsed);
          return normalizeUiSettings({
            ...DEFAULT_UI_SETTINGS,
            ...(parsed && typeof parsed === "object" ? parsed : {}),
          });
        } catch (error) {
          void error;
          state.uiSettingsMeta = uiSettingsMetaFromSource(DEFAULT_UI_SETTINGS);
          return normalizeUiSettings(DEFAULT_UI_SETTINGS);
        }
      }

      function loadSisConfigFromStorage() {
        const stored = window.SIS_PORTAL_PREFERENCES?.get("sis.admin.sisConfig", null);
        if (!stored) {
          state.sisConfigMeta = null;
          return normalizeSisConfig(DEFAULT_SIS_CONFIG);
        }
        try {
          const parsed = typeof stored === "string" ? JSON.parse(stored) : stored;
          state.sisConfigMeta = parsed && typeof parsed === "object" ? parsed.meta || null : null;
          return normalizeSisConfig({
            ...DEFAULT_SIS_CONFIG,
            ...(parsed && typeof parsed === "object" ? parsed : {}),
          });
        } catch (error) {
          void error;
          state.sisConfigMeta = null;
          return normalizeSisConfig(DEFAULT_SIS_CONFIG);
        }
      }

      function persistUiSettings(settings, metaOverride = null) {
        const normalized = normalizeUiSettings({
          ...DEFAULT_UI_SETTINGS,
          ...(settings && typeof settings === "object" ? settings : {}),
        });
        state.uiSettings = normalized;
        state.uiSettingsMeta =
          metaOverride && typeof metaOverride === "object" ?
            metaOverride :
            uiSettingsMetaFromSource(normalized);
        void window.SIS_PORTAL_PREFERENCES?.save("sis.admin.uiSettings", normalized);
        return normalized;
      }

      function persistSisConfig(config, metaOverride = null) {
        const normalized = normalizeSisConfig({
          ...DEFAULT_SIS_CONFIG,
          ...(config && typeof config === "object" ? config : {}),
        });
        state.sisConfig = normalized;
        state.sisConfigMeta = metaOverride && typeof metaOverride === "object" ? metaOverride : null;
        void window.SIS_PORTAL_PREFERENCES?.save("sis.admin.sisConfig", { ...normalized, meta: state.sisConfigMeta });
        return normalized;
      }

      async function hydrateUiSettingsFromServer() {
        if (!canReadData()) return null;
        try {
          const result = await api(ADMIN_UI_SETTINGS_PATH);
          const candidate =
            result && typeof result === "object" ? result.uiSettings : null;
          const sisConfigCandidate =
            result && typeof result === "object" ? result.sisConfig : null;
          if (!candidate || typeof candidate !== "object" || Array.isArray(candidate))
            return null;
          const meta = result?.meta && typeof result.meta === "object" ?
            result.meta :
            uiSettingsMetaFromSource(candidate);
          const settings = persistUiSettings(candidate, meta);
          persistSisConfig(sisConfigCandidate || DEFAULT_SIS_CONFIG, result?.sisConfigMeta || null);
          applySisConfigToForm(state.sisConfig);
          return settings;
        } catch (error) {
          void error;
          return null;
        }
      }

      async function persistUiSettingsToServer(
        settings,
        sisConfig = state.sisConfig || DEFAULT_SIS_CONFIG,
        { notifyOnFailure = false } = {},
      ) {
        if (!canManageSettings()) return null;
        const normalized = normalizeUiSettings(settings);
        const normalizedSisConfig = normalizeSisConfig(sisConfig);
        try {
          return await api(ADMIN_UI_SETTINGS_PATH, {
            method: "PUT",
            body: {
              uiSettings: normalized,
              sisConfig: normalizedSisConfig,
            },
          });
        } catch (error) {
          if (notifyOnFailure) {
            const message =
              normalizeText(error?.message) || "Unable to sync settings to server.";
            setStatus(`Settings saved locally only: ${message}`, true);
          }
          return null;
        }
      }

      const CLASS_LEVEL_TILE_STYLE_STORAGE_KEY = "sis.admin.levelTiles.v1";
      const LEGACY_ATTENDANCE_LEVEL_TILE_STORAGE_KEY =
        "sis.admin.attendance.levelTiles.v1";
      const ATTENDANCE_FORM_STORAGE_KEY = "sis.admin.attendance.form.v1";
      const ATTENDANCE_STATUS_CHOICES = ["absent", "present", "tardy10", "tardy30"];

      function attendanceTodayIsoDate() {
        return localIsoDate(new Date());
      }

      function defaultAttendanceSchoolYear(value = new Date()) {
        const setup = schoolSetupState();
        const schoolYear = normalizeText(setup?.schoolYear);
        const isoDate =
          value instanceof Date ?
            localIsoDate(value)
          : normalizeText(value).slice(0, 10);
        if (!schoolYear) return "";
        if (!isoDate) return schoolYear;
        if (
          !parseIsoDateLocal(isoDate) ||
          !parseIsoDateLocal(setup.startDate) ||
          !parseIsoDateLocal(setup.endDate)
        ) {
          return "";
        }
        if (
          compareIsoDateText(isoDate, setup.startDate) >= 0 &&
          compareIsoDateText(isoDate, setup.endDate) <= 0
        ) {
          return schoolYear;
        }
        return "";
      }

      function loadAttendanceLevelTileConfigFromStorage() {
        const stored = window.SIS_PORTAL_PREFERENCES?.get(CLASS_LEVEL_TILE_STYLE_STORAGE_KEY, {});
        return stored && typeof stored === "object" && !Array.isArray(stored) ? stored : {};
      }

      function rehydratePreferenceBackedState() {
        state.uiSettings = loadUiSettingsFromStorage();
        state.sisConfig = loadSisConfigFromStorage();
        applySisConfigToForm(state.sisConfig);
        state.profileFormConfig = loadProfileFormConfigFromStorage();
        state.tableArchiveIndex = loadTableArchiveIndexFromStorage();
        state.performanceHoldIndex = loadPerformanceHoldIndexFromStorage();
        state.tableColumnVisibility = loadAllTableColumnVisibilityFromStorage();
        state.attendanceColumnVisibility = state.tableColumnVisibility.attendance;
        state.eaglesIdSearchHistory = loadStudentIdSearchHistoryFromStorage();
        state.globalTextZoomPercent = loadGlobalTextZoomFromStorage();
        state.attendanceLanding.tileConfigByLevel =
          loadAttendanceLevelTileConfigFromStorage();
        state.parentTracking.teacherNames = loadParentTrackingTeacherNamesFromStorage();
        state.parentTracking.lessonSummaryByLevelDate =
          loadParentTrackingLessonSummaryFromStorage();
      }

      async function persistAttendanceLevelTileConfig(tileConfigByLevel) {
        const normalized =
          tileConfigByLevel && typeof tileConfigByLevel === "object" ?
            tileConfigByLevel
          : {};
        state.attendanceLanding.tileConfigByLevel = normalized;
        state.uiSettings.levelTileStylesByLevel = normalized;
        const persisted = await persistUiSettingsToServer(state.uiSettings);
        if (!persisted) throw new Error("Unable to save class-level tile settings to PostgreSQL.");
        void window.SIS_PORTAL_PREFERENCES?.save(CLASS_LEVEL_TILE_STYLE_STORAGE_KEY, normalized);
        return normalized;
      }

      async function saveAttendanceTileAsset(assetKey, dataUrl, levelName) {
        const normalizedDataUrl = normalizeText(dataUrl);
        if (!normalizedDataUrl) return null;
        const result = await api(`${ADMIN_ASSETS_PATH}/${encodeURIComponent(assetKey)}`, {
          method: "PUT",
          body: {
            assetKey,
            dataUrl: normalizedDataUrl,
            kind: "class-level-tile",
            ownerType: "system-config",
            ownerId: `level:${levelNameKey(levelName)}`,
            metadata: { level: normalizeText(levelName), source: "admin-level-tile-editor" },
          },
        });
        return result?.asset || null;
      }

      function loadAttendanceFormContextFromStorage() {
        const parsed = window.SIS_PORTAL_PREFERENCES?.get(ATTENDANCE_FORM_STORAGE_KEY, {});
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
        return { selectedLevel: normalizeText(parsed.selectedLevel) };
      }

      function persistAttendanceFormContext() {
        void window.SIS_PORTAL_PREFERENCES?.save(ATTENDANCE_FORM_STORAGE_KEY, {
          selectedLevel: normalizeText(state.attendanceLanding?.selectedLevel),
        });
      }

      state.uiSettings = loadUiSettingsFromStorage();
      state.sisConfig = loadSisConfigFromStorage();
      applySisConfigToForm(state.sisConfig);
      state.profileFormConfig = loadProfileFormConfigFromStorage();
      state.tableArchiveIndex = loadTableArchiveIndexFromStorage();
      state.performanceHoldIndex = loadPerformanceHoldIndexFromStorage();
      state.tableColumnVisibility = loadAllTableColumnVisibilityFromStorage();
      state.attendanceColumnVisibility = state.tableColumnVisibility.attendance;
      state.eaglesIdSearchHistory = loadStudentIdSearchHistoryFromStorage();
      state.globalTextZoomPercent = loadGlobalTextZoomFromStorage();
      state.attendanceLanding.tileConfigByLevel =
        loadAttendanceLevelTileConfigFromStorage();
      state.parentTracking.teacherNames = loadParentTrackingTeacherNamesFromStorage();
      state.parentTracking.lessonSummaryByLevelDate =
        loadParentTrackingLessonSummaryFromStorage();

      function schoolSetupQuarterRowsHtml(setup = schoolSetupState()) {
        const quarters = Array.isArray(setup?.quarters) ? setup.quarters : [];
        if (!quarters.length)
          return '<tr><td colspan="4">Click Auto-Fill Quarters to generate the explicit quarter rows.</td></tr>';
        return quarters
          .map((entry) => {
            const quarter = normalizeText(entry?.quarter || "").toUpperCase();
            const startDate = normalizeText(entry?.startDate).slice(0, 10);
            const endDate = normalizeText(entry?.endDate).slice(0, 10);
            const days = Math.max(0, isoDateDiffDays(startDate, endDate) + 1);
            return `<tr><td>${escapeHtml(quarter)}</td><td>${escapeHtml(startDate)}</td><td>${escapeHtml(endDate)}</td><td>${days}</td></tr>`;
          })
          .join("");
      }

      function schoolSetupDraftQuarters() {
        const setup = state.uiSettings?.schoolSetup || {};
        return normalizeSchoolSetupQuarters(setup.quarters);
      }

      function autoFillSchoolSetupFromInputs() {
        const startDate = normalizeText(
          document.getElementById("schoolSetupStartDate")?.value,
        ).slice(0, 10);
        const endDate = normalizeText(
          document.getElementById("schoolSetupEndDate")?.value,
        ).slice(0, 10);
        const letterGradeRangesText = normalizeText(
          document.getElementById("schoolSetupLetterGradeRanges")?.value,
        );
        if (!parseIsoDateLocal(startDate) || !parseIsoDateLocal(endDate)) {
          throw new Error("First and last school day are required.");
        }
        if (compareIsoDateText(startDate, endDate) > 0) {
          throw new Error("Last school day must be on or after the first school day.");
        }
        const quarters = splitSchoolYearIntoQuarters(startDate, endDate);
        if (!quarters.length) {
          throw new Error("Unable to generate quarter rows for the selected school days.");
        }
        const setup = normalizeSchoolSetup({
          startDate,
          endDate,
          schoolYear: schoolYearLabelFromRange(startDate, endDate),
          quarters,
          letterGradeRanges: parseSchoolLetterGradeRangesText(letterGradeRangesText),
        });
        state.uiSettings = {
          ...state.uiSettings,
          schoolSetup: setup,
        };
        renderSchoolSetupPanel({
          setup,
          profile: draftSchoolProfileFromInputs({
            fallbackProfile: schoolProfileState(),
          }),
          newsReportValidation: draftNewsReportValidationFromInputs({
            fallbackValidation: newsReportValidationState(),
          }),
          message: "Quarter rows auto-filled. Review and save to persist them.",
        });
        return setup;
      }

      function previewSchoolSetupFromInputsData() {
        const startDate = normalizeText(
          document.getElementById("schoolSetupStartDate")?.value,
        ).slice(0, 10);
        const endDate = normalizeText(
          document.getElementById("schoolSetupEndDate")?.value,
        ).slice(0, 10);
        const letterGradeRangesText = normalizeText(
          document.getElementById("schoolSetupLetterGradeRanges")?.value,
        );
        if (!parseIsoDateLocal(startDate) || !parseIsoDateLocal(endDate)) return null;
        if (compareIsoDateText(startDate, endDate) > 0) return null;
        return normalizeSchoolSetup({
          startDate,
          endDate,
          schoolYear: schoolYearLabelFromRange(startDate, endDate),
          quarters: splitSchoolYearIntoQuarters(startDate, endDate),
          letterGradeRanges: parseSchoolLetterGradeRangesText(letterGradeRangesText),
        });
      }

      function schoolSetupInputValue(id = "", fallback = "") {
        const fieldEl = document.getElementById(id);
        if (!fieldEl) return normalizeText(fallback);
        return normalizeText(fieldEl.value || fallback);
      }

      function draftSchoolProfileFromInputs({
        fallbackProfile = schoolProfileState(),
      } = {}) {
        const fallback = normalizeSchoolProfile(fallbackProfile);
        return normalizeSchoolProfile({
          schoolName: schoolSetupInputValue("schoolSetupName", fallback.schoolName),
          bilingualTextVi: schoolSetupInputValue(
            "schoolSetupBilingualVi",
            fallback.bilingualTextVi,
          ),
          bilingualTextEn: schoolSetupInputValue(
            "schoolSetupBilingualEn",
            fallback.bilingualTextEn,
          ),
          motto: schoolSetupInputValue("schoolSetupMotto", fallback.motto),
          mission: schoolSetupInputValue("schoolSetupMission", fallback.mission),
          values: schoolSetupInputValue("schoolSetupValues", fallback.values),
          address: schoolSetupInputValue("schoolSetupAddress", fallback.address),
          phone: schoolSetupInputValue("schoolSetupPhone", fallback.phone),
          publicSite: schoolSetupInputValue(
            "schoolSetupPublicSite",
            fallback.publicSite,
          ),
          privateLessonSite: schoolSetupInputValue(
            "schoolSetupPrivateLessonSite",
            fallback.privateLessonSite,
          ),
          webPresence: schoolSetupInputValue(
            "schoolSetupWebPresence",
            fallback.webPresence,
          ),
          socialIm: schoolSetupInputValue("schoolSetupSocialIm", fallback.socialIm),
          businessTaxId: schoolSetupInputValue(
            "schoolSetupBusinessTaxId",
            fallback.businessTaxId,
          ),
          timeFormat: schoolSetupInputValue(
            "schoolSetupTimeFormat",
            fallback.timeFormat,
          ),
          timeZone: schoolSetupInputValue("schoolSetupTimeZone", fallback.timeZone),
          googleMapsEmbedIframe: schoolSetupInputValue(
            "schoolSetupGoogleMapsEmbedIframe",
            fallback.googleMapsEmbedIframe,
          ),
          logoDataUrl: schoolSetupInputValue(
            "schoolSetupLogoDataUrl",
            fallback.logoDataUrl,
          ),
        });
      }

      function draftNewsReportValidationFromInputs({
        fallbackValidation = newsReportValidationState(),
      } = {}) {
        const fallback = normalizeNewsReportValidationSettings(fallbackValidation);
        const vocabularyMinimumEl = document.getElementById("schoolSetupNewsVocabularyMinimum");
        const readToggle = (id, fallbackValue = false) =>
          document.getElementById(id) instanceof HTMLInputElement ?
            document.getElementById(id).checked
          : Boolean(fallbackValue);
        const readText = (id, fallbackValue = "") =>
          document.getElementById(id) instanceof HTMLInputElement ?
            normalizeNewsSourceDomain(document.getElementById(id).value)
          : normalizeNewsSourceDomain(fallbackValue);
        const customSources = Array.from({ length: 8 }, (_, index) => {
          const slot = fallback.customSources[index] || {};
          const n = index + 1;
          return {
            enabled: readToggle(`schoolSetupNewsSourceCustom${n}Enabled`, slot.enabled),
            domain: readText(`schoolSetupNewsSourceCustom${n}Domain`, slot.domain),
          };
        });
        return normalizeNewsReportValidationSettings({
          vocabularyMinimumWords: vocabularyMinimumEl instanceof HTMLInputElement
            ? vocabularyMinimumEl.value
            : fallback.vocabularyMinimumWords,
          defaultSources: {
            cnn: readToggle(
              "schoolSetupNewsSourceDefaultCnn",
              fallback.defaultSources.cnn,
            ),
            bbc: readToggle(
              "schoolSetupNewsSourceDefaultBbc",
              fallback.defaultSources.bbc,
            ),
          },
          customSources,
        });
      }

      function renderSchoolSetupLogoPreview(logoDataUrl = "") {
        const previewEl = document.getElementById("schoolSetupLogoPreview");
        const imgEl = document.getElementById("schoolSetupLogoPreviewImg");
        const fallbackEl = document.getElementById("schoolSetupLogoPreviewFallback");
        const dataUrl = normalizeText(logoDataUrl);
        const hasLogo = Boolean(dataUrl);
        if (previewEl) previewEl.classList.toggle("has-image", hasLogo);
        if (imgEl) {
          imgEl.classList.toggle("hidden", !hasLogo);
          imgEl.src = hasLogo ? dataUrl : "data:,";
        }
        if (fallbackEl) fallbackEl.classList.toggle("hidden", hasLogo);
      }

      function extractGoogleMapsEmbedSrc(value = "") {
        const text = normalizeText(value);
        if (!text) return "";
        if (/^https:\/\/www\.google\.com\/maps\/embed/i.test(text)) {
          return text;
        }
        const iframeMatch = text.match(/src\s*=\s*["']([^"']+)["']/i);
        const candidate = normalizeText(iframeMatch?.[1]);
        if (/^https:\/\/www\.google\.com\/maps\/embed/i.test(candidate)) {
          return candidate;
        }
        return "";
      }

      function renderSchoolSetupGoogleMapsPreview(embedValue = "") {
        const previewEl = document.getElementById("schoolSetupGoogleMapsPreview");
        if (!(previewEl instanceof HTMLIFrameElement)) return;
        const src = extractGoogleMapsEmbedSrc(embedValue);
        if (!src) {
          previewEl.removeAttribute("src");
          return;
        }
        previewEl.src = src;
      }

      function schoolSetupLogoFileAllowed(file = null) {
        if (!file) return false;
        const mime = normalizeLower(file.type);
        const fileName = normalizeLower(file.name);
        if (SCHOOL_LOGO_ALLOWED_MIME.includes(mime)) return true;
        return SCHOOL_LOGO_ALLOWED_EXTENSIONS.some((ext) => fileName.endsWith(ext));
      }

      function schoolSetupImageDimensions(dataUrl = "") {
        return new Promise((resolve, reject) => {
          const image = new Image();
          image.onload = () =>
            resolve({
              width: Number(image.naturalWidth) || 0,
              height: Number(image.naturalHeight) || 0,
            });
          image.onerror = () => reject(new Error("Unable to read logo dimensions."));
          image.src = dataUrl;
        });
      }

      function schoolSetupDraftForRender() {
        const setup = previewSchoolSetupFromInputsData();
        return {
          setup: setup || schoolSetupState(),
          profile: draftSchoolProfileFromInputs({
            fallbackProfile: schoolProfileState(),
          }),
          newsReportValidation: draftNewsReportValidationFromInputs({
            fallbackValidation: newsReportValidationState(),
          }),
        };
      }

      async function handleSchoolSetupLogoUpload(event) {
        const inputEl = event?.target;
        if (!(inputEl instanceof HTMLInputElement)) return;
        const file = inputEl.files && inputEl.files[0];
        if (!file) return;
        if (!schoolSetupLogoFileAllowed(file)) {
          inputEl.value = "";
          throw new Error("Logo must be one of: svg, jpg, png, webp.");
        }

        const dataUrl = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(normalizeText(reader.result));
          reader.onerror = () =>
            reject(new Error("Unable to read selected logo file."));
          reader.readAsDataURL(file);
        });
        if (!dataUrl) throw new Error("Selected logo file is empty.");

        const dimensions = await schoolSetupImageDimensions(dataUrl);
        if (
          (Number.isFinite(dimensions.width) &&
            dimensions.width > SCHOOL_LOGO_MAX_PX) ||
          (Number.isFinite(dimensions.height) && dimensions.height > SCHOOL_LOGO_MAX_PX)
        ) {
          inputEl.value = "";
          throw new Error(
            `Logo must be max ${SCHOOL_LOGO_MAX_PX}px on width and height.`,
          );
        }

        const logoEl = document.getElementById("schoolSetupLogoDataUrl");
        if (logoEl) logoEl.value = dataUrl;
        const draft = schoolSetupDraftForRender();
        renderSchoolSetupPanel({
          setup: draft.setup,
          profile: draft.profile,
          newsReportValidation: draft.newsReportValidation,
          message: `Logo ready (${dimensions.width || "?"}x${dimensions.height || "?"}). Save School Setup to apply.`,
        });
      }

      function clearSchoolSetupLogoDraft() {
        const logoEl = document.getElementById("schoolSetupLogoDataUrl");
        const fileEl = document.getElementById("schoolSetupLogoFile");
        if (logoEl) logoEl.value = "";
        if (fileEl) fileEl.value = "";
        const draft = schoolSetupDraftForRender();
        renderSchoolSetupPanel({
          setup: draft.setup,
          profile: draft.profile,
          newsReportValidation: draft.newsReportValidation,
          message: "Logo removed from draft.",
        });
      }

      function renderSchoolSetupPanel({
        setup = schoolSetupState(),
        profile = schoolProfileState(),
        newsReportValidation = newsReportValidationState(),
        message = "",
        isError = false,
      } = {}) {
        const normalizedSetup = normalizeSchoolSetup(setup);
        const normalizedProfile = normalizeSchoolProfile(profile);
        const normalizedNewsValidation = normalizeNewsReportValidationSettings(
          newsReportValidation,
        );
        const startEl = document.getElementById("schoolSetupStartDate");
        const endEl = document.getElementById("schoolSetupEndDate");
        const labelEl = document.getElementById("schoolSetupSchoolYearLabel");
        const rowsEl = document.getElementById("schoolSetupQuarterRows");
        const warningEl = document.getElementById("schoolSetupWarning");
        const statusEl = document.getElementById("schoolSetupStatus");
        const schoolNameEl = document.getElementById("schoolSetupName");
        const bilingualViEl = document.getElementById("schoolSetupBilingualVi");
        const bilingualEnEl = document.getElementById("schoolSetupBilingualEn");
        const mottoEl = document.getElementById("schoolSetupMotto");
        const missionEl = document.getElementById("schoolSetupMission");
        const valuesEl = document.getElementById("schoolSetupValues");
        const addressEl = document.getElementById("schoolSetupAddress");
        const phoneEl = document.getElementById("schoolSetupPhone");
        const publicSiteEl = document.getElementById("schoolSetupPublicSite");
        const privateSiteEl = document.getElementById("schoolSetupPrivateLessonSite");
        const webPresenceEl = document.getElementById("schoolSetupWebPresence");
        const socialImEl = document.getElementById("schoolSetupSocialIm");
        const businessTaxIdEl = document.getElementById("schoolSetupBusinessTaxId");
        const timeFormatEl = document.getElementById("schoolSetupTimeFormat");
        const timeZoneEl = document.getElementById("schoolSetupTimeZone");
        const googleMapsEmbedIframeEl = document.getElementById(
          "schoolSetupGoogleMapsEmbedIframe",
        );
        const logoDataUrlEl = document.getElementById("schoolSetupLogoDataUrl");
        const letterGradeRangesEl = document.getElementById(
          "schoolSetupLetterGradeRanges",
        );
        if (startEl) startEl.value = normalizedSetup.startDate;
        if (endEl) endEl.value = normalizedSetup.endDate;
        if (labelEl) labelEl.value = normalizedSetup.schoolYear;
        if (schoolNameEl) schoolNameEl.value = normalizedProfile.schoolName;
        if (bilingualViEl) bilingualViEl.value = normalizedProfile.bilingualTextVi;
        if (bilingualEnEl) bilingualEnEl.value = normalizedProfile.bilingualTextEn;
        if (mottoEl) mottoEl.value = normalizedProfile.motto;
        if (missionEl) missionEl.value = normalizedProfile.mission;
        if (valuesEl) valuesEl.value = normalizedProfile.values;
        if (addressEl) addressEl.value = normalizedProfile.address;
        if (phoneEl) phoneEl.value = normalizedProfile.phone;
        if (publicSiteEl) publicSiteEl.value = normalizedProfile.publicSite;
        if (privateSiteEl) privateSiteEl.value = normalizedProfile.privateLessonSite;
        if (webPresenceEl) webPresenceEl.value = normalizedProfile.webPresence;
        if (socialImEl) socialImEl.value = normalizedProfile.socialIm;
        if (businessTaxIdEl) businessTaxIdEl.value = normalizedProfile.businessTaxId;
        if (timeFormatEl) timeFormatEl.value = normalizedProfile.timeFormat;
        if (timeZoneEl) timeZoneEl.value = normalizedProfile.timeZone;
        if (googleMapsEmbedIframeEl)
          googleMapsEmbedIframeEl.value = normalizedProfile.googleMapsEmbedIframe;
        if (logoDataUrlEl) logoDataUrlEl.value = normalizedProfile.logoDataUrl;
        if (letterGradeRangesEl)
          letterGradeRangesEl.value = schoolLetterGradeRangesText(
            normalizedSetup.letterGradeRanges,
          );
        const defaultCnnEl = document.getElementById(
          "schoolSetupNewsSourceDefaultCnn",
        );
        const defaultBbcEl = document.getElementById(
          "schoolSetupNewsSourceDefaultBbc",
        );
        if (defaultCnnEl instanceof HTMLInputElement) {
          defaultCnnEl.checked = normalizedNewsValidation.defaultSources.cnn === true;
        }
        if (defaultBbcEl instanceof HTMLInputElement) {
          defaultBbcEl.checked = normalizedNewsValidation.defaultSources.bbc === true;
        }
        const vocabularyMinimumEl = document.getElementById("schoolSetupNewsVocabularyMinimum");
        if (vocabularyMinimumEl instanceof HTMLInputElement) {
          vocabularyMinimumEl.value = String(normalizedNewsValidation.vocabularyMinimumWords);
        }
        Array.from({ length: 8 }, (_, index) => {
          const n = index + 1;
          const slot = normalizedNewsValidation.customSources[index] || {};
          const enabledEl = document.getElementById(
            `schoolSetupNewsSourceCustom${n}Enabled`,
          );
          const domainEl = document.getElementById(
            `schoolSetupNewsSourceCustom${n}Domain`,
          );
          if (enabledEl instanceof HTMLInputElement) {
            enabledEl.checked = slot.enabled === true;
          }
          if (domainEl instanceof HTMLInputElement) {
            domainEl.value = normalizeText(slot.domain);
          }
        });
        renderSchoolSetupLogoPreview(normalizedProfile.logoDataUrl);
        renderSchoolSetupGoogleMapsPreview(normalizedProfile.googleMapsEmbedIframe);
        if (rowsEl) rowsEl.innerHTML = schoolSetupQuarterRowsHtml(normalizedSetup);
        if (warningEl instanceof HTMLElement) {
          const meta = state.uiSettingsMeta || {};
          const portalIssue =
            meta.schoolSetupHasIssues === true ||
            meta.schoolSetupStoredQuartersMissing === true ||
            meta.schoolSetupState === "maintenance" ||
            normalizedSetup.schoolSetupState !== "ok";
          warningEl.classList.toggle("hidden", !portalIssue);
          warningEl.style.color = portalIssue ? "var(--portal-status-warn-text)" : "";
          warningEl.style.fontWeight = portalIssue ? "700" : "";
          warningEl.innerHTML = portalIssue ?
            'Quarter setup is incomplete or invalid. Click Auto-Fill Quarters, then save to restore it before rollover or after any settings hiccup.' :
            "";
        }
        if (statusEl) {
          statusEl.style.color = isError ? "#b3262d" : "var(--portal-status-muted-text)";
          const defaultMessage = normalizedSetup.schoolSetupState === "ok" ?
            `School year ${normalizedSetup.schoolYear}: ${normalizedSetup.startDate} to ${normalizedSetup.endDate}. Quarter rows are ready to save.` :
            "School setup is incomplete until quarter rows are auto-filled and saved.";
          statusEl.textContent = normalizeText(message) || defaultMessage;
        }
        renderSchoolSetupAccessWarning(normalizedSetup);
      }

      function schoolSetupAccessWarningHtml(setup = schoolSetupState()) {
        const normalizedSetup = normalizeSchoolSetup(setup);
        const hasIssues =
          normalizedSetup.schoolSetupState !== "ok" ||
          state.uiSettingsMeta?.schoolSetupHasIssues === true;
        if (!hasIssues) return "";
        const isUnset =
          !normalizeText(normalizedSetup.startDate) &&
          !normalizeText(normalizedSetup.endDate) &&
          !normalizeText(normalizedSetup.schoolYear) &&
          (!Array.isArray(normalizedSetup.quarters) || !normalizedSetup.quarters.length);
        const message = isUnset ?
          "School setup is unset." :
          "School setup is incomplete or invalid.";
        const schoolSetupHref = buildAdminRuntimeHrefWithOrigin(
          "/admin/school-setup#schoolSetupPanel",
          resolveApiOrigin(),
          resolveAdminPagePath(),
        );
        return `${message} <a href="${schoolSetupHref}" rel="bookmark">Open School Setup</a> to set the quarter rows before using grades or portals.`;
      }

      let schoolSetupWarningAcknowledged = false;
      let schoolSetupWarningCheckReady = false;
      let schoolSetupWarningCheckScheduled = false;
      let schoolSetupWarningCheckTimer = null;
      let latestSchoolSetupWarningSetup = null;

      function scheduleSchoolSetupWarningCheck() {
        if (schoolSetupWarningCheckScheduled) return;
        schoolSetupWarningCheckScheduled = true;
        schoolSetupWarningCheckTimer = window.setTimeout(() => {
          schoolSetupWarningCheckReady = true;
          renderSchoolSetupAccessWarning(latestSchoolSetupWarningSetup || schoolSetupState());
        }, /\bjsdom\b/i.test(String(window.navigator?.userAgent || "")) ? 0 : 10000);
      }

      function closeSchoolSetupWarningModal(acknowledge = true) {
        const modal = document.getElementById("schoolSetupWarningModal");
        if (!(modal instanceof HTMLElement)) return;
        modal.classList.add("hidden");
        modal.setAttribute("aria-hidden", "true");
        document.body.classList.remove("modal-open");
        if (acknowledge) schoolSetupWarningAcknowledged = true;
      }

      function openSchoolSetupWarningModal(setup = schoolSetupState()) {
        const modal = document.getElementById("schoolSetupWarningModal");
        if (!(modal instanceof HTMLElement)) return;
        const normalizedSetup = normalizeSchoolSetup(setup);
        const isUnset =
          !normalizeText(normalizedSetup.startDate) &&
          !normalizeText(normalizedSetup.endDate) &&
          !normalizeText(normalizedSetup.schoolYear) &&
          (!Array.isArray(normalizedSetup.quarters) || !normalizedSetup.quarters.length);
        const statusEl = document.getElementById("schoolSetupWarningModalStatus");
        const openBtn = document.getElementById("schoolSetupWarningOpenBtn");
        const actionStatusEl = document.getElementById("schoolSetupWarningModalActionStatus");
        const schoolSetupHref = buildAdminRuntimeHrefWithOrigin(
          "/admin/school-setup#schoolSetupPanel",
          resolveApiOrigin(),
          resolveAdminPagePath(),
        );
        if (statusEl) {
          statusEl.textContent = isUnset ?
            "No school year or quarter data is currently available." :
            "Stored school setup data is incomplete or invalid.";
        }
        if (openBtn) openBtn.setAttribute("href", schoolSetupHref);
        if (actionStatusEl) actionStatusEl.textContent = "";
        const autoFixBtn = document.getElementById("schoolSetupWarningAutoFixBtn");
        const syncBtn = document.getElementById("schoolSetupWarningSyncBtn");
        if (autoFixBtn instanceof HTMLButtonElement) autoFixBtn.disabled = !canManageUsers();
        if (syncBtn instanceof HTMLButtonElement) syncBtn.disabled = !canManageUsers();
        modal.classList.remove("hidden");
        modal.setAttribute("aria-hidden", "false");
        document.body.classList.add("modal-open");
        document.getElementById("schoolSetupWarningCloseBtn")?.focus();
      }

      function recoverSchoolSetupFromWarning() {
        autoFillSchoolSetupFromInputs();
        return saveSchoolSetupFromInputs({ notify: true });
      }

      function renderSchoolSetupAccessWarning(setup = schoolSetupState()) {
        scheduleSchoolSetupWarningCheck();
        latestSchoolSetupWarningSetup = normalizeSchoolSetup(setup);
        const warningHtml = schoolSetupAccessWarningHtml(setup);
        document
          .querySelectorAll("[data-school-setup-access-warning]")
          .forEach((warningEl) => {
            if (!(warningEl instanceof HTMLElement)) return;
            warningEl.classList.add("hidden");
            warningEl.replaceChildren();
          });
        if (!warningHtml) {
          schoolSetupWarningAcknowledged = false;
          closeSchoolSetupWarningModal(false);
          return;
        }
        if (schoolSetupWarningCheckReady && state.authUser && !schoolSetupWarningAcknowledged) {
          openSchoolSetupWarningModal(setup);
        }
      }

      function draftSchoolSetupFromInputs() {
        const startDate = normalizeText(
          document.getElementById("schoolSetupStartDate")?.value,
        ).slice(0, 10);
        const endDate = normalizeText(
          document.getElementById("schoolSetupEndDate")?.value,
        ).slice(0, 10);
        const letterGradeRangesText = normalizeText(
          document.getElementById("schoolSetupLetterGradeRanges")?.value,
        );
        if (!parseIsoDateLocal(startDate) || !parseIsoDateLocal(endDate)) {
          throw new Error("First and last school day are required.");
        }
        if (compareIsoDateText(startDate, endDate) > 0) {
          throw new Error("Last school day must be on or after the first school day.");
        }
        const quarters = schoolSetupDraftQuarters();
        if (!quarters.length) {
          throw new Error("Click Auto-Fill Quarters before saving school setup.");
        }
        const setup = normalizeSchoolSetup({
          startDate,
          endDate,
          schoolYear: schoolYearLabelFromRange(startDate, endDate),
          quarters,
          letterGradeRanges: parseSchoolLetterGradeRangesText(letterGradeRangesText),
        });
        if (setup.schoolSetupState !== "ok") {
          throw new Error("Quarter rows do not match the selected school year. Click Auto-Fill Quarters again.");
        }
        return setup;
      }

      async function saveSchoolSetupFromInputs({ notify = true } = {}) {
        if (!canManageSettings())
          throw new Error(
            "Only roles with settings permission can update school setup.",
          );
        const setup = draftSchoolSetupFromInputs();
        const profile = draftSchoolProfileFromInputs({
          fallbackProfile: schoolProfileState(),
        });
        const newsReportValidation = draftNewsReportValidationFromInputs({
          fallbackValidation: newsReportValidationState(),
        });
        if (setup.schoolSetupState !== "ok") {
          throw new Error("Click Auto-Fill Quarters before saving school setup.");
        }
        persistUiSettings({
          ...state.uiSettings,
          schoolSetup: {
            startDate: setup.startDate,
            endDate: setup.endDate,
            schoolYear: setup.schoolYear,
            quarters: setup.quarters,
            letterGradeRanges: normalizeSchoolLetterGradeRanges(
              setup.letterGradeRanges,
            ),
          },
          schoolProfile: profile,
          newsReportValidation,
        });
        const persisted = await persistUiSettingsToServer(state.uiSettings, state.sisConfig, {
          notifyOnFailure: notify,
        });
        if (persisted?.uiSettings) {
          persistUiSettings(persisted.uiSettings, persisted.meta || null);
        }
        applyUiSettings();
        const savedSetup = schoolSetupState();
        renderSchoolSetupPanel({
          setup: savedSetup,
          profile,
          newsReportValidation,
          message: "School setup saved.",
        });
        if (notify) {
          const schoolName = profile.schoolName ? ` for ${profile.schoolName}` : "";
          setStatus(`School setup saved (${setup.schoolYear})${schoolName}.`);
        }
        return setup;
      }

      function schoolSetupQuarterForIsoDate(value = "", setup = schoolSetupState()) {
        const isoDate = normalizeText(value).slice(0, 10);
        if (!parseIsoDateLocal(isoDate)) return null;
        const normalizedSetup = normalizeSchoolSetup(setup);
        if (normalizedSetup.schoolSetupState !== "ok") return null;
        const quarters = Array.isArray(normalizedSetup?.quarters) ? normalizedSetup.quarters : [];
        for (let index = 0; index < quarters.length; index += 1) {
          const entry = quarters[index];
          const startDate = normalizeText(entry?.startDate).slice(0, 10);
          const endDate = normalizeText(entry?.endDate).slice(0, 10);
          if (!startDate || !endDate) continue;
          if (
            compareIsoDateText(isoDate, startDate) >= 0 &&
            compareIsoDateText(isoDate, endDate) <= 0
          ) {
            return entry;
          }
        }
        return null;
      }

      function syncAttendanceDateDerivedFields() {
        const classDate = normalizeText(document.getElementById("a_date")?.value).slice(
          0,
          10,
        );
        if (!classDate) return;
        const yearEl = document.getElementById("a_schoolYear");
        const quarterEl = document.getElementById("a_quarter");
        if (yearEl) yearEl.value = defaultAttendanceSchoolYear(classDate);
        if (quarterEl) quarterEl.value = quarterFromIsoDate(classDate);
        updateAttendanceQuarterWarning();
      }

      function applyUiSettings() {
        const multiSchool = Boolean(state.uiSettings?.multiSchool);
        state.uiSettings = normalizeUiSettings(state.uiSettings);
        normalizeQuarterDropdownDefaults();
        const schoolFilterCol = document.getElementById("schoolFilterCol");
        const profileSchoolCol = document.getElementById("profileSchoolCol");
        if (schoolFilterCol) schoolFilterCol.classList.toggle("hidden", !multiSchool);
        if (profileSchoolCol) profileSchoolCol.classList.toggle("hidden", !multiSchool);
        document.querySelectorAll(".school-col,.school-col-cell").forEach((cell) => {
          cell.classList.toggle("hidden", !multiSchool);
        });
        if (!multiSchool) {
          const schoolSelect = document.getElementById("filterSchool");
          if (schoolSelect) schoolSelect.value = "";
        }
        const multiSchoolToggle = document.getElementById("settingMultiSchool");
        if (multiSchoolToggle) multiSchoolToggle.checked = multiSchool;
        const settingsStatus = document.getElementById("settingsStatus");
        if (settingsStatus) {
          const profileFieldCount = sortedProfileFields(true).length;
          const setup = schoolSetupState();
          const schoolProfile = schoolProfileState();
          const newsValidation = newsReportValidationState();
          const allowedSources = [];
          if (newsValidation.defaultSources.cnn) allowedSources.push("cnn.com");
          if (newsValidation.defaultSources.bbc) allowedSources.push("bbc.com");
          (Array.isArray(newsValidation.customSources) ?
            newsValidation.customSources
          : []
          ).forEach((entry) => {
            if (entry?.enabled === true && normalizeText(entry?.domain)) {
              allowedSources.push(normalizeText(entry.domain));
            }
          });
          const schoolName = schoolProfile.schoolName || "(school name not set)";
          settingsStatus.textContent =
            `Multi-school: ${multiSchool ? "enabled" : "disabled"} | school year: ${setup.schoolYear} ` +
            `(${setup.startDate} to ${setup.endDate}) | school: ${schoolName} | profile fields: ${profileFieldCount} | news sources: ${allowedSources.join(", ") || "cnn.com, bbc.com"}`;
        }
        renderSchoolBranding();
        renderSchoolSetupPanel();
        if (!document.body?.classList.contains("admin-auth-booting")) {
          renderSchoolSetupAccessWarning();
        }
        state.queueHub.panelOrder = normalizeQueueHubPanelOrder(
          state.uiSettings?.queueHub?.panelOrder || state.queueHub.panelOrder,
        );
        if (
          state.activePage === "attendance" ||
          state.activePage === "attendance-admin"
        ) {
          syncAttendanceDateDerivedFields();
        }
        if (state.queueHub.loaded) renderQueueHubPanels();
      }

      const apiPrefixConfig = resolveApiPrefixConfig();
      const HAS_EXPLICIT_API_PREFIX_OVERRIDE = apiPrefixConfig.hasExplicitOverride;
      const INFERRED_ADMIN_API_PREFIX = apiPrefixConfig.inferredPrefix;
      let ACTIVE_ADMIN_API_PREFIX = apiPrefixConfig.resolvedPrefix;
      const ADMIN_PAGE_PATH = resolveAdminPagePath();
      const ADMIN_API_ORIGIN = resolveApiOrigin();
      const ADMIN_PERMISSIONS_PATH =
        normalizeText(window.__SIS_ADMIN_PERMISSIONS_PATH) || "/api/admin/permissions";
      const ADMIN_UI_SETTINGS_PATH =
        normalizeText(window.__SIS_ADMIN_UI_SETTINGS_PATH) || "/api/admin/settings/ui";
      const ADMIN_ASSETS_PATH =
        normalizeText(window.__SIS_ADMIN_ASSETS_PATH) || "/api/admin/assets";
      const ADMIN_DASHBOARD_PATH =
        normalizeText(window.__SIS_ADMIN_DASHBOARD_PATH) || "/api/admin/dashboard";
      const ADMIN_QUEUE_HUB_PATH =
        normalizeText(window.__SIS_ADMIN_QUEUE_HUB_PATH) || "/api/admin/queue-hub";
      const ADMIN_NEWS_REPORTS_PATH =
        normalizeText(window.__SIS_ADMIN_NEWS_REPORTS_PATH) ||
        "/api/admin/news-reports";
      const ADMIN_EXERCISE_TITLES_PATH =
        normalizeText(window.__SIS_ADMIN_EXERCISE_TITLES_PATH) ||
        "/api/admin/exercise-titles";
      const ADMIN_NOTIFY_EMAIL_PATH =
        normalizeText(window.__SIS_ADMIN_NOTIFY_EMAIL_PATH) ||
        "/api/admin/notifications/email";
      const ADMIN_NOTIFY_BATCH_STATUS_PATH =
        normalizeText(window.__SIS_ADMIN_NOTIFY_BATCH_STATUS_PATH) ||
        "/api/admin/notifications/batch-status";
      const ADMIN_ASSIGNMENT_ENGAGEMENT_PATH = "/api/admin/assignment-reminder-engagement";
      const ADMIN_INCOMING_EXERCISE_RESULTS_PATH =
        normalizeText(window.__SIS_ADMIN_INCOMING_EXERCISE_RESULTS_PATH) ||
        "/api/admin/exercise-results/incoming";
      const ADMIN_ASSIGNMENT_TEMPLATES_PATH =
        normalizeText(window.__SIS_ADMIN_ASSIGNMENT_TEMPLATES_PATH) ||
        "/api/admin/assignment-templates";
      const ADMIN_ASSIGNMENT_TEMPLATES_IMPORT_PATH =
        normalizeText(window.__SIS_ADMIN_ASSIGNMENT_TEMPLATES_IMPORT_PATH) ||
        `${ADMIN_ASSIGNMENT_TEMPLATES_PATH}/import`;
      const ADMIN_RUNTIME_HEALTH_PATH =
        normalizeText(window.__SIS_ADMIN_RUNTIME_HEALTH_PATH) ||
        "/api/admin/runtime/health";
      const ADMIN_SIS_CONFIG_REPAIR_PATH =
        normalizeText(window.__SIS_ADMIN_SIS_CONFIG_REPAIR_PATH) ||
        "/api/admin/runtime/sis-config-repair";
      const ADMIN_SERVICE_CONTROL_PATH =
        normalizeText(window.__SIS_ADMIN_SERVICE_CONTROL_PATH) ||
        "/api/admin/runtime/service-control";
      const ADMIN_ASSIGNMENT_ANNOUNCEMENT_PREVIEW_CREATE_PATH =
        normalizeText(window.__SIS_ADMIN_ASSIGNMENT_ANNOUNCEMENT_PREVIEW_CREATE_PATH) ||
        "/api/admin/assignment-announcements/volatile";
      const HUB_HEALTH_PROBE_PATH = "/healthz";
      const HUB_AUTH_PROBE_PATH = "/api/admin/auth/me";
      const ASSIGNMENT_ANNOUNCEMENT_PREVIEW_TTL_MINUTES = Math.max(
        1,
        Number.parseInt(
          String(
            window.__SIS_ADMIN_ASSIGNMENT_ANNOUNCEMENT_PREVIEW_TTL_MINUTES || "480",
          ),
          10,
        ) || 480,
      );
      const MANAGED_PERMISSION_ROLES =
        Array.isArray(window.__SIS_ADMIN_PERMISSION_ROLES) ?
          window.__SIS_ADMIN_PERMISSION_ROLES
            .map((entry) => normalizeLower(entry))
            .filter(Boolean)
        : ["admin", "teacher", "student", "parent"];
      const initialHubProbeMode = defaultHubProbeMode();
      setHubProbeMode(
        initialHubProbeMode,
        initialHubProbeMode === "auth" ? "non-loopback-default" : "",
      );
      const PAGE_GROUPS = {
        students: ["overview", "queue-hub", "profile"],
        tracking: [
          "attendance",
          "attendance-admin",
          "assignments",
          "assignments-data",
          "grades",
          "grades-data",
          "grades-tabulator",
          "parent-tracking",
          "performance-data",
          "performance-engagement",
          "assignment-engagement",
          "news-reports",
          "reports",
        ],
        support: ["family"],
        admin: ["student-admin", "school-setup", "users", "permissions", "settings"],
      };
      const PAGES_WITH_HIDDEN_TOP_SEARCH = new Set([
        "overview",
        "queue-hub",
        "attendance",
        "attendance-admin",
        "assignments",
        "assignments-data",
        "grades",
        "grades-data",
        "parent-tracking",
        "performance-data",
        "performance-engagement",
        "assignment-engagement",
        "news-reports",
        "school-setup",
        "settings",
        "users",
        "permissions",
      ]);
      const DEFAULT_PAGE_SECTION_LIST = Object.values(PAGE_GROUPS).flat();
      const injectedPageSections =
        Array.isArray(window.__SIS_ADMIN_PAGE_SECTIONS) ?
          window.__SIS_ADMIN_PAGE_SECTIONS
            .map((entry) => normalizeLower(entry))
            .filter(Boolean)
        : [];
      const VALID_PAGE_SECTIONS = Array.from(
        new Set([
          DEFAULT_ADMIN_PAGE_SLUG,
          ...DEFAULT_PAGE_SECTION_LIST,
          ...injectedPageSections,
        ]),
      );
      const VALID_PAGE_SECTION_SET = new Set(VALID_PAGE_SECTIONS);

      function defaultRolePermissionsConfig() {
        return {
          admin: {
            role: "admin",
            canRead: true,
            canWrite: true,
            canManageUsers: true,
            canManagePermissions: true,
            startPage: "overview",
            allowedPages: [...VALID_PAGE_SECTIONS],
          },
          teacher: {
            role: "teacher",
            canRead: true,
            canWrite: true,
            canManageUsers: false,
            canManagePermissions: false,
            startPage: "overview",
            allowedPages: [
              "overview",
              "profile",
              "attendance",
              "assignments",
              "parent-tracking",
              "news-reports",
              "performance-engagement",
              "grades",
              "reports",
              "family",
            ],
          },
          student: {
            role: "student",
            canRead: true,
            canWrite: false,
            canManageUsers: false,
            canManagePermissions: false,
            startPage: "overview",
            allowedPages: ["overview", "profile", "reports"],
          },
          parent: {
            role: "parent",
            canRead: true,
            canWrite: false,
            canManageUsers: false,
            canManagePermissions: false,
            startPage: "family",
            allowedPages: ["overview", "family", "reports"],
          },
        };
      }

      function uniquePageList(values, fallback) {
        const source = Array.isArray(values) ? values : [];
        const normalized = source
          .map((entry) => normalizeLower(entry))
          .filter((entry) => VALID_PAGE_SECTION_SET.has(entry));
        const picked = normalized.length ? normalized : fallback;
        return Array.from(new Set(picked));
      }

      function normalizeRolePolicy(role, policy, fallbackPolicy) {
        const fallback =
          fallbackPolicy ||
          defaultRolePermissionsConfig()[role] ||
          defaultRolePermissionsConfig().teacher;
        const allowedPages = uniquePageList(
          policy?.allowedPages,
          fallback.allowedPages,
        );
        if (role === "admin") {
          [
            "queue-hub",
            "student-admin",
            "school-setup",
            "users",
            "permissions",
            "settings",
          ].forEach((slug) => {
            if (!VALID_PAGE_SECTION_SET.has(slug)) return;
            if (!allowedPages.includes(slug)) allowedPages.push(slug);
          });
          [
            "attendance-admin",
            "assignments-data",
            "grades-data",
            "performance-data",
          ].forEach((slug) => {
            if (!VALID_PAGE_SECTION_SET.has(slug)) return;
            if (!allowedPages.includes(slug)) allowedPages.push(slug);
          });
        }
        // Backward compatibility: keep Performance visible for teacher/admin even when older runtimes
        // return permissions payloads that predate parent-tracking page registration.
        if (
          (role === "admin" || role === "teacher") &&
          VALID_PAGE_SECTION_SET.has("parent-tracking") &&
          !allowedPages.includes("parent-tracking")
        ) {
          allowedPages.push("parent-tracking");
        }
        if (
          (role === "admin" || role === "teacher") &&
          VALID_PAGE_SECTION_SET.has("performance-engagement") &&
          !allowedPages.includes("performance-engagement")
        ) {
          allowedPages.push("performance-engagement");
        }
        let startPage = normalizeLower(policy?.startPage);
        if (!startPage || !allowedPages.includes(startPage)) {
          startPage = allowedPages[0] || fallback.startPage || DEFAULT_ADMIN_PAGE_SLUG;
        }
        const adminRole = role === "admin";
        return {
          role,
          canRead:
            adminRole ? true
            : policy?.canRead !== undefined ? Boolean(policy.canRead)
            : Boolean(fallback.canRead),
          canWrite:
            adminRole ? true
            : policy?.canWrite !== undefined ? Boolean(policy.canWrite)
            : Boolean(fallback.canWrite),
          canManageUsers:
            adminRole ? true
            : policy?.canManageUsers !== undefined ? Boolean(policy.canManageUsers)
            : Boolean(fallback.canManageUsers),
          canManagePermissions:
            adminRole ? true
            : policy?.canManagePermissions !== undefined ?
              Boolean(policy.canManagePermissions)
            : Boolean(fallback.canManagePermissions),
          startPage,
          allowedPages,
        };
      }

      function normalizeRolePermissionsMap(source) {
        const defaults = defaultRolePermissionsConfig();
        const input = source && typeof source === "object" ? source : {};
        const normalized = {};
        const roles = Array.from(
          new Set([...MANAGED_PERMISSION_ROLES, ...Object.keys(defaults)]),
        );

        roles.forEach((roleName) => {
          const role = normalizeLower(roleName);
          if (!role) return;
          normalized[role] = normalizeRolePolicy(role, input[role], defaults[role]);
        });

        if (!normalized.admin)
          normalized.admin = normalizeRolePolicy("admin", {}, defaults.admin);
        normalized.admin.canRead = true;
        normalized.admin.canWrite = true;
        normalized.admin.canManageUsers = true;
        normalized.admin.canManagePermissions = true;
        normalized.admin.allowedPages = uniquePageList(
          normalized.admin.allowedPages,
          defaults.admin.allowedPages,
        );
        if (!normalized.admin.allowedPages.includes(normalized.admin.startPage)) {
          normalized.admin.startPage =
            normalized.admin.allowedPages[0] || DEFAULT_ADMIN_PAGE_SLUG;
        }
        if (normalized.teacher) {
          normalized.teacher.canRead = true;
          normalized.teacher.canWrite = true;
        }

        return normalized;
      }

      function getAlternateApiPrefix(currentPrefix) {
        const normalizedCurrent = normalizePathPrefix(
          currentPrefix,
          DEFAULT_ADMIN_API_PREFIX,
        );
        const candidates = [INFERRED_ADMIN_API_PREFIX, DEFAULT_ADMIN_API_PREFIX]
          .map((entry) => normalizePathPrefix(entry || "", DEFAULT_ADMIN_API_PREFIX))
          .filter((entry, index, list) => list.indexOf(entry) === index);

        for (let i = 0; i < candidates.length; i += 1) {
          if (candidates[i] !== normalizedCurrent) return candidates[i];
        }
        return "";
      }

      function isAuthApiPath(path) {
        const normalizedPath = normalizeText(path);
        return (
          normalizedPath.startsWith("/api/admin/auth/") ||
          normalizedPath.startsWith("/api/sis-admin/auth/")
        );
      }

      function resolveApiUrl(path) {
        const rawPath = normalizeText(path);
        if (!rawPath) return rawPath;
        if (/^https?:\/\//i.test(rawPath)) return rawPath;

        let resolvedPath = rawPath;
        if (resolvedPath.startsWith(DEFAULT_ADMIN_API_PREFIX)) {
          resolvedPath = `${ACTIVE_ADMIN_API_PREFIX}${resolvedPath.slice(DEFAULT_ADMIN_API_PREFIX.length)}`;
        }
        if (!resolvedPath.startsWith("/")) {
          resolvedPath = `/${resolvedPath}`;
        }

        if (ADMIN_API_ORIGIN) {
          return new URL(resolvedPath, ADMIN_API_ORIGIN).toString();
        }
        return resolvedPath;
      }

      function isStaticAdminPreviewMode() {
        return isStaticAdminPreviewPath(window.location.pathname);
      }

      const IS_JSDOM_ENV =
        typeof window !== "undefined" &&
        /\bjsdom\b/i.test(String(window.navigator?.userAgent || ""));

      function staticPreviewHelpMessage() {
        return `Static preview mode requires ?apiOrigin=http://127.0.0.1:<mailer-port> or opening ${ADMIN_PAGE_PATH}.`;
      }

      function assertApiOriginConfiguredForStaticPreview() {
        if (!isStaticAdminPreviewMode() || ADMIN_API_ORIGIN) return;
        const error = new Error(staticPreviewHelpMessage());
        error.status = 400;
        throw error;
      }

      function normalizePageSlug(slug) {
        const normalized = normalizeLower(slug);
        if (!normalized) return DEFAULT_ADMIN_PAGE_SLUG;
        if (!VALID_PAGE_SECTION_SET.has(normalized)) return DEFAULT_ADMIN_PAGE_SLUG;
        return normalized;
      }

      function pageSlugFromLocationPathname(pathname) {
        const currentPath = normalizeText(pathname || window.location.pathname);
        if (currentPath === ADMIN_PAGE_PATH) return DEFAULT_ADMIN_PAGE_SLUG;
        if (!currentPath.startsWith(`${ADMIN_PAGE_PATH}/`)) return "";
        const suffix = currentPath.slice(ADMIN_PAGE_PATH.length + 1);
        const firstSegment = normalizeText(suffix.split("/")[0]);
        if (!firstSegment) return "";
        try {
          return normalizePageSlug(decodeURIComponent(firstSegment));
        } catch (error) {
          void error;
          return DEFAULT_ADMIN_PAGE_SLUG;
        }
      }

      function pageSlugFromLocationSearch(searchValue) {
        const rawSearch = normalizeText(
          searchValue !== undefined ? searchValue : window.location.search,
        );
        if (!rawSearch) return "";
        const params = new URLSearchParams(rawSearch);
        const candidate = normalizeText(params.get("page") || params.get("pageSlug"));
        if (!candidate) return "";
        return normalizePageSlug(candidate);
      }

      function normalizeAdminPageUrlMode(value) {
        const mode = normalizeLower(value);
        if (mode === "query" || mode === "path") return mode;
        return "";
      }

      function resolveAdminPageUrlMode() {
        const explicitMode = normalizeAdminPageUrlMode(
          window.__SIS_ADMIN_PAGE_URL_MODE,
        );
        if (explicitMode) return explicitMode;
        const params = new URLSearchParams(window.location.search || "");
        const modeParam = normalizeAdminPageUrlMode(
          params.get("pageUrlMode") || params.get("urlMode"),
        );
        if (modeParam) return modeParam;
        if (params.has("page") || params.has("pageSlug")) return "query";
        if (normalizeLower(window.location.hostname) === "admin.eagles.edu.vn")
          return "query";
        return "path";
      }

      const ADMIN_PAGE_URL_MODE = resolveAdminPageUrlMode();

      function resolveInitialPageSlug() {
        const injectedSlug = normalizePageSlug(window.__SIS_ADMIN_PAGE_SLUG);
        if (normalizeText(window.__SIS_ADMIN_PAGE_SLUG)) return injectedSlug;
        const fromSearch = pageSlugFromLocationSearch(window.location.search);
        const fromPathname = pageSlugFromLocationPathname(window.location.pathname);
        if (
          fromSearch &&
          (!fromPathname || fromPathname === DEFAULT_ADMIN_PAGE_SLUG)
        )
          return fromSearch;
        if (fromPathname) return fromPathname;
        if (fromSearch) return fromSearch;
        return DEFAULT_ADMIN_PAGE_SLUG;
      }

      function pageGroupForSlug(pageSlug) {
        const slug = normalizePageSlug(pageSlug);
        const groups = Object.keys(PAGE_GROUPS);
        for (let i = 0; i < groups.length; i += 1) {
          const key = groups[i];
          if (PAGE_GROUPS[key].includes(slug)) return key;
        }
        return "students";
      }

      function pageHidesTopSearch(pageSlug) {
        return PAGES_WITH_HIDDEN_TOP_SEARCH.has(normalizePageSlug(pageSlug));
      }

      function buildPagePath(pageSlug) {
        const slug = normalizePageSlug(pageSlug);
        if (slug === DEFAULT_ADMIN_PAGE_SLUG) return ADMIN_PAGE_PATH;
        return `${ADMIN_PAGE_PATH}/${encodeURIComponent(slug)}`;
      }

      function buildPageQueryPath(pageSlug) {
        const slug = normalizePageSlug(pageSlug);
        const params = new URLSearchParams(window.location.search || "");
        params.delete("page");
        params.delete("pageSlug");
        if (slug !== DEFAULT_ADMIN_PAGE_SLUG) params.set("page", slug);
        if (shouldPreserveAdminApiOriginParam() && !params.has("apiOrigin")) {
          params.set("apiOrigin", ADMIN_API_ORIGIN);
        }
        const query = params.toString();
        return `${ADMIN_PAGE_PATH}${query ? `?${query}` : ""}`;
      }

      function buildPagePathWithPreservedQuery(pageSlug) {
        const slug = normalizePageSlug(pageSlug);
        const params = new URLSearchParams(window.location.search || "");
        params.delete("page");
        params.delete("pageSlug");
        if (shouldPreserveAdminApiOriginParam() && !params.has("apiOrigin")) {
          params.set("apiOrigin", ADMIN_API_ORIGIN);
        }
        const query = params.toString();
        return `${buildPagePath(slug)}${query ? `?${query}` : ""}`;
      }

      function buildPageNavigationHref(pageSlug) {
        const slug = normalizePageSlug(pageSlug);
        if (isStaticAdminPreviewMode()) return "#";
        if (ADMIN_PAGE_URL_MODE === "query") return buildPageQueryPath(slug);
        return buildPagePathWithPreservedQuery(slug);
      }

      function buildAdminRuntimeHref(href = ADMIN_PAGE_PATH) {
        return buildAdminRuntimeHrefWithOrigin(
          href,
          ADMIN_API_ORIGIN,
          ADMIN_PAGE_PATH,
        );
      }

      function refreshMenuLinkTargets() {
        document.querySelectorAll("[data-page-link]").forEach((linkEl) => {
          const slug = normalizeText(linkEl.getAttribute("data-page-link"));
          if (!slug) return;
          linkEl.setAttribute("href", buildPageNavigationHref(slug));
        });
        document.querySelectorAll('a[href^="/admin"]').forEach((linkEl) => {
          const href = normalizeText(linkEl.getAttribute("href"));
          if (!href) return;
          linkEl.setAttribute("href", buildAdminRuntimeHref(href));
        });
      }

      function shouldSyncPagePathInHistory() {
        if (isStaticAdminPreviewMode()) return false;
        const path = normalizeText(window.location.pathname);
        return path === ADMIN_PAGE_PATH || path.startsWith(`${ADMIN_PAGE_PATH}/`);
      }

      function syncPageHistory(pageSlug, mode = "push") {
        if (!shouldSyncPagePathInHistory()) return;
        const urlMode = ADMIN_PAGE_URL_MODE;
        const nextUrl =
          urlMode === "query" ? buildPageQueryPath(pageSlug)
          : buildPagePathWithPreservedQuery(pageSlug);
        const currentUrl = `${window.location.pathname}${window.location.search || ""}`;
        if (currentUrl === nextUrl) return;
        if (mode === "replace") {
          window.history.replaceState({ page: pageSlug }, "", nextUrl);
        } else {
          window.history.pushState({ page: pageSlug }, "", nextUrl);
        }
      }

      function updateMenuExpansion(activeGroup) {
        document.querySelectorAll("[data-menu-group]").forEach((groupEl) => {
          const groupName = normalizeText(groupEl.getAttribute("data-menu-group"));
          const expanded = groupName === activeGroup;
          if (expanded) groupEl.classList.add("expanded");
          else groupEl.classList.remove("expanded");
          groupEl.querySelector("[data-menu-toggle]")?.setAttribute("aria-expanded", String(expanded));
        });
      }

      function desktopMenuCollapsedPreference() {
        return window.SIS_PORTAL_PREFERENCES?.get(DESKTOP_MENU_COLLAPSED_STORAGE_KEY, "0") === "1";
      }

      function persistDesktopMenuCollapsedPreference(collapsed = false) {
        void window.SIS_PORTAL_PREFERENCES?.save(DESKTOP_MENU_COLLAPSED_STORAGE_KEY, collapsed ? "1" : "0");
      }

      function applyDesktopMenuCollapsedPreference() {
        document.body.classList.remove("menu-collapsed");
      }

      function updateMenuToggleButtonLabel() {
        const menuToggleBtnEl = document.getElementById("menuToggleBtn");
        const floatingMenuBtnEl = document.getElementById("floatingMenuBtn");
        const menuOpen = document.body.classList.contains("menu-open");
        if (menuToggleBtnEl)
          menuToggleBtnEl.textContent = menuOpen ? "Close Menu" : "Menu";
        if (floatingMenuBtnEl) {
          floatingMenuBtnEl.setAttribute("aria-expanded", menuOpen ? "true" : "false");
          floatingMenuBtnEl.setAttribute(
            "aria-label",
            menuOpen ? "Close navigation menu" : "Open navigation menu",
          );
        }
      }

      // PERF-CONTRACT: ADMIN-PERFORMANCE-ISLAND
      // Performance engagement is evaluated only after its page is activated.
      let performanceEngagementIsland = null;
      let performanceEngagementIslandPromise = null;
      let queueHubIsland = null;
      let queueHubIslandPromise = null;
      let overviewChartIsland = null;
      let overviewChartIslandPromise = null;
      let overviewDashboardIsland = null;
      let overviewDashboardIslandPromise = null;
      // PERF-CONTRACT: ADMIN-FALLBACK-BOUNDARY
      // Compatibility handlers are loaded only after an island failure or by the test harness.
      let adminFallbacks = null;
      let adminFallbacksPromise = null;
      const ADMIN_FALLBACK_DEPENDENCY_NAMES =
        "STUDENT_NEWS_REVIEW_STATUS_SUBMITTED addAssignmentDraftItem applyAttendanceLevelTileStyle applyGradeChartCurrentQuarterDefault applyGradeChartCurrentSchoolYearDefault applyNewsReviewAction applyNewsReviewBulkApprove applyNewsReviewViewerAction applyParentTrackingLessonSummaryFromMemory applyParentTrackingRubricSummaryScores applyProfileFieldLayoutChanges applySortState autoFillSchoolSetupFromInputs bindById buildGradesTabulatorLaunchUrl clearAttendanceForm clearAttendanceLevelTileImage clearGradeForm clearLevelReminderForm clearParentTrackingActionShortcutInputs clearParentTrackingForm clearSchoolSetupLogoDraft closeGradeChartModal closeLevelDetailPanel closeNewsReviewViewer closeParentQueueModal compareIsoDateText createProfileFieldFromSettings dayLabelFromIsoDate deleteAssignmentTemplate deleteProfileFieldFromLayout deleteSelectedQueuedParentReports editParentQueueModalItem exportVisibleTableRowsToXlsx gradeChartCurrentSchoolYear handleAttendanceLevelImageUpload handleError handleSchoolSetupLogoUpload holdParentQueueModalItem insertParentTrackingActionShortcut loadAssignmentTemplatesFromServer loadExerciseTitles loadIncomingExerciseResults loadNewsReviewQueue loadParentReportQueue loadPerformanceEngagementData newsReviewViewerCurrentItem nextSundayIsoDate normalizeLower normalizeNewsReviewFilters normalizeText normalizedGradeChartPeriod openGradeChartModalForLaneKey openNewsReviewViewerByWeekSetId parentTrackingFieldSetValue persistAttendanceFormContext previewSchoolSetupFromInputs printVisibleTableRowsPdf queueParentTrackingEmail refreshAssignmentStudentOptions refreshAttendanceLanding refreshAttendanceLandingRows refreshNewsReviewFilterControls refreshParentTracking rememberParentTrackingLessonSummary rememberParentTrackingRecommendationFocus rememberParentTrackingTeacherName renderAssignmentLevelTiles renderAssignmentTemplates renderGradePulseChart renderParentQueueModal renderPerformanceEngagementPage renderPerformanceQueueSection renderPerformanceStagedSection renderProfileFieldLayoutEditor renderSchoolSetupPanel requeueParentQueueModalItem rerenderSortedTable resetAssignmentForm resetAttendanceLevelTileStyle resetParentTrackingManualMetricsTouched resetProfileFieldLayoutToDefault resetUiSettings saveAssignmentTemplate saveAttendance saveAttendanceLandingForSelectedLevel saveGrade saveParentTrackingReport saveSchoolSetupFromInputs schoolSetupDraftForRender sendAllQueuedParentReports sendAssignmentAnnouncement sendLevelReminders sendSelectedQueuedParentReports setAssignmentStatus setGradeChartState setNewsReviewFilterValues setNewsReviewViewerEditMode setParentQueueSelectionForVisibleRows setProfileFieldLayoutEditorExpanded setProfileLayoutStatus setStatus setTableSearchTerm shiftNewsReviewViewer state syncAttendanceDateDerivedFields syncAttendanceLevelEditorInputs syncParentTrackingForSelection toggleTableArchivedView unqueueSelectedQueuedParentReports updateAttendanceQuarterWarning".split(" ");

      function adminFallbackDependencies() {
        const dependencies = {};
        dependencies.STUDENT_NEWS_REVIEW_STATUS_SUBMITTED = typeof STUDENT_NEWS_REVIEW_STATUS_SUBMITTED === "undefined" ? undefined : STUDENT_NEWS_REVIEW_STATUS_SUBMITTED;
        dependencies.addAssignmentDraftItem = typeof addAssignmentDraftItem === "undefined" ? undefined : addAssignmentDraftItem;
        dependencies.applyAttendanceLevelTileStyle = typeof applyAttendanceLevelTileStyle === "undefined" ? undefined : applyAttendanceLevelTileStyle;
        dependencies.applyGradeChartCurrentQuarterDefault = typeof applyGradeChartCurrentQuarterDefault === "undefined" ? undefined : applyGradeChartCurrentQuarterDefault;
        dependencies.applyGradeChartCurrentSchoolYearDefault = typeof applyGradeChartCurrentSchoolYearDefault === "undefined" ? undefined : applyGradeChartCurrentSchoolYearDefault;
        dependencies.applyNewsReviewAction = typeof applyNewsReviewAction === "undefined" ? undefined : applyNewsReviewAction;
        dependencies.applyNewsReviewBulkApprove = typeof applyNewsReviewBulkApprove === "undefined" ? undefined : applyNewsReviewBulkApprove;
        dependencies.applyNewsReviewViewerAction = typeof applyNewsReviewViewerAction === "undefined" ? undefined : applyNewsReviewViewerAction;
        dependencies.applyParentTrackingLessonSummaryFromMemory = typeof applyParentTrackingLessonSummaryFromMemory === "undefined" ? undefined : applyParentTrackingLessonSummaryFromMemory;
        dependencies.applyParentTrackingRubricSummaryScores = typeof applyParentTrackingRubricSummaryScores === "undefined" ? undefined : applyParentTrackingRubricSummaryScores;
        dependencies.applyProfileFieldLayoutChanges = typeof applyProfileFieldLayoutChanges === "undefined" ? undefined : applyProfileFieldLayoutChanges;
        dependencies.applySortState = typeof applySortState === "undefined" ? undefined : applySortState;
        dependencies.autoFillSchoolSetupFromInputs = typeof autoFillSchoolSetupFromInputs === "undefined" ? undefined : autoFillSchoolSetupFromInputs;
        dependencies.bindById = typeof bindById === "undefined" ? undefined : bindById;
        dependencies.buildGradesTabulatorLaunchUrl = typeof buildGradesTabulatorLaunchUrl === "undefined" ? undefined : buildGradesTabulatorLaunchUrl;
        dependencies.clearAttendanceForm = typeof clearAttendanceForm === "undefined" ? undefined : clearAttendanceForm;
        dependencies.clearAttendanceLevelTileImage = typeof clearAttendanceLevelTileImage === "undefined" ? undefined : clearAttendanceLevelTileImage;
        dependencies.clearGradeForm = typeof clearGradeForm === "undefined" ? undefined : clearGradeForm;
        dependencies.clearLevelReminderForm = typeof clearLevelReminderForm === "undefined" ? undefined : clearLevelReminderForm;
        dependencies.clearParentTrackingActionShortcutInputs = typeof clearParentTrackingActionShortcutInputs === "undefined" ? undefined : clearParentTrackingActionShortcutInputs;
        dependencies.clearParentTrackingForm = typeof clearParentTrackingForm === "undefined" ? undefined : clearParentTrackingForm;
        dependencies.clearSchoolSetupLogoDraft = typeof clearSchoolSetupLogoDraft === "undefined" ? undefined : clearSchoolSetupLogoDraft;
        dependencies.closeGradeChartModal = typeof closeGradeChartModal === "undefined" ? undefined : closeGradeChartModal;
        dependencies.closeLevelDetailPanel = typeof closeLevelDetailPanel === "undefined" ? undefined : closeLevelDetailPanel;
        dependencies.closeNewsReviewViewer = typeof closeNewsReviewViewer === "undefined" ? undefined : closeNewsReviewViewer;
        dependencies.closeParentQueueModal = typeof closeParentQueueModal === "undefined" ? undefined : closeParentQueueModal;
        dependencies.compareIsoDateText = typeof compareIsoDateText === "undefined" ? undefined : compareIsoDateText;
        dependencies.createProfileFieldFromSettings = typeof createProfileFieldFromSettings === "undefined" ? undefined : createProfileFieldFromSettings;
        dependencies.dayLabelFromIsoDate = typeof dayLabelFromIsoDate === "undefined" ? undefined : dayLabelFromIsoDate;
        dependencies.deleteAssignmentTemplate = typeof deleteAssignmentTemplate === "undefined" ? undefined : deleteAssignmentTemplate;
        dependencies.deleteProfileFieldFromLayout = typeof deleteProfileFieldFromLayout === "undefined" ? undefined : deleteProfileFieldFromLayout;
        dependencies.deleteSelectedQueuedParentReports = typeof deleteSelectedQueuedParentReports === "undefined" ? undefined : deleteSelectedQueuedParentReports;
        dependencies.editParentQueueModalItem = typeof editParentQueueModalItem === "undefined" ? undefined : editParentQueueModalItem;
        dependencies.exportVisibleTableRowsToXlsx = typeof exportVisibleTableRowsToXlsx === "undefined" ? undefined : exportVisibleTableRowsToXlsx;
        dependencies.gradeChartCurrentSchoolYear = typeof gradeChartCurrentSchoolYear === "undefined" ? undefined : gradeChartCurrentSchoolYear;
        dependencies.handleAttendanceLevelImageUpload = typeof handleAttendanceLevelImageUpload === "undefined" ? undefined : handleAttendanceLevelImageUpload;
        dependencies.handleError = typeof handleError === "undefined" ? undefined : handleError;
        dependencies.handleSchoolSetupLogoUpload = typeof handleSchoolSetupLogoUpload === "undefined" ? undefined : handleSchoolSetupLogoUpload;
        dependencies.holdParentQueueModalItem = typeof holdParentQueueModalItem === "undefined" ? undefined : holdParentQueueModalItem;
        dependencies.insertParentTrackingActionShortcut = typeof insertParentTrackingActionShortcut === "undefined" ? undefined : insertParentTrackingActionShortcut;
        dependencies.loadAssignmentTemplatesFromServer = typeof loadAssignmentTemplatesFromServer === "undefined" ? undefined : loadAssignmentTemplatesFromServer;
        dependencies.loadExerciseTitles = typeof loadExerciseTitles === "undefined" ? undefined : loadExerciseTitles;
        dependencies.loadIncomingExerciseResults = typeof loadIncomingExerciseResults === "undefined" ? undefined : loadIncomingExerciseResults;
        dependencies.loadNewsReviewQueue = typeof loadNewsReviewQueue === "undefined" ? undefined : loadNewsReviewQueue;
        dependencies.loadParentReportQueue = typeof loadParentReportQueue === "undefined" ? undefined : loadParentReportQueue;
        dependencies.loadPerformanceEngagementData = typeof loadPerformanceEngagementData === "undefined" ? undefined : loadPerformanceEngagementData;
        dependencies.newsReviewViewerCurrentItem = typeof newsReviewViewerCurrentItem === "undefined" ? undefined : newsReviewViewerCurrentItem;
        dependencies.nextSundayIsoDate = typeof nextSundayIsoDate === "undefined" ? undefined : nextSundayIsoDate;
        dependencies.normalizeLower = typeof normalizeLower === "undefined" ? undefined : normalizeLower;
        dependencies.normalizeNewsReviewFilters = typeof normalizeNewsReviewFilters === "undefined" ? undefined : normalizeNewsReviewFilters;
        dependencies.normalizeText = typeof normalizeText === "undefined" ? undefined : normalizeText;
        dependencies.normalizedGradeChartPeriod = typeof normalizedGradeChartPeriod === "undefined" ? undefined : normalizedGradeChartPeriod;
        dependencies.open = typeof open === "undefined" ? undefined : open;
        dependencies.openGradeChartModalForLaneKey = typeof openGradeChartModalForLaneKey === "undefined" ? undefined : openGradeChartModalForLaneKey;
        dependencies.openNewsReviewViewerByWeekSetId = typeof openNewsReviewViewerByWeekSetId === "undefined" ? undefined : openNewsReviewViewerByWeekSetId;
        dependencies.parentTrackingFieldSetValue = typeof parentTrackingFieldSetValue === "undefined" ? undefined : parentTrackingFieldSetValue;
        dependencies.persistAttendanceFormContext = typeof persistAttendanceFormContext === "undefined" ? undefined : persistAttendanceFormContext;
        dependencies.previewSchoolSetupFromInputs = typeof previewSchoolSetupFromInputs === "undefined" ? undefined : previewSchoolSetupFromInputs;
        dependencies.printVisibleTableRowsPdf = typeof printVisibleTableRowsPdf === "undefined" ? undefined : printVisibleTableRowsPdf;
        dependencies.queueParentTrackingEmail = typeof queueParentTrackingEmail === "undefined" ? undefined : queueParentTrackingEmail;
        dependencies.refreshAssignmentStudentOptions = typeof refreshAssignmentStudentOptions === "undefined" ? undefined : refreshAssignmentStudentOptions;
        dependencies.refreshAttendanceLanding = typeof refreshAttendanceLanding === "undefined" ? undefined : refreshAttendanceLanding;
        dependencies.refreshAttendanceLandingRows = typeof refreshAttendanceLandingRows === "undefined" ? undefined : refreshAttendanceLandingRows;
        dependencies.refreshNewsReviewFilterControls = typeof refreshNewsReviewFilterControls === "undefined" ? undefined : refreshNewsReviewFilterControls;
        dependencies.refreshParentTracking = typeof refreshParentTracking === "undefined" ? undefined : refreshParentTracking;
        dependencies.rememberParentTrackingLessonSummary = typeof rememberParentTrackingLessonSummary === "undefined" ? undefined : rememberParentTrackingLessonSummary;
        dependencies.rememberParentTrackingRecommendationFocus = typeof rememberParentTrackingRecommendationFocus === "undefined" ? undefined : rememberParentTrackingRecommendationFocus;
        dependencies.rememberParentTrackingTeacherName = typeof rememberParentTrackingTeacherName === "undefined" ? undefined : rememberParentTrackingTeacherName;
        dependencies.renderAssignmentLevelTiles = typeof renderAssignmentLevelTiles === "undefined" ? undefined : renderAssignmentLevelTiles;
        dependencies.renderAssignmentTemplates = typeof renderAssignmentTemplates === "undefined" ? undefined : renderAssignmentTemplates;
        dependencies.renderGradePulseChart = typeof renderGradePulseChart === "undefined" ? undefined : renderGradePulseChart;
        dependencies.renderParentQueueModal = typeof renderParentQueueModal === "undefined" ? undefined : renderParentQueueModal;
        dependencies.renderPerformanceEngagementPage = typeof renderPerformanceEngagementPage === "undefined" ? undefined : renderPerformanceEngagementPage;
        dependencies.renderPerformanceQueueSection = typeof renderPerformanceQueueSection === "undefined" ? undefined : renderPerformanceQueueSection;
        dependencies.renderPerformanceStagedSection = typeof renderPerformanceStagedSection === "undefined" ? undefined : renderPerformanceStagedSection;
        dependencies.renderProfileFieldLayoutEditor = typeof renderProfileFieldLayoutEditor === "undefined" ? undefined : renderProfileFieldLayoutEditor;
        dependencies.renderSchoolSetupPanel = typeof renderSchoolSetupPanel === "undefined" ? undefined : renderSchoolSetupPanel;
        dependencies.requeueParentQueueModalItem = typeof requeueParentQueueModalItem === "undefined" ? undefined : requeueParentQueueModalItem;
        dependencies.rerenderSortedTable = typeof rerenderSortedTable === "undefined" ? undefined : rerenderSortedTable;
        dependencies.resetAssignmentForm = typeof resetAssignmentForm === "undefined" ? undefined : resetAssignmentForm;
        dependencies.resetAttendanceLevelTileStyle = typeof resetAttendanceLevelTileStyle === "undefined" ? undefined : resetAttendanceLevelTileStyle;
        dependencies.resetParentTrackingManualMetricsTouched = typeof resetParentTrackingManualMetricsTouched === "undefined" ? undefined : resetParentTrackingManualMetricsTouched;
        dependencies.resetProfileFieldLayoutToDefault = typeof resetProfileFieldLayoutToDefault === "undefined" ? undefined : resetProfileFieldLayoutToDefault;
        dependencies.resetUiSettings = typeof resetUiSettings === "undefined" ? undefined : resetUiSettings;
        dependencies.saveAssignmentTemplate = typeof saveAssignmentTemplate === "undefined" ? undefined : saveAssignmentTemplate;
        dependencies.saveAttendance = typeof saveAttendance === "undefined" ? undefined : saveAttendance;
        dependencies.saveAttendanceLandingForSelectedLevel = typeof saveAttendanceLandingForSelectedLevel === "undefined" ? undefined : saveAttendanceLandingForSelectedLevel;
        dependencies.saveGrade = typeof saveGrade === "undefined" ? undefined : saveGrade;
        dependencies.saveParentTrackingReport = typeof saveParentTrackingReport === "undefined" ? undefined : saveParentTrackingReport;
        dependencies.saveSchoolSetupFromInputs = typeof saveSchoolSetupFromInputs === "undefined" ? undefined : saveSchoolSetupFromInputs;
        dependencies.schoolSetupDraftForRender = typeof schoolSetupDraftForRender === "undefined" ? undefined : schoolSetupDraftForRender;
        dependencies.sendAllQueuedParentReports = typeof sendAllQueuedParentReports === "undefined" ? undefined : sendAllQueuedParentReports;
        dependencies.sendAssignmentAnnouncement = typeof sendAssignmentAnnouncement === "undefined" ? undefined : sendAssignmentAnnouncement;
        dependencies.sendLevelReminders = typeof sendLevelReminders === "undefined" ? undefined : sendLevelReminders;
        dependencies.sendSelectedQueuedParentReports = typeof sendSelectedQueuedParentReports === "undefined" ? undefined : sendSelectedQueuedParentReports;
        dependencies.setAssignmentStatus = typeof setAssignmentStatus === "undefined" ? undefined : setAssignmentStatus;
        dependencies.setGradeChartState = typeof setGradeChartState === "undefined" ? undefined : setGradeChartState;
        dependencies.setNewsReviewFilterValues = typeof setNewsReviewFilterValues === "undefined" ? undefined : setNewsReviewFilterValues;
        dependencies.setNewsReviewViewerEditMode = typeof setNewsReviewViewerEditMode === "undefined" ? undefined : setNewsReviewViewerEditMode;
        dependencies.setParentQueueSelectionForVisibleRows = typeof setParentQueueSelectionForVisibleRows === "undefined" ? undefined : setParentQueueSelectionForVisibleRows;
        dependencies.setProfileFieldLayoutEditorExpanded = typeof setProfileFieldLayoutEditorExpanded === "undefined" ? undefined : setProfileFieldLayoutEditorExpanded;
        dependencies.setProfileLayoutStatus = typeof setProfileLayoutStatus === "undefined" ? undefined : setProfileLayoutStatus;
        dependencies.setStatus = typeof setStatus === "undefined" ? undefined : setStatus;
        dependencies.setTableSearchTerm = typeof setTableSearchTerm === "undefined" ? undefined : setTableSearchTerm;
        dependencies.shiftNewsReviewViewer = typeof shiftNewsReviewViewer === "undefined" ? undefined : shiftNewsReviewViewer;
        dependencies.state = typeof state === "undefined" ? undefined : state;
        dependencies.syncAttendanceDateDerivedFields = typeof syncAttendanceDateDerivedFields === "undefined" ? undefined : syncAttendanceDateDerivedFields;
        dependencies.syncAttendanceLevelEditorInputs = typeof syncAttendanceLevelEditorInputs === "undefined" ? undefined : syncAttendanceLevelEditorInputs;
        dependencies.syncParentTrackingForSelection = typeof syncParentTrackingForSelection === "undefined" ? undefined : syncParentTrackingForSelection;
        dependencies.toggleTableArchivedView = typeof toggleTableArchivedView === "undefined" ? undefined : toggleTableArchivedView;
        dependencies.unqueueSelectedQueuedParentReports = typeof unqueueSelectedQueuedParentReports === "undefined" ? undefined : unqueueSelectedQueuedParentReports;
        dependencies.updateAttendanceQuarterWarning = typeof updateAttendanceQuarterWarning === "undefined" ? undefined : updateAttendanceQuarterWarning;
        return dependencies;
      }

      async function ensureAdminFallbacks() {
        if (adminFallbacks) return adminFallbacks;
        if (!adminFallbacksPromise) {
          adminFallbacksPromise = (IS_JSDOM_ENV && window.__SIS_ADMIN_FALLBACK_FACTORY__
            ? Promise.resolve({ initAdminFallbacks: window.__SIS_ADMIN_FALLBACK_FACTORY__ })
            : import("/web-asset/admin/admin-fallbacks.mjs"))
            .then((mod) => {
              adminFallbacks = mod.initAdminFallbacks(adminFallbackDependencies());
              return adminFallbacks;
            });
        }
        return adminFallbacksPromise;
      }

      function activateAdminFallback(name) {
        void ensureAdminFallbacks()
          .then((fallbacks) => fallbacks?.[name]?.())
          .catch(handleError);
      }

      async function ensureOverviewChartIsland() {
        if (overviewChartIsland) return overviewChartIsland;
        if (IS_JSDOM_ENV) {
          overviewChartIsland = {
            render({ weeklyRows = [], levelRows = [] } = {}) {
              const lineChart = document.getElementById("overviewLineChart");
              if (lineChart) {
                const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
                const todayIndex = Math.max(0, Math.min(days.length - 1, (new Date().getDay() + 6) % 7));
                const points = days
                  .slice(0, todayIndex + 1)
                  .map((_, index) => `<circle cx="${index}" cy="228" r="3.5"></circle>`)
                  .join("");
                lineChart.innerHTML = `${points}${days
                  .map((day) => `<text>${day}</text>`)
                  .join("")}`;
              }
              const barChart = document.getElementById("overviewBarChart");
              const actions = document.getElementById("overviewBarDetailActions");
              if (barChart) {
                barChart.innerHTML = levelRows
                  .map((row, index) => {
                    const theme = getLevelTheme(row?.level || "");
                    const enrolled = Number(row?.enrolledStudents ?? row?.totalAssignments ?? 0) || 0;
                    const completed = Number(row?.completedStudents ?? row?.completedAssignments ?? 0) || 0;
                    const x = 24 + index * 72;
                    return `<rect x="${x}" y="${Math.max(20, 280 - enrolled * 4)}" width="24" height="${Math.max(0, enrolled * 4)}" fill="${theme.color}"></rect><rect x="${x + 28}" y="${Math.max(20, 280 - completed * 4)}" width="24" height="${Math.max(0, completed * 4)}" fill="${theme.softColor}"></rect>`;
                  })
                  .join("");
              }
              if (actions) {
                actions.innerHTML = "";
                levelRows.forEach((row) => {
                  const button = document.createElement("button");
                  button.type = "button";
                  button.className = "bar-detail-action-btn";
                  button.classList.add("level-theme-btn");
                  const theme = getLevelTheme(row?.level || "");
                  button.style.setProperty("--level-theme-bg", theme.color);
                  button.style.setProperty("--level-theme-border", theme.borderColor);
                  button.style.setProperty("--level-theme-text", theme.textColor);
                  button.textContent = fullLevelLabel(row?.level || "");
                  button.addEventListener("click", () => openLevelDetailPanel(row));
                  actions.appendChild(button);
                });
              }
              void weeklyRows;
            },
          };
          return overviewChartIsland;
        }
        if (!overviewChartIslandPromise) {
          overviewChartIslandPromise = import("/web-asset/admin/overview-chart-island.mjs")
            .then((mod) => {
              overviewChartIsland = mod.initOverviewChartIsland({
                document,
                onLevelDetailOpen: openLevelDetailPanel,
                helpers: {
                  normalizeText,
                  normalizeWeeklyAssignmentCompletion,
                  shiftToFixedTimeZone,
                  getLevelTheme,
                  toRgba,
                  shortLevelLabel,
                  fullLevelLabel,
                  formatPercent,
                },
              });
              return overviewChartIsland;
            });
        }
        return overviewChartIslandPromise;
      }

      function renderOverviewChartsAfterPaint(payload = {}) {
        void (async () => {
          const island = await ensureOverviewChartIsland();
          island.render(payload);
        })().catch(handleError);
      }

      async function ensureOverviewDashboardIsland() {
        if (overviewDashboardIsland) return overviewDashboardIsland;
        if (IS_JSDOM_ENV) {
          overviewDashboardIsland = {
            renderDashboardSummary(summary = {}) {
              const today = summary?.today || {};
              const setValue = (id, value) => {
                const element = document.getElementById(id);
                if (element) element.textContent = String(value);
              };
              const totalEnrollment = Number(today.totalEnrollment ?? today.totalStudents ?? 0) || 0;
              const attendance = Number(today.attendance || 0) || 0;
              const attendancePercent = Number.isFinite(Number(today.attendancePercentOfEnrollment))
                ? Number(today.attendancePercentOfEnrollment)
                : totalEnrollment > 0 ? (attendance / totalEnrollment) * 100 : 0;
              setValue("ovTotalEnrollment", totalEnrollment);
              setValue("ovAttendancePctEnrollment", formatPercent(attendancePercent));
              setValue("ovUnenrolledYtd", Number(today.unenrolledYtd || 0) || 0);
              setValue("ovTodayAttendance", attendance);
              setValue("ovTodayAbsences", Number(today.absences || 0) || 0);
              setValue(
                "ovTardyRates",
                `${formatPercent(today.tardy10PlusPercent || 0)} / ${formatPercent(today.tardy30PlusPercent || 0)}`,
              );
              const levelRows = Array.isArray(state.dashboardLevelCompletionRows)
                ? state.dashboardLevelCompletionRows
                : [];
              const assignmentRows = document.getElementById("overviewAssignmentRows");
              if (assignmentRows) {
                const targeted = levelRows.reduce(
                  (sum, row) => sum + (Number(row?.totalAssignments ?? row?.enrolledStudents ?? 0) || 0),
                  0,
                );
                const completed = levelRows.reduce(
                  (sum, row) => sum + (Number(row?.completedAssignments ?? row?.completedStudents ?? 0) || 0),
                  0,
                );
                const pending = levelRows.reduce(
                  (sum, row) => sum + Math.max(0, (Number(row?.totalAssignments ?? row?.enrolledStudents ?? 0) || 0) - (Number(row?.completedAssignments ?? row?.completedStudents ?? 0) || 0)),
                  0,
                );
                assignmentRows.innerHTML = [
                  ["Active class levels", levelRows.length],
                  ["Targeted students", targeted],
                  ["Completed now", completed],
                  ["Pending reminders", pending],
                ].map(([label, value]) => `<tr><td>${label}</td><td>${value}</td></tr>`).join("");
              }
              state.parentReportQueue.savedReportCountHint = Math.max(
                0,
                Number(summary?.parentReports?.total || 0) || 0,
              );
              renderPerformanceStagedSection();
              void ensureOverviewChartIsland().then((island) => {
                island.render({
                  weeklyRows: summary?.weeklyAssignmentCompletion || [],
                  levelRows,
                });
              });
            },
          };
          return overviewDashboardIsland;
        }
        if (!overviewDashboardIslandPromise) {
          overviewDashboardIslandPromise = import("/web-asset/admin/overview-dashboard-island.mjs")
            .then((mod) => {
              overviewDashboardIsland = mod.initOverviewDashboardIsland({
                document,
                state,
                normalizeWeeklyAssignmentCompletion,
                sortLevelRows,
                isAssignedLevelRow,
                effectiveDashboardLevelCompletionRows,
                formatPercent,
                levelBadgeHtml,
                renderOverviewChartsAfterPaint,
                buildDashboardRiskLines,
                renderAttendanceAdminRiskSignals,
                renderPerformanceStagedSection,
              });
              return overviewDashboardIsland;
            });
        }
        return overviewDashboardIslandPromise;
      }

      async function ensureQueueHubIsland() {
        if (queueHubIsland) return queueHubIsland;
        if (IS_JSDOM_ENV) {
          if (window.__SIS_QUEUE_HUB_FACTORY__) {
            queueHubIsland = window.__SIS_QUEUE_HUB_FACTORY__({
              document,
              state,
              api,
              onQueueHubItemOpen(panelId, rowIndex) {
                openQueueHubItem(panelId, rowIndex).catch(handleError);
              },
              onOverviewNewsQueueUpdate(panel) {
                renderOverviewNewsQueueSection(panel);
              },
              helpers: {
                normalizeText,
                normalizeQueueHubPanelOrder,
                persistUiSettings,
                persistUiSettingsToServer,
                formatDateTime,
                formatPortalWeekRange,
                fullLevelLabel,
                resolveSystemLevelName,
                newsReviewAdminSetStatusToken,
                newsReviewWeekSetActionToken,
                weeklyMinimumNewsReports,
                newsReviewStatusChipHtml,
                newsReviewStatusLabel,
                newsReviewSetActionChipHtml,
                newsReviewSetActionLabel,
                escapeHtml,
                normalizeLower,
                currentRoleName,
                canManageUsers,
                setStatus,
                panelIds: QUEUE_HUB_PANEL_IDS,
                queueHubPath: ADMIN_QUEUE_HUB_PATH,
                fixedTimeZone: FIXED_TIME_ZONE,
                defaultPanelOrder: DEFAULT_UI_SETTINGS.queueHub.panelOrder,
              },
            });
            queueHubIsland.bind();
            return queueHubIsland;
          }
          queueHubIsland = {
            load() {},
            render() {},
            save() {},
            reset() {},
            setStatus() {},
            itemAt() { return null; },
          };
          return queueHubIsland;
        }
        if (!queueHubIslandPromise) {
          queueHubIslandPromise = import("/web-asset/admin/queue-hub-island.mjs")
            .then((mod) => {
              queueHubIsland = mod.initQueueHubIsland({
                document,
                state,
                api,
                onQueueHubItemOpen(panelId, rowIndex) {
                  openQueueHubItem(panelId, rowIndex).catch(handleError);
                },
                onOverviewNewsQueueUpdate(panel) {
                  renderOverviewNewsQueueSection(panel);
                },
                helpers: {
                  normalizeText,
                  normalizeQueueHubPanelOrder,
                  persistUiSettings,
                  persistUiSettingsToServer,
                  formatDateTime,
                  formatPortalWeekRange,
                  fullLevelLabel,
                  resolveSystemLevelName,
                  newsReviewAdminSetStatusToken,
                  newsReviewWeekSetActionToken,
                  weeklyMinimumNewsReports,
                  newsReviewStatusChipHtml,
                  newsReviewStatusLabel,
                  newsReviewSetActionChipHtml,
                  newsReviewSetActionLabel,
                  escapeHtml,
                  normalizeLower,
                  currentRoleName,
                  canManageUsers,
                  setStatus,
                  panelIds: QUEUE_HUB_PANEL_IDS,
                  queueHubPath: ADMIN_QUEUE_HUB_PATH,
                  fixedTimeZone: FIXED_TIME_ZONE,
                  defaultPanelOrder: DEFAULT_UI_SETTINGS.queueHub.panelOrder,
                },
              });
              queueHubIsland.bind();
              return queueHubIsland;
            });
        }
        return queueHubIslandPromise;
      }

      async function loadQueueHub(options = {}) {
        const island = await ensureQueueHubIsland();
        return island.load(options);
      }

      function renderQueueHubPanels() {
        queueHubIsland?.render();
      }

      function setQueueHubStatus(message = "", isError = false) {
        queueHubIsland?.setStatus(message, isError);
      }

      async function saveQueueHubPanelOrder() {
        const island = await ensureQueueHubIsland();
        return island.save();
      }

      function resetQueueHubPanelOrder() {
        queueHubIsland?.reset();
      }

      async function ensurePerformanceEngagementIsland() {
        if (performanceEngagementIsland) return performanceEngagementIsland;
        if (IS_JSDOM_ENV) {
          performanceEngagementIsland = { load() {}, render() {}, bind() {} };
          return performanceEngagementIsland;
        }
        if (!performanceEngagementIslandPromise) {
          performanceEngagementIslandPromise = import("/web-asset/admin/performance-engagement-island.mjs")
            .then((mod) => {
              performanceEngagementIsland = mod.initPerformanceEngagementIsland({
                document,
                state,
                api,
                onError: handleError,
                helpers: {
                  normalizeText,
                  normalizeLower,
                  compareTableText,
                  compareTableIsoDate,
                  applySortDirection,
                  rowWeekNumber,
                  engagementDayHeading,
                  escapeHtml,
                  formatDateTime,
                },
              });
              return performanceEngagementIsland;
            });
        }
        return performanceEngagementIslandPromise;
      }

      async function loadPerformanceEngagementData({ force = false } = {}) {
        const island = await ensurePerformanceEngagementIsland();
        return island.load({ force });
      }

      function renderPerformanceEngagementPage() {
        performanceEngagementIsland?.render();
      }

      function bindPerformanceEngagementSortHeaderEvents() {
        performanceEngagementIsland?.bind();
      }

      let assignmentEngagementIsland = null;
      let assignmentEngagementIslandPromise = null;

      async function ensureAssignmentEngagementIsland() {
        if (assignmentEngagementIsland) return assignmentEngagementIsland;
        if (!assignmentEngagementIslandPromise) {
          assignmentEngagementIslandPromise = import("/web-asset/admin/assignment-engagement-island.mjs")
            .then((mod) => {
              assignmentEngagementIsland = mod.initAssignmentEngagementIsland({
                document,
                state,
                api,
                onError: handleError,
                helpers: {
                  normalizeText,
                  normalizeLower,
                  compareTableIsoDateTime,
                  compareTableText,
                  applySortDirection,
                  escapeHtml,
                  formatDateTime,
                  rowWeekNumber,
                  updateTableHeaderSortIndicators,
                },
              });
              return assignmentEngagementIsland;
            });
        }
        return assignmentEngagementIslandPromise;
      }

      async function loadAssignmentEngagementData({ force = false } = {}) {
        const island = await ensureAssignmentEngagementIsland();
        return island.load({ force });
      }

      function renderAssignmentEngagementPage() {
        assignmentEngagementIsland?.render();
      }

      function ensureAssignmentEngagementPageLoaded(slug = "") {
        if (slug !== "assignment-engagement") return;
        if (document.querySelector('.page-section[data-page="assignment-engagement"]')) return;
        const template = document.getElementById("assignment-engagement-page-template");
        const host = template?.parentElement;
        if (!(template instanceof HTMLTemplateElement) || !host) return;
        host.insertBefore(template.content.cloneNode(true), template);
        template.remove();
        void ensureAssignmentEngagementIsland();
      }

      function setActivePage(pageSlug, options = {}) {
        const { syncUrl = true, historyMode = "push" } = options;
        let slug = normalizePageSlug(pageSlug);
        if (!isPageAllowedForCurrentRole(slug)) slug = roleStartPage();
        state.activePage = slug;
        document.dispatchEvent(new CustomEvent("sis-admin-page-activated", { detail: { page: slug } }));
        ensureAssignmentEngagementPageLoaded(slug);
        if (slug !== "news-reports") closeNewsReviewViewer();

        document.querySelectorAll(".page-section[data-page]").forEach((sectionEl) => {
          if (sectionEl.dataset.page === slug) sectionEl.classList.add("active");
          else sectionEl.classList.remove("active");
        });

        document.querySelectorAll("[data-page-link]").forEach((linkEl) => {
          if (linkEl.dataset.pageLink === slug) linkEl.classList.add("active");
          else linkEl.classList.remove("active");
        });

        updateMenuExpansion(pageGroupForSlug(slug));
        const gridMain = document.querySelector(".grid-main");
        const topControlsPanel = document.getElementById("topControlsPanel");
        const studentListPanel = document.getElementById("studentListPanel");
        const topSearchResultsPanel = document.getElementById("topSearchResultsPanel");
        const showStudentListPanel = slug === "student-admin";
        const hideTopSearch = pageHidesTopSearch(slug);
        if (topControlsPanel)
          topControlsPanel.classList.toggle("hidden", hideTopSearch);
        if (studentListPanel)
          studentListPanel.classList.toggle("hidden", !showStudentListPanel);
        if (topSearchResultsPanel)
          topSearchResultsPanel.classList.toggle("hidden", showStudentListPanel);
        if (gridMain) gridMain.classList.toggle("overview-full", !showStudentListPanel);
        const studentListPages = new Set([
          "student-admin",
          "attendance",
          "attendance-admin",
          "assignments",
          "assignments-data",
          "grades",
          "grades-data",
          "grades-tabulator",
          "parent-tracking",
          "performance-data",
          "performance-engagement",
          "reports",
        ]);
        if (studentListPages.has(slug) && canReadData() && !state.students.length) {
          loadStudents()
            .then(() => {
              if (slug === "assignments" || slug === "assignments-data") {
                refreshAssignmentStudentOptions();
                renderAssignmentLevelTiles();
              }
              if (slug === "parent-tracking") {
                renderParentTrackingTeacherOptions();
              }
            })
            .catch(handleError);
        }
        if (slug === "attendance" || slug === "attendance-admin") {
          ensureAttendanceLandingFormDefaults();
          refreshAttendanceLanding({ reloadRows: true }).catch(handleError);
        }
        if (slug === "profile") {
          setProfileMode("info");
          renderProfileInfoLayout(state.currentStudent);
          if (!state.currentStudent?.id) {
            scheduleAfterFirstPaint(() => hydrateNextStudentNumberFromApi().catch((error) => {
              if (error && (error.status === 401 || error.status === 404 || error.status === 503)) return;
              handleError(error);
            }), 1000);
          }
        }
        if (slug === "school-setup" || slug === "settings") {
          renderProfileFieldLayoutEditor();
          populateAttendanceLevelStyleOptions();
          syncAttendanceLevelEditorInputs();
          if (!IS_JSDOM_ENV && canReadData()) {
            loadFilters().catch(handleError);
          }
        }
        if (slug === "parent-tracking") {
          ensureParentTrackingFormDefaults({ forceSummaryFromMemory: false });
          refreshParentTracking({ preserveStudentSelection: true }).catch(handleError);
        }
        if (slug === "queue-hub") {
          loadQueueHub({ notify: false, compact: false }).catch(handleError);
        }
        if (slug === "assignments" || slug === "assignments-data") {
          refreshAssignmentStudentOptions();
          renderAssignmentLevelTiles();
          loadStudents()
            .then(() => loadExerciseTitles())
            .catch(handleError);
          loadAssignmentTemplatesFromServer({ migrateLegacy: true })
            .then(() => renderAssignmentTemplates())
            .catch(handleError);
        }
        if (slug === "performance-data") {
          loadParentReportQueue({ showAll: state.parentReportQueue.showAll }).catch(
            handleError,
          );
          const params = new URLSearchParams(window.location.search || "");
          const deepLinkedEaglesId = normalizeText(params.get("eaglesId"));
          if (deepLinkedEaglesId) {
            const performanceDataSearch = document.getElementById(
              "performanceDataSearch",
            );
            if (performanceDataSearch) {
              performanceDataSearch.value = deepLinkedEaglesId;
              setTableSearchTerm("performance", deepLinkedEaglesId);
              rerenderSortedTable("performance");
            }
          }
        }
        if (slug === "performance-engagement") {
          loadPerformanceEngagementData({ force: false }).catch(handleError);
        }
        if (slug === "assignment-engagement") {
          loadAssignmentEngagementData({ force: false }).catch(handleError);
        }
        if (slug === "news-reports") {
          loadNewsReviewQueue({ notify: false }).catch(handleError);
        }
        const adminDataTableKey = adminDataTableKeyForPage(slug);
        if (adminDataTableKey) {
          loadAdminDataRowsForTable(adminDataTableKey).catch(handleError);
        }
        updateTopSearchScopeHint();
        if (document.body.classList.contains("menu-open")) {
          document.body.classList.remove("menu-open");
        }
        updateMenuToggleButtonLabel();
        renderOverviewRuntimeRestartButton();
        if (syncUrl) syncPageHistory(slug, historyMode);
      }

      window.__SIS_ADMIN_ACTIVATE_PAGE__ = setActivePage;

      function updateNavigationAccess() {
        document.querySelectorAll("[data-page-link]").forEach((linkEl) => {
          const slug = normalizeText(linkEl.getAttribute("data-page-link"));
          if (!slug) return;
          if (isPageAllowedForCurrentRole(slug)) linkEl.classList.remove("hidden");
          else linkEl.classList.add("hidden");
        });

        document.querySelectorAll("[data-menu-group]").forEach((groupEl) => {
          const visibleLinks = groupEl.querySelectorAll(
            "[data-page-link]:not(.hidden)",
          );
          if (visibleLinks.length > 0) groupEl.classList.remove("hidden");
          else groupEl.classList.add("hidden");
        });
        updateTrackingDataSubmenuVisibility();
      }

      const INITIAL_PAGE_SLUG = resolveInitialPageSlug();
      state.activePage = INITIAL_PAGE_SLUG;

      function currentRoleName() {
        const role = normalizeLower(state.authUser?.role);
        return role || "teacher";
      }

      function getCurrentRolePolicy() {
        const role = currentRoleName();
        const normalized = normalizeRolePermissionsMap(state.rolePermissions);
        const policy = normalized[role] || normalized.teacher || normalized.admin;
        if (
          state.authRolePolicy &&
          normalizeLower(state.authRolePolicy.role) === role
        ) {
          return normalizeRolePolicy(role, state.authRolePolicy, policy);
        }
        return normalizeRolePolicy(role, policy, defaultRolePermissionsConfig()[role]);
      }

      function isPageAllowedForCurrentRole(pageSlug) {
        const policy = getCurrentRolePolicy();
        const slug = normalizePageSlug(pageSlug);
        return Array.isArray(policy.allowedPages) && policy.allowedPages.includes(slug);
      }

      function roleStartPage() {
        const policy = getCurrentRolePolicy();
        const candidate = normalizePageSlug(
          policy.startPage || DEFAULT_ADMIN_PAGE_SLUG,
        );
        if (
          Array.isArray(policy.allowedPages) &&
          policy.allowedPages.includes(candidate)
        )
          return candidate;
        const fallback =
          Array.isArray(policy.allowedPages) && policy.allowedPages.length ?
            policy.allowedPages[0]
          : DEFAULT_ADMIN_PAGE_SLUG;
        return normalizePageSlug(fallback);
      }

      function canManageUsers() {
        return Boolean(getCurrentRolePolicy().canManageUsers);
      }

      function canManagePermissions() {
        return Boolean(getCurrentRolePolicy().canManagePermissions);
      }

      function canManageSettings() {
        return canManageUsers() || canManagePermissions();
      }

      function canReadData() {
        return Boolean(getCurrentRolePolicy().canRead);
      }

      function canWriteData() {
        return Boolean(getCurrentRolePolicy().canWrite);
      }

      function updateWriteAccessControls() {
        const writable = canWriteData();
        const teacherDataEntryWrite = currentRoleName() === "teacher";
        const teacherParentTrackingWrite = currentRoleName() === "teacher";
        const ids = [
          "newBtn",
          "saveBtn",
          "deleteBtn",
          "profileEditInfoBtn",
          "profileCreateInfoBtn",
          "importBtn",
          "attendanceSaveBtn",
          "attendanceLandingSaveAllBtn",
          "assignmentAddItemBtn",
          "assignmentSaveTemplateBtn",
          "assignmentDeleteTemplateBtn",
          "assignmentSendBtn",
          "pt_saveBtn",
          "pt_queueSendBtn",
          "gradeSaveBtn",
          "reportSaveBtn",
          "reportGenerateBtn",
        ];
        ids.forEach((id) => {
          const el = document.getElementById(id);
          if (!el) return;
          if (id === "pt_saveBtn" || id === "pt_queueSendBtn") {
            el.disabled = !(writable || teacherParentTrackingWrite);
            return;
          }
          if (
            [
              "attendanceSaveBtn",
              "attendanceLandingSaveAllBtn",
              "gradeSaveBtn",
              "reportSaveBtn",
              "reportGenerateBtn",
            ].includes(id)
          ) {
            el.disabled = !(writable || teacherDataEntryWrite);
            return;
          }
          el.disabled = !writable;
        });
        const queueBtn = document.getElementById("pt_queueSendBtn");
        if (queueBtn) {
          queueBtn.textContent = "Submit";
        }
        const adminDataActionIds = [
          "attendanceArchiveToggleBtn",
          "assignmentArchiveToggleBtn",
          "gradeArchiveToggleBtn",
          "reportArchiveToggleBtn",
          "attendanceExportXlsxBtn",
          "assignmentExportXlsxBtn",
          "performanceExportXlsxBtn",
          "gradeExportXlsxBtn",
          "reportExportXlsxBtn",
          "attendancePrintPdfBtn",
          "assignmentPrintPdfBtn",
          "performancePrintPdfBtn",
          "gradePrintPdfBtn",
          "reportPrintPdfBtn",
        ];
        const isAdminRole = currentRoleName() === "admin";
        adminDataActionIds.forEach((id) => {
          const el = document.getElementById(id);
          if (!el) return;
          el.disabled = !isAdminRole;
        });
        renderAssignmentDraftItems();
        setProfileMode(state.profileMode);
      }

      function showUserPanel() {
        const panel = document.getElementById("userAdminPanel");
        if (canManageUsers()) panel.classList.remove("hidden");
        else panel.classList.add("hidden");
        const permissionsPanel = document.getElementById("permissionsPanel");
        if (canManagePermissions()) permissionsPanel.classList.remove("hidden");
        else permissionsPanel.classList.add("hidden");
        const schoolSetupPanel = document.getElementById("schoolSetupPanel");
        if (canManageSettings()) schoolSetupPanel.classList.remove("hidden");
        else schoolSetupPanel.classList.add("hidden");
        const settingsPanel = document.getElementById("settingsPanel");
        if (canManageSettings()) settingsPanel.classList.remove("hidden");
        else settingsPanel.classList.add("hidden");
        updateNavigationAccess();
        updateTrackingDataSubmenuVisibility();
        updateWriteAccessControls();
        updateArchiveToggleButtons();
        renderServiceControlCard();
        if (!isPageAllowedForCurrentRole(state.activePage)) {
          setActivePage(roleStartPage());
        }
      }

      function updateTrackingDataSubmenuVisibility() {
        const isAdminRole = currentRoleName() === "admin";
        document
          .querySelectorAll('[data-admin-submenu-group="tracking-data"]')
          .forEach((submenuEl) => {
            let hasVisibleLink = false;
            submenuEl
              .querySelectorAll('[data-admin-submenu="tracking-data"]')
              .forEach((linkEl) => {
                const slug = normalizeText(linkEl.getAttribute("data-page-link"));
                const allowed =
                  Boolean(slug) && isAdminRole && isPageAllowedForCurrentRole(slug);
                linkEl.classList.toggle("hidden", !allowed);
                if (allowed) hasVisibleLink = true;
              });
            submenuEl.classList.toggle("hidden", !hasVisibleLink);
          });
      }

      function clearUserForm() {
        state.currentAdminUser = null;
        document.getElementById("u_id").value = "";
        document.getElementById("u_username").value = "";
        document.getElementById("u_role").value = "teacher";
        document.getElementById("u_password").value = "";
      }

      function fillUserForm(user) {
        state.currentAdminUser = user || null;
        document.getElementById("u_id").value = user?.id || "";
        document.getElementById("u_username").value = user?.username || "";
        document.getElementById("u_role").value = user?.role || "teacher";
        document.getElementById("u_password").value = "";
      }

      function formatDate(value) {
        const text = value instanceof Date ? "" : normalizeText(value);
        const parsed = value instanceof Date ?
          new Date(value.getTime())
          : /^\d{4}-\d{2}-\d{2}$/.test(text) ?
            new Date(`${text}T00:00:00+07:00`)
          : new Date(text);
        if (Number.isNaN(parsed.valueOf())) return text;
        const parts = new Intl.DateTimeFormat("vi-VN", {
          day: "2-digit",
          month: "2-digit",
          year: "2-digit",
          timeZone: FIXED_TIME_ZONE,
        }).formatToParts(parsed);
        const pick = (type) => parts.find((part) => part.type === type)?.value || "";
        const day = pick("day");
        const month = pick("month");
        const year = pick("year");
        if (!day || !month || !year) return text;
        return `${day}/${month}/${year}`;
      }

      function formatDateTime(value) {
        const text = value instanceof Date ? "" : normalizeText(value);
        if (!text) return "";
        const parsed = value instanceof Date ? new Date(value.getTime()) : new Date(text);
        if (Number.isNaN(parsed.valueOf())) return text;
        const parts = new Intl.DateTimeFormat("vi-VN", {
          day: "2-digit",
          month: "2-digit",
          year: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: false,
          timeZone: FIXED_TIME_ZONE,
        }).formatToParts(parsed);
        const pick = (type) => parts.find((part) => part.type === type)?.value || "";
        const day = pick("day");
        const month = pick("month");
        const year = pick("year");
        const hour = pick("hour");
        const minute = pick("minute");
        const second = pick("second");
        if (!day || !month || !year || !hour || !minute || !second) return text;
        return `${day}/${month}/${year} ${hour}:${minute}:${second} +07`;
      }

      function formatPortalWeekRange(startValue = "", endValue = "") {
        const startRaw = normalizeText(startValue);
        const endRaw = normalizeText(endValue);
        const parse = (value) => {
          if (!value) return null;
          const parsed = /^\d{4}-\d{2}-\d{2}$/.test(value) ?
            new Date(`${value}T00:00:00+07:00`) :
            new Date(value);
          return Number.isNaN(parsed.valueOf()) ? null : parsed;
        };
        const startDate = parse(startRaw);
        const endDate = parse(endRaw);
        if (!startDate || !endDate) {
          return `${normalizeText(startRaw)} to ${normalizeText(endRaw)}`;
        }
        return `${formatDate(startDate)} to ${formatDate(endDate)}`;
      }

      function selectedStudentId() {
        return state.currentStudent && state.currentStudent.id ?
            state.currentStudent.id
          : "";
      }

      function updateOverviewStudentSummary() {
        const summaryEl = document.getElementById("overviewStudent");
        if (!summaryEl) return;
        if (!state.currentStudent) {
          summaryEl.textContent = "No student selected.";
          return;
        }
        const profile = state.currentStudent.profile || {};
        const pieces = [
          normalizeText(state.currentStudent.eaglesId),
          studentDisplayName(state.currentStudent, { preferEnglish: true }),
          studentDisplayNumber(state.currentStudent) ?
            `<${studentDisplayNumber(state.currentStudent)}>`
          : "",
          shortLevelLabel(profile.currentGrade) || "(no level)",
          normalizeText(profile.schoolName) || "(no school)",
        ].filter(Boolean);
        summaryEl.textContent = `Selected: ${pieces.join(" | ")}`;
      }

      function toBoolOrNull(value) {
        if (value === "true") return true;
        if (value === "false") return false;
        return null;
      }

      async function api(path, options = {}) {
        assertApiOriginConfiguredForStaticPreview();
        const method = options.method || "GET";
        const headers = {};
        if (options.body !== undefined) {
          headers["Content-Type"] = "application/json";
        }

        const requestInit = {
          method,
          headers,
          body: options.body ? JSON.stringify(options.body) : undefined,
          credentials: "include",
        };

        let response = await fetch(resolveApiUrl(path), requestInit);

        if (
          response.status === 404 &&
          isAuthApiPath(path) &&
          !HAS_EXPLICIT_API_PREFIX_OVERRIDE
        ) {
          const originalPrefix = ACTIVE_ADMIN_API_PREFIX;
          const alternatePrefix = getAlternateApiPrefix(originalPrefix);
          if (alternatePrefix) {
            ACTIVE_ADMIN_API_PREFIX = alternatePrefix;
            const retryResponse = await fetch(resolveApiUrl(path), requestInit);
            if (retryResponse.status === 404) {
              ACTIVE_ADMIN_API_PREFIX = originalPrefix;
            } else {
              ACTIVE_ADMIN_API_PREFIX = persistApiPrefix(alternatePrefix);
            }
            response = retryResponse;
          }
        }

        if (response.status === 204) return null;

        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          const error = new Error(data.error || `HTTP ${response.status}`);
          error.status = response.status;
          throw error;
        }

        return data;
      }

      function showApp() {
        // The session is valid now, so release the boot gate immediately and
        // let the app shell paint instead of leaving a blank reload frame.
        document.documentElement.dataset.adminAuthState = "authenticated";
        document.getElementById("authShell")?.classList.add("hidden");
        document.getElementById("authBootPanel")?.classList.add("hidden");
        document.getElementById("authPanel")?.classList.add("hidden");
        document.getElementById("app")?.classList.remove("hidden");
        setAuthBootstrapping(false);
        if (authStatusEl) authStatusEl.textContent = "";
        startHubPolling();
        setActivePage(state.activePage || INITIAL_PAGE_SLUG, {
          syncUrl: shouldSyncPagePathInHistory(),
          historyMode: "replace",
        });
      }

      function showLogin() {
        document.documentElement.dataset.adminAuthState = "unauthenticated";
        document.getElementById("authShell")?.classList.remove("hidden");
        setAuthBootstrapping(false);
        // Reveal the login panel only after the auth probe finishes unauthenticated.
        document.getElementById("authBootPanel")?.classList.add("hidden");
        document.getElementById("authPanel")?.classList.remove("hidden");
        document.getElementById("app")?.classList.add("hidden");
        stopHubPolling();
        setLoginPending(false);
        renderSchoolSetupAccessWarning();
      }

      async function login() {
        assertApiOriginConfiguredForStaticPreview();
        const username = normalizeText(document.getElementById("loginUser").value);
        const password = normalizeText(document.getElementById("loginPass").value);
        if (!username || !password) {
          throw new Error("Username and password are required.");
        }
        setLoginPending(true);
        setStatus("Authenticating...");
        try {
          const result = await api("/api/admin/auth/login", {
            method: "POST",
            body: { username, password },
          });
          state.authUser = result.user || null;
          state.authRolePolicy = normalizeRolePolicy(
            currentRoleName(),
            result?.rolePolicy,
            getCurrentRolePolicy(),
          );
          showApp();
          setStatus("Loading dashboard...");
          await bootAfterLogin();
          setStatus(
            `Authenticated as ${state.authUser?.username || "admin"}. Student admin loaded.`,
          );
        } finally {
          setLoginPending(false);
        }
      }

      async function logout(remote = true) {
        if (remote) {
          try {
            await api("/api/admin/auth/logout", { method: "POST" });
          } catch (error) {
            void error;
          }
        }
        state.authUser = null;
        state.authRolePolicy = null;
        state.rolePermissions = normalizeRolePermissionsMap(
          defaultRolePermissionsConfig(),
        );
        state.adminUsers = [];
        state.assignmentTemplates = [];
        state.assignmentDraft = {
          id: "",
          items: [],
        };
        state.parentReportQueue = {
          items: [],
          total: 0,
          hasMore: false,
          showAll: false,
          modalIndex: -1,
          savedReportCountHint: 0,
          sourceRows: [],
          stagedRows: [],
          pendingStageQueueById: {},
        };
        state.performanceEngagement = {
          loaded: false,
          loading: false,
          generatedAt: "",
          days: [],
          rows: [],
          selectedDayKey: "",
          selectedReportId: "",
          search: "",
          sortField: "classDate",
          sortDir: "desc",
        };
        state.incomingExerciseQueue = {
          items: [],
          total: 0,
          hasMore: false,
          showAll: false,
          statuses: [],
        };
        state.queueHub = {
          loaded: false,
          overviewNewsQueueShowAll: false,
          generatedAt: "",
          panelOrder: normalizeQueueHubPanelOrder(
            DEFAULT_UI_SETTINGS.queueHub.panelOrder,
          ),
          panelsById: {},
          draggingPanelId: "",
          hasUnsavedOrder: false,
        };
        state.activePage = INITIAL_PAGE_SLUG;
        clearUserForm();
        renderUserRows();
        renderPermissionsEditor();
        showUserPanel();
        state.currentStudent = null;
        state.students = [];
        state.dashboardSummary = null;
        state.dashboardLevelCompletionRows = [];
        state.topSearchOptionMap = {};
        state.topStudentScope = { query: "", level: "", school: "" };
        closeParentQueueModal();
        showLogin();
        setStatus("Logged out.");
      }

      function renderUserRows() {
        const tbody = document.getElementById("userRows");
        tbody.innerHTML = "";

        state.adminUsers.forEach((user) => {
          const tr = document.createElement("tr");
          if (state.currentAdminUser && state.currentAdminUser.id === user.id)
            tr.classList.add("active");
          tr.innerHTML = `
          <td>${user.username || ""}</td>
          <td>${user.role || ""}</td>
          <td>${formatDateTime(user.updatedAt)}</td>
          <td>
            <button type="button" class="portal-button portal-button-affirm" data-user-edit="${user.id}">Edit</button>
            <button type="button" class="portal-button portal-button-danger" data-user-del="${user.id}">Delete</button>
          </td>
        `;
          tr.querySelector(`[data-user-edit="${user.id}"]`).addEventListener(
            "click",
            () => fillUserForm(user),
          );
          tr.querySelector(`[data-user-del="${user.id}"]`).addEventListener(
            "click",
            () => {
              deleteAdminUser(user.id).catch(handleError);
            },
          );
          tbody.appendChild(tr);
        });

        document.getElementById("userCount").textContent =
          `${state.adminUsers.length} users`;
      }

      async function loadUsers() {
        if (!canManageUsers()) return;
        const data = await api("/api/admin/users");
        state.adminUsers = data.items || [];
        renderUserRows();
        renderParentTrackingTeacherOptions();
      }

      function userPayload() {
        return {
          username: normalizeText(document.getElementById("u_username").value),
          role: normalizeText(document.getElementById("u_role").value) || "teacher",
          password: normalizeText(document.getElementById("u_password").value),
        };
      }

      async function saveAdminUser() {
        if (!canManageUsers()) throw new Error("Only admin role can manage users");
        const id = normalizeText(document.getElementById("u_id").value);
        const payload = userPayload();

        if (!payload.username) throw new Error("username is required");
        if (!id && !payload.password)
          throw new Error("password is required for new user");
        if (!payload.password) delete payload.password;

        let result = null;
        if (id) {
          result = await api(`/api/admin/users/${encodeURIComponent(id)}`, {
            method: "PUT",
            body: payload,
          });
        } else {
          result = await api("/api/admin/users", {
            method: "POST",
            body: payload,
          });
        }

        await loadUsers();
        if (result?.user?.id) {
          const latest =
            state.adminUsers.find((entry) => entry.id === result.user.id) ||
            result.user;
          fillUserForm(latest);
        } else {
          clearUserForm();
        }
        setStatus(
          `User ${id ? "updated" : "created"}: ${result?.user?.username || payload.username}`,
        );
      }

      async function deleteAdminUser(userId = "") {
        if (!canManageUsers()) throw new Error("Only admin role can manage users");
        const id = normalizeText(userId || document.getElementById("u_id").value);
        if (!id) throw new Error("Select a user first");

        const target = state.adminUsers.find((entry) => entry.id === id);
        const label = target?.username || "this user";
        if (!confirm(`Delete ${label}?`)) return;

        await api(`/api/admin/users/${encodeURIComponent(id)}`, { method: "DELETE" });
        state.currentAdminUser = null;
        clearUserForm();
        await loadUsers();
        setStatus(`User deleted: ${label}`);
      }

      function rolePolicyFor(roleName) {
        const role = normalizeLower(roleName);
        const policies = normalizeRolePermissionsMap(state.rolePermissions);
        return policies[role] || policies.teacher || policies.admin;
      }

      function roleLabel(roleName) {
        const role = normalizeLower(roleName);
        return role ? role.charAt(0).toUpperCase() + role.slice(1) : "";
      }

      function buildPermissionRoleCard(roleName, policy) {
        const roleKey = normalizeText(roleName).toLowerCase().replace(/[^a-z0-9_-]+/g, "-");
        const startSelectId = `perm-start-${roleKey}`;
        const canReadId = `perm-can-read-${roleKey}`;
        const canWriteId = `perm-can-write-${roleKey}`;
        const canUsersId = `perm-can-users-${roleKey}`;
        const canPermsId = `perm-can-perms-${roleKey}`;
        const card = document.createElement("div");
        card.className = "permission-role-card card";
        card.dataset.surfaceRole = "card";
        card.dataset.permissionRole = roleName;

        const title = document.createElement("h3");
        title.className = "permission-role-title";
        title.textContent = `${roleLabel(roleName)} role`;
        card.appendChild(title);

        const options = document.createElement("div");
        options.className = "row";
        options.innerHTML = `
        <div class="col-3">
          <label for="${startSelectId}">Start page</label>
          <select id="${startSelectId}" data-perm-start="${roleName}"></select>
        </div>
        <div class="col-3 permission-page-item">
          <input id="${canReadId}" type="checkbox" data-perm-can-read="${roleName}" ${policy.canRead ? "checked" : ""}>
          <label for="${canReadId}">Can read data</label>
        </div>
        <div class="col-3 permission-page-item">
          <input id="${canWriteId}" type="checkbox" data-perm-can-write="${roleName}" ${policy.canWrite ? "checked" : ""}>
          <label for="${canWriteId}">Can write data</label>
        </div>
        <div class="col-3 permission-page-item">
          <input id="${canUsersId}" type="checkbox" data-perm-can-users="${roleName}" ${policy.canManageUsers ? "checked" : ""}>
          <label for="${canUsersId}">Manage users</label>
        </div>
        <div class="col-3 permission-page-item">
          <input id="${canPermsId}" type="checkbox" data-perm-can-perms="${roleName}" ${policy.canManagePermissions ? "checked" : ""}>
          <label for="${canPermsId}">Manage permissions</label>
        </div>
      `;
        card.appendChild(options);

        const startSelect = options.querySelector(`[data-perm-start="${roleName}"]`);
        VALID_PAGE_SECTIONS.forEach((slug) => {
          const option = document.createElement("option");
          option.value = slug;
          option.textContent = slug;
          if (policy.startPage === slug) option.selected = true;
          startSelect.appendChild(option);
        });

        const pageList = document.createElement("div");
        pageList.className = "permission-page-grid";
        VALID_PAGE_SECTIONS.forEach((slug) => {
          const item = document.createElement("label");
          item.className = "permission-page-item";
          item.innerHTML = `
          <input type="checkbox" id="perm_${sanitizeDomIdPart(roleName)}_${sanitizeDomIdPart(slug)}" name="perm_${sanitizeDomIdPart(roleName)}_${sanitizeDomIdPart(slug)}" data-perm-page="${roleName}" value="${slug}" ${policy.allowedPages.includes(slug) ? "checked" : ""}>
          <span>${slug}</span>
        `;
          pageList.appendChild(item);
        });
        card.appendChild(pageList);

        if (!canManagePermissions()) {
          card.querySelectorAll("input,select").forEach((el) => {
            el.disabled = true;
          });
        }

        return card;
      }

      function renderPermissionsEditor() {
        const container = document.getElementById("permissionsRows");
        if (!container) return;
        container.innerHTML = "";
        const canEdit = canManagePermissions();
        const saveBtn = document.getElementById("permissionsSaveBtn");
        if (saveBtn) saveBtn.disabled = !canEdit;

        const roles = Array.from(
          new Set([
            ...MANAGED_PERMISSION_ROLES,
            "admin",
            "teacher",
            "student",
            "parent",
          ]),
        );
        roles.forEach((roleName) => {
          const policy = rolePolicyFor(roleName);
          container.appendChild(buildPermissionRoleCard(roleName, policy));
        });
      }

      function collectPermissionsPayloadFromEditor() {
        const payload = {};
        const roles = Array.from(
          new Set([
            ...MANAGED_PERMISSION_ROLES,
            "admin",
            "teacher",
            "student",
            "parent",
          ]),
        );

        roles.forEach((roleName) => {
          const allowedPages = Array.from(
            document.querySelectorAll(`[data-perm-page="${roleName}"]:checked`),
          ).map((el) => normalizeLower(el.value));
          payload[roleName] = {
            startPage: normalizeLower(
              document.querySelector(`[data-perm-start="${roleName}"]`)?.value,
            ),
            canRead: Boolean(
              document.querySelector(`[data-perm-can-read="${roleName}"]`)?.checked,
            ),
            canWrite: Boolean(
              document.querySelector(`[data-perm-can-write="${roleName}"]`)?.checked,
            ),
            canManageUsers: Boolean(
              document.querySelector(`[data-perm-can-users="${roleName}"]`)?.checked,
            ),
            canManagePermissions: Boolean(
              document.querySelector(`[data-perm-can-perms="${roleName}"]`)?.checked,
            ),
            allowedPages,
          };
        });

        return payload;
      }

      async function loadRolePermissions() {
        const result = await api(ADMIN_PERMISSIONS_PATH);
        state.rolePermissions = normalizeRolePermissionsMap(result?.roles);
        state.authRolePolicy = normalizeRolePolicy(
          currentRoleName(),
          result?.rolePolicy,
          getCurrentRolePolicy(),
        );
        renderPermissionsEditor();
        updateNavigationAccess();
      }

      async function saveRolePermissions() {
        if (!canManagePermissions())
          throw new Error("Only roles with permission access can update role policies");
        const payload = collectPermissionsPayloadFromEditor();
        const result = await api(ADMIN_PERMISSIONS_PATH, {
          method: "PUT",
          body: payload,
        });
        state.rolePermissions = normalizeRolePermissionsMap(result?.roles);
        state.authRolePolicy = getCurrentRolePolicy();
        renderPermissionsEditor();
        updateNavigationAccess();
        setActivePage(roleStartPage());
        setStatus("Role permissions updated.");
      }

      function resetRolePermissionsEditor() {
        renderPermissionsEditor();
        setStatus("Role permissions form reset.");
      }

      function formatPercent(value) {
        const numeric = Number.parseFloat(String(value));
        if (!Number.isFinite(numeric)) return "0%";
        return `${numeric.toFixed(1)}%`;
      }

      function setAssignmentStatus(message, isError = false) {
        const el = document.getElementById("assignmentStatus");
        if (!el) return;
        el.style.color = isError ? "#b3262d" : "var(--portal-status-muted-text)";
        el.textContent = normalizeText(message) || "No assignments loaded.";
      }

      function normalizeAssignmentTargetLevel(value) {
        return resolveSystemLevelName(normalizeText(value));
      }

      function assignmentStudentSource() {
        return studentSourceForPage("assignments");
      }

      function assignmentRecipientsForStudent(student) {
        if (!student) return [];
        const profile = student.profile || {};
        const rawProfile = profile.rawFormPayload && typeof profile.rawFormPayload === "object" ? profile.rawFormPayload : {};
        const proctorValue = (field) => normalizeText(profile[field] || rawProfile[field]);
        const isTrue = (value) => ["1", "true", "yes", "on", "y", "có", "co", "si", "sí"].includes(normalizeLower(value));
        const proctorCandidates = [
          [profile.motherEmail, proctorValue("maIsHomeworkProctor")],
          [profile.fatherEmail, proctorValue("baIsHomeworkProctor")],
        ];
        const hasExplicitProctorSelection = proctorCandidates.some(([, flag]) => Boolean(flag));
        const parentEmails = proctorCandidates
          .filter(([, flag]) => !hasExplicitProctorSelection || isTrue(flag))
          .map(([address]) => normalizeLower(address));
        return Array.from(
          new Set(
            [
              student.email,
              profile.studentEmail,
              ...parentEmails,
              profile.signatureEmail,
            ]
              .map((entry) => normalizeLower(entry))
              .filter((entry) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(entry)),
          ),
        );
      }

      function safeHref(value) {
        const href = normalizeText(value);
        if (!href) return "";
        if (/^javascript:/i.test(normalizeLower(href))) return "";
        return href;
      }

      function normalizeExerciseCatalogEntry(entry) {
        if (typeof entry === "string") {
          return {
            title: normalizeText(entry),
            url: "",
          };
        }
        if (!entry || typeof entry !== "object") {
          return {
            title: "",
            url: "",
          };
        }
        return {
          title: normalizeText(
            entry.title || entry.exerciseTitle || entry.name || entry.label,
          ),
          url: normalizeText(
            entry.url || entry.exerciseUrl || entry.link || entry.href,
          ),
        };
      }

      function renderAssignmentExerciseOptions() {
        const select = document.getElementById("assignmentExerciseSelect");
        if (!select) return;
        const selected = normalizeText(select.value);
        const source =
          Array.isArray(state.exerciseCatalog) && state.exerciseCatalog.length ?
            state.exerciseCatalog
          : state.exerciseTitles.map((title) => ({ title, url: "" }));
        const deduped = Array.from(
          new Map(
            source
              .map((entry) => normalizeExerciseCatalogEntry(entry))
              .filter((entry) => entry.title)
              .map((entry) => [normalizeLower(entry.title), entry]),
          ).values(),
        );

        select.innerHTML = '<option value="">Select exercise</option>';
        deduped.forEach((entry) => {
          const option = document.createElement("option");
          option.value = entry.title;
          option.textContent = entry.title;
          option.dataset.url = entry.url;
          if (normalizeLower(entry.title) === normalizeLower(selected))
            option.selected = true;
          select.appendChild(option);
        });
      }

      function renderAssignmentLevelTiles() {
        const tilesEl = document.getElementById("assignmentLevelTiles");
        const hintEl = document.getElementById("assignmentLevelPanelHint");
        if (!tilesEl) return;

        const levels = collectAttendanceLevelNames();
        const selectedLevel = normalizeAssignmentTargetLevel(
          document.getElementById("assignLevel")?.value,
        );
        if (!levels.length) {
          tilesEl.innerHTML = "";
          if (hintEl) hintEl.textContent = "No class levels found.";
          return;
        }

        tilesEl.innerHTML = "";
        levels.forEach((levelName) => {
          const canonicalLevel = resolveSystemLevelName(levelName);
          const config = attendanceLevelTileConfig(canonicalLevel);
          const theme = getLevelTheme(canonicalLevel);
          const tile = document.createElement("button");
          tile.type = "button";
          tile.className = "attendance-level-tile";
          if (levelNamesMatch(canonicalLevel, selectedLevel))
            tile.classList.add("active");
          tile.style.backgroundColor = config.bgColor;
          tile.style.color = theme.textColor;
          tile.style.borderColor = theme.borderColor;
          tile.style.setProperty("--attendance-level-title-color", theme.textColor);
          tile.style.setProperty("--attendance-level-title-bg", tileTitleBackground(theme));
          if (config.imageDataUrl) {
            const safeUrl = config.imageDataUrl.replace(/"/g, "%22");
            tile.style.backgroundImage = `url("${safeUrl}")`;
          } else {
            tile.style.backgroundImage = "none";
          }
          tile.setAttribute("data-level", canonicalLevel);
          tile.setAttribute("aria-label", fullLevelLabel(canonicalLevel));
          const safeTitle = normalizeText(config.title);
          tile.innerHTML =
            safeTitle ?
              `<span class="attendance-level-tile-title">${escapeHtml(safeTitle)}</span>`
            : "";
          tile.addEventListener("click", () => {
            applyAssignmentLevelSelection(canonicalLevel, { applyDefaults: true });
          });
          tilesEl.appendChild(tile);
        });

        if (hintEl)
          hintEl.textContent = `Loaded ${levels.length} levels. Select one to prefill assignment fields.`;
      }

      function applyAssignmentLevelSelection(
        levelName,
        { applyDefaults = false } = {},
      ) {
        const normalized = normalizeAssignmentTargetLevel(levelName);
        const levelEl = document.getElementById("assignLevel");
        if (levelEl) levelEl.value = normalized;

        if (applyDefaults) {
          const assignedEl = document.getElementById("assignAssignedAt");
          const dueEl = document.getElementById("assignDueAt");
          const assignedIso = localIsoDate();
          if (assignedEl) assignedEl.value = assignedIso;
          if (dueEl) dueEl.value = nextSundayIsoDate(assignedIso);
        }

        refreshAssignmentStudentOptions();
        renderAssignmentLevelTiles();
        if (normalized && applyDefaults) {
          setAssignmentStatus(`Assignment level set to ${fullLevelLabel(normalized)}.`);
        }
      }

      function populateAssignmentLevelOptions() {
        const select = document.getElementById("assignLevel");
        if (!select) return;
        const selected = resolveSystemLevelName(select.value);
        const values = collectAttendanceLevelNames([
          selected,
          ...assignmentStudentSource().map((student) =>
            normalizeLevelName(student?.profile?.currentGrade || ""),
          ),
        ]).filter(Boolean);

        select.innerHTML = '<option value="">Select level</option>';
        values.forEach((levelName) => {
          const option = document.createElement("option");
          option.value = levelName;
          option.textContent = fullLevelLabel(levelName);
          if (levelNamesMatch(levelName, selected)) option.selected = true;
          select.appendChild(option);
        });
        renderAssignmentLevelTiles();
      }

      function refreshAssignmentStudentOptions() {
        const select = document.getElementById("assignStudent");
        if (!select) return;
        const selectedStudentId = normalizeText(select.value);
        const selectedLevel = normalizeAssignmentTargetLevel(
          document.getElementById("assignLevel")?.value,
        );
        const source = assignmentStudentSource();
        const filtered = source
          .filter((student) => {
            if (!selectedLevel) return true;
            const studentLevel = resolveSystemLevelName(
              student?.profile?.currentGrade || "",
            );
            return levelNamesMatch(studentLevel, selectedLevel);
          })
          .sort((left, right) =>
            studentDisplayName(left, { preferEnglish: true }).localeCompare(
              studentDisplayName(right, { preferEnglish: true }),
            ),
          );

        select.innerHTML = '<option value="">All students in selected level</option>';
        filtered.forEach((student) => {
          const option = document.createElement("option");
          option.value = normalizeText(student.id);
          option.textContent = studentIdentityLabel(student, {
            preferEnglish: true,
            wrapName: true,
            includeStudentNumber: true,
          });
          if (option.value === selectedStudentId) option.selected = true;
          select.appendChild(option);
        });
        if (
          selectedStudentId &&
          !filtered.some((student) => normalizeText(student?.id) === selectedStudentId)
        ) {
          const option = document.createElement("option");
          option.value = selectedStudentId;
          option.textContent = selectedStudentId;
          option.selected = true;
          select.appendChild(option);
        }
      }

      function renderExerciseTitleList() {
        const dataList = document.getElementById("exerciseTitleList");
        if (!dataList) return;
        dataList.innerHTML = "";
        state.exerciseTitles.forEach((title) => {
          const option = document.createElement("option");
          option.value = title;
          dataList.appendChild(option);
        });
      }

      async function loadExerciseTitles(query = "") {
        try {
          const response = await api(
            `${ADMIN_EXERCISE_TITLES_PATH}?q=${encodeURIComponent(normalizeText(query))}&take=250`,
          );
          const parsedItems =
            Array.isArray(response?.items) ?
              response.items.map((entry) => normalizeExerciseCatalogEntry(entry))
            : [];
          const catalog = Array.from(
            new Map(
              parsedItems
                .filter((entry) => entry.title)
                .map((entry) => [normalizeLower(entry.title), entry]),
            ).values(),
          );
          state.exerciseCatalog = catalog;
          state.exerciseTitles = catalog.map((entry) => entry.title);
          renderExerciseTitleList();
          renderAssignmentExerciseOptions();
          setAssignmentStatus(`Loaded ${state.exerciseTitles.length} exercise titles.`);
        } catch (error) {
          if (error && error.status === 404) {
            state.exerciseTitles = [];
            state.exerciseCatalog = [];
            renderExerciseTitleList();
            renderAssignmentExerciseOptions();
            setAssignmentStatus(
              "Exercise-title endpoint is not available on current runtime.",
              true,
            );
            return;
          }
          throw error;
        }
      }

      function setAssignmentDraft(items = [], id = "") {
        state.assignmentDraft = {
          id: normalizeText(id),
          items: normalizeAssignmentItems(items),
          studentRefId: normalizeText(state.assignmentDraft?.studentRefId),
        };
      }

      function renderAssignmentDraftItems() {
        const rowsEl = document.getElementById("assignmentItemRows");
        if (!rowsEl) return;
        const canWrite = canWriteData();
        const items = normalizeAssignmentItems(state.assignmentDraft?.items || []);
        state.assignmentDraft.items = items;
        rowsEl.innerHTML = "";
        if (!items.length) {
          rowsEl.innerHTML = '<tr><td colspan="4">No assignment items yet.</td></tr>';
          return;
        }

        items.forEach((item) => {
          const tr = document.createElement("tr");
          tr.dataset.assignmentItemId = item.id;
          const doneTd = document.createElement("td");
          const doneInput = document.createElement("input");
          doneInput.type = "checkbox";
          doneInput.checked = item.done === true;
          doneInput.disabled = !canWrite;
          doneInput.dataset.assignmentItemId = item.id;
          doneInput.setAttribute("aria-label", `Mark ${item.title} as complete`);
          const syncDoneState = () => {
            state.assignmentDraft.items = items.map((entry) => {
              if (entry.id !== item.id) return entry;
              return { ...entry, done: doneInput.checked };
            });
          };
          doneInput.addEventListener("click", syncDoneState);
          doneInput.addEventListener("change", syncDoneState);
          doneTd.appendChild(doneInput);

          const titleTd = document.createElement("td");
          const titleSpan = document.createElement("span");
          titleSpan.className = "assignment-item-title";
          titleSpan.textContent = item.title;
          titleTd.appendChild(titleSpan);

          const urlTd = document.createElement("td");
          const href = safeHref(item.url);
          if (href) {
            const link = document.createElement("a");
            link.className = "assignment-item-link";
            link.href = href;
            link.target = "_blank";
            link.rel = "noopener noreferrer";
            link.textContent = item.url;
            urlTd.appendChild(link);
          } else {
            urlTd.textContent = "-";
          }

          const actionTd = document.createElement("td");
          const removeBtn = document.createElement("button");
          removeBtn.type = "button";
          removeBtn.className = "portal-button portal-button-danger";
          removeBtn.textContent = "Remove";
          removeBtn.disabled = !canWrite;
          removeBtn.addEventListener("click", () => {
            state.assignmentDraft.items = items.filter((entry) => entry.id !== item.id);
            renderAssignmentDraftItems();
            setAssignmentStatus(`Removed assignment item: ${item.title}`);
          });
          actionTd.appendChild(removeBtn);

          tr.appendChild(doneTd);
          tr.appendChild(titleTd);
          tr.appendChild(urlTd);
          tr.appendChild(actionTd);
          rowsEl.appendChild(tr);
        });
      }

      function collectAssignmentDraftItems() {
        const normalized = normalizeAssignmentItems(state.assignmentDraft?.items || []);
        const rowsEl = document.getElementById("assignmentItemRows");
        if (!rowsEl) return normalized;
        const checkboxByItemId = new Map(
          Array.from(rowsEl.querySelectorAll("input[type='checkbox'][data-assignment-item-id]"))
            .map((checkbox) => [normalizeText(checkbox.dataset.assignmentItemId), checkbox.checked]),
        );
        return normalized.map((item) => ({
          ...item,
          done:
            checkboxByItemId.has(item.id) ?
              Boolean(checkboxByItemId.get(item.id))
            : item.done === true,
        }));
      }

      function collectAssignmentForm() {
        const level = normalizeAssignmentTargetLevel(
          document.getElementById("assignLevel").value,
        );
        const items = collectAssignmentDraftItems();
        const fallbackExerciseTitle = normalizeText(
          document.getElementById("assignmentExerciseSelect")?.value,
        );
        const selectedStudentId = normalizeText(
          document.getElementById("assignStudent").value ||
            state.assignmentDraft?.studentRefId,
        );
        const selectedStudent = assignmentStudentSource().find(
          (student) =>
            normalizeText(student?.id) === selectedStudentId ||
            normalizeText(student?.eaglesId) === selectedStudentId,
        );
        return {
          id: normalizeText(state.assignmentDraft?.id),
          assignmentTitle: normalizeText(document.getElementById("assignTitle").value),
          exerciseTitle: normalizeText(items[0]?.title || fallbackExerciseTitle),
          assignedAt: normalizeText(document.getElementById("assignAssignedAt").value),
          dueAt: normalizeText(document.getElementById("assignDueAt").value),
          level,
          eaglesId: normalizeText(selectedStudent?.id || selectedStudentId),
          studentRefId: normalizeText(selectedStudent?.id || selectedStudentId),
          studentEaglesId: normalizeText(selectedStudent?.eaglesId || ""),
          message: normalizeText(document.getElementById("assignMessage").value),
          items,
        };
      }

      function addAssignmentDraftItem() {
        const selectEl = document.getElementById("assignmentExerciseSelect");
        const urlEl = document.getElementById("assignmentExerciseUrl");
        const title = normalizeText(selectEl?.value);
        const url = normalizeText(urlEl?.value);
        if (!title)
          throw new Error("Choose an exercise before adding an assignment item.");

        const existing = normalizeAssignmentItems(state.assignmentDraft?.items || []);
        const duplicate = existing.some(
          (entry) =>
            normalizeLower(entry.title) === normalizeLower(title) &&
            normalizeLower(entry.url) === normalizeLower(url),
        );
        if (duplicate)
          throw new Error("This exercise item is already in the assignment.");

        existing.push({
          id: createLocalId("assignment-item"),
          title,
          url,
          done: false,
        });
        setAssignmentDraft(existing, state.assignmentDraft?.id);
        renderAssignmentDraftItems();
        if (selectEl) selectEl.value = "";
        if (urlEl) urlEl.value = "";
        setAssignmentStatus(`Added assignment item: ${title}`);
      }

      function fillAssignmentForm(template = {}) {
        const normalized = normalizeAssignmentTemplate(template);
        document.getElementById("assignTitle").value = normalizeText(
          normalized.assignmentTitle,
        );
        document.getElementById("assignAssignedAt").value = normalizeText(
          normalized.assignedAt,
        );
        document.getElementById("assignDueAt").value = normalizeText(normalized.dueAt);
        document.getElementById("assignLevel").value = normalizeAssignmentTargetLevel(
          normalized.level,
        );
        document.getElementById("assignMessage").value = normalizeText(
          normalized.message,
        );
        setAssignmentDraft(normalized.items, normalized.id);
        refreshAssignmentStudentOptions();
        const selectedStudent = assignmentStudentSource().find((student) => {
          const studentId = normalizeText(student?.id);
          const studentPublicId = normalizeText(student?.eaglesId);
          return (
            studentId === normalizeText(normalized.eaglesId) ||
            studentPublicId === normalizeText(normalized.eaglesId)
          );
        });
        state.assignmentDraft.studentRefId = normalizeText(
          selectedStudent ? tableFilterStudentOptionValue(selectedStudent) : "",
        );
        document.getElementById("assignStudent").value = normalizeText(
          selectedStudent ? tableFilterStudentOptionValue(selectedStudent) : normalized.eaglesId,
        );
        renderAssignmentLevelTiles();
        renderAssignmentDraftItems();
        setAssignmentStatus("Assignment loaded into form.");
      }

      function resetAssignmentForm() {
        document.getElementById("assignTitle").value = "";
        document.getElementById("assignAssignedAt").value = "";
        document.getElementById("assignDueAt").value = "";
        document.getElementById("assignLevel").value = "";
        document.getElementById("assignStudent").value = "";
        document.getElementById("assignMessage").value = "";
        if (state.assignmentDraft) state.assignmentDraft.studentRefId = "";
        const exerciseSelect = document.getElementById("assignmentExerciseSelect");
        const exerciseUrl = document.getElementById("assignmentExerciseUrl");
        if (exerciseSelect) exerciseSelect.value = "";
        if (exerciseUrl) exerciseUrl.value = "";
        setAssignmentDraft([], "");
        refreshAssignmentStudentOptions();
        renderAssignmentLevelTiles();
        renderAssignmentDraftItems();
        setAssignmentStatus("Assignment form reset.");
      }

      function assignmentRecordItemsHtml(template = {}) {
        const items = normalizeAssignmentItems(template.items);
        if (!items.length) return "-";
        return `<div class="assignment-record-items">${items
          .map((entry) => {
            const prefix = entry.done ? "[x]" : "[ ]";
            const href = safeHref(entry.url);
            const titleHtml =
              href ?
                `<a class="assignment-item-link" href="${escapeHtml(href)}" target="_blank" rel="noopener noreferrer">${escapeHtml(entry.title)}</a>`
              : escapeHtml(entry.title);
            if (entry.done)
              return `<div class="assignment-record-item done">${prefix} ${titleHtml}</div>`;
            return `<div class="assignment-record-item">${prefix} ${titleHtml}</div>`;
          })
          .join("")}</div>`;
      }

      function assignmentCompletionPillHtml(template = {}) {
        const completion = assignmentCompletionFromItems(template.items);
        if (!completion.total)
          return '<span class="assignment-completion-pill">No items</span>';
        if (completion.completed) {
          const completedAt = normalizeText(template.completedAt);
          const suffix = completedAt ? ` (${escapeHtml(completedAt)})` : "";
          return `<span class="assignment-completion-pill complete">Completed${suffix}</span>`;
        }
        return `<span class="assignment-completion-pill">${completion.done}/${completion.total} done</span>`;
      }

      function renderAssignmentTemplates() {
        const tbody = document.getElementById("assignmentTemplateRows");
        if (!tbody) return;
        tbody.innerHTML = "";

        const assignmentStudents = tableFilterStudentSource("assignments");
        const studentByOptionValue = new Map(
          assignmentStudents
            .map((student) => [
              normalizeLower(tableFilterStudentOptionValue(student)),
              student,
            ])
            .filter(([key]) => Boolean(key)),
        );
        const studentByPublicId = new Map(
          assignmentStudents
            .map((student) => [normalizeLower(student?.eaglesId), student])
            .filter(([key]) => Boolean(key)),
        );
        const sortedTemplates = sortedAssignmentTemplates(state.assignmentTemplates);
        const filteredTemplates = filterRowsForTable(
          "assignments",
          sortedTemplates,
          assignmentRowSearchText,
        );
        state.visibleTableRows.assignments = filteredTemplates;
        updateTableFilterSummary("assignments");
        filteredTemplates.forEach((template) => {
          const archived = isTableRecordArchived("assignments", template.id);
          const templateStudentKey = normalizeLower(template?.eaglesId);
          const matchedStudent =
            studentByOptionValue.get(templateStudentKey) ||
            studentByPublicId.get(templateStudentKey);
          const studentNumberText =
            matchedStudent && studentDisplayNumber(matchedStudent) ?
              escapeHtml(String(studentDisplayNumber(matchedStudent)))
            : "";
          const studentLabel =
            matchedStudent ?
              studentIdentityLabel(matchedStudent, {
                preferEnglish: true,
                wrapName: true,
                includeStudentNumber: true,
              })
            : normalizeText(template?.eaglesId) || "All students in level";
          const tr = document.createElement("tr");
          tr.innerHTML = `
          <td class="table-col-student-number" data-assignments-col="studentNumber">${studentNumberText}</td>
          <td data-assignments-col="assignmentTitle">${escapeHtml(template.assignmentTitle || template.exerciseTitle || "")}</td>
          <td data-assignments-col="level">${levelBadgeHtml(template.level || "", { full: true })}</td>
          <td data-assignments-col="student">${escapeHtml(studentLabel)}</td>
          <td data-assignments-col="assignedAt">${escapeHtml(template.assignedAt || "-")}</td>
          <td data-assignments-col="dueAt">${escapeHtml(template.dueAt || "-")}</td>
          <td data-assignments-col="weekNumber">${rowWeekNumber("assignments", template) ? `Week ${rowWeekNumber("assignments", template)}` : "-"}</td>
          <td data-assignments-col="items">${assignmentRecordItemsHtml(template)}</td>
          <td data-assignments-col="completion">${assignmentCompletionPillHtml(template)}</td>
          <td class="table-row-options-cell">
            <details class="row-options-menu">
              <summary class="row-options-trigger portal-button portal-button-primary portal-button-compact tbm01">Actions</summary>
              <div class="row-options-dropdown">
                <button type="button" class="portal-button portal-button-affirm portal-button-compact" data-template-edit="${template.id}">Edit</button>
                <button type="button" class="portal-button portal-button-info portal-button-compact" data-template-archive="${template.id}">${archived ? "Restore" : "Archive"}</button>
                <button type="button" class="portal-button portal-button-danger portal-button-compact" data-template-del="${template.id}">Delete</button>
              </div>
            </details>
          </td>
        `;
          tr.querySelector(`[data-template-edit="${template.id}"]`)?.addEventListener(
            "click",
            () => {
              fillAssignmentForm(template);
              setActivePage("assignments");
            },
          );
          tr.querySelector(
            `[data-template-archive="${template.id}"]`,
          )?.addEventListener("click", () => {
            const nextArchived = !isTableRecordArchived("assignments", template.id);
            setTableRecordArchived("assignments", template.id, nextArchived);
            renderAssignmentTemplates();
            setAssignmentStatus(
              nextArchived ? "Assignment archived." : "Assignment restored.",
            );
            setStatus(
              nextArchived ?
                "Assignments data archived."
              : "Assignments data restored.",
            );
          });
          tr.querySelector(`[data-template-del="${template.id}"]`)?.addEventListener(
            "click",
            () => {
              deleteAssignmentTemplate(template.id).catch(handleError);
            },
          );
          tbody.appendChild(tr);
        });

        if (!filteredTemplates.length) {
          tbody.innerHTML =
            '<tr><td colspan="9">No assignment rows match current search/archive filters.</td></tr>';
        }
        applyTableColumnVisibility("assignments");

        if (!sortedTemplates.length) {
          setAssignmentStatus("No assignments loaded.");
        } else if (!filteredTemplates.length) {
          setAssignmentStatus("No assignment rows match current filters.");
        } else {
          setAssignmentStatus(
            `Assignments loaded: ${filteredTemplates.length}/${sortedTemplates.length}`,
          );
        }
      }

      async function saveAssignmentTemplate() {
        const form = collectAssignmentForm();
        if (!form.level) throw new Error("Select a class level before saving.");
        if (!form.eaglesId) throw new Error("Select a student before saving this assignment.");
        if (!form.items.length)
          throw new Error("Add at least one assignment item before saving.");
        if (form.items.some((item) => !normalizeText(item.title) || !normalizeText(item.url))) {
          throw new Error("Each assignment item needs an exercise URL before saving.");
        }

        const assignedAt = form.assignedAt || localIsoDate();
        const dueAt = form.dueAt || nextSundayIsoDate(assignedAt);
        const assignmentTitle =
          form.assignmentTitle || `${fullLevelLabel(form.level)} Assignment`;
        const completion = assignmentCompletionFromItems(form.items);
        const existing = state.assignmentTemplates.find(
          (entry) => entry.id === form.id,
        );
        const template = normalizeAssignmentTemplate({
          ...(existing || {}),
          id: form.id || existing?.id || createLocalId("assignment"),
          assignmentTitle,
          exerciseTitle: form.exerciseTitle,
          assignedAt,
          dueAt,
          level: form.level,
          eaglesId: form.eaglesId,
          message: form.message,
          items: form.items,
          completed: completion.completed,
          completedAt:
            completion.completed ?
              normalizeText(existing?.completedAt) || localIsoDate()
            : "",
        });
        const templateId = normalizeText(existing?.id || template.id);
        const requestPath = templateId ?
          `${ADMIN_ASSIGNMENT_TEMPLATES_PATH}/${encodeURIComponent(templateId)}`
        : ADMIN_ASSIGNMENT_TEMPLATES_PATH;
        const result = await api(requestPath, {
          method: templateId ? "PUT" : "POST",
          body: template,
        });
        const savedTemplate = normalizeAssignmentTemplate(result?.item || template);
        assignmentTemplatesLastWriteAt = Date.now();
        state.assignmentTemplates = normalizeAssignmentTemplateList([
          ...state.assignmentTemplates.filter((entry) => entry.id !== savedTemplate.id),
          savedTemplate,
        ]);
        state.tableFilters.assignments = {
          level: "",
          studentRefId: "",
          dateFrom: "",
          dateTo: "",
          weekNumber: "",
        };
        state.tableSearch.assignments = "";
        state.tableShowArchived.assignments = false;
        state.tableArchiveIndex.assignments = {};
        renderAssignmentTemplates();
        fillAssignmentForm(savedTemplate);
        renderAssignmentTemplates();
        if (state.dashboardSummary) renderDashboardSummary(state.dashboardSummary);
        setAssignmentStatus(`Assignment saved: ${savedTemplate.assignmentTitle}`);
      }

      async function deleteAssignmentTemplate(templateId = "") {
        const targetId = normalizeText(templateId || state.assignmentDraft?.id);
        if (!targetId) throw new Error("Select or load an assignment first.");
        await api(`${ADMIN_ASSIGNMENT_TEMPLATES_PATH}/${encodeURIComponent(targetId)}`, {
          method: "DELETE",
        });
        setTableRecordArchived("assignments", targetId, false);
        if (normalizeText(state.assignmentDraft?.id) === targetId) {
          resetAssignmentForm();
        } else {
          renderAssignmentTemplates();
        }
        await loadAssignmentTemplatesFromServer();
        if (state.dashboardSummary) renderDashboardSummary(state.dashboardSummary);
        setAssignmentStatus("Assignment deleted.");
      }

      function buildDashboardRiskLines(levelRows = []) {
        const rows = Array.isArray(levelRows) ? levelRows : [];
        const pendingLines = [];
        rows.forEach((row) => {
          const level = shortLevelLabel(row?.level || "");
          const assignmentName = normalizeText(row?.assignmentName);
          const dueAt = normalizeText(row?.dueAt);
          const students =
            Array.isArray(row?.uncompletedStudents) ? row.uncompletedStudents : [];
          students.forEach((student) => {
            const name = normalizeText(student?.fullName);
            const sid = normalizeText(student?.eaglesId);
            const studentToken = [name, sid].filter(Boolean).join(" | ");
            const assignmentToken = assignmentName || "Assignment";
            pendingLines.push(
              `${studentToken} [${level}] - pending:${assignmentToken}${dueAt ? ` | due:${dueAt}` : ""}`,
            );
          });
        });
        if (!pendingLines.length)
          return "No pending students for current not-yet-due assignments.";
        return pendingLines.join("\n");
      }

      function buildAttendanceRiskLines(items = []) {
        if (!Array.isArray(items) || !items.length)
          return "No attendance risk students flagged for this week.";
        return items
          .map((row) => {
            const level = shortLevelLabel(row.level || "");
            const name = normalizeText(row.fullName);
            const sid = normalizeText(row.eaglesId);
            const studentToken = [name, sid].filter(Boolean).join(" | ");
            return `${studentToken} [${level}] - absences:${row.absences || 0}, late30+:${row.late30Plus || 0}`;
          })
          .join("\n");
      }

      function startOfWeekMonday(value = new Date()) {
        const source =
          value instanceof Date ? new Date(value.getTime()) : new Date(value);
        if (Number.isNaN(source.valueOf())) return new Date(Number.NaN);
        const shifted = shiftToFixedTimeZone(source);
        shifted.setUTCHours(0, 0, 0, 0);
        const day = shifted.getUTCDay();
        const diffToMonday = (day + 6) % 7;
        shifted.setUTCDate(shifted.getUTCDate() - diffToMonday);
        shifted.setUTCHours(0, 0, 0, 0);
        return shiftFromFixedTimeZone(shifted);
      }

      function buildDefaultWeeklyAssignmentCompletion(value = new Date()) {
        const weekStart = startOfWeekMonday(value);
        const dayLabels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
        return dayLabels.map((day, index) => {
          const dayDate = new Date(weekStart);
          const shifted = shiftToFixedTimeZone(dayDate);
          shifted.setUTCDate(shifted.getUTCDate() + index);
          const normalizedDay = shiftFromFixedTimeZone(shifted);
          return {
            index,
            day,
            date: localIsoDate(normalizedDay),
            studentsWithAssignments: 0,
            studentsCompletedAll: 0,
            weeklyAssignedStudents: 0,
            cumulativeCompletedStudents: 0,
            completionPercent: 0,
          };
        });
      }

      function normalizeWeeklyAssignmentCompletion(rows = []) {
        const source = Array.isArray(rows) ? rows : [];
        const normalized = buildDefaultWeeklyAssignmentCompletion();
        if (!source.length) return normalized;

        const dayIndexByName = new Map(
          ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((label, index) => [
            normalizeLower(label),
            index,
          ]),
        );
        const weekStart =
          parseIsoDateLocal(normalized[0].date) || startOfWeekMonday(new Date());
        const msPerDay = 24 * 60 * 60 * 1000;

        source.forEach((row) => {
          if (!row || typeof row !== "object") return;
          let index = Number.parseInt(String(row.index ?? ""), 10);
          const dateText = normalizeText(row.date);

          // Week boundary is authoritative: only current Monday-Sunday rows are accepted.
          if (dateText) {
            const parsed = parseIsoDateLocal(dateText);
            if (parsed && !Number.isNaN(parsed.valueOf())) {
              const offset = Math.round(
                (parsed.valueOf() - weekStart.valueOf()) / msPerDay,
              );
              if (offset < 0 || offset > 6) return;
              index = offset;
            }
          } else if (!Number.isFinite(index)) {
            const dayKey = normalizeLower(row.day || row.label || "");
            if (dayIndexByName.has(dayKey)) index = dayIndexByName.get(dayKey);
          }

          if (!Number.isFinite(index) || index < 0 || index > 6) return;
          const target = normalized[index];
          const assigned = Number(
            row.studentsWithAssignments ??
              row.assignedStudents ??
              row.totalAssignments ??
              0,
          );
          const completed = Number(
            row.studentsCompletedAll ??
              row.completedStudents ??
              row.completedAssignments ??
              0,
          );
          const weeklyAssigned = Number(
            row.weeklyAssignedStudents ??
              row.studentsWithAssignments ??
              row.assignedStudents ??
              0,
          );
          const cumulativeCompleted = Number(
            row.cumulativeCompletedStudents ??
              row.studentsCompletedAll ??
              row.completedStudents ??
              0,
          );
          const completionPercent = Number(
            row.completionPercent ??
              row.completedPercent ??
              row.completionRatePercent ??
              0,
          );
          target.studentsWithAssignments =
            Number.isFinite(assigned) ? Math.max(0, Math.round(assigned)) : 0;
          target.studentsCompletedAll =
            Number.isFinite(completed) ? Math.max(0, Math.round(completed)) : 0;
          target.weeklyAssignedStudents =
            Number.isFinite(weeklyAssigned) ?
              Math.max(0, Math.round(weeklyAssigned))
            : 0;
          target.cumulativeCompletedStudents =
            Number.isFinite(cumulativeCompleted) ?
              Math.max(0, Math.round(cumulativeCompleted))
            : 0;
          target.completionPercent =
            Number.isFinite(completionPercent) ?
              Math.max(0, Math.min(100, completionPercent))
            : 0;
        });

        const fallbackAssigned = Math.max(
          0,
          ...normalized.map((row) =>
            Math.max(
              Number(row.weeklyAssignedStudents || 0),
              Number(row.studentsWithAssignments || 0),
            ),
          ),
        );
        let rollingCompleted = 0;
        normalized.forEach((row, index) => {
          if (
            !Number.isFinite(Number(row.weeklyAssignedStudents)) ||
            Number(row.weeklyAssignedStudents) <= 0
          ) {
            row.weeklyAssignedStudents = fallbackAssigned;
          }
          // Weekly chart always starts from zero on Monday.
          if (index === 0) {
            row.cumulativeCompletedStudents = 0;
            row.completionPercent = 0;
            return;
          }
          rollingCompleted = Math.max(
            rollingCompleted,
            Number(row.cumulativeCompletedStudents || row.studentsCompletedAll || 0),
          );
          row.cumulativeCompletedStudents = Math.max(0, Math.round(rollingCompleted));
          if (
            !Number.isFinite(Number(row.completionPercent)) ||
            Number(row.completionPercent) <= 0
          ) {
            row.completionPercent =
              row.weeklyAssignedStudents > 0 ?
                Math.max(
                  0,
                  Math.min(
                    100,
                    (row.cumulativeCompletedStudents / row.weeklyAssignedStudents) *
                      100,
                  ),
                )
              : 0;
          }
        });

        return normalized;
      }

      function buildFallbackDashboardSummary() {
        const levelMap = new Map();
        const students = assignmentStudentSource();
        const totalEnrollment = students.reduce((count, student) => {
          const level = normalizeLevelName(student?.profile?.currentGrade || "");
          return level ? count + 1 : count;
        }, 0);
        const unenrolledYtd = Math.max(0, students.length - totalEnrollment);
        students.forEach((student) => {
          const level = normalizeLevelName(student?.profile?.currentGrade || "");
          if (!level) return;
          const row = levelMap.get(level) || {
            level,
            enrolledStudents: 0,
            totalAssignments: 0,
            completedAssignments: 0,
            outstandingAssignments: 0,
            completedStudents: 0,
            uncompletedStudents: [],
          };
          row.enrolledStudents += 1;
          levelMap.set(level, row);
        });
        const levels = sortLevelRows(Array.from(levelMap.values()));
        return {
          generatedAt: new Date().toISOString(),
          today: {
            date: localIsoDate(new Date()),
            totalStudents: students.length,
            totalEnrollment,
            attendancePercentOfEnrollment: 0,
            unenrolledYtd,
            attendance: 0,
            absences: 0,
            tardy10PlusPercent: 0,
            tardy30PlusPercent: 0,
          },
          weeklyAssignmentCompletion: buildDefaultWeeklyAssignmentCompletion(),
          classEnrollmentAttendance: levels.map((entry) => ({
            level: entry.level,
            enrolled: entry.enrolledStudents,
            attendanceToday: 0,
          })),
          assignments: {
            total: 0,
            completedOnTime: 0,
            completedLate: 0,
            outstanding: 0,
            outstandingYtd: 0,
            currentActiveLevels: 0,
            currentTargetedStudents: 0,
            currentCompletedStudents: 0,
            currentPendingStudents: 0,
            currentCompletionPercent: 0,
            currentDueSoonLevels: 0,
            currentDueSoonPendingStudents: 0,
          },
          atRiskWeek: {
            total: 0,
            students: [],
          },
          attendanceRiskWeek: {
            total: 0,
            students: [],
          },
          levelCompletion: [],
        };
      }

      function isAssignedLevelRow(row = {}) {
        const normalized = normalizeLower(normalizeLevelName(row?.level || ""));
        return Boolean(normalized) && normalized !== "unassigned";
      }



      function setLevelDetailStatus(message, isError = false) {
        const el = document.getElementById("levelDetailStatus");
        if (!el) return;
        el.style.color = isError ? "#b3262d" : "var(--portal-status-muted-text)";
        el.textContent = normalizeText(message);
      }

      function shouldAutoScrollHomeworkProgressPanel() {
        return Boolean(
          window.matchMedia && window.matchMedia("(max-width: 820px)").matches,
        );
      }

      function parseLocalDateOrDateTime(value) {
        const text = normalizeText(value);
        if (!text) return null;
        const localDate = parseIsoDateLocal(text);
        if (localDate) return localDate;
        return parseDateTime(text);
      }

      function currentWeekBounds(value = new Date()) {
        const start = startOfWeekMonday(value);
        const shiftedEnd = shiftToFixedTimeZone(start);
        shiftedEnd.setUTCDate(shiftedEnd.getUTCDate() + 6);
        shiftedEnd.setUTCHours(23, 59, 59, 999);
        const end = shiftFromFixedTimeZone(shiftedEnd);
        return { start, end };
      }

      function isDateWithinBounds(dateValue, bounds = currentWeekBounds()) {
        if (!(dateValue instanceof Date) || Number.isNaN(dateValue.valueOf()))
          return false;
        return (
          dateValue.valueOf() >= bounds.start.valueOf() &&
          dateValue.valueOf() <= bounds.end.valueOf()
        );
      }

      function assignmentTemplateSortStamp(template = {}) {
        const updatedAt = parseLocalDateOrDateTime(template.updatedAt);
        const assignedAt = parseLocalDateOrDateTime(template.assignedAt);
        const dueAt = parseLocalDateOrDateTime(template.dueAt);
        return (
          (updatedAt && updatedAt.valueOf()) ||
          (assignedAt && assignedAt.valueOf()) ||
          (dueAt && dueAt.valueOf()) ||
          0
        );
      }

      function assignmentTemplateTouchesCurrentWeek(
        template = {},
        bounds = currentWeekBounds(),
      ) {
        const assignedAt = parseLocalDateOrDateTime(template.assignedAt);
        const dueAt = parseLocalDateOrDateTime(template.dueAt);
        return (
          isDateWithinBounds(assignedAt, bounds) || isDateWithinBounds(dueAt, bounds)
        );
      }

      function currentWeekAssignmentTemplateForLevel(levelName = "") {
        const targetLevel = resolveSystemLevelName(levelName);
        if (!targetLevel) return null;
        const bounds = currentWeekBounds(new Date());
        const templates =
          Array.isArray(state.assignmentTemplates) ? state.assignmentTemplates : [];
        return (
          templates
            .filter((template) => levelNamesMatch(template?.level, targetLevel))
            .filter((template) =>
              assignmentTemplateTouchesCurrentWeek(template, bounds),
            )
            .sort(
              (left, right) =>
                assignmentTemplateSortStamp(right) - assignmentTemplateSortStamp(left),
            )[0] || null
        );
      }

      function daysUntilLocalDateFloor(targetDateValue, asOfDate = new Date()) {
        const dueAt = parseLocalDateOrDateTime(targetDateValue);
        const asOf = asOfDate instanceof Date ? asOfDate : new Date(asOfDate);
        if (!(dueAt instanceof Date) || Number.isNaN(dueAt.valueOf())) return null;
        if (Number.isNaN(asOf.valueOf())) return null;
        const dueDay = shiftToFixedTimeZone(dueAt);
        dueDay.setUTCHours(0, 0, 0, 0);
        const asOfDay = shiftToFixedTimeZone(asOf);
        asOfDay.setUTCHours(0, 0, 0, 0);
        const msPerDay = 24 * 60 * 60 * 1000;
        return Math.floor((dueDay.valueOf() - asOfDay.valueOf()) / msPerDay);
      }

      function buildTemplateLevelCompletionRows(asOfDate = new Date()) {
        const templates =
          Array.isArray(state.assignmentTemplates) ? state.assignmentTemplates : [];
        if (!templates.length) return [];

        const asOf = asOfDate instanceof Date ? asOfDate : new Date(asOfDate);
        if (Number.isNaN(asOf.valueOf())) return [];

        const students = assignmentStudentSource().filter((student) =>
          normalizeText(student?.eaglesId),
        );
        const studentsByLevel = new Map();
        students.forEach((student) => {
          const level = resolveSystemLevelName(student?.profile?.currentGrade || "");
          if (!level) return;
          if (!studentsByLevel.has(level)) studentsByLevel.set(level, []);
          studentsByLevel.get(level).push(student);
        });

        const selectedTemplateByLevel = new Map();
        templates.forEach((template) => {
          const level = resolveSystemLevelName(template?.level || "");
          if (!level) return;
          const dueAt = parseLocalDateOrDateTime(template?.dueAt);
          if (!(dueAt instanceof Date) || Number.isNaN(dueAt.valueOf())) return;
          const daysUntilDue = daysUntilLocalDateFloor(dueAt, asOf);
          if (!Number.isFinite(daysUntilDue) || daysUntilDue < 0) return;

          const current = selectedTemplateByLevel.get(level);
          if (!current) {
            selectedTemplateByLevel.set(level, { template, dueAt, daysUntilDue });
            return;
          }

          const dueDelta = dueAt.valueOf() - current.dueAt.valueOf();
          if (dueDelta < 0) {
            selectedTemplateByLevel.set(level, { template, dueAt, daysUntilDue });
            return;
          }
          if (dueDelta > 0) return;

          if (
            assignmentTemplateSortStamp(template) >
            assignmentTemplateSortStamp(current.template)
          ) {
            selectedTemplateByLevel.set(level, { template, dueAt, daysUntilDue });
          }
        });

        const rows = [];
        selectedTemplateByLevel.forEach(({ template, daysUntilDue }, level) => {
          const levelStudents =
            Array.isArray(studentsByLevel.get(level)) ? studentsByLevel.get(level) : [];
          const targetEaglesId = normalizeLower(template?.eaglesId);
          const targetedStudents =
            targetEaglesId ?
              levelStudents.filter(
                (student) => normalizeLower(student?.eaglesId) === targetEaglesId,
              )
            : levelStudents;
          if (!targetedStudents.length) return;

          const assignmentName = normalizeText(
            template?.assignmentTitle || template?.exerciseTitle,
          );
          const dueAt = normalizeText(template?.dueAt);
          const singleStudentMarkedCompleted =
            targetedStudents.length === 1 && Boolean(template?.completed);
          const completedStudents = singleStudentMarkedCompleted ? 1 : 0;
          const completedStudentRefId =
            singleStudentMarkedCompleted ?
              normalizeText(
                targetedStudents[0]?.id || targetedStudents[0]?.studentRefId,
              )
            : "";

          const uncompletedStudents = targetedStudents
            .filter((student) => {
              if (!completedStudentRefId) return true;
              const studentRefId = normalizeText(student?.id || student?.studentRefId);
              return studentRefId !== completedStudentRefId;
            })
            .map((student) => ({
              studentRefId: normalizeText(student?.id || student?.studentRefId),
              eaglesId: normalizeText(student?.eaglesId),
              studentNumber: studentDisplayNumber(student) || null,
              fullName: normalizeText(
                student?.profile?.fullName ||
                  student?.profile?.englishName ||
                  student?.eaglesId,
              ),
              emails: assignmentRecipientsForStudent(student),
              outstandingCount: 1,
              assignmentNames: assignmentName ? [assignmentName] : [],
              nextDueAt: dueAt,
            }))
            .sort((left, right) =>
              normalizeText(left?.fullName).localeCompare(
                normalizeText(right?.fullName),
              ),
            );

          const targetedCount = targetedStudents.length;
          rows.push({
            level,
            enrolledStudents: levelStudents.length,
            totalAssignments: targetedCount,
            completedAssignments: completedStudents,
            outstandingAssignments: Math.max(0, targetedCount - completedStudents),
            completedStudents,
            completionPercent:
              targetedCount > 0 ? (completedStudents / targetedCount) * 100 : 0,
            assignmentName,
            dueAt,
            daysUntilDue,
            uncompletedStudents,
          });
        });

        return sortLevelRows(rows);
      }

      function buildEnrollmentOnlyLevelCompletionRows(summary = {}) {
        const enrolledByLevel = new Map();
        (Array.isArray(summary?.classEnrollmentAttendance) ?
          summary.classEnrollmentAttendance
        : []
        )
          .filter(isAssignedLevelRow)
          .forEach((row) => {
            const level = resolveSystemLevelName(row?.level || "");
            if (!level) return;
            const enrolled = Math.max(
              0,
              Number.parseInt(String(row?.enrolled || 0), 10) || 0,
            );
            const current = enrolledByLevel.get(level) || 0;
            enrolledByLevel.set(level, Math.max(current, enrolled));
          });

        if (!enrolledByLevel.size) {
          assignmentStudentSource().forEach((student) => {
            const level = resolveSystemLevelName(student?.profile?.currentGrade || "");
            if (!level) return;
            const current = enrolledByLevel.get(level) || 0;
            enrolledByLevel.set(level, current + 1);
          });
        }

        const rows = Array.from(enrolledByLevel.entries())
          .filter(([, enrolled]) => Number(enrolled) > 0)
          .map(([level, enrolledStudents]) => ({
            level,
            enrolledStudents,
            totalAssignments: 0,
            completedAssignments: 0,
            outstandingAssignments: 0,
            completedStudents: 0,
            completionPercent: 0,
            assignmentName: "",
            dueAt: "",
            daysUntilDue: null,
            uncompletedStudents: [],
          }));

        return sortLevelRows(rows);
      }

      function effectiveDashboardLevelCompletionRows(summary = {}) {
        const dashboardRows = sortLevelRows(
          (Array.isArray(summary?.levelCompletion) ?
            summary.levelCompletion
          : []
          ).filter(isAssignedLevelRow),
        );
        if (dashboardRows.length) return dashboardRows;
        const templateRows = buildTemplateLevelCompletionRows(new Date());
        if (templateRows.length) return templateRows;
        return buildEnrollmentOnlyLevelCompletionRows(summary);
      }

      function buildAnnouncementPreviewPayloadFromTemplate(
        template = {},
        levelName = "",
      ) {
        const level = resolveSystemLevelName(levelName || template?.level || "");
        const items = normalizeAssignmentItems(template?.items)
          .map((item) => ({
            title: normalizeText(item.title),
            url: safeHref(item.url),
          }))
          .filter((item) => item.title || item.url);

        const assignmentTitle =
          normalizeText(template?.assignmentTitle || template?.exerciseTitle) ||
          `${fullLevelLabel(level)} Assignment`;
        const assignedAt = normalizeText(template?.assignedAt) || localIsoDate();
        const dueAt = normalizeText(template?.dueAt) || nextSundayIsoDate(assignedAt);
        const messageFromTemplate = normalizeText(template?.message);
        const itemLines = items
          .map(
            (item, index) =>
              `${index + 1}. ${item.title}${item.url ? ` - ${item.url}` : ""}`,
          )
          .filter(Boolean);
        const generatedMessage =
          itemLines.length ?
            `Date assigned: ${assignedAt}\n\nAssignment items:\n${itemLines.join("\n")}`
          : `Date assigned: ${assignedAt}`;

        return {
          assignmentTitle,
          level,
          assignedAt,
          dueAt,
          message: messageFromTemplate || generatedMessage,
          items,
        };
      }

      function buildAnnouncementPreviewPayloadFromLevelDetail(levelDetail = {}) {
        const level = resolveSystemLevelName(levelDetail?.level || "");
        if (!level) return null;

        const assignmentTitle = normalizeText(
          levelDetail?.assignmentName || levelDetail?.assignment,
        );
        const assignedAt = localIsoDate();
        const dueAt =
          normalizeText(levelDetail?.dueAt || levelDetail?.nextDueAt) ||
          nextSundayIsoDate(assignedAt);
        const explicitDueAt = normalizeText(
          levelDetail?.dueAt || levelDetail?.nextDueAt,
        );
        const message =
          explicitDueAt ?
            `Date assigned: ${assignedAt}\nDue date: ${explicitDueAt}`
          : `Date assigned: ${assignedAt}`;

        return {
          assignmentTitle: assignmentTitle || `${fullLevelLabel(level)} Assignment`,
          level,
          assignedAt,
          dueAt,
          message,
          items: [],
        };
      }

      function levelDetailAnnouncementLink(levelDetail = {}) {
        return normalizeText(
          levelDetail?.announcementLink ||
            levelDetail?.assignmentLink ||
            levelDetail?.link ||
            levelDetail?.url,
        );
      }

      async function createVolatileAssignmentAnnouncementPreview(payload = {}) {
        if (!canWriteData() && !canManageUsers()) return null;
        let result = null;
        try {
          result = await api(ADMIN_ASSIGNMENT_ANNOUNCEMENT_PREVIEW_CREATE_PATH, {
            method: "POST",
            body: payload,
          });
        } catch (error) {
          if (error && (error.status === 403 || error.status === 404)) return null;
          throw error;
        }

        const absoluteUrl = normalizeText(result?.url);
        if (absoluteUrl) {
          return {
            url: absoluteUrl,
            expiresAt: normalizeText(result?.expiresAt),
            ttlMinutes:
              Number.parseInt(
                String(
                  result?.ttlMinutes || ASSIGNMENT_ANNOUNCEMENT_PREVIEW_TTL_MINUTES,
                ),
                10,
              ) || ASSIGNMENT_ANNOUNCEMENT_PREVIEW_TTL_MINUTES,
          };
        }

        const relativePath = normalizeText(result?.path);
        if (!relativePath) return null;
        try {
          return {
            url: new URL(relativePath, window.location.origin).toString(),
            expiresAt: normalizeText(result?.expiresAt),
            ttlMinutes:
              Number.parseInt(
                String(
                  result?.ttlMinutes || ASSIGNMENT_ANNOUNCEMENT_PREVIEW_TTL_MINUTES,
                ),
                10,
              ) || ASSIGNMENT_ANNOUNCEMENT_PREVIEW_TTL_MINUTES,
          };
        } catch (error) {
          void error;
          return null;
        }
      }

      async function autoPopulateHomeworkProgressForLevel(levelDetail = {}) {
        const level = resolveSystemLevelName(levelDetail?.level || "");
        if (!level) return;

        if (!Array.isArray(state.assignmentTemplates) || !state.assignmentTemplates.length)
          await loadAssignmentTemplatesFromServer();

        const assignmentInput = document.getElementById("levelReminderAssignment");
        const linkInput = document.getElementById("levelReminderLink");
        const dueInput = document.getElementById("levelReminderDueAt");
        const detailAssignmentName = normalizeText(levelDetail?.assignmentName);
        const detailDueAt = normalizeText(levelDetail?.dueAt);
        const detailLink = levelDetailAnnouncementLink(levelDetail);

        if (assignmentInput && detailAssignmentName)
          assignmentInput.value = detailAssignmentName;
        if (dueInput && detailDueAt) dueInput.value = detailDueAt;
        if (linkInput && detailLink) linkInput.value = detailLink;

        const template = currentWeekAssignmentTemplateForLevel(level);
        if (!template) {
          if (
            linkInput &&
            !normalizeText(linkInput.value) &&
            (detailAssignmentName || detailDueAt)
          ) {
            const fallbackPreviewPayload =
              buildAnnouncementPreviewPayloadFromLevelDetail(levelDetail);
            const fallbackPreview =
              fallbackPreviewPayload ?
                await createVolatileAssignmentAnnouncementPreview(
                  fallbackPreviewPayload,
                )
              : null;
            const fallbackPreviewUrl = normalizeText(fallbackPreview?.url);
            if (fallbackPreviewUrl) {
              linkInput.value = fallbackPreviewUrl;
              const ttlMins =
                Number.parseInt(
                  String(
                    fallbackPreview?.ttlMinutes ||
                      ASSIGNMENT_ANNOUNCEMENT_PREVIEW_TTL_MINUTES,
                  ),
                  10,
                ) || ASSIGNMENT_ANNOUNCEMENT_PREVIEW_TTL_MINUTES;
              setLevelDetailStatus(
                `Auto-filled from dashboard current assignment for ${fullLevelLabel(level)}. Volatile preview link expires in ${ttlMins} mins.`,
              );
              return;
            }
          }

          if (detailAssignmentName || detailDueAt || detailLink) {
            setLevelDetailStatus(
              `Auto-filled from dashboard current assignment for ${fullLevelLabel(level)}. Add reminder link if needed.`,
            );
            return;
          }
          setLevelDetailStatus(
            `No current not-yet-due assignment found for ${fullLevelLabel(level)}. Enter reminder details manually.`,
          );
          return;
        }

        const payload = buildAnnouncementPreviewPayloadFromTemplate(template, level);
        const preview = await createVolatileAssignmentAnnouncementPreview(payload);
        const firstLiveItemLink = normalizeText(
          payload.items.find((item) => normalizeText(item.url))?.url,
        );
        if (assignmentInput && !detailAssignmentName)
          assignmentInput.value = normalizeText(payload.assignmentTitle);
        if (dueInput && !detailDueAt) dueInput.value = normalizeText(payload.dueAt);
        const templateLink = normalizeText(preview?.url || firstLiveItemLink);
        if (linkInput && templateLink) linkInput.value = templateLink;

        if (normalizeText(preview?.url)) {
          const ttlMins =
            Number.parseInt(
              String(
                preview?.ttlMinutes || ASSIGNMENT_ANNOUNCEMENT_PREVIEW_TTL_MINUTES,
              ),
              10,
            ) || ASSIGNMENT_ANNOUNCEMENT_PREVIEW_TTL_MINUTES;
          setLevelDetailStatus(
            `Auto-filled from current assignment. Volatile preview link expires in ${ttlMins} mins.`,
          );
          return;
        }

        setLevelDetailStatus("Auto-filled from current assignment.");
      }

      function closeLevelDetailPanel() {
        state.activeLevelDetail = null;
        applyLevelThemeToDetailPanel("");
        const panel = document.getElementById("levelDetailPanel");
        const title = document.getElementById("levelDetailTitle");
        if (title) title.textContent = "Current assignment progress";
        if (panel) panel.classList.add("hidden");
      }

      function openLevelDetailPanel(levelNameOrRow) {
        const rows =
          Array.isArray(state.dashboardLevelCompletionRows) ?
            state.dashboardLevelCompletionRows
          : [];
        const directRow =
          levelNameOrRow && typeof levelNameOrRow === "object" ? levelNameOrRow : null;
        const levelName = normalizeText(directRow?.level || levelNameOrRow);
        const detail =
          directRow || rows.find((entry) => levelNamesMatch(entry?.level, levelName));
        const fallback = detail || {
          level: levelName,
          uncompletedStudents: [],
        };
        state.activeLevelDetail = fallback;
        applyLevelThemeToDetailPanel(fallback.level);
        const panel = document.getElementById("levelDetailPanel");
        const title = document.getElementById("levelDetailTitle");
        const tbody = document.getElementById("levelDetailRows");
        const detailDueAt = normalizeText(fallback?.dueAt);
        if (title) {
          title.textContent =
            detailDueAt ?
              `Current assignment progress - ${fullLevelLabel(fallback.level)} (due ${detailDueAt})`
            : `Current assignment progress - ${fullLevelLabel(fallback.level)}`;
        }
        if (tbody) {
          tbody.innerHTML = "";
          const students =
            Array.isArray(fallback.uncompletedStudents) ?
              fallback.uncompletedStudents
            : [];
          if (!students.length) {
            const tr = document.createElement("tr");
            tr.innerHTML =
              '<td colspan="6">No not-completed-yet students for this level.</td>';
            tbody.appendChild(tr);
          }
          students.forEach((student, index) => {
            const tr = document.createElement("tr");
            const assignments =
              Array.isArray(student.assignmentNames) ?
                student.assignmentNames.join(", ")
              : "";
            tr.innerHTML = `
          <td><input type="checkbox" id="remind_student_${sanitizeDomIdPart(student.studentRefId)}" name="remind_student_${sanitizeDomIdPart(student.studentRefId)}" class="checkbox-inline" data-remind-student="${student.studentRefId}" ${index < 5 ? "checked" : ""}></td>
            <td>${student.fullName || ""}</td>
            <td>${student.eaglesId || ""}</td>
            <td>${student.outstandingCount || 0}</td>
            <td>${assignments || "-"}</td>
            <td>${Array.isArray(student.emails) ? student.emails.join(", ") : ""}</td>
          `;
            tbody.appendChild(tr);
          });
        }
        if (panel) panel.classList.remove("hidden");
        if (
          panel &&
          shouldAutoScrollHomeworkProgressPanel() &&
          typeof panel.scrollIntoView === "function"
        ) {
          panel.scrollIntoView({ behavior: "smooth", block: "start" });
        }
        if (detail) {
          setLevelDetailStatus("Loading current assignment...");
          autoPopulateHomeworkProgressForLevel(fallback).catch((error) => {
            setLevelDetailStatus("Unable to auto-fill current assignment.", true);
            handleError(error);
          });
        } else {
          setLevelDetailStatus("No detail payload found for selected level.", true);
        }
      }



      function renderDashboardSummary(summary = {}) {
        void ensureOverviewDashboardIsland()
          .then((island) => island.renderDashboardSummary(summary))
          .catch(handleError);
      }

      function canReviewIncomingExerciseQueue() {
        return currentRoleName() === "admin" || canManageUsers();
      }

      function normalizeIncomingExerciseItemForUi(item = {}) {
        return {
          id: normalizeText(item.id),
          status: normalizeText(item.status),
          submittedEaglesId: normalizeText(item.submittedEaglesId),
          submittedEmail: normalizeText(item.submittedEmail),
          pageTitle: normalizeText(item.pageTitle),
          totalQuestions: Number.parseInt(String(item.totalQuestions || 0), 10) || 0,
          correctCount: Number.parseInt(String(item.correctCount || 0), 10) || 0,
          scorePercent: Number(item.scorePercent || 0),
          reviewedByUsername: normalizeText(item.reviewedByUsername),
          createdAt: normalizeText(item.createdAt),
        };
      }

      function formatIncomingExerciseScore(item = {}) {
        const total = Math.max(0, Number(item.totalQuestions || 0) || 0);
        const correct = Math.max(0, Number(item.correctCount || 0) || 0);
        const percentValue = Number(item.scorePercent || 0);
        const percent = Number.isFinite(percentValue) ? percentValue.toFixed(1) : "0.0";
        if (total > 0) return `${correct}/${total} (${percent}%)`;
        return `${percent}%`;
      }

      function setIncomingExerciseActionStatus(message, isError = false) {
        const statusEl = document.getElementById(
          "overviewIncomingExerciseActionStatus",
        );
        if (!statusEl) return;
        statusEl.style.color = isError ? "#b3262d" : "var(--portal-status-muted-text)";
        statusEl.textContent =
          normalizeText(message) || "Disposition actions are available per queue row.";
      }

      function normalizeIncomingSubmittedEaglesId(value) {
        const text = normalizeText(value);
        if (!text) return "";
        if (normalizeLower(text) === "(not provided)") return "";
        return text;
      }

      async function resolveIncomingTargetStudentByEaglesId(eaglesIdInput) {
        const requested = normalizeText(eaglesIdInput);
        if (!requested) throw new Error("Eagles ID is required.");
        const requestedKey = normalizeLower(requested);

        const fromPool = (pool) => {
          const list = Array.isArray(pool) ? pool : [];
          return (
            list.find((entry) => normalizeLower(entry?.eaglesId) === requestedKey) ||
            null
          );
        };

        const localMatch =
          fromPool(state.students) || fromPool(state.dashboardStudents);
        if (localMatch?.id) {
          return {
            id: normalizeText(localMatch.id),
            eaglesId: normalizeText(localMatch.eaglesId),
          };
        }

        const fetched = await api(
          `/api/admin/students?q=${encodeURIComponent(requested)}&take=100`,
        );
        const fetchedItems = Array.isArray(fetched?.items) ? fetched.items : [];
        const fetchedMatch = fromPool(fetchedItems);
        if (fetchedMatch?.id) {
          return {
            id: normalizeText(fetchedMatch.id),
            eaglesId: normalizeText(fetchedMatch.eaglesId),
          };
        }

        throw new Error(`Eagles ID "${requested}" was not found.`);
      }

      async function addIncomingExerciseToSpecificStudent(item = {}) {
        const defaultStudentId =
          normalizeText(state.currentStudent?.eaglesId) ||
          normalizeIncomingSubmittedEaglesId(item.submittedEaglesId) ||
          "";
        const enteredStudentId = window.prompt(
          "Add to specific student: enter Eagles ID",
          defaultStudentId,
        );
        if (enteredStudentId == null) return;
        const targetStudent =
          await resolveIncomingTargetStudentByEaglesId(enteredStudentId);
        await applyIncomingExerciseDisposition(
          item.id,
          "match",
          {
            studentRefId: targetStudent.id,
          },
          {
            doneMessage: `Added this quiz score to ${targetStudent.eaglesId}.`,
          },
        );
      }

      async function createIncomingExerciseStudentAccount(item = {}) {
        const suggestedEaglesId = normalizeIncomingSubmittedEaglesId(
          item.submittedEaglesId,
        );
        const enteredEaglesId = window.prompt(
          "Create new user: Eagles ID",
          suggestedEaglesId,
        );
        if (enteredEaglesId == null) return;
        const eaglesId = normalizeText(enteredEaglesId);
        if (!eaglesId) throw new Error("eaglesId is required to create account.");

        const fullName = window.prompt("Student full name (optional):", "") || "";
        const result = await applyIncomingExerciseDisposition(
          item.id,
          "create-account",
          {
            eaglesId,
            email: normalizeText(item.submittedEmail),
            fullName: normalizeText(fullName),
          },
          {
            doneMessage: `Created user ${eaglesId}, auto-added quiz score, and opened Profile.`,
          },
        );

        const createdStudentRefId = normalizeText(
          result?.student?.id || result?.studentRefId,
        );
        if (!createdStudentRefId) return;

        await loadFilters();
        await loadStudents();
        await loadDashboardStudents();
        await loadStudentDetail(createdStudentRefId);
        setActivePage("profile");
      }

      function incomingDispositionOptionsForItem(item = {}) {
        const status = normalizeLower(item.status);
        const options = [];
        if (status === "queued") {
          options.push({
            action: "match",
            label: "Add to Specific Student",
            className: "portal-button portal-button-affirm",
          });
          options.push({
            action: "create-account",
            label: "Create New User",
            className: "portal-button portal-button-primary",
          });
          options.push({ action: "save-temp", label: "Temp", className: "portal-button portal-button-affirm" });
          options.push({
            action: "archive",
            label: "Archive",
            className: "portal-button portal-button-warning",
          });
          options.push({ action: "delete", label: "Delete", className: "portal-button portal-button-danger" });
          return options;
        }
        if (status === "temporary") {
          options.push({
            action: "match",
            label: "Add to Specific Student",
            className: "portal-button portal-button-affirm",
          });
          options.push({
            action: "create-account",
            label: "Create New User",
            className: "portal-button portal-button-primary",
          });
          options.push({
            action: "requeue",
            label: "Requeue",
            className: "portal-button portal-button-teal-refresh",
          });
          options.push({
            action: "archive",
            label: "Archive",
            className: "portal-button portal-button-warning",
          });
          options.push({ action: "delete", label: "Delete", className: "portal-button portal-button-danger" });
          return options;
        }
        if (status === "archived") {
          options.push({
            action: "match",
            label: "Add to Specific Student",
            className: "portal-button portal-button-affirm",
          });
          options.push({
            action: "create-account",
            label: "Create New User",
            className: "portal-button portal-button-primary",
          });
          options.push({
            action: "requeue",
            label: "Requeue",
            className: "portal-button portal-button-teal-refresh",
          });
          options.push({ action: "delete", label: "Delete", className: "portal-button portal-button-danger" });
          return options;
        }
        if (status === "resolved") {
          options.push({
            action: "archive",
            label: "Archive",
            className: "portal-button portal-button-warning",
          });
        }
        return options;
      }

      async function applyIncomingExerciseDisposition(
        incomingResultId,
        action,
        extraPayload = {},
        options = {},
      ) {
        const id = normalizeText(incomingResultId);
        const normalizedAction = normalizeLower(action);
        if (!id || !normalizedAction)
          throw new Error("incoming result action requires id and action.");
        if (!canReviewIncomingExerciseQueue())
          throw new Error("Only admin can manage incoming exercise queue.");
        if (normalizedAction === "delete") {
          const confirmed = window.confirm("Delete this incoming exercise queue item?");
          if (!confirmed) return;
        }

        state.incomingExerciseQueue.pendingActionById[id] = normalizedAction;
        renderOverviewIncomingExerciseSection({
          total: state.incomingExerciseQueue.total,
          hasMore: state.incomingExerciseQueue.hasMore,
          statuses: state.incomingExerciseQueue.statuses,
          items: state.incomingExerciseQueue.items,
        });
        setIncomingExerciseActionStatus(`Applying ${normalizedAction}...`);

        try {
          const result = await api(ADMIN_INCOMING_EXERCISE_RESULTS_PATH, {
            method: "POST",
            body: {
              action: normalizedAction,
              incomingResultId: id,
              ...extraPayload,
            },
          });
          await loadIncomingExerciseResults({
            showAll: state.incomingExerciseQueue.showAll,
          });
          const doneMessage =
            normalizeText(options?.doneMessage) ||
            (normalizedAction === "delete" ?
              "Incoming exercise queue item deleted."
            : `Incoming exercise queue item updated (${normalizedAction}).`);
          setIncomingExerciseActionStatus(doneMessage);
          setStatus(doneMessage);
          return result;
        } finally {
          delete state.incomingExerciseQueue.pendingActionById[id];
          renderOverviewIncomingExerciseSection({
            total: state.incomingExerciseQueue.total,
            hasMore: state.incomingExerciseQueue.hasMore,
            statuses: state.incomingExerciseQueue.statuses,
            items: state.incomingExerciseQueue.items,
          });
        }
      }

      function renderOverviewIncomingExerciseSection(queueBlock = null) {
        const sectionEl = document.getElementById("overviewIncomingExerciseSection");
        const detailsEl = document.getElementById("overviewIncomingExerciseDetails");
        const summaryEl = document.getElementById("overviewIncomingExerciseSummary");
        const rowsEl = document.getElementById("overviewIncomingExerciseRows");
        const expandBtn = document.getElementById("overviewIncomingExerciseExpandBtn");
        if (!sectionEl || !summaryEl || !rowsEl || !expandBtn) return;

        const canReviewQueue = canReviewIncomingExerciseQueue();
        sectionEl.classList.toggle("hidden", !canReviewQueue);
        if (!canReviewQueue) return;

        const sourceItems =
          Array.isArray(queueBlock?.items) ?
            queueBlock.items
          : state.incomingExerciseQueue.items;
        const normalizedItems = sourceItems.map((entry) =>
          normalizeIncomingExerciseItemForUi(entry),
        );
        state.incomingExerciseQueue.items = normalizedItems;
        if (queueBlock && Number.isFinite(Number(queueBlock.total))) {
          state.incomingExerciseQueue.total = Number(queueBlock.total) || 0;
        } else {
          state.incomingExerciseQueue.total = normalizedItems.length;
        }
        if (queueBlock && typeof queueBlock.hasMore === "boolean") {
          state.incomingExerciseQueue.hasMore = queueBlock.hasMore;
        } else {
          state.incomingExerciseQueue.hasMore =
            state.incomingExerciseQueue.total > normalizedItems.length;
        }
        state.incomingExerciseQueue.statuses =
          Array.isArray(queueBlock?.statuses) ?
            queueBlock.statuses.map((entry) => normalizeText(entry)).filter(Boolean)
          : state.incomingExerciseQueue.statuses;

        const statusLabel =
          state.incomingExerciseQueue.statuses.length ?
            state.incomingExerciseQueue.statuses.join(",")
          : "all";
        const visibleCount = normalizedItems.length;
        summaryEl.textContent = `statuses=${statusLabel} | total=${state.incomingExerciseQueue.total} | showing=${visibleCount}`;
        expandBtn.textContent =
          state.incomingExerciseQueue.showAll ?
            "Active Only"
          : "All Statuses";
        if (detailsEl && !detailsEl.open) detailsEl.open = false;

        rowsEl.innerHTML = "";
        if (!normalizedItems.length) {
          rowsEl.innerHTML =
            '<tr><td colspan="8">No anonymous exercise submissions.</td></tr>';
          setIncomingExerciseActionStatus("");
          return;
        }

        normalizedItems.forEach((item) => {
          const tr = document.createElement("tr");
          tr.innerHTML = `
          <td>${escapeHtml(formatDateTime(item.createdAt))}</td>
          <td>${escapeHtml(item.submittedEaglesId || "(not provided)")}</td>
          <td>${escapeHtml(item.submittedEmail || "-")}</td>
          <td>${escapeHtml(item.pageTitle || "-")}</td>
          <td>${escapeHtml(formatIncomingExerciseScore(item))}</td>
          <td>${escapeHtml(item.status || "-")}</td>
          <td>${escapeHtml(item.reviewedByUsername || "-")}</td>
        `;

          const actionTd = document.createElement("td");
          const actionsWrap = document.createElement("div");
          actionsWrap.className = "incoming-disposition-actions";
          const actionOptions = incomingDispositionOptionsForItem(item);
          const pendingAction = normalizeText(
            state.incomingExerciseQueue.pendingActionById[item.id],
          );
          if (!actionOptions.length) {
            actionsWrap.textContent = "-";
          } else {
            actionOptions.forEach((entry) => {
              const button = document.createElement("button");
              button.type = "button";
              button.className = entry.className;
              button.textContent = entry.label;
              button.dataset.incomingDispositionAction = entry.action;
              button.disabled = Boolean(pendingAction);
              if (pendingAction && pendingAction === entry.action) {
                button.textContent = `${entry.label}...`;
              }
              button.addEventListener("click", () => {
                if (entry.action === "match") {
                  addIncomingExerciseToSpecificStudent(item).catch(handleError);
                  return;
                }
                if (entry.action === "create-account") {
                  createIncomingExerciseStudentAccount(item).catch(handleError);
                  return;
                }
                applyIncomingExerciseDisposition(item.id, entry.action).catch(
                  handleError,
                );
              });
              actionsWrap.appendChild(button);
            });
          }
          actionTd.appendChild(actionsWrap);
          tr.appendChild(actionTd);
          rowsEl.appendChild(tr);
        });
      }

      function renderOverviewNewsQueueSection(panel = null) {
        const sectionEl = document.getElementById("overviewNewsQueueSection");
        const detailsEl = document.getElementById("overviewNewsQueueDetails");
        const summaryEl = document.getElementById("overviewNewsQueueSummary");
        const rowsEl = document.getElementById("overviewNewsQueueRows");
        if (!sectionEl || !summaryEl || !rowsEl) return;

        const canReview = canManageUsers();
        sectionEl.classList.toggle("hidden", !canReview);
        if (!canReview) return;

        const sourcePanel =
          panel ||
          (state.queueHub?.panelsById ?
            state.queueHub.panelsById["news-report-review"]
          : null);
        const items = Array.isArray(sourcePanel?.items) ? sourcePanel.items : [];
        const total =
          Number.isFinite(Number(sourcePanel?.total)) ?
            Number(sourcePanel.total)
          : items.length;
        const currentWeekStart = newsReviewWeekStartIso(localIsoDate(new Date()));
        const currentWeekItems = items.filter(
          (item) => normalizeText(item?.weekStart) === currentWeekStart,
        );
        const showAll = Boolean(state.queueHub.overviewNewsQueueShowAll);
        const displayItems = showAll ? items : currentWeekItems;
        const visible = Math.min(displayItems.length, 25);
        summaryEl.textContent =
          items.length ?
            showAll ?
              `total=${total} | showing=${visible}`
            : `total=${total} | current week=${visible}`
          : "No news report queue rows.";
        const showAllBtn = document.getElementById("overviewNewsQueueShowAllBtn");
        if (showAllBtn) {
          showAllBtn.textContent = showAll ? "Show Current Week" : "Show All Pending";
          showAllBtn.setAttribute("aria-pressed", showAll ? "true" : "false");
        }

        rowsEl.innerHTML = "";
        if (!displayItems.length) {
          rowsEl.innerHTML =
            items.length && !showAll ?
              '<tr><td colspan="7">No current-week rows. Use Show All Pending to view older pending reports.</td></tr>'
            : '<tr><td colspan="7">No news report queue rows.</td></tr>';
          return;
        }

        displayItems.slice(0, 25).forEach((item) => {
          const setStatus = newsReviewAdminSetStatusToken(item);
          const setAction = normalizeText(
            item?.setAction || newsReviewWeekSetActionToken(item),
          );
          const reportCount =
            Math.max(0, Number.parseInt(String(item?.reportCount || 0), 10)) || 0;
          const requiredReports = weeklyMinimumNewsReports();
          const tr = document.createElement("tr");
          tr.innerHTML = `
          <td>${escapeHtml(formatPortalWeekRange(item?.weekStart, item?.weekEnd))}</td>
          <td>${escapeHtml(
            item?.fullName || item?.student?.fullName || "(student)",
          )}</td>
          <td>${escapeHtml(
            item?.eaglesId || item?.student?.eaglesId || item?.studentRefId || "",
          )}</td>
          <td>${escapeHtml(
            fullLevelLabel(resolveSystemLevelName(item?.level || "")),
          )}</td>
          <td>${reportCount}/${requiredReports}</td>
          <td>${newsReviewStatusChipHtml(setStatus)}</td>
          <td>${newsReviewSetActionChipHtml(setAction)}</td>
        `;
          rowsEl.appendChild(tr);
        });
      }

      async function loadIncomingExerciseResults({
        showAll = state.incomingExerciseQueue.showAll,
      } = {}) {
        if (!canReviewIncomingExerciseQueue()) {
          renderOverviewIncomingExerciseSection({
            total: 0,
            hasMore: false,
            statuses: [],
            items: [],
          });
          return;
        }
        const nextShowAll = Boolean(showAll);
        state.incomingExerciseQueue.showAll = nextShowAll;
        const take = nextShowAll ? 500 : 10;
        let result = null;
        try {
          result = await api(
            `${ADMIN_INCOMING_EXERCISE_RESULTS_PATH}?take=${encodeURIComponent(String(take))}&showAll=${nextShowAll ? "1" : "0"}`,
          );
        } catch (error) {
          if (!(error && error.status === 404)) throw error;
        }
        state.incomingExerciseQueue.items =
          Array.isArray(result?.items) ?
            result.items.map((entry) => normalizeIncomingExerciseItemForUi(entry))
          : [];
        state.incomingExerciseQueue.total =
          Number(result?.total || state.incomingExerciseQueue.items.length) || 0;
        state.incomingExerciseQueue.hasMore = Boolean(result?.hasMore);
        state.incomingExerciseQueue.statuses =
          Array.isArray(result?.statuses) ?
            result.statuses.map((entry) => normalizeText(entry)).filter(Boolean)
          : [];
        renderOverviewIncomingExerciseSection({
          total: state.incomingExerciseQueue.total,
          hasMore: state.incomingExerciseQueue.hasMore,
          statuses: state.incomingExerciseQueue.statuses,
          items: state.incomingExerciseQueue.items,
        });
      }

      function queueHubItemByPanelIndex(panelId = "", rowIndex = 0) {
        return queueHubIsland?.itemAt(panelId, rowIndex) || null;
      }

      async function openQueueHubItem(panelId = "", rowIndex = 0) {
        const id = normalizeText(panelId);
        const item = queueHubItemByPanelIndex(id, rowIndex);
        if (!id || !item) throw new Error("Queue item not found.");

        if (id === "queued-performance-reports") {
          await loadParentReportQueue({ showAll: true });
          setActivePage("parent-tracking");
          const queueIndex = state.parentReportQueue.items.findIndex(
            (entry) => normalizeText(entry?.id) === normalizeText(item?.id),
          );
          if (queueIndex >= 0) {
            openParentQueueModal(queueIndex);
            setStatus("Opened queued performance report details.");
          } else {
            setStatus(
              "Queued report detail was not found in current queue data.",
              true,
            );
          }
          return;
        }

        if (id === "unmatched-exercise-submissions") {
          await loadIncomingExerciseResults({ showAll: true });
          setActivePage("overview");
          const detailsEl = document.getElementById("overviewIncomingExerciseDetails");
          if (detailsEl) detailsEl.open = true;
          setStatus("Opened unmatched exercise submission details.");
          return;
        }

        if (id === "current-assignments-pending") {
          setActivePage("overview");
          openLevelDetailPanel(item);
          setStatus("Opened current-assignment detail panel.");
          return;
        }

        if (id === "overdue-homework") {
          const studentRefId = normalizeText(item?.studentRefId);
          if (!studentRefId)
            throw new Error(
              "Student detail is unavailable for this overdue homework row.",
            );
          await loadStudentDetail(studentRefId);
          setActivePage("assignments-data");
          setStatus("Opened overdue-homework student details.");
          return;
        }

        if (id === "attendance-risk") {
          const studentRefId = normalizeText(item?.studentRefId);
          if (!studentRefId)
            throw new Error(
              "Student detail is unavailable for this attendance-risk row.",
            );
          await loadStudentDetail(studentRefId);
          setActivePage("attendance-admin");
          setStatus("Opened attendance-risk student details.");
          return;
        }

        if (id === "news-report-review") {
          const weekSetId = normalizeText(item?.id);
          const reportId = normalizeText(item?.latestReportId || item?.id);
          const studentRefId = normalizeText(item?.studentRefId);
          const weekStart = normalizeText(item?.weekStart);
          const weekEnd = normalizeText(item?.weekEnd);
          setActivePage("news-reports");
          setNewsReviewFilterValues({
            status: "all",
            setAction: "all",
            studentRefId,
            dateFrom: weekStart,
            dateTo: weekEnd,
          });
          await loadNewsReviewQueue({ notify: false });
          if (weekSetId) {
            await openNewsReviewViewerByWeekSetId(weekSetId, {
              loadAll: true,
              reportId,
            });
            setStatus("Opened student news report viewer.");
          } else {
            setStatus(
              "News review queue opened. No week-set id was provided for this row.",
              true,
            );
          }
          return;
        }

        if (id === "pending-profile-submissions") {
          const studentRefId = normalizeText(item?.studentRefId);
          if (studentRefId) await loadStudentDetail(studentRefId);
          setActivePage("family");
          setStatus("Opened pending profile submission context.");
          return;
        }

        setStatus("Queue detail open is not configured for this panel.", true);
      }

      function canReviewParentQueue() {
        return currentRoleName() === "admin" || canManageUsers();
      }

      function normalizeQueueItemForUi(item = {}) {
        const payloadJson =
          item?.payloadJson && typeof item.payloadJson === "object" ?
            item.payloadJson
          : null;
        const parsedEaglesId =
          normalizeText(
            item.eaglesId ||
              payloadJson?.eaglesId ||
              payloadJson?.student?.eaglesId ||
              payloadJson?.studentRef?.eaglesId ||
              extractEaglesIdFromText(item.message || payloadJson?.message || ""),
          );
        return {
          id: normalizeText(item.id),
          queueType: normalizeText(item.queueType),
          status: normalizeText(item.status),
          assignmentTitle: normalizeText(item.assignmentTitle),
          exerciseTitle: normalizeText(item.exerciseTitle),
          level: normalizeText(item.level),
          dueAt: normalizeText(item.dueAt),
          message: normalizeText(item.message),
          recipients:
            Array.isArray(item.recipients) ?
              item.recipients.map((entry) => normalizeText(entry)).filter(Boolean)
            : [],
          queuedByUsername: normalizeText(item.queuedByUsername),
          reviewedByUsername: normalizeText(item.reviewedByUsername),
          queuedAt: normalizeText(item.queuedAt),
          scheduledFor: normalizeText(item.scheduledFor),
          sentAt: normalizeText(item.sentAt),
          attempts: Number.parseInt(String(item.attempts || 0), 10) || 0,
          lastError: normalizeText(item.lastError),
          payloadJson,
          teacherName: normalizeText(
            item.teacherName ||
              payloadJson?.metaPayload?.teacherName ||
              payloadJson?.teacherName ||
              item.queuedByUsername ||
              "",
          ),
          eaglesId: parsedEaglesId,
          linkedReportId: normalizeText(payloadJson?.reportId),
          linkedStudentRefId: normalizeText(payloadJson?.studentRefId),
          studentReviewedAt:
            normalizeText(item.studentReviewedAt || payloadJson?.studentReviewedAt),
          studentReviewedByUsername: normalizeText(
            item.studentReviewedByUsername || payloadJson?.studentReviewedByUsername,
          ),
          parentReviewedAt:
            normalizeText(item.parentReviewedAt || payloadJson?.parentReviewedAt),
          parentReviewedByUsername: normalizeText(
            item.parentReviewedByUsername || payloadJson?.parentReviewedByUsername,
          ),
        };
      }

      function queueItemForReportId(reportId = "") {
        const id = normalizeText(reportId);
        if (!id) return null;
        const items =
          Array.isArray(state.parentReportQueue?.items) ?
            state.parentReportQueue.items
          : [];
        return items.find((item) => normalizeText(item?.linkedReportId) === id) || null;
      }

      function setParentQueueModalStatus(message, isError = false) {
        const statusEl = document.getElementById("parentQueueModalStatus");
        if (!statusEl) return;
        statusEl.style.color = isError ? "#b3262d" : "var(--portal-status-muted-text)";
        statusEl.textContent =
          normalizeText(message) || "Review queued performance reports before sending.";
      }

      function queueItemByModalIndex(index = state.parentReportQueue.modalIndex) {
        const list =
          Array.isArray(state.parentReportQueue?.items) ?
            state.parentReportQueue.items
          : [];
        if (!list.length) return null;
        const idx = Math.max(0, Math.min(Number(index) || 0, list.length - 1));
        return list[idx] || null;
      }

      function queueItemReportId(item = {}) {
        return normalizeText(
          item?.linkedReportId ||
            item?.payloadJson?.reportId ||
            item?.id,
        );
      }

      function setQueuedPerformanceReportId(reportId = "", queued = true) {
        const id = normalizeText(reportId);
        if (!id) return;
        const next = {
          ...(state.parentReportQueue?.queuedReportIds || {}),
        };
        if (queued) next[id] = true;
        else delete next[id];
        state.parentReportQueue.queuedReportIds = next;
      }

      function queuedPerformanceReportIdState() {
        const source =
          state.parentReportQueue &&
          state.parentReportQueue.queuedReportIds &&
          typeof state.parentReportQueue.queuedReportIds === "object" ?
            state.parentReportQueue.queuedReportIds
          : {};
        state.parentReportQueue.queuedReportIds = source;
        return source;
      }

      function parentQueueSelectionState() {
        const selectedIds =
          state.parentReportQueue && state.parentReportQueue.selectedIds && typeof state.parentReportQueue.selectedIds === "object" ?
            state.parentReportQueue.selectedIds
          : {};
        state.parentReportQueue.selectedIds = selectedIds;
        return selectedIds;
      }

      function isParentQueueItemSelected(queueId = "") {
        const id = normalizeText(queueId);
        if (!id) return false;
        return Boolean(parentQueueSelectionState()[id]);
      }

      function setParentQueueItemSelected(queueId = "", selected = false) {
        const id = normalizeText(queueId);
        if (!id) return;
        const selectedIds = { ...parentQueueSelectionState() };
        if (selected) selectedIds[id] = true;
        else delete selectedIds[id];
        state.parentReportQueue.selectedIds = selectedIds;
      }

      function clearParentQueueSelection() {
        state.parentReportQueue.selectedIds = {};
      }

      function selectedParentQueueItems() {
        const items = Array.isArray(state.parentReportQueue?.items) ? state.parentReportQueue.items : [];
        return items.filter((item) => isParentQueueItemSelected(item.id));
      }

      function setParentQueueSelectionForVisibleRows(selected = false, visibleItems = []) {
        const items = Array.isArray(visibleItems) ? visibleItems : [];
        items.forEach((item) => setParentQueueItemSelected(item.id, selected));
      }

      function updateParentQueueSelectAllState(visibleItems = []) {
        const selectAllEl = document.getElementById("performanceQueueSelectAll");
        if (!(selectAllEl instanceof HTMLInputElement)) return;
        const items = Array.isArray(visibleItems) ? visibleItems : [];
        const selectedCount = items.filter((item) => isParentQueueItemSelected(item.id)).length;
        selectAllEl.disabled = !items.length;
        selectAllEl.checked = Boolean(items.length && selectedCount === items.length);
        selectAllEl.indeterminate = Boolean(selectedCount > 0 && selectedCount < items.length);
      }

      async function updateQueuedPerformanceReportHold(queueId = "", nextHeld = false) {
        const id = normalizeText(queueId);
        if (!id) throw new Error("Select a queued report item first.");
        const action = nextHeld ? "hold" : "requeue";
        const result = await api(ADMIN_NOTIFY_BATCH_STATUS_PATH, {
          method: "POST",
          body: {
            action,
            queueId: id,
            queueType: "parent-report",
          },
        });
        await loadParentReportQueue({ showAll: state.parentReportQueue.showAll });
        const latest = result?.item ? normalizeQueueItemForUi(result.item) : null;
        if (latest) {
          const idx = state.parentReportQueue.items.findIndex(
            (entry) => entry.id === latest.id,
          );
          state.parentReportQueue.modalIndex = idx >= 0 ? idx : 0;
        }
        const modal = document.getElementById("parentQueueModal");
        if (modal && !modal.classList.contains("hidden")) renderParentQueueModal();
        const statusMessage =
          nextHeld ? "Queued performance report moved to hold." : "Queued performance report released from hold.";
        setParentQueueModalStatus(
          nextHeld ? "Queue item placed on hold." : "Queue item released from hold.",
        );
        setStatus(statusMessage);
      }

      function buildAdminReportCardPreviewUrl(item = {}) {
        const reportId = queueItemReportId(item);
        const queueId = normalizeText(item?.id);
        const studentRefId = normalizeText(item?.linkedStudentRefId || item?.payloadJson?.studentRefId);
        const className = normalizeText(item?.level || item?.payloadJson?.className || item?.payloadJson?.metaPayload?.className);
        const schoolYear = normalizeText(item?.payloadJson?.schoolYear || item?.payloadJson?.metaPayload?.schoolYear);
        const quarter = normalizeText(item?.payloadJson?.quarter || item?.payloadJson?.metaPayload?.quarter);
        const targetUrl =
          window.location.protocol.startsWith("http") ?
            new URL("/admin/report-card-preview", window.location.origin)
          : new URL("report-card-preview", window.location.href);
        const params = targetUrl.searchParams;
        if (shouldPreserveAdminApiOriginParam())
          params.set("apiOrigin", ADMIN_API_ORIGIN);
        if (studentRefId) params.set("studentRefId", studentRefId);
        if (className) params.set("className", className);
        if (schoolYear) params.set("schoolYear", schoolYear);
        if (quarter) params.set("quarter", quarter);
        if (reportId) params.set("reportId", reportId);
        if (queueId) params.set("queueId", queueId);
        targetUrl.search = params.toString();
        return `${targetUrl.pathname}${targetUrl.search}${targetUrl.hash}`;
      }

      function persistQueuedReportCardSnapshot(item = {}) {
        const queueId = normalizeText(item?.id);
        const snapshot = queueItemReportCardSnapshot(item);
        if (!queueId || !snapshot) return;
        void window.SIS_PORTAL_PREFERENCES?.save(`sis.reportCardPreview.${queueId}`, snapshot);
      }

      function incomingPerformanceRows(rows = []) {
        const queuedReportIds = new Set([
          ...Object.keys(queuedPerformanceReportIdState()),
          ...state.parentReportQueue.items
            .map((item) => queueItemReportId(item))
            .filter(Boolean),
        ]);
        return (Array.isArray(rows) ? rows : []).filter((row) => {
          if (!row || typeof row !== "object") return false;
          if (isPerformanceReportHeld(row.id)) return true;
          if (row.id && queuedReportIds.has(normalizeText(row.id))) return false;
          const workflowState = normalizeText(row.workflowState).toLowerCase();
          return (
            workflowState === "submitted_for_admin_review"
            || workflowState === "incoming_admin_review"
            || workflowState === "awaiting_admin_approval"
          );
        });
      }

      function queueItemStudentName(item = {}) {
        const payloadStudent = item?.payloadJson?.student || {};
        return normalizeText(
          payloadStudent?.fullName ||
            payloadStudent?.englishName ||
            item?.fullName ||
            item?.assignmentTitle ||
            item?.exerciseTitle ||
            item?.eaglesId ||
            "",
        );
      }

      function queueItemStudentEnglishName(item = {}) {
        const payloadStudent = item?.payloadJson?.student || {};
        return normalizeText(
          payloadStudent?.englishName ||
            item?.englishName ||
            payloadStudent?.fullName ||
            "",
        );
      }

      function queueItemReportCardSnapshot(item = {}) {
        const payload = item?.payloadJson && typeof item.payloadJson === "object" ? item.payloadJson : {};
        return payload?.reportSnapshot && typeof payload.reportSnapshot === "object" ? payload.reportSnapshot : null;
      }

      function setQueueItemReportCardSnapshot(item = {}, snapshot = null) {
        if (!item || typeof item !== "object" || !snapshot || typeof snapshot !== "object")
          return;
        if (!item.payloadJson || typeof item.payloadJson !== "object")
          item.payloadJson = {};
        item.payloadJson.reportSnapshot = snapshot;
      }

      function reportCardSnapshotNeedsHydration(report = null) {
        if (!report || typeof report !== "object") return true;
        const metrics = report?.metrics && typeof report.metrics === "object" ? report.metrics : null;
        const rubricRows =
          report?.rubric && Array.isArray(report.rubric.rows) ? report.rubric.rows : [];
        if (!metrics) return true;
        if (!normalizeText(metrics.teacherName) && !normalizeText(metrics.lessonSummary))
          return true;
        if (rubricRows.length < 10) return true;
        if (Number.parseInt(String(report?.snapshot?.schemaVersion || 0), 10) < 2) return true;
        return false;
      }

      async function hydrateQueueItemReportCardSnapshot(item = {}) {
        const studentRefId = normalizeText(
          item?.linkedStudentRefId || item?.payloadJson?.studentRefId,
        );
        const reportId = queueItemReportId(item);
        if (!studentRefId || !reportId) return queueItemReportCardSnapshot(item);
        const nextSnapshot = await fetchPerformanceReportCardSnapshot(studentRefId, {
          className: normalizeText(
            item?.payloadJson?.className ||
              item?.payloadJson?.metaPayload?.className ||
              item?.exerciseTitle ||
              item?.level,
          ),
          schoolYear: normalizeText(
            item?.payloadJson?.schoolYear || item?.payloadJson?.metaPayload?.schoolYear,
          ),
          quarter: normalizeText(
            item?.payloadJson?.quarter || item?.payloadJson?.metaPayload?.quarter,
          ),
          reportId,
        }).catch(() => null);
        if (!nextSnapshot) return queueItemReportCardSnapshot(item);
        setQueueItemReportCardSnapshot(item, nextSnapshot);
        persistQueuedReportCardSnapshot(item);
        return nextSnapshot;
      }

      function queueReportCardSectionLines(title = "", payload = {}) {
        const lines = [title];
        const add = (label, value) => {
          lines.push(`${label}: ${normalizeText(value) || "-"}`);
        };
        add("Title", payload?.title || payload?.assignmentName || payload?.name);
        add("Subject", payload?.subject || payload?.className || payload?.course);
        add("Teacher", payload?.teacher || payload?.owner || payload?.assignee);
        add("Note", payload?.note || payload?.summary || payload?.description);
        add("Assignments", payload?.assignmentsCount ?? payload?.assignmentCount);
        add("Exercises", payload?.exercisesCount ?? payload?.exerciseCount);
        if (Array.isArray(payload?.exercises) && payload.exercises.length) {
          payload.exercises.forEach((exercise, index) => {
            const titleText = normalizeText(exercise?.title || exercise?.name || exercise?.assignmentName) || "(untitled)";
            const detailText = normalizeText(exercise?.detail || exercise?.note || exercise?.description);
            const statusText = normalizeText(exercise?.status || exercise?.state || "");
            lines.push(
              `${index + 1}. ${titleText}${statusText ? ` | ${statusText}` : ""}${detailText ? ` | ${detailText}` : ""}`,
            );
          });
        }
        return lines;
      }

      function queueReportCardRubricLines(report = {}) {
        const rubric = report?.rubric && typeof report.rubric === "object" ? report.rubric : {};
        const rows = Array.isArray(rubric?.rows) ? rubric.rows : [];
        if (!rows.length) return ["Rubric: none"];
        return [
          "Rubric:",
          ...rows.map((row, index) => {
            const prompt = normalizeText(row?.prompt || row?.metric || row?.title) || `Row ${index + 1}`;
            const score = normalizeText(row?.resultScore || row?.observedResult || row?.result || row?.observed) || "-";
            const explanation = normalizeText(row?.resultExplanation || row?.detail || row?.summary || row?.interpretation);
            const recommendation = normalizeText(row?.recommendation || row?.actionNote || row?.action || row?.note) || "-";
            return `${index + 1}. ${prompt} | rating=${score}${explanation ? ` | meaning=${explanation}` : ""} | comment=${recommendation}`;
          }),
        ];
      }

      function normalizeAttendanceSummary(attendanceReport = {}, report = {}) {
        const source = attendanceReport && typeof attendanceReport === "object" ? attendanceReport : {};
        const total = source.total ?? report.attendanceTotal ?? report.totalAttendance ?? null;
        const absences =
          source.absences ??
          source.absenceCount ??
          report.absenceCount ??
          report.absences ??
          report.absentCount ??
          null;
        const tardy =
          source.tardy ??
          source.tardyCount ??
          report.tardyCount ??
          report.tardy ??
          null;
        const attendancePercent =
          source.percent ??
          source.rate ??
          source.attendanceRate ??
          source.attendancePercent ??
          report.attendanceRate ??
          report.attendancePercent ??
          null;
        return { total, absences, tardy, attendancePercent };
      }

      function reportCardSnapshotText(report = {}) {
        if (!report || typeof report !== "object") return "";
        const identity = report?.identity && typeof report.identity === "object" ? report.identity : {};
        const scope = report?.scope && typeof report.scope === "object" ? report.scope : {};
        const snapshot = report?.snapshot && typeof report.snapshot === "object" ? report.snapshot : {};
        const attendance = normalizeAttendanceSummary(report?.attendance, report);
        const metrics = report?.metrics && typeof report.metrics === "object" ? report.metrics : {};
        const currentHomework = report?.currentHomework && typeof report.currentHomework === "object" ? report.currentHomework : {};
        const pastDueHomework = report?.pastDueHomework && typeof report.pastDueHomework === "object" ? report.pastDueHomework : {};
        const parentReview = report?.parentReview && typeof report.parentReview === "object" ? report.parentReview : {};
        const studentReview = report?.studentReview && typeof report.studentReview === "object" ? report.studentReview : {};
        return [
          "Report Card Snapshot",
          `Snapshot ID: ${normalizeText(snapshot.reportId) || "-"}`,
          `Snapshot source: ${normalizeText(snapshot.source) || "-"}`,
          `Captured at: ${normalizeText(snapshot.capturedAtDisplay || snapshot.capturedAt) || "-"}`,
          `Approved at: ${normalizeText(snapshot.approvedAtDisplay || snapshot.approvedAt) || "-"}`,
          `Student: ${normalizeText(identity.fullName) || "-"}`,
          `English name: ${normalizeText(identity.englishName) || "-"}`,
          `Eagles ID: ${normalizeText(identity.eaglesId) || "-"}`,
          `Student number: ${normalizeText(identity.studentNumber) || "-"}`,
          `Scope: ${[
            normalizeText(scope.className) || normalizeText(snapshot.className),
            normalizeText(scope.schoolYear) || normalizeText(snapshot.schoolYear),
            normalizeText(scope.quarter) || normalizeText(snapshot.quarter),
          ].filter(Boolean).join(" | ") || "-"}`,
          `Attendance: total=${normalizeText(attendance.total) || "-"} | absences=${normalizeText(attendance.absences) || "-"} | tardy=${normalizeText(attendance.tardy) || "-"} | percent=${normalizeText(attendance.attendancePercent) || "-"}`,
          `Metrics: homework completion=${normalizeText(metrics.homeworkCompletionRate) || "-"} | homework on-time=${normalizeText(metrics.homeworkOnTimeRate) || "-"} | behavior=${normalizeText(metrics.behaviorScore) || "-"} | skills=${normalizeText(metrics.participationScore) || "-"} | academic=${normalizeText(metrics.inClassScore) || "-"} | participation points=${normalizeText(metrics.participationPointsAward) || "-"}`,
          `Teacher snapshot: teacher=${normalizeText(metrics.teacherName) || "-"} | lesson=${normalizeText(metrics.lessonSummary) || "-"} | vision=${normalizeText(metrics.visionStatus) || "-"} | comment=${normalizeText(metrics.teacherComment) || "-"}`,
          "",
          ...queueReportCardSectionLines("Current homework:", currentHomework),
          "",
          ...queueReportCardSectionLines("Past due homework:", pastDueHomework),
          "",
          ...queueReportCardRubricLines(report),
          "",
          `Parent review: ${normalizeText(parentReview.reviewedBy) || "-"} | ${normalizeText(parentReview.reviewedAt) || "-"}`,
          `Student review: ${normalizeText(studentReview.reviewedBy) || "-"} | ${normalizeText(studentReview.reviewedAt) || "-"}`,
        ]
          .filter((line, index, lines) => line !== "" || lines[index - 1] !== "")
          .join("\n");
      }

      function parentReportTeacherCommentFromSnapshot(report = null) {
        if (!report || typeof report !== "object") return "";
        const metrics =
          report?.metrics && typeof report.metrics === "object" ? report.metrics : {};
        return normalizeText(metrics.teacherComment);
      }

      function setParentReportTeacherCommentInSnapshot(report = null, teacherComment = "") {
        if (!report || typeof report !== "object") return null;
        const nextComment = normalizeText(teacherComment);
        const nextMetrics =
          report?.metrics && typeof report.metrics === "object" ?
            { ...report.metrics }
          : {};
        nextMetrics.teacherComment = nextComment || "-";
        return {
          ...report,
          metrics: nextMetrics,
        };
      }

      function parentReportEmailBodyFromSnapshot(report = null) {
        return normalizeText(reportCardSnapshotText(report));
      }

      function buildAdminReportCardPreviewUrlFromReportRow(row = {}) {
        if (!row || typeof row !== "object") return "";
        const targetUrl =
          window.location.protocol.startsWith("http") ?
            new URL("/admin/report-card-preview", window.location.origin)
          : new URL("report-card-preview", window.location.href);
        const params = targetUrl.searchParams;
        if (shouldPreserveAdminApiOriginParam())
          params.set("apiOrigin", ADMIN_API_ORIGIN);
        const studentRefId = normalizeText(row.studentRefId);
        const className = normalizeText(row.className);
        const schoolYear = normalizeText(row.schoolYear);
        const quarter = normalizeText(row.quarter);
        const reportId = normalizeText(row.id);
        if (studentRefId) params.set("studentRefId", studentRefId);
        if (className) params.set("className", className);
        if (schoolYear) params.set("schoolYear", schoolYear);
        if (quarter) params.set("quarter", quarter);
        if (reportId) params.set("reportId", reportId);
        targetUrl.search = params.toString();
        return `${targetUrl.pathname}${targetUrl.search}${targetUrl.hash}`;
      }

      function queueTextOrDash(value = "") {
        return normalizeText(value) || "-";
      }

      function queueScoreDescription(scoreValue = "") {
        const text = normalizeText(scoreValue);
        if (!text) return "not yet scored";
        const score = Number.parseInt(text, 10);
        if (!Number.isFinite(score)) return text;
        switch (Math.max(0, Math.min(5, score))) {
          case 0:
            return "not yet observed";
          case 1:
            return "just beginning";
          case 2:
            return "emerging with support";
          case 3:
            return "developing";
          case 4:
            return "usually secure";
          case 5:
            return "consistently mastered";
          default:
            return "not yet scored";
        }
      }

      function queueRatingSummary(scoreValue = "") {
        const text = normalizeText(scoreValue);
        if (!text) return "-";
        return `${text}/5`;
      }

      function queueRatingDetail(scoreValue = "") {
        const text = normalizeText(scoreValue);
        if (!text) return "-";
        return `${text}/5 - ${queueScoreDescription(text)}. This is a progress marker, not a good/bad judgment.`;
      }

      function queueItemEaglesId(item = {}) {
        const payload = item?.payloadJson && typeof item.payloadJson === "object" ? item.payloadJson : {};
        return normalizeText(
          item?.eaglesId ||
            payload?.eaglesId ||
            payload?.student?.eaglesId ||
            payload?.studentRef?.eaglesId ||
            extractEaglesIdFromText(item?.message || payload?.message || ""),
        );
      }

      function buildPerformanceDataUrl(eaglesId = "") {
        const targetUrl =
          window.location.protocol.startsWith("http") ?
            new URL("/admin/performance-data", window.location.origin)
          : new URL("performance-data", window.location.href);
        const targetParams = targetUrl.searchParams;
        if (shouldPreserveAdminApiOriginParam())
          targetParams.set("apiOrigin", ADMIN_API_ORIGIN);
        const normalizedEaglesId = normalizeText(eaglesId);
        if (normalizedEaglesId) targetParams.set("eaglesId", normalizedEaglesId);
        targetUrl.search = targetParams.toString();
        return `${targetUrl.pathname}${targetUrl.search}${targetUrl.hash}`;
      }

      function renderParentQueueModal() {
        const item = queueItemByModalIndex();
        const indexEl = document.getElementById("parentQueueModalIndex");
        const prevBtn = document.getElementById("parentQueuePrevBtn");
        const nextBtn = document.getElementById("parentQueueNextBtn");
        const total =
          Array.isArray(state.parentReportQueue?.items) ?
            state.parentReportQueue.items.length
          : 0;
        if (!item || !total) {
          if (indexEl) indexEl.textContent = "0 / 0";
          if (prevBtn) prevBtn.disabled = true;
          if (nextBtn) nextBtn.disabled = true;
          return;
        }

        const currentIndex = Math.max(
          0,
          Math.min(state.parentReportQueue.modalIndex, total - 1),
        );
        state.parentReportQueue.modalIndex = currentIndex;
        if (indexEl) indexEl.textContent = `${currentIndex + 1} / ${total}`;
        if (prevBtn) prevBtn.disabled = currentIndex <= 0;
        if (nextBtn) nextBtn.disabled = currentIndex >= total - 1;

        const setValue = (id, value) => {
          const el = document.getElementById(id);
          if (el) el.value = value;
        };
        setValue("parentQueueItemId", item.id);
        setValue("parentQueueItemReportId", queueItemReportId(item));
        const reportPreviewLink = document.getElementById("parentQueueItemReportPreviewLink");
        if (reportPreviewLink instanceof HTMLAnchorElement) {
          persistQueuedReportCardSnapshot(item);
          const previewUrl = buildAdminReportCardPreviewUrl(item);
          if (previewUrl) {
            reportPreviewLink.hidden = false;
            reportPreviewLink.href = previewUrl;
          } else {
            reportPreviewLink.hidden = true;
            reportPreviewLink.removeAttribute("href");
          }
        }
        const eaglesId = queueItemEaglesId(item);
        setValue("parentQueueItemEaglesId", eaglesId);
        setValue("parentQueueItemStatus", item.status);
        const studentFullName = queueItemStudentName(item);
        const studentEnglishName = queueItemStudentEnglishName(item);
        setValue("parentQueueItemStudentName", studentFullName);
        setValue("parentQueueItemQueuedAt", formatDateTime(item.queuedAt));
        setValue("parentQueueItemScheduledFor", item.scheduledFor);
        setValue("parentQueueItemTitle", item.assignmentTitle);
        setValue("parentQueueItemLevel", item.level);
        setValue("parentQueueItemExercise", item.exerciseTitle);
        setValue("parentQueueItemStudentFullName", studentFullName);
        setValue("parentQueueItemStudentEnglishName", studentEnglishName);
        setValue(
          "parentQueueItemStudentIdentityLine",
          [
            eaglesId ? `Eagles ID: ${eaglesId}` : "",
            queueItemReportId(item) ? `Report ID: ${queueItemReportId(item)}` : "",
          ]
            .filter(Boolean)
            .join(" • "),
        );
        const eaglesDataLink = document.getElementById("parentQueueItemEaglesDataLink");
        if (eaglesDataLink instanceof HTMLAnchorElement) {
          if (eaglesId) {
            eaglesDataLink.hidden = false;
            eaglesDataLink.href = buildPerformanceDataUrl(eaglesId);
            eaglesDataLink.textContent = `Open performance data for ${eaglesId}`;
          } else {
            eaglesDataLink.hidden = true;
            eaglesDataLink.removeAttribute("href");
            eaglesDataLink.textContent = "Open performance data";
          }
        }
        const daySource = item.scheduledFor || item.queuedAt;
        const dayOfWeek = daySource ?
              new Date(daySource).toLocaleDateString("vi-VN", { weekday: "long", timeZone: FIXED_TIME_ZONE })
          : "";
        const summaryParts = [
          eaglesId ? `eaglesId=${eaglesId}` : "",
          dayOfWeek ? `day=${dayOfWeek}` : "",
          item.recipients.length ? `recipients=${item.recipients.join(", ")}` : "",
        ].filter(Boolean);
        setValue("parentQueueItemSummary", summaryParts.join("; "));
        setValue("parentQueueItemDueAt", item.dueAt);
        setValue("parentQueueItemQueuedBy", item.queuedByUsername);
        setValue("parentQueueItemHsReviewedAt", item.studentReviewedAt);
        setValue("parentQueueItemHsReviewedBy", item.studentReviewedByUsername);
        setValue("parentQueueItemCmReviewedAt", item.parentReviewedAt);
        setValue("parentQueueItemCmReviewedBy", item.parentReviewedByUsername);
        setValue("parentQueueItemRecipients", item.recipients.join(", "));
        setValue(
          "parentQueueItemMessage",
          parentReportTeacherCommentFromSnapshot(queueItemReportCardSnapshot(item)) || item.message,
        );
        setValue("parentQueueItemLastError", item.lastError);
        setParentQueueModalStatus("");
        if (reportCardSnapshotNeedsHydration(queueItemReportCardSnapshot(item))) {
          hydrateQueueItemReportCardSnapshot(item)
            .then((snapshot) => {
              if (!snapshot) return;
              const activeItem = queueItemByModalIndex();
              if (!activeItem || normalizeText(activeItem.id) !== normalizeText(item.id))
                return;
              setValue(
                "parentQueueItemMessage",
                parentReportTeacherCommentFromSnapshot(snapshot) || item.message,
              );
              const refreshedPreviewUrl = buildAdminReportCardPreviewUrl(item);
              if (reportPreviewLink instanceof HTMLAnchorElement && refreshedPreviewUrl) {
                reportPreviewLink.hidden = false;
                reportPreviewLink.href = refreshedPreviewUrl;
              }
            })
            .catch(() => {});
        }
      }

      function openParentQueueModal(index = 0) {
        const modal = document.getElementById("parentQueueModal");
        if (!modal) return;
        const total =
          Array.isArray(state.parentReportQueue?.items) ?
            state.parentReportQueue.items.length
          : 0;
        if (!total) return;
        state.parentReportQueue.modalIndex = Math.max(
          0,
          Math.min(Number(index) || 0, total - 1),
        );
        modal.classList.remove("hidden");
        renderParentQueueModal();
      }

      function closeParentQueueModal() {
        const modal = document.getElementById("parentQueueModal");
        if (!modal) return;
        modal.classList.add("hidden");
        state.parentReportQueue.modalIndex = -1;
        setParentQueueModalStatus("");
      }

      function normalizeStagedPerformanceRow(row = {}) {
        return {
          id: normalizeText(row.id),
          studentRefId: normalizeText(row.studentRefId),
          studentNumber: parsePositiveInteger(row.studentNumber),
          fullName: normalizeText(row.fullName),
          englishName: normalizeText(row.englishName),
          eaglesId: normalizeText(row.eaglesId),
          generatedAt: normalizeText(row.generatedAt),
          teacherName: normalizeText(row.teacherName || row.approvedByUsername),
          approvedAt: normalizeText(row.approvedAt),
          approvedByUsername: normalizeText(row.approvedByUsername),
          workflowState: normalizeText(row.workflowState),
          className: normalizeText(row.className),
          level: normalizeText(row.level || row.classLevel),
          schoolYear: normalizeText(row.schoolYear),
          quarter: normalizeText(row.quarter),
          behaviorScore: row.behaviorScore,
          participationScore: row.participationScore,
          inClassScore: row.inClassScore,
          participationPointsAward: row.participationPointsAward,
          homeworkOnTimeRate: row.homeworkOnTimeRate,
          homeworkCompletionRate: row.homeworkCompletionRate,
          comments: normalizeText(row.comments),
        };
      }

      function stagedRowsFromPerformanceRecords(rows = []) {
        const source = Array.isArray(rows) ? rows : [];
        const seen = new Set();
        const normalizedRows = [];
        source.forEach((row) => {
          const normalized = normalizeStagedPerformanceRow(row);
          if (!normalized.id || seen.has(normalized.id)) return;
          seen.add(normalized.id);
          normalizedRows.push(normalized);
        });
        return normalizedRows;
      }

      function renderPerformanceQueueSection(queueBlock = null) {
        const sectionEl = document.getElementById("performanceQueueSection");
        const detailsEl = document.getElementById("performanceQueueDetails");
        const summaryEl = document.getElementById("performanceQueueSummary");
        const rowsEl = document.getElementById("performanceQueueRows");
        const expandBtn = document.getElementById("performanceQueueExpandBtn");
        if (!sectionEl || !summaryEl || !rowsEl || !expandBtn) return;

        const adminCanReview = canReviewParentQueue();
        sectionEl.classList.toggle("hidden", !adminCanReview);
        if (!adminCanReview) return;

        const sourceItems =
          Array.isArray(queueBlock?.items) ?
            queueBlock.items
          : state.parentReportQueue.items;
        const normalizedItems = sourceItems.map((entry) =>
          normalizeQueueItemForUi(entry),
        );
        state.parentReportQueue.items = normalizedItems;
        state.parentReportQueue.queuedReportIds = Object.fromEntries(
          normalizedItems
            .map((item) => queueItemReportId(item))
            .filter(Boolean)
            .map((id) => [id, true]),
        );
        if (queueBlock && Number.isFinite(Number(queueBlock.total))) {
          state.parentReportQueue.total = Number(queueBlock.total) || 0;
        } else {
          state.parentReportQueue.total = normalizedItems.length;
        }
        if (queueBlock && typeof queueBlock.hasMore === "boolean") {
          state.parentReportQueue.hasMore = queueBlock.hasMore;
        } else {
          state.parentReportQueue.hasMore =
            state.parentReportQueue.total > normalizedItems.length;
        }

        const visibleCount = normalizedItems.length;
        const selectedCount = selectedParentQueueItems().length;
        summaryEl.textContent = `total=${state.parentReportQueue.total} | showing=${visibleCount} | selected=${selectedCount}`;
        expandBtn.textContent =
          state.parentReportQueue.showAll ? "Show First 10" : "Show All";
        if (detailsEl) detailsEl.open = true;

        rowsEl.innerHTML = "";
        if (!normalizedItems.length) {
          rowsEl.innerHTML =
            '<tr><td colspan="8">No queued performance reports.</td></tr>';
          updateParentQueueSelectAllState([]);
          return;
        }

        const queueApprovalLabel = (item = {}) => {
          const status = normalizeLower(item?.status);
          if (status === "queued") return "Approved / staged";
          if (status === "hold") return "On hold";
          if (status === "sent") return "Sent";
          if (!status) return "-";
          return normalizeText(status);
        };

        normalizedItems.forEach((item, index) => {
          const tr = document.createElement("tr");
          const hsYes = Boolean(normalizeText(item.studentReviewedAt));
          const cmYes = Boolean(normalizeText(item.parentReviewedAt));
          const eaglesId = normalizeText(item.eaglesId);
          const teacherName = normalizeText(item.teacherName || item.queuedByUsername || "-");
          const selected = isParentQueueItemSelected(item.id);
          const held = normalizeLower(item.status) === "hold";
          tr.innerHTML = `
          <td><input type="checkbox" name="performanceQueueSelect_${sanitizeDomIdPart(item.id)}" data-performance-queue-select="${escapeHtml(item.id)}"${selected ? " checked" : ""}></td>
          <td><label class="small" for="queue_hold_${sanitizeDomIdPart(item.id)}">Hold</label><input type="checkbox" id="queue_hold_${sanitizeDomIdPart(item.id)}" data-performance-queue-hold="${escapeHtml(item.id)}"${held ? " checked" : ""}></td>
          <td>${escapeHtml(formatDateTime(item.queuedAt))}</td>
          <td><a href="#" class="queue-row-link" data-queue-open="${escapeHtml(item.id)}">${escapeHtml(eaglesId || "(missing id)")}</a></td>
          <td>${escapeHtml(teacherName || "-")}</td>
          <td>${escapeHtml(queueApprovalLabel(item))}</td>
          <td>${escapeHtml(item.queuedByUsername || "-")}</td>
          <td class="hs-cm-cell">${hsYes ? '<span class="hs-cm-flag is-yes">HS: Y</span>' : '<span class="hs-cm-flag is-no">HS: N</span>'} / ${cmYes ? '<span class="hs-cm-flag is-yes">CM: Y</span>' : '<span class="hs-cm-flag is-no">CM: N</span>'}</td>
        `;
          tr.querySelector(`[data-performance-queue-select="${item.id}"]`)?.addEventListener("change", (event) => {
            const target = event.target;
            setParentQueueItemSelected(item.id, Boolean(target?.checked));
            updateParentQueueSelectAllState(normalizedItems);
            summaryEl.textContent = `total=${state.parentReportQueue.total} | showing=${visibleCount} | selected=${selectedParentQueueItems().length}`;
          });
          tr.querySelector(`[data-performance-queue-hold="${item.id}"]`)?.addEventListener("change", (event) => {
            const target = event.target;
            updateQueuedPerformanceReportHold(item.id, Boolean(target?.checked)).catch(handleError);
          });
          tr.querySelector(`[data-queue-open="${item.id}"]`)?.addEventListener("click", (event) => {
            event.preventDefault();
            openParentQueueModal(index);
          });
          rowsEl.appendChild(tr);
        });
        updateParentQueueSelectAllState(normalizedItems);
      }

      function renderPerformanceStagedSection(rows = null) {
        const sectionEl = document.getElementById("performanceStagedSection");
        const summaryEl = document.getElementById("performanceStagedSummary");
        const rowsEl = document.getElementById("performanceStagedRows");
        if (!sectionEl || !summaryEl || !rowsEl) return;

        const adminCanReview = canReviewParentQueue();
        sectionEl.classList.toggle("hidden", !adminCanReview);
        if (!adminCanReview) return;

        if (Array.isArray(rows))
          state.parentReportQueue.sourceRows = stagedRowsFromPerformanceRecords(rows);
        const sourceRows =
          Array.isArray(state.parentReportQueue.sourceRows) ?
            state.parentReportQueue.sourceRows
          : [];
        const queuedReportIds = new Set([
          ...Object.keys(queuedPerformanceReportIdState()),
          ...state.parentReportQueue.items
            .map((item) => queueItemReportId(item))
            .filter(Boolean),
        ]);
        const queuedByReportId = new Set(
          Array.from(queuedReportIds).filter(Boolean),
        );
        const stagedRows = sourceRows.filter(
          (row) => {
            const workflowState = normalizeText(row?.workflowState).toLowerCase();
            return (
              row.id
              && !queuedByReportId.has(normalizeText(row.id))
              && (
                workflowState === "submitted_for_admin_review"
                || workflowState === "incoming_admin_review"
                || workflowState === "awaiting_admin_approval"
              )
            );
          },
        );
        state.parentReportQueue.stagedRows = stagedRows;
        const savedCountHint = Math.max(
          0,
          Number(state.parentReportQueue.savedReportCountHint || 0) || 0,
        );
        const loadedSavedCount = sourceRows.length;
        const queuedCount = Math.max(
          0,
          Number(state.parentReportQueue.total || 0) || 0,
        );
        if (!loadedSavedCount && savedCountHint > 0) {
          summaryEl.textContent = `saved reports=${savedCountHint} | staged list pending data load | queued=${queuedCount}`;
        } else {
          summaryEl.textContent = `saved=${loadedSavedCount} | staged=${stagedRows.length} | queued=${queuedCount}`;
        }

        rowsEl.innerHTML = "";
        if (!stagedRows.length) {
          if (!loadedSavedCount && savedCountHint > 0) {
            const noun = savedCountHint === 1 ? "report is" : "reports are";
            rowsEl.innerHTML = `<tr><td colspan="6">${savedCountHint} saved performance ${noun} awaiting approval. Open Performance data and click Reload Staged.</td></tr>`;
          } else {
            rowsEl.innerHTML =
              '<tr><td colspan="6">No reports awaiting approval.</td></tr>';
          }
          return;
        }

        stagedRows.forEach((row) => {
          const pending = Boolean(
            state.parentReportQueue.pendingStageQueueById?.[row.id],
          );
          const tr = document.createElement("tr");
          const held = isPerformanceReportHeld(row.id);
          const workflowState = normalizeText(row.workflowState).toLowerCase();
          const actionLabel =
            workflowState === "awaiting_admin_approval" ?
              "Approve -> Queue"
            : workflowState === "incoming_admin_review" ?
              "Move to AAA"
            : "Start Admin Review";
          const reportStatus =
            held ? "On hold"
            : workflowState === "awaiting_admin_approval" ?
              "Awaiting Admin Approval"
            : workflowState === "incoming_admin_review" ?
              "Incoming Admin Review"
            : workflowState === "submitted_for_admin_review" ?
              "Submitted for Admin Review"
            : normalizeText(row.approvedAt) ?
              `Approved${normalizeText(row.approvedByUsername) ? ` by ${normalizeText(row.approvedByUsername)}` : ""}`
            : "Awaiting review";
          const previewUrl = buildAdminReportCardPreviewUrlFromReportRow(row);
          tr.innerHTML = `
          <td>${escapeHtml(formatDate(row.generatedAt) || "-")}</td>
          <td>${escapeHtml(row.eaglesId || "")}</td>
          <td>${escapeHtml(row.teacherName || "-")}</td>
          <td>${escapeHtml(reportStatus)}</td>
          <td><label class="small" for="stage_hold_${sanitizeDomIdPart(row.id)}">Hold</label><input type="checkbox" id="stage_hold_${sanitizeDomIdPart(row.id)}" name="stage_hold_${sanitizeDomIdPart(row.id)}" data-stage-hold="${escapeHtml(row.id)}"${held ? " checked" : ""}></td>
          <td>
            ${previewUrl ? `<a class="portal-button portal-button-info" href="${escapeHtml(previewUrl)}" target="_blank" rel="noopener noreferrer">Preview RC</a>` : ""}
            <button type="button" class="portal-button portal-button-affirm" data-stage-report-id="${escapeHtml(row.id)}"${pending ? " disabled" : ""}>${pending ? "Working..." : actionLabel}</button>
          </td>
        `;
          tr.querySelector(`[data-stage-hold="${row.id}"]`)?.addEventListener(
            "change",
            (event) => {
              const target = event.target;
              const nextHeld = Boolean(target?.checked);
              setPerformanceReportHeld(row.id, nextHeld);
              renderPerformanceStagedSection();
              setParentQueueModalStatus(
                nextHeld ? "Report placed on hold and kept in the approval list." : "Report released from hold.",
              );
              setStatus(
                nextHeld ? "Performance report held." : "Performance report released from hold.",
              );
            },
          );
          tr.querySelector(`[data-stage-report-id="${row.id}"]`)?.addEventListener(
            "click",
            () => {
              queueStagedPerformanceReport(row.id).catch(handleError);
            },
          );
          rowsEl.appendChild(tr);
        });
      }

      async function loadParentReportQueue({
        showAll = state.parentReportQueue.showAll,
      } = {}) {
        if (!canReviewParentQueue()) {
          renderPerformanceQueueSection({
            total: 0,
            hasMore: false,
            items: [],
          });
          renderPerformanceStagedSection();
          return;
        }
        const nextShowAll = Boolean(showAll);
        state.parentReportQueue.showAll = nextShowAll;
        const take = nextShowAll ? 500 : 10;
        let result = null;
        try {
          result = await api(
            `${ADMIN_NOTIFY_BATCH_STATUS_PATH}?queueType=parent-report&take=${encodeURIComponent(String(take))}&showAll=${nextShowAll ? "1" : "0"}`,
          );
        } catch (error) {
          if (!(error && error.status === 404)) throw error;
        }
        state.parentReportQueue.items =
          Array.isArray(result?.items) ?
            result.items.map((entry) => normalizeQueueItemForUi(entry))
          : [];
        const validIds = new Set(state.parentReportQueue.items.map((entry) => entry.id));
        state.parentReportQueue.selectedIds = Object.fromEntries(
          Object.entries(parentQueueSelectionState()).filter(([id]) => validIds.has(id)),
        );
        state.parentReportQueue.total =
          Number(result?.total || state.parentReportQueue.items.length) || 0;
        state.parentReportQueue.hasMore = Boolean(result?.hasMore);
        renderPerformanceQueueSection({
          total: state.parentReportQueue.total,
          hasMore: state.parentReportQueue.hasMore,
          items: state.parentReportQueue.items,
        });
        renderPerformanceStagedSection();
      }

      async function fetchPerformanceReportCardSnapshot(studentRefId = "", filters = {}) {
        const id = normalizeText(studentRefId);
        if (!id) return null;
        const apiOrigin = ADMIN_API_ORIGIN || window.location.origin;
        const targetUrl = new URL(`/api/admin/students/${encodeURIComponent(id)}/report-card.json`, apiOrigin);
        const className = normalizeText(filters?.className);
        const schoolYear = normalizeText(filters?.schoolYear);
        const quarter = normalizeText(filters?.quarter);
        const reportId = normalizeText(filters?.reportId);
        if (className) targetUrl.searchParams.set("className", className);
        if (schoolYear) targetUrl.searchParams.set("schoolYear", schoolYear);
        if (quarter) targetUrl.searchParams.set("quarter", quarter);
        if (reportId) targetUrl.searchParams.set("reportId", reportId);
        const response = await fetch(targetUrl.toString(), {
          credentials: "include",
          headers: { accept: "application/json" },
        });
        if (!response.ok) {
          throw new Error(`Unable to load report snapshot (${response.status})`);
        }
        return response.json();
      }

      async function queueStagedPerformanceReport(reportId = "") {
        if (!canReviewParentQueue())
          throw new Error("Only admin can approve staged performance reports.");
        const id = normalizeText(reportId);
        if (!id) throw new Error("Select a staged performance report first.");
        const stagedRow = (
          Array.isArray(state.parentReportQueue.stagedRows) ?
            state.parentReportQueue.stagedRows
          : []).find((row) => normalizeText(row?.id) === id);
        if (!stagedRow)
          throw new Error(
            "Staged performance report not found. Reload staged reports and try again.",
          );
        const studentRefId = normalizeText(stagedRow.studentRefId);
        if (!studentRefId) throw new Error("Staged report has no student reference.");
        if (state.parentReportQueue.pendingStageQueueById[id]) return;

        state.parentReportQueue.pendingStageQueueById[id] = true;
        renderPerformanceStagedSection();
        try {
          const workflowState = normalizeText(stagedRow.workflowState).toLowerCase();
          if (
            workflowState === "submitted_for_admin_review"
            || workflowState === "incoming_admin_review"
          ) {
            const action = workflowState === "submitted_for_admin_review" ? "start-review" : "stage";
            const stagedResult = await api(
              `/api/admin/students/${encodeURIComponent(studentRefId)}/reports/${encodeURIComponent(id)}/workflow`,
              {
                method: "POST",
                body: { action },
              },
            );
            if (stagedResult?.student?.id) {
              state.parentTracking.studentDetailsByStudentId[stagedResult.student.id] =
                stagedResult.student;
              state.currentStudent = stagedResult.student;
              fillStudentForm(state.currentStudent);
            }
            await loadParentReportQueue({ showAll: state.parentReportQueue.showAll });
            await loadDashboardSummary();
            if (
              normalizeText(state.parentTracking.selectedStudentId)
              === normalizeText(studentRefId)
            ) {
              await syncParentTrackingForSelection({});
            }
            setStatus(
              action === "start-review" ?
                "Performance report moved into incoming admin review."
              : "Performance report moved to Awaiting Admin Approval.",
            );
            return;
          }
          const detail = await ensureStudentDetailCached(studentRefId);
          const recipients = parentTrackingRecipientsForStudent(detail);
          const fullName = studentFullName(detail);
          const studentEaglesId = requiredEaglesId(
            detail?.eaglesId,
            "staged performance report",
          );
          requiredStudentNumber(detail?.studentNumber, "staged performance report");
          const className =
            normalizeText(stagedRow.className) ||
            fullLevelLabel(
              resolveSystemLevelName(
                stagedRow.level || detail?.profile?.currentGrade || "",
              ),
            );
          const level = resolveSystemLevelName(
            stagedRow.level || detail?.profile?.currentGrade || "",
          );
          const generatedDate =
            normalizeText(stagedRow.generatedAt).slice(0, 10) || localIsoDate();
          const reportSnapshot = await fetchPerformanceReportCardSnapshot(studentRefId, {
            className,
            schoolYear: stagedRow.schoolYear,
            quarter: stagedRow.quarter,
            reportId: id,
          }).catch(() => null);
          if (!reportSnapshot) {
            throw new Error("Unable to load the report card snapshot for this approval. Open Preview RC and retry.");
          }
          const messageBody = parentReportEmailBodyFromSnapshot(reportSnapshot);
          if (!messageBody) {
            throw new Error("Report card snapshot is empty. Queueing stopped.");
          }

          const approvalResult = await api(
            `/api/admin/students/${encodeURIComponent(studentRefId)}/reports/${encodeURIComponent(id)}/workflow`,
            {
              method: "POST",
              body: { action: "approve-publish" },
            },
          );
          if (approvalResult?.student?.id) {
            state.parentTracking.studentDetailsByStudentId[approvalResult.student.id] =
              approvalResult.student;
            if (state.currentStudent?.id === approvalResult.student.id) {
              state.currentStudent = approvalResult.student;
              fillStudentForm(state.currentStudent);
            }
          }

          await api(ADMIN_NOTIFY_EMAIL_PATH, {
            method: "POST",
            body: {
              deliveryMode: "weekend-batch",
              queueType: "parent-report",
              assignmentTitle: `${fullName || "student"} class report`,
              exerciseTitle: className,
              dueAt: generatedDate,
              level,
              message: messageBody,
              recipients,
              reportId: id,
              studentRefId,
              eaglesId: studentEaglesId,
              artifactVersion: normalizeText(
                approvalResult?.report?.finalArtifactVersion,
              ),
              requestOrigin: window.location.origin,
              className: normalizeText(stagedRow.className),
              schoolYear: normalizeText(stagedRow.schoolYear),
              quarter: normalizeText(stagedRow.quarter),
              participationPointsAward: normalizeText(
                stagedRow.participationPointsAward,
              ),
              reportSnapshot,
            },
          });
          setQueuedPerformanceReportId(id, true);
          await loadParentReportQueue({ showAll: state.parentReportQueue.showAll });
          setQueuedPerformanceReportId(id, true);
          await loadDashboardSummary();
          if (
            normalizeText(state.parentTracking.selectedStudentId)
            === normalizeText(studentRefId)
          ) {
            await syncParentTrackingForSelection({});
          }
          const recipientCount = recipients.length;
          setStatus(
            recipientCount > 0 ?
              `Final report approved, published, and queued (${recipientCount} recipients).`
            : "Final report approved, published, and queued with 0 recipients. Add emails in Queue Review.",
          );
        } finally {
          delete state.parentReportQueue.pendingStageQueueById[id];
          renderPerformanceStagedSection();
        }
      }

      async function sendSelectedQueuedParentReports() {
        if (!canReviewParentQueue())
          throw new Error("Only admin can send queued performance reports.");
        const selectedItems = selectedParentQueueItems().filter(
          (item) => normalizeLower(item?.status) === "queued",
        );
        if (!selectedItems.length) {
          throw new Error("Select one or more queued reports before sending.");
        }
        const result = await api(ADMIN_NOTIFY_BATCH_STATUS_PATH, {
          method: "POST",
          body: {
            action: "sendSelected",
            queueType: "parent-report",
            queueIds: selectedItems.map((item) => item.id),
          },
        });
        await loadParentReportQueue({ showAll: state.parentReportQueue.showAll });
        clearParentQueueSelection();
        setParentQueueModalStatus(
          `Send selected completed: sent=${result?.sent || 0}, failed=${result?.failed || 0}`,
        );
        setStatus(
          `Selected performance reports processed (sent=${result?.sent || 0}, failed=${result?.failed || 0}).`,
        );
        await loadDashboardSummary();
      }

      async function deleteSelectedQueuedParentReports() {
        if (!canManageUsers())
          throw new Error("Only admin can delete queued performance reports.");
        const selectedItems = selectedParentQueueItems().filter((item) => Boolean(item?.id));
        if (!selectedItems.length) {
          throw new Error("Select one or more queued reports before deleting.");
        }
        if (!window.confirm(`Delete ${selectedItems.length} selected queued report(s)?`)) return;
        await Promise.all(
          selectedItems.map((item) =>
            api(ADMIN_NOTIFY_BATCH_STATUS_PATH, {
              method: "POST",
              body: {
                action: "delete",
                queueId: item.id,
                queueType: "parent-report",
              },
            }),
          ),
        );
        clearParentQueueSelection();
        await loadParentReportQueue({ showAll: state.parentReportQueue.showAll });
        renderPerformanceStagedSection(state.visibleTableRows?.performance || []);
        setStatus(`Deleted queued performance reports (${selectedItems.length}).`);
      }

      async function unqueueSelectedQueuedParentReports() {
        if (!canManageUsers())
          throw new Error("Only admin can return queued performance reports to AAA.");
        const selectedItems = selectedParentQueueItems().filter((item) => Boolean(item?.id));
        if (!selectedItems.length) {
          throw new Error("Select one or more queued reports before un-queueing.");
        }
        if (!window.confirm(`Return ${selectedItems.length} selected queued report(s) to AAA?`)) return;
        await Promise.all(
          selectedItems.map((item) =>
            api(ADMIN_NOTIFY_BATCH_STATUS_PATH, {
              method: "POST",
              body: {
                action: "unqueue",
                queueId: item.id,
                queueType: "parent-report",
              },
            }),
          ),
        );
        clearParentQueueSelection();
        await loadParentReportQueue({ showAll: state.parentReportQueue.showAll });
        renderPerformanceStagedSection(state.visibleTableRows?.performance || []);
        setStatus(`Returned queued performance reports to AAA (${selectedItems.length}).`);
      }

      async function holdParentQueueModalItem() {
        const item = queueItemByModalIndex();
        if (!item?.id) throw new Error("Select a queued report item first.");
        const nextHeld = normalizeLower(item.status) !== "hold";
        await updateQueuedPerformanceReportHold(item.id, nextHeld);
      }

      async function editParentQueueModalItem() {
        const item = queueItemByModalIndex();
        if (!item?.id) throw new Error("Select a queued report item first.");
        const recipients = normalizeText(
          document.getElementById("parentQueueItemRecipients")?.value,
        )
          .split(",")
          .map((entry) => normalizeText(entry))
          .filter(Boolean);
        const existingSnapshot = queueItemReportCardSnapshot(item);
        const nextTeacherComment = normalizeText(
          document.getElementById("parentQueueItemMessage")?.value,
        );
        const nextSnapshot = setParentReportTeacherCommentInSnapshot(
          existingSnapshot,
          nextTeacherComment,
        );
        const nextMessageBody =
          nextSnapshot ? parentReportEmailBodyFromSnapshot(nextSnapshot) : nextTeacherComment;
        const result = await api(ADMIN_NOTIFY_BATCH_STATUS_PATH, {
          method: "POST",
          body: {
            action: "edit",
            queueId: item.id,
            queueType: "parent-report",
            assignmentTitle: normalizeText(
              document.getElementById("parentQueueItemTitle")?.value,
            ),
            exerciseTitle: normalizeText(
              document.getElementById("parentQueueItemExercise")?.value,
            ),
            level: normalizeText(
              document.getElementById("parentQueueItemLevel")?.value,
            ),
            dueAt: normalizeText(
              document.getElementById("parentQueueItemDueAt")?.value,
            ),
            scheduledFor: normalizeText(
              document.getElementById("parentQueueItemScheduledFor")?.value,
            ),
            message: nextMessageBody,
            recipients,
            status: "queued",
            studentReviewedAt: normalizeText(
              document.getElementById("parentQueueItemHsReviewedAt")?.value,
            ),
            studentReviewedByUsername: normalizeText(
              document.getElementById("parentQueueItemHsReviewedBy")?.value,
            ),
            parentReviewedAt: normalizeText(
              document.getElementById("parentQueueItemCmReviewedAt")?.value,
            ),
            parentReviewedByUsername: normalizeText(
              document.getElementById("parentQueueItemCmReviewedBy")?.value,
            ),
            payloadJson: nextSnapshot ? { reportSnapshot: nextSnapshot } : undefined,
          },
        });
        await loadParentReportQueue({ showAll: state.parentReportQueue.showAll });
        const latest = result?.item ? normalizeQueueItemForUi(result.item) : null;
        if (latest) {
          const idx = state.parentReportQueue.items.findIndex(
            (entry) => entry.id === latest.id,
          );
          state.parentReportQueue.modalIndex = idx >= 0 ? idx : 0;
        }
        renderParentQueueModal();
        setParentQueueModalStatus("Queue item updated.");
        setStatus("Queued performance report updated.");
      }

      async function requeueParentQueueModalItem() {
        const item = queueItemByModalIndex();
        if (!item?.id) throw new Error("Select a queued report item first.");
        const result = await api(ADMIN_NOTIFY_BATCH_STATUS_PATH, {
          method: "POST",
          body: {
            action: "requeue",
            queueId: item.id,
            queueType: "parent-report",
          },
        });
        await loadParentReportQueue({ showAll: state.parentReportQueue.showAll });
        const latest = result?.item ? normalizeQueueItemForUi(result.item) : null;
        if (latest) {
          const idx = state.parentReportQueue.items.findIndex(
            (entry) => entry.id === latest.id,
          );
          state.parentReportQueue.modalIndex = idx >= 0 ? idx : 0;
        }
        renderParentQueueModal();
        setParentQueueModalStatus("Queue item requeued.");
        setStatus("Queued performance report requeued.");
      }

      async function sendAllQueuedParentReports(queueIds = []) {
        if (!canReviewParentQueue())
          throw new Error("Only admin can send queued performance reports.");
        const selectedQueueIds = Array.isArray(queueIds) ?
          queueIds.map((entry) => normalizeText(entry)).filter(Boolean)
          : [];
        const result = await api(ADMIN_NOTIFY_BATCH_STATUS_PATH, {
          method: "POST",
          body: {
            action: selectedQueueIds.length ? "sendSelected" : "sendAll",
            queueType: "parent-report",
            queueIds: selectedQueueIds,
          },
        });
        await loadParentReportQueue({ showAll: state.parentReportQueue.showAll });
        clearParentQueueSelection();
        setParentQueueModalStatus(
          `${selectedQueueIds.length ? "Send selected" : "Send all"} completed: sent=${result?.sent || 0}, failed=${result?.failed || 0}`,
        );
        setStatus(
          `${selectedQueueIds.length ? "Selected" : "Queued"} performance reports processed (sent=${result?.sent || 0}, failed=${result?.failed || 0}).`,
        );
        await loadDashboardSummary();
      }

      async function loadDashboardSummary() {
        try {
          const summary = await api(ADMIN_DASHBOARD_PATH);
          if (
            !Array.isArray(summary?.levelCompletion) ||
            !summary.levelCompletion.length
          ) {
            const currentTemplates = Array.isArray(state.assignmentTemplates) ?
              state.assignmentTemplates
            : [];
            if (!currentTemplates.length) await loadAssignmentTemplatesFromServer();
          }
          state.dashboardSummary = summary || {};
          const effectiveCompletionRows = effectiveDashboardLevelCompletionRows(
            state.dashboardSummary,
          );
          state.dashboardLevelCompletionRows = effectiveCompletionRows;
          syncSystemLevelNames([
            ...effectiveCompletionRows.map((entry) =>
              normalizeLevelName(entry?.level || ""),
            ),
            ...(Array.isArray(state.dashboardSummary?.classEnrollmentAttendance) ?
              state.dashboardSummary.classEnrollmentAttendance
            : []
            ).map((entry) => normalizeLevelName(entry?.level || "")),
          ]);
        } catch (error) {
          if (error && error.status === 404) {
            state.dashboardSummary = buildFallbackDashboardSummary();
            state.dashboardLevelCompletionRows = effectiveDashboardLevelCompletionRows(
              state.dashboardSummary,
            );
            renderDashboardSummary(state.dashboardSummary);
            return;
          }
          throw error;
        }
        renderDashboardSummary(state.dashboardSummary);
      }

      async function loadDashboardStudents() {
        const data = await api("/api/admin/students?take=1000");
        const source = Array.isArray(data?.items) ? data.items : [];
        state.dashboardStudents = source.filter((student) => {
          if (!normalizeText(student?.eaglesId)) return false;
          if (
            hasStudentNumberKey(student) &&
            !parsePositiveInteger(student?.studentNumber)
          )
            return false;
          return true;
        });
        if (state.dashboardSummary) {
          state.dashboardLevelCompletionRows = effectiveDashboardLevelCompletionRows(
            state.dashboardSummary,
          );
        }
        syncSystemLevelNames(
          state.dashboardStudents.map((student) =>
            normalizeLevelName(student?.profile?.currentGrade || ""),
          ),
        );
        populateProfileLevelOptions();
        populateAssignmentLevelOptions();
        populateAttendanceLevelStyleOptions();
        refreshAllTableSearchFilterControls();
        syncAttendanceLevelEditorInputs();
        refreshAssignmentStudentOptions();
        renderTopSearchStudentOptions();
        updateTopSearchScopeHint();
        if (state.activePage === "attendance" || state.activePage === "attendance-admin") {
          await refreshAttendanceLanding({ reloadRows: true });
        }
        if (state.activePage === "parent-tracking") {
          await refreshParentTracking({ preserveStudentSelection: true });
        }
        if (state.dashboardSummary) renderDashboardSummary(state.dashboardSummary);
      }

      async function sendAssignmentAnnouncement() {
        const form = collectAssignmentForm();
        const title = form.assignmentTitle || form.exerciseTitle;
        if (!title) throw new Error("Assignment title or exercise title is required.");
        if (!form.items.length)
          throw new Error("Add at least one assignment item before sending.");

        const source = assignmentStudentSource();
        const targetLevel = normalizeAssignmentTargetLevel(form.level);
        const dueAt =
          form.dueAt || nextSundayIsoDate(form.assignedAt || localIsoDate());
        let recipients = [];

        if (form.eaglesId) {
          const selectedStudent = source.find(
            (entry) => normalizeText(entry.id) === form.eaglesId,
          );
          recipients = assignmentRecipientsForStudent(selectedStudent);
        } else if (targetLevel) {
          source.forEach((student) => {
            const studentLevel = resolveSystemLevelName(
              student?.profile?.currentGrade || "",
            );
            if (!levelNamesMatch(studentLevel, targetLevel)) return;
            recipients.push(...assignmentRecipientsForStudent(student));
          });
          recipients = Array.from(new Set(recipients));
        } else {
          throw new Error(
            "Select a target level or an individual student before sending.",
          );
        }

        if (!recipients.length) {
          throw new Error("No valid recipient email found for the selected target.");
        }

        const itemLines = form.items.map((entry, index) => {
          const titleText = normalizeText(entry.title);
          const urlText = normalizeText(entry.url);
          return `${index + 1}. ${titleText}${urlText ? ` - ${urlText}` : ""}`;
        });
        const messageBlocks = [];
        if (form.message) messageBlocks.push(form.message);
        messageBlocks.push(`Date assigned: ${form.assignedAt || localIsoDate()}`);
        messageBlocks.push(`Assignment items:\n${itemLines.join("\n")}`);
        const message = messageBlocks.filter(Boolean).join("\n\n");

        const result = await api(ADMIN_NOTIFY_EMAIL_PATH, {
          method: "POST",
          body: {
            assignmentTitle: title,
            exerciseTitle: form.exerciseTitle || form.items[0]?.title || "",
            dueAt,
            level: targetLevel,
            message,
            recipients,
          },
        });
        setAssignmentStatus(
          `Assignment email sent to ${result?.sent || recipients.length} recipients.`,
        );
        setStatus(
          `Assignment notification sent (${result?.sent || recipients.length} recipients).`,
        );
      }

      function applyReminderTemplate(templateText, context = {}) {
        const template = normalizeText(templateText);
        return template
          .replace(/\{\{\s*name\s*\}\}/gi, normalizeText(context.name))
          .replace(/\{\{\s*assignment\s*\}\}/gi, normalizeText(context.assignment))
          .replace(/\{\{\s*link\s*\}\}/gi, normalizeText(context.link))
          .replace(/\{\{\s*dueDate\s*\}\}/gi, normalizeText(context.dueDate))
          .replace(/\{\{\s*level\s*\}\}/gi, shortLevelLabel(context.level || ""));
      }

      function selectedReminderStudents(mode = "selected") {
        const detail = state.activeLevelDetail;
        if (!detail || !Array.isArray(detail.uncompletedStudents)) return [];
        if (mode === "all") return detail.uncompletedStudents;

        const selectedIds = new Set(
          Array.from(document.querySelectorAll("[data-remind-student]:checked"))
            .map((entry) => normalizeText(entry.getAttribute("data-remind-student")))
            .filter(Boolean),
        );
        return detail.uncompletedStudents.filter((entry) =>
          selectedIds.has(normalizeText(entry.studentRefId)),
        );
      }

      function clearLevelReminderForm() {
        const assignmentEl = document.getElementById("levelReminderAssignment");
        const linkEl = document.getElementById("levelReminderLink");
        const dueAtEl = document.getElementById("levelReminderDueAt");
        const modeEl = document.getElementById("levelReminderMode");
        const templateEl = document.getElementById("levelReminderTemplate");

        if (assignmentEl) assignmentEl.value = "";
        if (linkEl) linkEl.value = "";
        if (dueAtEl) dueAtEl.value = "";
        if (modeEl) modeEl.value = "selected";
        if (templateEl) templateEl.value = DEFAULT_LEVEL_REMINDER_TEMPLATE;

        Array.from(document.querySelectorAll("[data-remind-student]")).forEach(
          (entry, index) => {
            entry.checked = index < 5;
          },
        );
        setLevelDetailStatus("Reminder form cleared.");
      }

      async function sendLevelReminders(mode = "selected") {
        if (!state.activeLevelDetail) throw new Error("Open a level detail first.");
        const assignmentTitle = normalizeText(
          document.getElementById("levelReminderAssignment").value,
        );
        const assignmentLink = normalizeText(
          document.getElementById("levelReminderLink").value,
        );
        const dueDate = normalizeText(
          document.getElementById("levelReminderDueAt").value,
        );
        const template = normalizeText(
          document.getElementById("levelReminderTemplate").value,
        );
        if (!assignmentTitle) throw new Error("Reminder assignment title is required.");
        if (!template) throw new Error("Reminder message template is required.");

        const targets = selectedReminderStudents(mode);
        if (!targets.length) throw new Error("No reminder recipients selected.");

        let sent = 0;
        for (let i = 0; i < targets.length; i += 1) {
          const student = targets[i];
          if (!Array.isArray(student.emails) || !student.emails.length) continue;
          const personalized = applyReminderTemplate(template, {
            name: student.fullName,
            assignment: assignmentTitle,
            link: assignmentLink,
            dueDate: dueDate || student.nextDueAt || "",
            level: state.activeLevelDetail.level,
          });
          await api(ADMIN_NOTIFY_EMAIL_PATH, {
            method: "POST",
            body: {
              assignmentTitle,
              exerciseTitle: assignmentTitle,
              dueAt: dueDate || student.nextDueAt || "",
              level: state.activeLevelDetail.level,
              message: personalized,
              recipients: student.emails,
            },
          });
          sent += 1;
        }

        setLevelDetailStatus(`Reminders sent: ${sent}/${targets.length}`);
        setStatus(
          `Reminder emails sent for ${fullLevelLabel(state.activeLevelDetail.level)} (${sent} messages).`,
        );
      }

      function setParentTrackingStatus(message, isError = false) {
        const statusEl = document.getElementById("pt_status");
        if (!statusEl) return;
        statusEl.style.color = isError ? "#b3262d" : "var(--portal-status-muted-text)";
        statusEl.textContent =
          normalizeText(message) ||
          "Weekend batch windows: Sat/Sun at 12:00, 15:30, 18:00, 20:15.";
      }

      function setParentTrackingSaveNotice(message = "", isError = false, detail = "") {
        const noticeEl = document.getElementById("pt_saveNotice");
        if (!noticeEl) return;
        const text = normalizeText(message);
        if (!text) {
          noticeEl.classList.add("hidden");
          noticeEl.classList.remove("error");
          noticeEl.innerHTML = "";
          return;
        }
        const detailText = normalizeText(detail);
        const detailHtml =
          detailText ? `<span class="small">${escapeHtml(detailText)}</span>` : "";
        noticeEl.classList.remove("hidden");
        noticeEl.classList.toggle("error", Boolean(isError));
        noticeEl.innerHTML = `${escapeHtml(text)}${detailHtml}`;
      }

      const PARENT_TRACKING_SCORE_MIN = 0;
      const PARENT_TRACKING_SCORE_MAX = 5;
      const PARENT_TRACKING_SCORE_TOOLTIPS = Object.freeze({
        0: "0 = hiện không áp dụng cho học sinh.",
        1: "1 = thể hiện hành vi nếu được nhắc nhở trực tiếp",
        2: "2 = thể hiện hành vi nếu được nhắc nhở gián tiếp",
        3: "3 = thể hiện hành vi một cách độc lập dưới 50% thời gian",
        4: "4 = thể hiện hành vi một cách độc lập trên 50% thời gian",
        5: "5 = thể hiện hành vi một cách độc lập",
      });
      let parentTrackingScoreLegendBound = false;

      function parentTrackingScoreTooltip(value) {
        const normalized = normalizeParentTrackingScoreValue(value);
        if (!normalized) return "";
        return normalizeText(PARENT_TRACKING_SCORE_TOOLTIPS[normalized]);
      }

      function parentTrackingScoreLegendLines() {
        return Object.keys(PARENT_TRACKING_SCORE_TOOLTIPS)
          .map((entry) => Number.parseInt(String(entry), 10))
          .filter((entry) => Number.isFinite(entry))
          .sort((left, right) => left - right)
          .map((entry) =>
            normalizeText(
              PARENT_TRACKING_SCORE_TOOLTIPS[String(entry)] ||
                PARENT_TRACKING_SCORE_TOOLTIPS[entry],
            ),
          )
          .filter(Boolean);
      }

      function closeParentTrackingScoreLegendPopovers(exceptWrapper = null) {
        Array.from(document.querySelectorAll("[data-pt-score-legend]")).forEach(
          (wrapperEl) => {
            if (!(wrapperEl instanceof HTMLElement)) return;
            if (exceptWrapper && wrapperEl === exceptWrapper) return;
            const popoverEl = wrapperEl.querySelector(
              "[data-pt-score-legend-popover]",
            );
            const triggerEl = wrapperEl.querySelector(
              "[data-pt-score-legend-toggle]",
            );
            if (popoverEl instanceof HTMLElement) popoverEl.classList.add("hidden");
            if (triggerEl instanceof HTMLButtonElement)
              triggerEl.setAttribute("aria-expanded", "false");
          },
        );
      }

      function toggleParentTrackingScoreLegend(triggerEl) {
        if (!(triggerEl instanceof HTMLButtonElement)) return;
        const wrapperEl = triggerEl.closest("[data-pt-score-legend]");
        if (!(wrapperEl instanceof HTMLElement)) return;
        const popoverEl = wrapperEl.querySelector("[data-pt-score-legend-popover]");
        if (!(popoverEl instanceof HTMLElement)) return;
        const currentlyOpen = !popoverEl.classList.contains("hidden");
        if (currentlyOpen) {
          popoverEl.classList.add("hidden");
          triggerEl.setAttribute("aria-expanded", "false");
          return;
        }
        closeParentTrackingScoreLegendPopovers(wrapperEl);
        popoverEl.classList.remove("hidden");
        triggerEl.setAttribute("aria-expanded", "true");
      }

      function initializeParentTrackingScoreLegendPopovers() {
        const legendLines = parentTrackingScoreLegendLines();
        Array.from(
          document.querySelectorAll("[data-pt-score-legend-popover]"),
        ).forEach((popoverEl) => {
          if (!(popoverEl instanceof HTMLElement)) return;
          if (popoverEl.dataset.ready === "true") return;
          const titleEl = document.createElement("p");
          titleEl.className = "pt-score-legend-title";
          titleEl.textContent = "Thang điểm 0-5";
          const listEl = document.createElement("ul");
          listEl.className = "pt-score-legend-list";
          legendLines.forEach((line) => {
            const itemEl = document.createElement("li");
            itemEl.textContent = line;
            listEl.appendChild(itemEl);
          });
          popoverEl.append(titleEl, listEl);
          popoverEl.dataset.ready = "true";
        });

        if (parentTrackingScoreLegendBound) return;
        document.addEventListener("click", (event) => {
          const target = event?.target;
          if (!(target instanceof Element)) return;
          const triggerEl = target.closest("[data-pt-score-legend-toggle]");
          if (triggerEl instanceof HTMLButtonElement) {
            event.preventDefault();
            toggleParentTrackingScoreLegend(triggerEl);
            return;
          }
          const insidePopover = target.closest("[data-pt-score-legend-popover]");
          if (!insidePopover) closeParentTrackingScoreLegendPopovers();
        });
        document.addEventListener("keydown", (event) => {
          if (normalizeText(event.key) !== "Escape") return;
          closeParentTrackingScoreLegendPopovers();
        });
        parentTrackingScoreLegendBound = true;
      }

      function normalizeParentTrackingScoreValue(value) {
        const text = normalizeText(value);
        if (!text) return "";
        const numeric = Number.parseFloat(text);
        if (!Number.isFinite(numeric)) return "";
        const rounded = Math.round(numeric);
        const clamped = Math.max(
          PARENT_TRACKING_SCORE_MIN,
          Math.min(PARENT_TRACKING_SCORE_MAX, rounded),
        );
        return String(clamped);
      }

      function markParentTrackingManualMetricsTouched() {
        state.parentTracking.manualMetricsTouched = true;
      }

      function resetParentTrackingManualMetricsTouched() {
        state.parentTracking.manualMetricsTouched = false;
      }

      function parentTrackingScoreChoiceName(fieldName = "") {
        const normalizedFieldName = normalizeText(fieldName);
        if (!normalizedFieldName) return "";
        return `pt_score_choice_${normalizedFieldName}`;
      }

      function parentTrackingScoreRadioInputs(fieldName = "") {
        const normalizedFieldName = normalizeText(fieldName);
        if (!normalizedFieldName) return [];
        return Array.from(
          document.querySelectorAll(
            `input[type="radio"][data-pt-score-name="${normalizedFieldName}"]`,
          ),
        );
      }

      function syncParentTrackingScoreRadioFromField(fieldEl, { emit = false } = {}) {
        if (!(fieldEl instanceof HTMLInputElement)) return;
        const fieldName = normalizeText(fieldEl.name);
        if (!fieldName.startsWith("pt_skill_") && !fieldName.startsWith("pt_conduct_"))
          return;
        const normalizedValue = normalizeParentTrackingScoreValue(fieldEl.value);
        fieldEl.value = normalizedValue;

        const radios = parentTrackingScoreRadioInputs(fieldName);
        radios.forEach((radioEl) => {
          radioEl.checked =
            Boolean(normalizedValue) &&
            normalizeText(radioEl.value) === normalizedValue;
        });

        if (!emit) return;
        fieldEl.dispatchEvent(new Event("change", { bubbles: true }));
        fieldEl.dispatchEvent(new Event("input", { bubbles: true }));
      }

      function initializeParentTrackingRubricScoreSelects() {
        const rubricInputs = Array.from(
          document.querySelectorAll(
            '.progress-report-rubric-table input[type="number"][name^="pt_skill_"], .progress-report-rubric-table input[type="number"][name^="pt_conduct_"]',
          ),
        );
        rubricInputs.forEach((inputEl) => {
          const fieldName = normalizeText(inputEl.name);
          if (!fieldName) return;
          const normalizedValue = normalizeParentTrackingScoreValue(inputEl.value);
          const hiddenField = document.createElement("input");
          hiddenField.type = "hidden";
          hiddenField.name = fieldName;
          hiddenField.value = normalizedValue;
          hiddenField.className = "pt-score-hidden";
          hiddenField.disabled = inputEl.disabled;

          const radioGroup = document.createElement("div");
          radioGroup.className = "pt-score-radio-grid";
          radioGroup.setAttribute("role", "radiogroup");
          radioGroup.setAttribute("aria-label", `${fieldName} score`);

          for (
            let score = PARENT_TRACKING_SCORE_MIN;
            score <= PARENT_TRACKING_SCORE_MAX;
            score += 1
          ) {
            const optionLabel = document.createElement("label");
            optionLabel.className = "pt-score-radio-option";
            const tooltipText = parentTrackingScoreTooltip(score);
            optionLabel.title = tooltipText;

            const radioEl = document.createElement("input");
            radioEl.type = "radio";
            radioEl.name = parentTrackingScoreChoiceName(fieldName);
            radioEl.value = String(score);
            radioEl.dataset.ptScoreName = fieldName;
            radioEl.checked = normalizedValue === String(score);
            radioEl.disabled = inputEl.disabled;
            radioEl.title = tooltipText;
            radioEl.setAttribute("aria-label", tooltipText || `Score ${score}`);
            radioEl.addEventListener("change", () => {
              if (!radioEl.checked) return;
              hiddenField.value = normalizeParentTrackingScoreValue(radioEl.value);
              syncParentTrackingScoreRadioFromField(hiddenField, { emit: true });
            });

            const scoreText = document.createElement("span");
            scoreText.textContent = String(score);
            optionLabel.append(radioEl, scoreText);
            radioGroup.appendChild(optionLabel);
          }

          const wrapper = document.createElement("div");
          wrapper.className = "pt-score-radio-wrapper";
          wrapper.append(radioGroup, hiddenField);
          inputEl.replaceWith(wrapper);
        });
      }

      function initializeParentTrackingScoreSelects() {
        initializeParentTrackingRubricScoreSelects();
      }

      function parentTrackingRecommendationTextareas() {
        return Array.from(document.querySelectorAll('textarea[name^="pt_rec_"]'));
      }

      function normalizeParentTrackingRubricScore(value) {
        const numeric = Number.parseFloat(String(value));
        if (!Number.isFinite(numeric)) return null;
        const clamped = Math.max(
          PARENT_TRACKING_SCORE_MIN,
          Math.min(PARENT_TRACKING_SCORE_MAX, numeric),
        );
        return clamped;
      }

      function parentTrackingRubricScoreValues(selector = "") {
        const targetSelector = normalizeText(selector);
        if (!targetSelector) return [];
        return Array.from(document.querySelectorAll(targetSelector))
          .map((entry) => normalizeParentTrackingRubricScore(entry?.value))
          .filter((entry) => entry !== null);
      }

      function parentTrackingRubricAverage(selector = "") {
        return toAverage(parentTrackingRubricScoreValues(selector));
      }

      function parentTrackingSummaryFallbackFromRubric() {
        return {
          behaviorScore: normalizeParentTrackingScoreValue(
            parentTrackingRubricAverage('[name^="pt_conduct_"]'),
          ),
          participationScore: normalizeParentTrackingScoreValue(
            parentTrackingRubricAverage('[name^="pt_skill_"]'),
          ),
        };
      }

      function applyParentTrackingRubricSummaryScores() {
        const rubricSummary = parentTrackingSummaryFallbackFromRubric();
        parentTrackingFieldSetValue("pt_behaviorScore", rubricSummary.behaviorScore);
        parentTrackingFieldSetValue(
          "pt_participationScore",
          rubricSummary.participationScore,
        );
      }

      function parentTrackingRubricScoreFields() {
        return Array.from(
          document.querySelectorAll('[name^="pt_skill_"], [name^="pt_conduct_"]'),
        );
      }

      function parentTrackingRubricFieldByName(fieldName = "") {
        const normalizedFieldName = normalizeText(fieldName);
        if (!normalizedFieldName) return null;
        return (
          Array.from(
            document.querySelectorAll(
              '[name^="pt_skill_"], [name^="pt_conduct_"], textarea[name^="pt_rec_"]',
            ),
          ).find((entry) => normalizeText(entry?.name) === normalizedFieldName) || null
        );
      }

      function parentTrackingCurrentRubricLevel(detail = null) {
        const detailLevel = resolveSystemLevelName(
          detail?.profile?.currentGrade || detail?.currentGrade || "",
        );
        if (detailLevel) return detailLevel;
        const selectedLevel = selectedParentTrackingLevel();
        if (selectedLevel) return selectedLevel;
        return resolveSystemLevelName(
          document.getElementById("pt_classLevel")?.value || "",
        );
      }

      function shouldDisableParentTrackingRubricRow(
        requiredLevelName = "",
        currentLevelName = "",
      ) {
        const requiredLevel = fullLevelLabel(
          resolveSystemLevelName(requiredLevelName || ""),
        );
        const currentLevel = fullLevelLabel(
          resolveSystemLevelName(currentLevelName || ""),
        );
        if (!requiredLevel || !currentLevel) return false;
        return compareLevelLabels(currentLevel, requiredLevel) < 0;
      }

      function applyParentTrackingLevelBasedRubricAvailability(detail = null) {
        const currentLevel = parentTrackingCurrentRubricLevel(detail);
        let mutatedFields = false;

        Array.from(
          document.querySelectorAll(
            ".progress-report-rubric-table tr[data-pt-min-level]",
          ),
        ).forEach((rowEl) => {
          if (!(rowEl instanceof HTMLTableRowElement)) return;
          const requiredLevel =
            normalizeText(rowEl.getAttribute("data-pt-min-level")) ||
            PARENT_TRACKING_DIGITAL_SKILL_MIN_LEVEL;
          const disabled = shouldDisableParentTrackingRubricRow(
            requiredLevel,
            currentLevel,
          );
          rowEl.classList.toggle("progress-report-rubric-row-disabled", disabled);
          rowEl.dataset.ptDisabled = disabled ? "true" : "false";

          Array.from(rowEl.querySelectorAll("select, textarea, input")).forEach(
            (fieldEl) => {
              if (
                !(fieldEl instanceof HTMLSelectElement) &&
                !(fieldEl instanceof HTMLTextAreaElement) &&
                !(fieldEl instanceof HTMLInputElement)
              ) {
                return;
              }
              if (fieldEl instanceof HTMLInputElement && fieldEl.type === "radio") {
                if (disabled && fieldEl.checked) {
                  fieldEl.checked = false;
                  const scoreField = parentTrackingRubricFieldByName(
                    fieldEl.dataset.ptScoreName || "",
                  );
                  if (scoreField instanceof HTMLInputElement) {
                    scoreField.value = "";
                    syncParentTrackingScoreRadioFromField(scoreField);
                  }
                  mutatedFields = true;
                }
                fieldEl.disabled = disabled;
                if (disabled)
                  fieldEl.setAttribute(
                    "title",
                    `${fullLevelLabel(requiredLevel)} and above only.`,
                  );
                else fieldEl.removeAttribute("title");
                return;
              }
              if (disabled && normalizeText(fieldEl.value)) {
                fieldEl.value = "";
                if (fieldEl instanceof HTMLInputElement)
                  syncParentTrackingScoreRadioFromField(fieldEl);
                mutatedFields = true;
              }
              fieldEl.disabled = disabled;
              if (disabled)
                fieldEl.setAttribute(
                  "title",
                  `${fullLevelLabel(requiredLevel)} and above only.`,
                );
              else fieldEl.removeAttribute("title");
            },
          );
        });

        if (mutatedFields) applyParentTrackingRubricSummaryScores();
      }

      function collectParentTrackingRubricPayload() {
        const skillScores = {};
        const conductScores = {};
        const recommendations = {};

        parentTrackingRubricScoreFields().forEach((fieldEl) => {
          const fieldName = normalizeText(fieldEl?.name);
          if (!fieldName) return;
          const scoreValue = normalizeParentTrackingScoreValue(fieldEl?.value);
          if (!scoreValue) return;
          if (fieldName.startsWith("pt_skill_")) {
            skillScores[fieldName] = scoreValue;
            return;
          }
          if (fieldName.startsWith("pt_conduct_")) {
            conductScores[fieldName] = scoreValue;
          }
        });

        parentTrackingRecommendationTextareas().forEach((textareaEl) => {
          const fieldName = normalizeText(textareaEl?.name);
          const recommendation = normalizeText(textareaEl?.value);
          if (!fieldName || !recommendation) return;
          recommendations[fieldName] = recommendation;
        });

        if (
          !Object.keys(skillScores).length &&
          !Object.keys(conductScores).length &&
          !Object.keys(recommendations).length
        ) {
          return null;
        }
        return {
          skillScores,
          conductScores,
          recommendations,
        };
      }

      function clearParentTrackingRubricInputs() {
        parentTrackingRubricScoreFields().forEach((fieldEl) => {
          fieldEl.value = "";
          if (fieldEl instanceof HTMLInputElement)
            syncParentTrackingScoreRadioFromField(fieldEl);
        });
        parentTrackingRecommendationTextareas().forEach((textareaEl) => {
          textareaEl.value = "";
        });
      }

      function applyParentTrackingRubricPayload(payload = null) {
        clearParentTrackingRubricInputs();
        const source = payload && typeof payload === "object" ? payload : null;
        if (!source) {
          applyParentTrackingRubricSummaryScores();
          return;
        }

        ["skillScores", "conductScores"].forEach((bucketName) => {
          const sourceBucket = source?.[bucketName];
          if (!sourceBucket || typeof sourceBucket !== "object") return;
          Object.entries(sourceBucket).forEach(([fieldName, rawValue]) => {
            const fieldEl = parentTrackingRubricFieldByName(fieldName);
            if (
              !(
                fieldEl instanceof HTMLInputElement ||
                fieldEl instanceof HTMLSelectElement
              )
            )
              return;
            const normalizedScore = normalizeParentTrackingScoreValue(rawValue);
            if (!normalizedScore) return;
            fieldEl.value = normalizedScore;
            if (fieldEl instanceof HTMLInputElement)
              syncParentTrackingScoreRadioFromField(fieldEl);
          });
        });

        const sourceRecommendations = source?.recommendations;
        if (sourceRecommendations && typeof sourceRecommendations === "object") {
          Object.entries(sourceRecommendations).forEach(([fieldName, rawValue]) => {
            const fieldEl = parentTrackingRubricFieldByName(fieldName);
            if (!(fieldEl instanceof HTMLTextAreaElement)) return;
            const normalizedRecommendation = normalizeText(rawValue);
            if (!normalizedRecommendation) return;
            fieldEl.value = normalizedRecommendation;
          });
        }

        applyParentTrackingLevelBasedRubricAvailability();
        applyParentTrackingRubricSummaryScores();
      }

      function parentTrackingCommentFallbackFromRecommendations(maxLines = 3) {
        const limit = Math.max(1, Number.parseInt(String(maxLines), 10) || 3);
        const lines = parentTrackingRecommendationTextareas()
          .map((entry) => normalizeText(entry?.value).replace(/\s+/g, " ").trim())
          .filter(Boolean)
          .slice(0, limit);
        if (!lines.length) return "";
        return `Corrective actions: ${lines.join(" | ")}`;
      }

      function parentTrackingRecommendationFieldByName(fieldName = "") {
        const normalizedFieldName = normalizeText(fieldName);
        if (!normalizedFieldName) return null;
        return (
          parentTrackingRecommendationTextareas().find(
            (entry) => normalizeText(entry?.name) === normalizedFieldName,
          ) || null
        );
      }

      function setParentTrackingActionHelperStatus(message = "", isError = false) {
        const helperEl = document.getElementById("pt_actionHelperStatus");
        if (!helperEl) return;
        helperEl.style.color = isError ? "#b3262d" : "var(--ink-muted)";
        helperEl.textContent =
          normalizeText(message) ||
          "Focus any corrective-action textarea in Skills/Conduct, then insert shorthand. Free text remains fully editable.";
      }

      function rememberParentTrackingRecommendationFocus(fieldName = "") {
        const normalizedFieldName = normalizeText(fieldName);
        if (!normalizedFieldName) return;
        state.parentTracking.activeRecommendationFieldName = normalizedFieldName;
        setParentTrackingActionHelperStatus(
          `Focused action field: ${normalizedFieldName}`,
        );
      }

      function focusedParentTrackingRecommendationField() {
        const activeElement = document.activeElement;
        if (
          activeElement instanceof HTMLTextAreaElement &&
          normalizeText(activeElement.name).startsWith("pt_rec_")
        ) {
          rememberParentTrackingRecommendationFocus(activeElement.name);
          return activeElement;
        }
        return parentTrackingRecommendationFieldByName(
          state.parentTracking.activeRecommendationFieldName,
        );
      }

      function clearParentTrackingActionShortcutInputs({
        preserveStatus = false,
      } = {}) {
        const shorthandEl = document.getElementById("pt_actionShorthand");
        const additionEl = document.getElementById("pt_actionAddition");
        if (shorthandEl) shorthandEl.value = "";
        if (additionEl) additionEl.value = "";
        if (!preserveStatus) setParentTrackingActionHelperStatus("");
      }

      function insertParentTrackingActionShortcut() {
        const targetTextarea = focusedParentTrackingRecommendationField();
        if (!targetTextarea) {
          setParentTrackingActionHelperStatus(
            "Select a corrective-action textarea first.",
            true,
          );
          return;
        }
        const shorthand = normalizeText(
          document.getElementById("pt_actionShorthand")?.value,
        );
        const addition = normalizeText(
          document.getElementById("pt_actionAddition")?.value,
        );
        if (!shorthand && !addition) {
          setParentTrackingActionHelperStatus(
            "Choose a shorthand template and/or free-text addition first.",
            true,
          );
          return;
        }

        const nextLine = [shorthand, addition].filter(Boolean).join(" ");
        const current = normalizeText(targetTextarea.value);
        targetTextarea.value = current ? `${current}\n${nextLine}` : nextLine;
        targetTextarea.dispatchEvent(new Event("input", { bubbles: true }));

        const additionEl = document.getElementById("pt_actionAddition");
        if (additionEl) additionEl.value = "";
        rememberParentTrackingRecommendationFocus(targetTextarea.name);
        setParentTrackingActionHelperStatus(
          `Inserted shorthand into: ${normalizeText(targetTextarea.name)}`,
        );
        targetTextarea.focus();
      }

      function parentTrackingStudentSource() {
        return studentSourceForPage("parent-tracking");
      }

      function dayLabelFromIsoDate(value) {
        const parsed = parseIsoDateLocal(value);
        if (!parsed) return "";
        const dayIndex = shiftToFixedTimeZone(parsed).getUTCDay();
        return (
          [
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
          ][dayIndex] || ""
        );
      }

      function quarterFromIsoDate(value) {
        const isoDate = normalizeText(value).slice(0, 10);
        const setupQuarter = schoolSetupQuarterForIsoDate(isoDate);
        if (setupQuarter?.quarter) return normalizeLower(setupQuarter.quarter);
        return "";
      }

      function currentQuarterFromToday() {
        return quarterFromIsoDate(localIsoDate(new Date()));
      }

      function normalizeQuarterDropdownDefaults() {
        const currentQuarter = normalizeLower(currentQuarterFromToday());
        if (!currentQuarter) return "";
        ["a_quarter", "g_quarter", "r_quarter", "gradeChartQuarter"].forEach((id) => {
          const select = document.getElementById(id);
          if (!(select instanceof HTMLSelectElement)) return;
          const value = normalizeLower(select.value);
          if (!/^q[1-4]$/.test(value)) select.value = currentQuarter;
        });
        updateAttendanceQuarterWarning();
        return currentQuarter;
      }

      function parentTrackingSummaryKey(levelName, classDate) {
        const level = levelNameKey(resolveSystemLevelName(levelName || ""));
        const date = normalizeText(classDate);
        if (!level || !date) return "";
        return `${level}|${date}`;
      }

      function parentTrackingCurrentSummaryKey() {
        const selectedLevel = resolveSystemLevelName(
          state.parentTracking?.selectedLevel || "",
        );
        const classDate = normalizeText(document.getElementById("pt_classDate")?.value);
        return parentTrackingSummaryKey(selectedLevel, classDate);
      }

      function rememberParentTrackingLessonSummary() {
        const key = parentTrackingCurrentSummaryKey();
        if (!key) return;
        const lessonSummary = normalizeText(
          document.getElementById("pt_lessonSummary")?.value,
        );
        const next = {
          ...(state.parentTracking?.lessonSummaryByLevelDate || {}),
        };
        if (lessonSummary) next[key] = lessonSummary;
        else delete next[key];
        persistParentTrackingLessonSummary(next);
      }

      function applyParentTrackingLessonSummaryFromMemory({ force = false } = {}) {
        const lessonEl = document.getElementById("pt_lessonSummary");
        if (!lessonEl) return;
        const key = parentTrackingCurrentSummaryKey();
        if (!key) return;
        const existing = normalizeText(lessonEl.value);
        if (existing && !force) return;
        lessonEl.value = normalizeText(
          state.parentTracking?.lessonSummaryByLevelDate?.[key],
        );
      }

      function parentTrackingTeacherCandidates() {
        const knownTeachers = normalizeTeacherNameList(
          (Array.isArray(state.adminUsers) ? state.adminUsers : [])
            .filter((entry) =>
              ["admin", "teacher"].includes(normalizeLower(entry?.role)),
            )
            .map((entry) => entry?.username),
        );
        const fallbackCurrent = normalizeText(state.authUser?.username);
        return normalizeTeacherNameList([
          fallbackCurrent,
          ...(state.parentTracking?.teacherNames || []),
          ...knownTeachers,
        ]);
      }

      function renderParentTrackingTeacherOptions() {
        const selectEl = document.getElementById("pt_teacherName");
        if (!selectEl) return;
        const current = normalizeText(selectEl.value);
        const names = parentTrackingTeacherCandidates();
        selectEl.innerHTML = '<option value="">Select teacher</option>';
        names.forEach((name) => {
          const option = document.createElement("option");
          option.value = name;
          option.textContent = name;
          if (normalizeLower(option.value) === normalizeLower(current))
            option.selected = true;
          selectEl.appendChild(option);
        });
        if (!normalizeText(selectEl.value) && names.length) selectEl.value = names[0];
      }

      function rememberParentTrackingTeacherName() {
        const selected = normalizeText(
          document.getElementById("pt_teacherName")?.value,
        );
        if (!selected) return;
        persistParentTrackingTeacherNames([
          selected,
          ...(state.parentTracking?.teacherNames || []),
        ]);
        renderParentTrackingTeacherOptions();
      }

      function selectedParentTrackingLevel() {
        return resolveSystemLevelName(state.parentTracking?.selectedLevel || "");
      }

      function parentTrackingStudentsByLevel(
        levelName = selectedParentTrackingLevel(),
      ) {
        const selectedLevel = resolveSystemLevelName(levelName);
        const source = parentTrackingStudentSource();
        const rows = source
          .filter((student) => {
            if (!selectedLevel) return true;
            const studentLevel = resolveSystemLevelName(
              student?.profile?.currentGrade || "",
            );
            return levelNamesMatch(studentLevel, selectedLevel);
          })
          .slice();
        rows.sort((left, right) =>
          studentDisplayName(left, { preferEnglish: true }).localeCompare(
            studentDisplayName(right, { preferEnglish: true }),
          ),
        );
        return rows;
      }

      function clearParentTrackingDetailPanel() {
        const panel = document.getElementById("pt_assignmentDetailPanel");
        const titleEl = document.getElementById("pt_assignmentDetailTitle");
        const bodyEl = document.getElementById("pt_assignmentDetailBody");
        if (panel) panel.classList.add("hidden");
        if (titleEl) titleEl.textContent = "Homework Details";
        if (bodyEl)
          bodyEl.textContent = "Select a homework link to inspect details.";
      }

      function parentTrackingDeepLinkPath(studentRefId, assignmentId = "") {
        const normalizedStudentRefId = normalizeText(studentRefId);
        if (!normalizedStudentRefId) return buildPagePath("parent-tracking");
        const params = new URLSearchParams();
        params.set("ptStudent", normalizedStudentRefId);
        if (normalizeText(assignmentId))
          params.set("ptAssignment", normalizeText(assignmentId));
        return `${buildPagePath("parent-tracking")}?${params.toString()}`;
      }

      function parentTrackingDeepLinkAbsolute(studentRefId, assignmentId = "") {
        const path = parentTrackingDeepLinkPath(studentRefId, assignmentId);
        try {
          return new URL(path, window.location.origin).toString();
        } catch (error) {
          void error;
          return path;
        }
      }

      function parseDateTime(value) {
        const text = normalizeText(value);
        if (!text) return null;
        const parsed = new Date(text);
        if (Number.isNaN(parsed.valueOf())) return null;
        return parsed;
      }

      function isGradeRecordCompleted(record) {
        if (record?.homeworkCompleted === true) return true;
        if (record?.homeworkCompleted === false) return false;
        return Boolean(parseDateTime(record?.submittedAt));
      }

      function isGradeRecordOnTime(record) {
        if (record?.homeworkOnTime === true) return true;
        if (record?.homeworkOnTime === false) return false;
        const dueAt = parseDateTime(record?.dueAt);
        const submittedAt = parseDateTime(record?.submittedAt);
        if (!dueAt || !submittedAt) return false;
        return submittedAt.valueOf() <= dueAt.valueOf();
      }

      function isGradeRecordOutstanding(record, asOfDate = new Date()) {
        const dueAt = parseDateTime(record?.dueAt);
        if (!dueAt) return false;
        const asOf = asOfDate instanceof Date ? asOfDate : new Date(asOfDate);
        if (Number.isNaN(asOf.valueOf())) return false;
        if (dueAt.valueOf() > asOf.valueOf()) return false;
        return !isGradeRecordCompleted(record);
      }

      function parentTrackingHomeworkRowSnapshot(
        entry = {},
        studentRefId = "",
      ) {
        const assignmentName = normalizeText(entry?.assignmentName);
        const dueAt = formatDate(entry?.dueAt);
        if (!assignmentName && !dueAt) return null;
        return {
          assignmentName: assignmentName || "(untitled homework)",
          dueAt,
          className: normalizeText(entry?.className),
          quarter: normalizeText(entry?.quarter),
          deepLink: parentTrackingDeepLinkAbsolute(
            normalizeText(studentRefId),
            normalizeText(entry?.id),
          ),
        };
      }

      function parentTrackingHomeworkBuckets(
        metrics = {},
        studentRefId = "",
        classDate = "",
      ) {
        const records = Array.isArray(metrics?.records) ? metrics.records : [];
        const trackedHomeworkRecords = records.filter((entry) =>
          isTrackedHomeworkRecord(entry),
        );
        const asOf = parseIsoDateLocal(classDate) || new Date();
        const weekBounds = currentWeekBounds(asOf);
        const shiftedAsOfEnd = shiftToFixedTimeZone(asOf);
        shiftedAsOfEnd.setUTCHours(23, 59, 59, 999);
        const asOfEnd = shiftFromFixedTimeZone(shiftedAsOfEnd);
        const sortByDueThenTitle = (left, right) => {
          const leftDue =
            parseDateTime(left?.dueAt)?.valueOf() || Number.MAX_SAFE_INTEGER;
          const rightDue =
            parseDateTime(right?.dueAt)?.valueOf() || Number.MAX_SAFE_INTEGER;
          if (leftDue !== rightDue) return leftDue - rightDue;
          return normalizeText(left?.assignmentName).localeCompare(
            normalizeText(right?.assignmentName),
          );
        };
        const currentWeekHomework = trackedHomeworkRecords
          .filter((entry) => {
            const dueAt = parseDateTime(entry?.dueAt);
            return (
              dueAt &&
              isDateWithinBounds(dueAt, weekBounds) &&
              !isGradeRecordOutstanding(entry, asOfEnd)
            );
          })
          .slice()
          .sort(sortByDueThenTitle);
        const pastDueHomework = trackedHomeworkRecords
          .filter((entry) => isGradeRecordOutstanding(entry, asOfEnd))
          .slice()
          .sort(sortByDueThenTitle);
        return {
          studentRefId: normalizeText(studentRefId),
          classDate: normalizeText(classDate),
          currentWeekHomework,
          pastDueHomework,
        };
      }

      function parentTrackingCurrentSnapshotRows(
        metrics = {},
        studentRefId = "",
        classDate = "",
      ) {
        const buckets = parentTrackingHomeworkBuckets(
          metrics,
          studentRefId,
          classDate,
        );
        return buckets.currentWeekHomework
          .map((entry) =>
            parentTrackingHomeworkRowSnapshot(entry, buckets.studentRefId),
          )
          .filter(Boolean);
      }

      function parentTrackingPastDueSnapshotRows(
        metrics = {},
        studentRefId = "",
        classDate = "",
      ) {
        const buckets = parentTrackingHomeworkBuckets(
          metrics,
          studentRefId,
          classDate,
        );
        return buckets.pastDueHomework
          .map((entry) =>
            parentTrackingHomeworkRowSnapshot(entry, buckets.studentRefId),
          )
          .filter(Boolean);
      }

      function toAverage(values = []) {
        const numbers = (Array.isArray(values) ? values : [])
          .map((entry) => Number.parseFloat(String(entry)))
          .filter((entry) => Number.isFinite(entry));
        if (!numbers.length) return null;
        const sum = numbers.reduce((acc, entry) => acc + entry, 0);
        return sum / numbers.length;
      }

      function roundTo2(value) {
        const numeric = Number.parseFloat(String(value));
        if (!Number.isFinite(numeric)) return null;
        return Math.round(numeric * 100) / 100;
      }

      function percentValue(numerator = 0, denominator = 0) {
        const num = Number(numerator) || 0;
        const den = Number(denominator) || 0;
        if (!den) return 0;
        return (num / den) * 100;
      }

      function gradeRecordAcademicPercent(record) {
        const score = Number.parseFloat(String(record?.score));
        const maxScore = Number.parseFloat(String(record?.maxScore));
        if (!Number.isFinite(score) || !Number.isFinite(maxScore) || maxScore <= 0)
          return null;
        return (score / maxScore) * 100;
      }

      function gradeRecordAcademicScore(record) {
        const score = Number.parseFloat(String(record?.score));
        if (Number.isFinite(score)) return score;
        return gradeRecordAcademicPercent(record);
      }

      function levelMatchesGradeRecord(record, selectedLevel) {
        const targetLevel = resolveSystemLevelName(selectedLevel || "");
        if (!targetLevel) return true;
        const recordLevel = resolveSystemLevelName(record?.level || "");
        if (recordLevel && levelNamesMatch(recordLevel, targetLevel)) return true;
        const className = normalizeText(record?.className);
        if (!className) return false;
        if (levelNamesMatch(className, targetLevel)) return true;
        if (normalizeLower(className) === normalizeLower(fullLevelLabel(targetLevel)))
          return true;
        return false;
      }

      function quarterKey(value = "") {
        const normalized = normalizeLower(value);
        if (["q1", "q2", "q3", "q4"].includes(normalized)) return normalized;
        return "";
      }

      function quarterKeyForGradeRecord(record = {}, fallbackDate = "") {
        const explicitQuarter = quarterKey(record?.quarter);
        if (explicitQuarter) return explicitQuarter;
        const dateCandidates = [
          record?.dueAt,
          record?.submittedAt,
          record?.assignedAt,
          record?.attendanceDate,
          record?.classDate,
          record?.createdAt,
          fallbackDate,
        ];
        for (let index = 0; index < dateCandidates.length; index += 1) {
          const parsed =
            parseDateTime(dateCandidates[index]) ||
            parseIsoDateLocal(normalizeText(dateCandidates[index]));
          if (!parsed) continue;
          const isoDate = localIsoDate(parsed);
          const derivedQuarter = quarterKey(quarterFromIsoDate(isoDate));
          if (derivedQuarter) return derivedQuarter;
        }
        return "";
      }

      function gradeRecordMatchesQuarter(
        record = {},
        targetQuarter = "",
        fallbackDate = "",
      ) {
        const normalizedQuarter = quarterKey(targetQuarter);
        if (!normalizedQuarter) return true;
        return quarterKeyForGradeRecord(record, fallbackDate) === normalizedQuarter;
      }

      function gradeChartPeriodLabel(period = "") {
        const normalized = normalizedGradeChartPeriod(period);
        if (normalized === "week") return "Week Set";
        if (normalized === "quarter") return "Quarter";
        if (normalized === "qtd") return "QTD";
        if (normalized === "sytd") return "SYTD";
        return "Custom";
      }

      function normalizedGradeChartPeriod(value = "") {
        const normalized = normalizeLower(value);
        if (["week", "quarter", "qtd", "sytd", "custom"].includes(normalized))
          return normalized;
        return "custom";
      }

      function normalizedGradeChartGroupBy(value = "") {
        const normalized = normalizeLower(value);
        if (["class", "student", "school"].includes(normalized)) return normalized;
        return "class";
      }

      function gradeChartGroupLabel(value = "") {
        const normalized = normalizedGradeChartGroupBy(value);
        if (normalized === "student") return "By Student";
        if (normalized === "school") return "By School";
        return "By Class";
      }

      function parseSchoolYearRange(value = "") {
        const match = normalizeText(value).match(/(\d{4})(?:\D+(\d{4}))?/);
        if (!match) return null;
        const startYear = Number.parseInt(match[1], 10);
        const endYearRaw = Number.parseInt(match[2], 10);
        const endYear = Number.isFinite(endYearRaw) ? endYearRaw : startYear + 1;
        if (
          !Number.isFinite(startYear) ||
          !Number.isFinite(endYear) ||
          endYear < startYear
        )
          return null;
        return { startYear, endYear };
      }

      function gradeChartCurrentSchoolYear() {
        return normalizeText(schoolSetupState()?.schoolYear || "");
      }

      function gradeChartCurrentQuarter() {
        return currentQuarterFromToday();
      }

      function applyGradeChartCurrentQuarterDefault(force = false) {
        const chart = gradeChartState();
        const currentQuarter = gradeChartCurrentQuarter();
        if (!currentQuarter) return chart;
        if (!force && normalizeText(chart.quarter)) return chart;
        return setGradeChartState({ quarter: currentQuarter });
      }

      function normalizeGradeChartOperationalSchoolYear(value = "") {
        const normalized = normalizeText(value);
        if (normalizeLower(normalized) === "all") return gradeChartCurrentSchoolYear();
        return normalized || gradeChartCurrentSchoolYear();
      }

      function normalizeGradeChartState(source = {}) {
        const next = source && typeof source === "object" ? source : {};
        const normalizedQuarter = quarterKey(next.quarter) || "";
        let customFrom = normalizeText(next.customFrom).slice(0, 10);
        let customTo = normalizeText(next.customTo).slice(0, 10);
        if (customFrom && customTo && compareIsoDateText(customFrom, customTo) > 0) {
          const swapped = customFrom;
          customFrom = customTo;
          customTo = swapped;
        }
        const schoolYear = normalizeGradeChartOperationalSchoolYear(next.schoolYear);
        return {
          period: normalizedGradeChartPeriod(next.period),
          groupBy: normalizedGradeChartGroupBy(next.groupBy),
          quarter: normalizedQuarter,
          schoolYear,
          customFrom,
          customTo,
        };
      }

      function gradeChartState() {
        state.gradeChart = normalizeGradeChartState(state.gradeChart || {});
        return state.gradeChart;
      }

      function setGradeChartState(patch = {}) {
        const merged = {
          ...gradeChartState(),
          ...(patch && typeof patch === "object" ? patch : {}),
        };
        state.gradeChart = normalizeGradeChartState(merged);
        return state.gradeChart;
      }

      function applyGradeChartCurrentSchoolYearDefault() {
        const chart = gradeChartState();
        const currentSchoolYear = normalizeText(gradeChartCurrentSchoolYear());
        if (!currentSchoolYear) return chart;
        if (normalizeText(chart.schoolYear) === currentSchoolYear) return chart;
        if (normalizeText(chart.schoolYear)) return chart;
        return setGradeChartState({ schoolYear: currentSchoolYear });
      }

      function gradeRecordPrimaryIsoDate(record = {}) {
        const candidates = [
          record?.dueAt,
          record?.submittedAt,
          record?.generatedAt,
          record?.createdAt,
          record?.attendanceDate,
        ];
        for (let index = 0; index < candidates.length; index += 1) {
          const raw = normalizeText(candidates[index]);
          if (!raw) continue;
          const parsed = parseDateTime(raw) || parseIsoDateLocal(raw.slice(0, 10));
          if (!parsed) continue;
          return localIsoDate(parsed);
        }
        return "";
      }

      function gradeRecordSchoolYear(record = {}) {
        const explicit = normalizeText(record?.schoolYear);
        if (explicit) return explicit;
        const isoDate = gradeRecordPrimaryIsoDate(record);
        if (isoDate) return defaultAttendanceSchoolYear(isoDate);
        return gradeChartCurrentSchoolYear();
      }

      function gradeChartSchoolYearRange(yearLabel = "") {
        const currentSchoolYear = gradeChartCurrentSchoolYear();
        const targetYear = normalizeText(yearLabel) || currentSchoolYear;
        const setup = schoolSetupState();
        if (
          targetYear &&
          targetYear === currentSchoolYear &&
          parseIsoDateLocal(setup?.startDate) &&
          parseIsoDateLocal(setup?.endDate) &&
          normalizeText(setup?.schoolYear) === currentSchoolYear
        ) {
          return {
            startDate: normalizeText(setup.startDate).slice(0, 10),
            endDate: normalizeText(setup.endDate).slice(0, 10),
          };
        }
        return { startDate: "", endDate: "" };
      }

      function gradeChartQuarterRange(quarter = "", schoolYearLabel = "") {
        const normalizedQuarter = quarterKey(quarter);
        if (!normalizedQuarter) return { startDate: "", endDate: "" };
        const currentSchoolYear = gradeChartCurrentSchoolYear();
        const targetYear = normalizeText(schoolYearLabel) || currentSchoolYear;
        const setup = schoolSetupState();
        if (
          targetYear &&
          targetYear === currentSchoolYear &&
          normalizeText(setup?.schoolYear) === currentSchoolYear &&
          Array.isArray(setup?.quarters)
        ) {
          const matched = setup.quarters.find(
            (entry) => quarterKey(entry?.quarter) === normalizedQuarter,
          );
          if (matched) {
            return {
              startDate: normalizeText(matched.startDate).slice(0, 10),
              endDate: normalizeText(matched.endDate).slice(0, 10),
            };
          }
        }
        return { startDate: "", endDate: "" };
      }

      function gradeChartSchoolYearOptionValues(rows = []) {
        const source = Array.isArray(rows) ? rows : [];
        const currentSchoolYear = gradeChartCurrentSchoolYear();
        const values = new Set([currentSchoolYear]);
        source.forEach((row) => {
          const schoolYear = gradeRecordSchoolYear(row);
          if (schoolYear) values.add(schoolYear);
        });
        return Array.from(values)
          .filter(Boolean)
          .sort((left, right) => {
            const leftRange = parseSchoolYearRange(left);
            const rightRange = parseSchoolYearRange(right);
            const leftStart =
              Number.isFinite(leftRange?.startYear) ? leftRange.startYear : -1;
            const rightStart =
              Number.isFinite(rightRange?.startYear) ? rightRange.startYear : -1;
            if (leftStart !== rightStart) return rightStart - leftStart;
            return right.localeCompare(left, undefined, { sensitivity: "base" });
          });
      }

      function gradeChartGroupIdentity(row = {}, groupBy = "class") {
        const grouping = normalizedGradeChartGroupBy(groupBy);
        if (grouping === "student") {
          const fallbackProfile = state.currentStudent?.profile || {};
          const fullName = normalizeText(
            row?.fullName ||
              row?.englishName ||
              fallbackProfile?.fullName ||
              fallbackProfile?.englishName,
          );
          const eaglesId = normalizeText(
            row?.eaglesId || row?.studentRefId || state.currentStudent?.eaglesId,
          );
          const studentNumber = parsePositiveInteger(
            row?.studentNumber || state.currentStudent?.studentNumber,
          );
          let label = fullName || eaglesId || "Unknown student";
          if (fullName && eaglesId) label = `${fullName} (${eaglesId})`;
          if (studentNumber) label = `${label} <${studentNumber}>`;
          return {
            key: `student:${normalizeLower(eaglesId || fullName || label)}`,
            label,
          };
        }
        if (grouping === "school") {
          const schoolName =
            normalizeText(row?.profile?.schoolName || row?.schoolName) || "No school";
          return {
            key: `school:${normalizeLower(schoolName)}`,
            label: schoolName,
          };
        }
        const classLabel =
          normalizeText(row?.className) ||
          fullLevelLabel(resolveSystemLevelName(row?.classLevel || row?.level || "")) ||
          "No class";
        return {
          key: `class:${normalizeLower(classLabel)}`,
          label: classLabel,
        };
      }

      function gradeScoreBandColor(value = null) {
        if (!Number.isFinite(value)) return "#96a6bd";
        if (value >= 90) return "#0c8f54";
        if (value >= 80) return "#2ca56b";
        if (value >= 70) return "#c69a17";
        if (value >= 60) return "#c6761c";
        return "#b73b44";
      }

      function gradeScoreText(value = null) {
        if (!Number.isFinite(value)) return "n/a";
        return `${Math.round(value)}%`;
      }

      function gradeChartSparklineSvg(points = [], laneLabel = "", options = {}) {
        const source = Array.isArray(points) ? points.slice(-12) : [];
        const widthRaw = Number(options?.width);
        const heightRaw = Number(options?.height);
        const width =
          Number.isFinite(widthRaw) && widthRaw >= 220 ? Math.round(widthRaw) : 340;
        const height =
          Number.isFinite(heightRaw) && heightRaw >= 96 ? Math.round(heightRaw) : 108;
        const leftPad = 34;
        const rightPad = 16;
        const topPad = 12;
        const bottomPad = 30;
        const usableWidth = Math.max(1, width - leftPad - rightPad);
        const usableHeight = Math.max(1, height - topPad - bottomPad);
        const yForScore = (score) => topPad + ((100 - score) / 100) * usableHeight;
        const baselineY = yForScore(0);
        const thresholdRaw = Number(options?.thresholdScore);
        const thresholdScore =
          Number.isFinite(thresholdRaw) ? Math.max(0, Math.min(100, thresholdRaw)) : 80;

        const mapped = source.map((point, index) => {
          const ratio = source.length <= 1 ? 0.5 : index / (source.length - 1);
          const x = leftPad + ratio * usableWidth;
          const numericScore = Number(point?.score);
          const score =
            Number.isFinite(numericScore) ?
              Math.max(0, Math.min(100, numericScore))
            : null;
          const y = score === null ? baselineY : yForScore(score);
          return {
            ...point,
            index,
            x,
            y,
            score,
          };
        });

        const scoreValues = mapped
          .map((point) => point.score)
          .filter((value) => Number.isFinite(value));
        const averageRaw = Number(options?.averageScore);
        const averageScore =
          Number.isFinite(averageRaw) ? Math.max(0, Math.min(100, averageRaw))
          : scoreValues.length ? toAverage(scoreValues)
          : null;
        const averageY = Number.isFinite(averageScore) ? yForScore(averageScore) : null;
        const showTrendLine = options?.showTrendLine !== false;
        const trendPoints = mapped.filter((point) => point.score !== null);
        let trendSvg = "";
        if (showTrendLine && trendPoints.length >= 2) {
          const trendStats = trendPoints.reduce(
            (acc, point) => {
              const x = Number(point.index);
              const y = Number(point.score);
              return {
                n: acc.n + 1,
                sumX: acc.sumX + x,
                sumY: acc.sumY + y,
                sumXX: acc.sumXX + x * x,
                sumXY: acc.sumXY + x * y,
              };
            },
            { n: 0, sumX: 0, sumY: 0, sumXX: 0, sumXY: 0 },
          );
          const denominator =
            trendStats.n * trendStats.sumXX - trendStats.sumX * trendStats.sumX;
          if (Number.isFinite(denominator) && Math.abs(denominator) > 0.000001) {
            const slope =
              (trendStats.n * trendStats.sumXY - trendStats.sumX * trendStats.sumY) /
              denominator;
            const intercept =
              (trendStats.sumY - slope * trendStats.sumX) / trendStats.n;
            const firstPoint = trendPoints[0];
            const lastPoint = trendPoints[trendPoints.length - 1];
            const firstTrendScore = Math.max(
              0,
              Math.min(100, intercept + slope * firstPoint.index),
            );
            const lastTrendScore = Math.max(
              0,
              Math.min(100, intercept + slope * lastPoint.index),
            );
            const firstTrendY = yForScore(firstTrendScore);
            const lastTrendY = yForScore(lastTrendScore);
            const slopeLabel = `${slope >= 0 ? "+" : ""}${slope.toFixed(2)} / index`;
            trendSvg =
              `<line class="grade-chart-trend" x1="${firstPoint.x.toFixed(2)}" y1="${firstTrendY.toFixed(2)}" x2="${lastPoint.x.toFixed(2)}" y2="${lastTrendY.toFixed(2)}">` +
              `<title>${escapeHtml(`Trendline slope ${slopeLabel}`)}</title>` +
              `</line>`;
          }
        }
        const thresholdY = yForScore(thresholdScore);
        const yTicks = [100, 80, 60, 40, 20, 0];
        const gridSvg = yTicks
          .map((tick) => {
            const y = yForScore(tick);
            return (
              `<line class="grade-chart-grid" x1="${leftPad}" y1="${y.toFixed(2)}" x2="${(width - rightPad).toFixed(2)}" y2="${y.toFixed(2)}"></line>` +
              `<text class="grade-chart-axis-label" x="${(leftPad - 6).toFixed(2)}" y="${(y + 3.4).toFixed(2)}" text-anchor="end">${tick}</text>`
            );
          })
          .join("");

        const linePoints = mapped
          .filter((point) => point.score !== null)
          .map((point) => `${point.x.toFixed(2)},${point.y.toFixed(2)}`)
          .join(" ");
        const linePointCount = linePoints ? linePoints.split(" ").length : 0;
        const lineSvg =
          linePointCount >= 2 ?
            `<polyline class="grade-chart-data" points="${linePoints}"></polyline>`
          : "";

        const dotsSvg = mapped
          .map((point) => {
            const fill = gradeScoreBandColor(point.score);
            const radius = point.score === null ? 2.6 : 3.6;
            const scoreLabel =
              point.score === null ? "No score" : `${Math.round(point.score)}%`;
            const dateLabel = normalizeText(point?.date);
            const titleLabel = normalizeText(point?.title);
            const hoverLabel = [scoreLabel, titleLabel, dateLabel]
              .filter(Boolean)
              .join(" | ");
            return (
              `<circle class="grade-chart-dot" cx="${point.x.toFixed(2)}" cy="${point.y.toFixed(2)}" r="${radius}" fill="${fill}" stroke="#ffffff" stroke-width="1">` +
              `<title>${escapeHtml(hoverLabel)}</title>` +
              `</circle>`
            );
          })
          .join("");

        const thresholdSvg =
          `<line class="grade-chart-threshold" x1="${leftPad}" y1="${thresholdY.toFixed(2)}" x2="${(width - rightPad).toFixed(2)}" y2="${thresholdY.toFixed(2)}"></line>` +
          `<text class="grade-chart-axis-label" x="${(width - rightPad - 2).toFixed(2)}" y="${Math.max(topPad + 9, thresholdY - 4).toFixed(2)}" text-anchor="end">Target ${Math.round(thresholdScore)}%</text>`;
        const averageSvg =
          Number.isFinite(averageY) ?
            `<line class="grade-chart-average" x1="${leftPad}" y1="${averageY.toFixed(2)}" x2="${(width - rightPad).toFixed(2)}" y2="${averageY.toFixed(2)}"></line>` +
            `<text class="grade-chart-axis-label" x="${(width - rightPad - 2).toFixed(2)}" y="${Math.max(topPad + 18, averageY + 11).toFixed(2)}" text-anchor="end">Avg ${Math.round(averageScore)}%</text>`
          : "";

        const xLabelIndexes = Array.from(
          new Set(
            [
              0,
              Math.floor(Math.max(0, mapped.length - 1) / 2),
              Math.max(0, mapped.length - 1),
            ].filter((index) => index >= 0 && index < mapped.length),
          ),
        );
        const xLabelsSvg = xLabelIndexes
          .map((index) => {
            const point = mapped[index];
            if (!point) return "";
            const rawDate = normalizeText(point.date).slice(0, 10);
            const compactDate =
              /^\d{4}-\d{2}-\d{2}$/.test(rawDate) ?
                `${rawDate.slice(5, 7)}/${rawDate.slice(8, 10)}`
              : rawDate;
            const label = compactDate || `${index + 1}`;
            return `<text class="grade-chart-axis-label" x="${point.x.toFixed(2)}" y="${(height - 8).toFixed(2)}" text-anchor="middle">${escapeHtml(label)}</text>`;
          })
          .join("");

        return (
          `<svg class="grade-chart-svg" viewBox="0 0 ${width} ${height}" role="img">` +
          `<title>${escapeHtml(laneLabel)}</title>` +
          `${gridSvg}` +
          `<line class="grade-chart-axis" x1="${leftPad}" y1="${baselineY}" x2="${(width - rightPad).toFixed(2)}" y2="${baselineY}"></line>` +
          `<line class="grade-chart-axis" x1="${leftPad}" y1="${topPad}" x2="${leftPad}" y2="${baselineY}"></line>` +
          `${thresholdSvg}` +
          `${averageSvg}` +
          `${trendSvg}` +
          `${lineSvg}` +
          `${dotsSvg}` +
          `${xLabelsSvg}` +
          `</svg>`
        );
      }

      function gradeChartFilteredRows(rows = [], chart = gradeChartState()) {
        const source = Array.isArray(rows) ? rows : [];
        const normalized = normalizeGradeChartState(chart);
        const todayIso = localIsoDate();
        const currentSchoolYear = gradeChartCurrentSchoolYear();
        const selectedSchoolYear = normalizeGradeChartOperationalSchoolYear(
          normalized.schoolYear,
        );
        let rangeStart = "";
        let rangeEnd = "";

        if (normalized.period === "week") {
          rangeEnd = todayIso;
          rangeStart = isoDateOffset(todayIso, -6);
        } else if (normalized.period === "quarter" || normalized.period === "qtd") {
          const targetSchoolYear = selectedSchoolYear;
          const quarterRange = gradeChartQuarterRange(
            normalized.quarter,
            targetSchoolYear,
          );
          rangeStart = normalizeText(quarterRange.startDate).slice(0, 10);
          rangeEnd =
            normalized.period === "quarter" ?
              normalizeText(quarterRange.endDate).slice(0, 10)
            : todayIso;
        } else if (normalized.period === "sytd") {
          const targetSchoolYear = selectedSchoolYear;
          const schoolYearRange = gradeChartSchoolYearRange(targetSchoolYear);
          rangeStart = normalizeText(schoolYearRange.startDate).slice(0, 10);
          rangeEnd =
            targetSchoolYear === currentSchoolYear ? todayIso : (
              normalizeText(schoolYearRange.endDate).slice(0, 10)
            );
        } else if (normalized.period === "custom") {
          rangeStart = normalizeText(normalized.customFrom).slice(0, 10);
          rangeEnd = normalizeText(normalized.customTo).slice(0, 10);
        }

        if (rangeStart && rangeEnd && compareIsoDateText(rangeStart, rangeEnd) > 0) {
          const swapped = rangeStart;
          rangeStart = rangeEnd;
          rangeEnd = swapped;
        }

        const filteredRows = source.filter((row) => {
          const rowSchoolYear = gradeRecordSchoolYear(row);
          if (selectedSchoolYear && rowSchoolYear && rowSchoolYear !== selectedSchoolYear)
            return false;
          if (!rangeStart && !rangeEnd) return true;
          const rowDate = gradeRecordPrimaryIsoDate(row);
          if (!rowDate) return false;
          if (rangeStart && compareIsoDateText(rowDate, rangeStart) < 0) return false;
          if (rangeEnd && compareIsoDateText(rowDate, rangeEnd) > 0) return false;
          return true;
        });

        return {
          rows: filteredRows,
          rangeStart,
          rangeEnd,
          selectedSchoolYear,
          currentSchoolYear,
          period: normalized.period,
        };
      }

      function refreshGradeChartControls(rows = []) {
        const chart = gradeChartState();
        const sourceRows = Array.isArray(rows) ? rows : [];
        const periodBarEl = document.getElementById("gradeChartPeriods");
        const groupByEl = document.getElementById("gradeChartGroupBy");
        const quarterEl = document.getElementById("gradeChartQuarter");
        const schoolYearEl = document.getElementById("gradeChartSchoolYear");
        const customFromEl = document.getElementById("gradeChartCustomFrom");
        const customToEl = document.getElementById("gradeChartCustomTo");

        periodBarEl
          ?.querySelectorAll("[data-grade-chart-period]")
          .forEach((buttonEl) => {
            const period = normalizedGradeChartPeriod(
              buttonEl.getAttribute("data-grade-chart-period"),
            );
            buttonEl.classList.toggle("is-active", chart.period === period);
          });

        if (groupByEl) groupByEl.value = normalizedGradeChartGroupBy(chart.groupBy);
        applyGradeChartCurrentQuarterDefault();
        const activeChart = gradeChartState();
        if (quarterEl) {
          quarterEl.value = quarterKey(activeChart.quarter) || gradeChartCurrentQuarter();
          quarterEl.disabled = !["quarter", "qtd"].includes(activeChart.period);
        }

        if (schoolYearEl) {
          const currentSchoolYear = gradeChartCurrentSchoolYear();
          const optionValues = gradeChartSchoolYearOptionValues(sourceRows);
          schoolYearEl.innerHTML = "";
          optionValues.forEach((schoolYear) => {
            const option = document.createElement("option");
            option.value = schoolYear;
            option.textContent =
              schoolYear === currentSchoolYear ? `${schoolYear} (current)` : schoolYear;
            schoolYearEl.appendChild(option);
          });
          if (!optionValues.includes(chart.schoolYear)) {
            setGradeChartState({ schoolYear: currentSchoolYear });
          }
          schoolYearEl.value = gradeChartState().schoolYear;
        }

        if (customFromEl) {
          customFromEl.value = normalizeText(chart.customFrom).slice(0, 10);
          customFromEl.disabled = chart.period !== "custom";
        }
        if (customToEl) {
          customToEl.value = normalizeText(chart.customTo).slice(0, 10);
          customToEl.disabled = chart.period !== "custom";
        }
      }

      function renderGradePulseChart(rows = []) {
        const lanesEl = document.getElementById("gradeChartLanes");
        const summaryEl = document.getElementById("gradeChartSummary");
        if (!lanesEl || !summaryEl) return;

        const sourceRows = Array.isArray(rows) ? rows : [];
        refreshGradeChartControls(sourceRows);
        const chart = gradeChartState();
        const filtered = gradeChartFilteredRows(sourceRows, chart);
        const grouped = new Map();

        filtered.rows.forEach((row) => {
          const group = gradeChartGroupIdentity(row, chart.groupBy);
          if (!grouped.has(group.key)) {
            grouped.set(group.key, { key: group.key, label: group.label, rows: [] });
          }
          grouped.get(group.key).rows.push(row);
        });

        const lanes = Array.from(grouped.values())
          .map((group) => {
            const orderedRows = [...group.rows].sort((left, right) => {
              const leftDate = gradeRecordPrimaryIsoDate(left);
              const rightDate = gradeRecordPrimaryIsoDate(right);
              const dateCompare = compareIsoDateText(leftDate, rightDate);
              if (dateCompare !== 0) return dateCompare;
              return normalizeText(left?.id).localeCompare(normalizeText(right?.id));
            });
            const points = orderedRows.map((row) => ({
              score: gradeSortScoreValue(row),
              date: gradeRecordPrimaryIsoDate(row),
              title: normalizeText(
                row?.assignmentName || row?.className || row?.eaglesId,
              ),
            }));
            const scoreValues = points
              .map((entry) => Number(entry.score))
              .filter((entry) => Number.isFinite(entry));
            const averageScore = scoreValues.length ? toAverage(scoreValues) : null;
            const trendScore =
              scoreValues.length >= 2 ?
                scoreValues[scoreValues.length - 1] - scoreValues[0]
              : null;
            const completionRows = orderedRows.filter(
              (entry) => typeof entry?.homeworkCompleted === "boolean",
            );
            const completionDone = completionRows.filter(
              (entry) => entry.homeworkCompleted === true,
            ).length;
            const onTimeRows = orderedRows.filter(
              (entry) => typeof entry?.homeworkOnTime === "boolean",
            );
            const onTimeDone = onTimeRows.filter(
              (entry) => entry.homeworkOnTime === true,
            ).length;
            return {
              key: group.key,
              label: group.label,
              rows: orderedRows,
              points,
              averageScore,
              trendScore,
              completionRate:
                completionRows.length ?
                  percentValue(completionDone, completionRows.length)
                : null,
              onTimeRate:
                onTimeRows.length ? percentValue(onTimeDone, onTimeRows.length) : null,
            };
          })
          .sort((left, right) => {
            const leftAverage =
              Number.isFinite(left.averageScore) ? left.averageScore : -1;
            const rightAverage =
              Number.isFinite(right.averageScore) ? right.averageScore : -1;
            if (leftAverage !== rightAverage) return rightAverage - leftAverage;
            return normalizeText(left.label).localeCompare(
              normalizeText(right.label),
              undefined,
              { sensitivity: "base" },
            );
          });

        const periodLabel = gradeChartPeriodLabel(filtered.period);
        const groupLabel = gradeChartGroupLabel(chart.groupBy);
        const schoolYearLabel = chart.schoolYear;
        const rangeLabel =
          filtered.rangeStart || filtered.rangeEnd ?
            `${filtered.rangeStart || "..."} to ${filtered.rangeEnd || "..."}`
          : "All dates";

        if (!lanes.length) {
          state.gradeChartLaneSnapshotByKey = {};
          closeGradeChartModal();
          lanesEl.innerHTML =
            '<p class="grade-chart-empty">No grade records match the pulse chart period and scope.</p>';
          summaryEl.textContent = `Period: ${periodLabel} | Group: ${groupLabel} | School year: ${schoolYearLabel} | Range: ${rangeLabel} | Rows: 0 | Lanes: 0`;
          return;
        }

        state.gradeChartLaneSnapshotByKey = Object.fromEntries(
          lanes.map((lane) => [lane.key, lane]),
        );
        if (state.gradeChartModalOpen) {
          const activeLaneKey = normalizeText(state.gradeChartModalLaneKey);
          if (activeLaneKey && state.gradeChartLaneSnapshotByKey[activeLaneKey]) {
            openGradeChartModalForLaneKey(activeLaneKey);
          } else {
            closeGradeChartModal();
          }
        }

        lanesEl.innerHTML = lanes
          .map((lane) => {
            const averageLabel = gradeScoreText(lane.averageScore);
            const trendLabel =
              Number.isFinite(lane.trendScore) ?
                `${lane.trendScore >= 0 ? "+" : ""}${Math.round(lane.trendScore)}`
              : "n/a";
            const completionLabel =
              Number.isFinite(lane.completionRate) ?
                `${Math.round(lane.completionRate)}%`
              : "n/a";
            const onTimeLabel =
              Number.isFinite(lane.onTimeRate) ?
                `${Math.round(lane.onTimeRate)}%`
              : "n/a";
            const sparkline = gradeChartSparklineSvg(
              lane.points,
              `${lane.label} score pulse`,
              {
                thresholdScore: 80,
                averageScore: lane.averageScore,
              },
            );
            return (
              `<article class="grade-chart-lane data-surface" data-grade-chart-lane="${escapeHtml(lane.key)}" data-surface-role="data-surface">` +
              `<div class="grade-chart-lane-head">` +
              `<h4 class="grade-chart-lane-title">${escapeHtml(lane.label)}</h4>` +
              `<div class="grade-chart-lane-actions">` +
              `<p class="grade-chart-lane-metrics">Rows ${lane.rows.length} | Avg ${averageLabel}</p>` +
              `<button type="button" class="grade-chart-expand-btn portal-button portal-button-info" title="Open the detailed grade chart for this level" aria-label="Open the detailed grade chart for this level" data-grade-chart-open="${escapeHtml(lane.key)}">Open</button>` +
              `</div>` +
              `</div>` +
              `<div class="grade-chart-svg-wrap">${sparkline}</div>` +
              `<p class="grade-chart-lane-legend">` +
              `<span class="grade-chart-legend-item"><span class="grade-chart-legend-dot data" aria-hidden="true"></span>Data</span>` +
              `<span class="grade-chart-legend-item"><span class="grade-chart-legend-dot trend" aria-hidden="true"></span>Trend</span>` +
              `<span class="grade-chart-legend-item"><span class="grade-chart-legend-dot threshold" aria-hidden="true"></span>Target 80%</span>` +
              `<span class="grade-chart-legend-item"><span class="grade-chart-legend-dot average" aria-hidden="true"></span>Average</span>` +
              `</p>` +
              `<p class="grade-chart-lane-meta">Trend: ${trendLabel} | HW Completion: ${completionLabel} | On-Time: ${onTimeLabel}</p>` +
              `</article>`
            );
          })
          .join("");

        summaryEl.textContent = `Period: ${periodLabel} | Group: ${groupLabel} | School year: ${schoolYearLabel} | Range: ${rangeLabel} | Rows: ${filtered.rows.length} | Lanes: ${lanes.length}`;
      }

      function closeGradeChartModal() {
        const modalEl = document.getElementById("gradeChartModal");
        if (!(modalEl instanceof HTMLDivElement)) return;
        modalEl.classList.add("hidden");
        state.gradeChartModalOpen = false;
        state.gradeChartModalLaneKey = "";
      }

      function openGradeChartModalForLaneKey(laneKey = "") {
        const key = normalizeText(laneKey);
        const lane = state.gradeChartLaneSnapshotByKey?.[key];
        if (!lane) return;
        const modalEl = document.getElementById("gradeChartModal");
        const titleEl = document.getElementById("gradeChartModalTitle");
        const metaEl = document.getElementById("gradeChartModalMeta");
        const svgWrapEl = document.getElementById("gradeChartModalSvgWrap");
        if (!(modalEl instanceof HTMLDivElement) || !titleEl || !metaEl || !svgWrapEl)
          return;
        const chart = gradeChartState();
        const trendLabel =
          Number.isFinite(lane?.trendScore) ?
            `${lane.trendScore >= 0 ? "+" : ""}${Math.round(lane.trendScore)}`
          : "n/a";
        titleEl.textContent = `${lane.label} | Grades Pulse Detail`;
        metaEl.textContent = `Period: ${gradeChartPeriodLabel(chart.period)} | Group: ${gradeChartGroupLabel(chart.groupBy)} | Rows: ${lane.rows.length} | Avg: ${gradeScoreText(lane.averageScore)} | Trend Δ: ${trendLabel}`;
        const detailSvg = gradeChartSparklineSvg(
          lane.points,
          `${lane.label} score pulse detail`,
          {
            thresholdScore: 80,
            averageScore: lane.averageScore,
            width: 980,
            height: 420,
            showTrendLine: true,
          },
        );
        svgWrapEl.innerHTML = detailSvg;
        modalEl.classList.remove("hidden");
        state.gradeChartModalOpen = true;
        state.gradeChartModalLaneKey = key;
      }

      function isTrackedHomeworkRecord(record = {}) {
        return (
          typeof record?.homeworkCompleted === "boolean" ||
          typeof record?.homeworkOnTime === "boolean" ||
          Boolean(parseDateTime(record?.dueAt)) ||
          Boolean(parseDateTime(record?.submittedAt))
        );
      }

      function parentTrackingRecipientsForStudent(student) {
        return assignmentRecipientsForStudent(student);
      }

      function parentTrackingMetricsForStudent(student, selectedLevel, classDate) {
        const gradeRows =
          Array.isArray(student?.gradeRecords) ? student.gradeRecords : [];
        const currentQuarter = quarterKey(quarterFromIsoDate(classDate));
        const records = gradeRows.filter(
          (entry) =>
            levelMatchesGradeRecord(entry, selectedLevel) &&
            gradeRecordMatchesQuarter(entry, currentQuarter, classDate),
        );
        const asOf = parseIsoDateLocal(classDate) || new Date();
        const shiftedAsOfEnd = shiftToFixedTimeZone(asOf);
        shiftedAsOfEnd.setUTCHours(23, 59, 59, 999);
        const asOfEnd = shiftFromFixedTimeZone(shiftedAsOfEnd);
        const trackedHomeworkRecords = records.filter((entry) =>
          isTrackedHomeworkRecord(entry),
        );

        const completedCount = trackedHomeworkRecords.filter((entry) =>
          isGradeRecordCompleted(entry),
        ).length;
        const onTimeCount = trackedHomeworkRecords.filter((entry) =>
          isGradeRecordOnTime(entry),
        ).length;
        const academicValues = records
          .map((entry) => gradeRecordAcademicScore(entry))
          .filter((entry) => entry !== null);
        const behaviorScore = toAverage(records.map((entry) => entry?.behaviorScore));
        const skillsScore = toAverage(
          records.map((entry) => entry?.participationScore),
        );
        const fallbackAcademic = toAverage(records.map((entry) => entry?.inClassScore));
        const academicScore = toAverage(academicValues) ?? fallbackAcademic;
        const outstanding = trackedHomeworkRecords
          .filter((entry) => isGradeRecordOutstanding(entry, asOfEnd))
          .slice()
          .sort((left, right) => {
            const leftDue =
              parseDateTime(left?.dueAt)?.valueOf() || Number.MAX_SAFE_INTEGER;
            const rightDue =
              parseDateTime(right?.dueAt)?.valueOf() || Number.MAX_SAFE_INTEGER;
            if (leftDue !== rightDue) return leftDue - rightDue;
            return normalizeText(left?.assignmentName).localeCompare(
              normalizeText(right?.assignmentName),
            );
          });

        return {
          behaviorScore: roundTo2(behaviorScore),
          skillsScore: roundTo2(skillsScore),
          participationScore: roundTo2(skillsScore),
          academicScore: roundTo2(academicScore),
          homeworkOnTimeRate:
            roundTo2(percentValue(onTimeCount, trackedHomeworkRecords.length)) || 0,
          homeworkCompletionRate:
            roundTo2(percentValue(completedCount, trackedHomeworkRecords.length)) || 0,
          records,
          outstanding,
        };
      }

      function parentTrackingFieldSetValue(fieldId, value) {
        const el = document.getElementById(fieldId);
        if (!el) return;
        el.value = value === null || value === undefined ? "" : String(value);
      }

      const PARENT_TRACKING_VISION_STATUS_DEFAULT = "no-issues";
      const PARENT_TRACKING_VISION_STATUS_ALLOWED = new Set([
        "no-issues",
        "needs-check",
        "monitor",
      ]);

      function normalizeParentTrackingVisionStatus(value = "") {
        const normalized = normalizeText(value);
        return PARENT_TRACKING_VISION_STATUS_ALLOWED.has(normalized) ? normalized : (
            PARENT_TRACKING_VISION_STATUS_DEFAULT
          );
      }

      function parentTrackingVisionStatusValue() {
        const checked = document.querySelector('input[name="pt_visionStatus"]:checked');
        return normalizeParentTrackingVisionStatus(checked?.value);
      }

      function setParentTrackingVisionStatus(value = "") {
        const normalized = normalizeParentTrackingVisionStatus(value);
        const target = document.querySelector(
          `input[name="pt_visionStatus"][value="${normalized}"]`,
        );
        if (target) target.checked = true;
      }

      function parentTrackingHomeworkSnapshotFromContext(
        context = {},
        homeworkAnnouncement = "",
      ) {
        const metrics =
          context?.metrics && typeof context.metrics === "object" ?
            context.metrics
          : {};
        const studentRefId = normalizeText(
          context?.studentRefId || context?.student?.id,
        );
        const classDate = normalizeText(context?.classDate || "");
        const buckets = parentTrackingHomeworkBuckets(
          metrics,
          studentRefId,
          classDate,
        );
        const currentHomework = buckets.currentWeekHomework;
        const pastDueHomework = buckets.pastDueHomework;
        const firstCurrentHomework = currentHomework[0] || null;
        const currentHomeworkName =
          normalizeText(firstCurrentHomework?.assignmentName) ||
          "Current week homework";
        const currentHomeworkDue = formatDate(firstCurrentHomework?.dueAt);
        const currentHomeworkLink = normalizeText(firstCurrentHomework?.deepLink);
        const currentCount = Math.max(0, currentHomework.length);
        const pastDueCount = Math.max(0, pastDueHomework.length);
        const fallbackAnnouncement =
          currentCount > 0 ?
            `${currentHomeworkName}${currentHomeworkDue ? ` | due ${currentHomeworkDue}` : ""}${currentHomeworkLink ? ` | ${currentHomeworkLink}` : ""}`
          : pastDueCount > 0 ?
            `${pastDueCount} past due homework item(s) require attention.`
          : "No current week homework due later this week.";
        const normalizedAnnouncement =
          normalizeText(homeworkAnnouncement) || fallbackAnnouncement;
        const currentSummary =
          currentCount > 0 ?
            `${currentCount} current week homework item(s).`
          : "No current week homework due later this week.";
        const pastDueSummary =
          pastDueCount > 0 ?
            `${pastDueCount} past due homework item(s) should already have been done.`
          : "No past due homework.";
        return {
          homeworkAnnouncement: normalizedAnnouncement,
          currentHomeworkStatus: currentCount > 0 ? "Current week" : "None",
          currentHomeworkHeader: "Current week homework",
          currentHomeworkSummary: currentSummary,
          currentHomeworkCount: String(currentCount),
          pastDueHomeworkCount: String(pastDueCount),
          pastDueHomeworkSummary: pastDueSummary,
          currentHomeworkAssignments: currentHomework
            .map((entry) =>
              parentTrackingHomeworkRowSnapshot(entry, studentRefId),
            )
            .filter(Boolean),
          pastDueHomeworkAssignments: pastDueHomework
            .map((entry) =>
              parentTrackingHomeworkRowSnapshot(entry, studentRefId),
            )
            .filter(Boolean),
        };
      }

      function parentTrackingOutstandingSnapshotRows(metrics = {}, studentRefId = "") {
        return parentTrackingPastDueSnapshotRows(metrics, studentRefId, "");
      }

      function clearParentTrackingComputedFields() {
        parentTrackingFieldSetValue("pt_behaviorScore", "");
        parentTrackingFieldSetValue("pt_participationScore", "");
        parentTrackingFieldSetValue("pt_academicScore", "");
        parentTrackingFieldSetValue("pt_homeworkOnTimeRate", "");
        parentTrackingFieldSetValue("pt_homeworkCompletionRate", "");
        parentTrackingFieldSetValue("pt_participationPointsAward", "");
        parentTrackingFieldSetValue("pt_recipients", "");
        parentTrackingFieldSetValue("pt_homeworkAnnouncement", "");
        const currentRowsEl = document.getElementById("pt_currentRows");
        if (currentRowsEl)
          currentRowsEl.innerHTML =
            '<tr><td colspan="4">Select a student to load homework status.</td></tr>';
        const rowsEl = document.getElementById("pt_outstandingRows");
        if (rowsEl)
          rowsEl.innerHTML =
            '<tr><td colspan="4">Select a student to load homework status.</td></tr>';
        clearParentTrackingDetailPanel();
      }

      function renderParentTrackingMetrics(metrics = {}) {
        applyParentTrackingRubricSummaryScores();
        parentTrackingFieldSetValue(
          "pt_academicScore",
          normalizeParentTrackingScoreValue(metrics.academicScore),
        );
        parentTrackingFieldSetValue(
          "pt_homeworkOnTimeRate",
          metrics.homeworkOnTimeRate ?? 0,
        );
        parentTrackingFieldSetValue(
          "pt_homeworkCompletionRate",
          metrics.homeworkCompletionRate ?? 0,
        );
      }

      function renderParentTrackingHomeworkAnnouncement(
        student = null,
        metrics = {},
        classDate = "",
      ) {
        const targetEl = document.getElementById("pt_homeworkAnnouncement");
        if (!targetEl) return;
        const studentRefId = normalizeText(student?.id);
        if (!studentRefId) {
          targetEl.value = "";
          return;
        }
        const buckets = parentTrackingHomeworkBuckets(
          metrics,
          studentRefId,
          classDate,
        );
        if (!buckets.currentWeekHomework.length) {
          targetEl.value =
            buckets.pastDueHomework.length ?
              `${buckets.pastDueHomework.length} past due homework item(s) need attention.`
            : "No current week homework due later this week.";
          return;
        }
        const firstRow = buckets.currentWeekHomework[0];
        const assignment =
          normalizeText(firstRow?.assignmentName) || "Current week homework";
        const due = formatDate(firstRow?.dueAt);
        const deepLink = normalizeText(
          parentTrackingDeepLinkAbsolute(studentRefId, normalizeText(firstRow?.id)),
        );
        targetEl.value = `${assignment}${due ? ` | due ${due}` : ""}${deepLink ? ` | ${deepLink}` : ""}`;
      }

      function showParentTrackingAssignmentDetail(record = {}, student = null) {
        const panel = document.getElementById("pt_assignmentDetailPanel");
        const titleEl = document.getElementById("pt_assignmentDetailTitle");
        const bodyEl = document.getElementById("pt_assignmentDetailBody");
        if (!panel || !titleEl || !bodyEl) return;

        const assignmentName =
          normalizeText(record.assignmentName) || "(untitled homework)";
        const dueAt = formatDate(record.dueAt);
        const submittedAt = formatDate(record.submittedAt);
        const completionState =
          isGradeRecordCompleted(record) ? "Completed" : "Uncompleted";
        const onTimeState = isGradeRecordOnTime(record) ? "On Time" : "Late / Pending";
        const studentName = studentIdentityLabel(student, {
          preferEnglish: true,
          wrapName: true,
          includeStudentNumber: true,
        });
        const deepLink = parentTrackingDeepLinkAbsolute(student?.id, record?.id);

        titleEl.textContent = `Homework Details: ${assignmentName}`;
        bodyEl.textContent = [
          studentName ? `Student: ${studentName}` : "",
          `Homework item: ${assignmentName}`,
          `Class: ${normalizeText(record.className) || "-"}`,
          `Quarter: ${normalizeText(record.quarter) || "-"}`,
          `Due: ${dueAt || "-"}`,
          `Submitted: ${submittedAt || "-"}`,
          `Status: ${completionState}`,
          `Timeliness: ${onTimeState}`,
          `Score: ${record.score ?? "-"}/${record.maxScore ?? "-"}`,
          `Behavior: ${record.behaviorScore ?? "-"}`,
          `Skills: ${record.participationScore ?? "-"}`,
          `Academic/In Class: ${record.inClassScore ?? "-"}`,
          `Comments: ${normalizeText(record.comments) || "-"}`,
          `Dynamic Link: ${deepLink}`,
        ]
          .filter(Boolean)
          .join("\n");
        panel.classList.remove("hidden");
      }

      async function openParentTrackingAssignmentLink(
        studentRefId,
        assignmentId = "",
        options = {},
      ) {
        const { syncUrl = false } = options;
        const targetStudentRefId = normalizeText(studentRefId);
        if (!targetStudentRefId) return;

        const sourceStudent = parentTrackingStudentSource().find(
          (entry) => normalizeText(entry?.id) === targetStudentRefId,
        );
        if (sourceStudent?.profile?.currentGrade) {
          state.parentTracking.selectedLevel = resolveSystemLevelName(
            sourceStudent.profile.currentGrade,
          );
        }

        setActivePage("parent-tracking", { syncUrl });
        await refreshParentTracking({
          preferredStudentId: targetStudentRefId,
          preferredAssignmentId: assignmentId,
        });
      }

      function renderParentTrackingHomeworkRows(
        rowsElId = "",
        records = [],
        student = null,
        {
          emptyMessage = "No homework items for selected class date.",
          clearDetailOnEmpty = false,
          forceLateStatus = false,
        } = {},
      ) {
        const rowsEl = document.getElementById(rowsElId);
        if (!rowsEl) return;
        const studentRefId = normalizeText(student?.id);

        if (rowsElId === "pt_outstandingRows") {
          state.parentTracking.outstandingByRecordId = Object.fromEntries(
            (Array.isArray(records) ? records : [])
              .map((entry) => [normalizeText(entry?.id), entry])
              .filter(([id]) => Boolean(id)),
          );
        }

        if (!records.length) {
          rowsEl.innerHTML = `<tr><td colspan="4">${escapeHtml(emptyMessage)}</td></tr>`;
          if (clearDetailOnEmpty) clearParentTrackingDetailPanel();
          return;
        }

        rowsEl.innerHTML = "";
        records.forEach((record) => {
          const dueAt = normalizeText(record?.dueAt).slice(0, 10);
          const assignmentName =
            normalizeText(record?.assignmentName) || "(untitled homework)";
          const rowId = normalizeText(record?.id);
          const deepLink = parentTrackingDeepLinkPath(studentRefId, rowId);
          const tr = document.createElement("tr");
          tr.innerHTML = `
          <td>${escapeHtml(dueAt || "-")}</td>
          <td>
            <a href="${escapeHtml(deepLink)}" data-pt-open-assignment="${escapeHtml(rowId)}" class="assignment-item-link">${escapeHtml(assignmentName)}</a>
          </td>
          <td>${forceLateStatus ? "Late / Pending" : (isGradeRecordCompleted(record) ? "Completed" : "Pending")}</td>
          <td><button type="button" class="parent-tracking-link-btn portal-button portal-button-info" title="Open assignment details and parent tracking" aria-label="Open assignment details and parent tracking" data-pt-view-assignment="${escapeHtml(rowId)}">View details</button></td>
        `;

          const link = tr.querySelector(`[data-pt-open-assignment="${rowId}"]`);
          link?.addEventListener("click", (event) => {
            event.preventDefault();
            openParentTrackingAssignmentLink(studentRefId, rowId).catch(handleError);
          });

          const viewButton = tr.querySelector(`[data-pt-view-assignment="${rowId}"]`);
          viewButton?.addEventListener("click", () => {
            showParentTrackingAssignmentDetail(record, student);
          });
          rowsEl.appendChild(tr);
        });
      }

      function renderParentTrackingCurrentRows(records = [], student = null) {
        renderParentTrackingHomeworkRows("pt_currentRows", records, student, {
          emptyMessage:
            "No current week homework due later this week for the selected class date.",
          clearDetailOnEmpty: false,
          forceLateStatus: false,
        });
      }

      function renderParentTrackingOutstandingRows(records = [], student = null) {
        renderParentTrackingHomeworkRows("pt_outstandingRows", records, student, {
          emptyMessage: "No past due homework for the selected class date.",
          clearDetailOnEmpty: true,
          forceLateStatus: true,
        });
      }

      async function loadParentTrackingStudentDetail(
        studentRefId,
        { force = false } = {},
      ) {
        const targetId = normalizeText(studentRefId);
        if (!targetId) return null;
        if (!force && state.parentTracking.studentDetailsByStudentId[targetId]) {
          return state.parentTracking.studentDetailsByStudentId[targetId];
        }
        const detail = await api(`/api/admin/students/${encodeURIComponent(targetId)}`);
        if (!detail?.id) return null;
        state.parentTracking.studentDetailsByStudentId[targetId] = detail;
        return detail;
      }

      function renderParentTrackingLevelTiles() {
        const tilesEl = document.getElementById("parentTrackingLevelTiles");
        const hintEl = document.getElementById("parentTrackingLevelHint");
        if (!tilesEl) return;
        const selectedLevel = selectedParentTrackingLevel();
        const levels = collectAttendanceLevelNames([selectedLevel]);
        if (!levels.length) {
          tilesEl.innerHTML = "";
          if (hintEl) hintEl.textContent = "No class levels available.";
          return;
        }

        tilesEl.innerHTML = "";
        levels.forEach((levelName) => {
          const canonicalLevel = resolveSystemLevelName(levelName);
          if (!canonicalLevel) return;
          const theme = getLevelTheme(canonicalLevel);
          const tile = document.createElement("button");
          tile.type = "button";
          tile.className = "attendance-level-tile";
          tile.dataset.level = canonicalLevel;
          if (levelNamesMatch(canonicalLevel, selectedLevel))
            tile.classList.add("active");
          const config = attendanceLevelTileConfig(canonicalLevel);
          tile.style.backgroundColor = config.bgColor;
          tile.style.color = theme.textColor;
          tile.style.borderColor = theme.borderColor;
          tile.style.setProperty("--attendance-level-title-color", theme.textColor);
          tile.style.setProperty("--attendance-level-title-bg", tileTitleBackground(theme));
          if (config.imageDataUrl) {
            const safeUrl = config.imageDataUrl.replace(/"/g, "%22");
            tile.style.backgroundImage = `url("${safeUrl}")`;
          } else {
            tile.style.backgroundImage = "none";
          }
          const safeTitle = normalizeText(config.title);
          tile.innerHTML =
            safeTitle ?
              `<span class="attendance-level-tile-title">${escapeHtml(safeTitle)}</span>`
            : "";
          tile.addEventListener("click", () => {
            if (levelNamesMatch(state.parentTracking.selectedLevel, canonicalLevel))
              return;
            state.parentTracking.selectedLevel = canonicalLevel;
            state.parentTracking.selectedStudentId = "";
            resetParentTrackingManualMetricsTouched();
            ensureParentTrackingFormDefaults({ forceSummaryFromMemory: true });
            refreshParentTracking({ preserveStudentSelection: false }).catch(
              handleError,
            );
          });
          tilesEl.appendChild(tile);
        });
        if (hintEl)
          hintEl.textContent = `Loaded ${levels.length} levels. Select a class level to continue.`;
      }

      function renderAllClassLevelTiles() {
        renderAttendanceLevelTiles();
        renderAssignmentLevelTiles();
        renderParentTrackingLevelTiles();
      }

      function parentTrackingSelectedStudents() {
        return parentTrackingStudentsByLevel(selectedParentTrackingLevel());
      }

      function refreshParentTrackingStudentOptions({
        preserveStudentSelection = true,
        preferredStudentId = "",
      } = {}) {
        const selectEl = document.getElementById("pt_studentRefId");
        if (!selectEl) return [];
        const students = parentTrackingSelectedStudents();
        const preferredId = normalizeText(preferredStudentId);
        const current =
          preserveStudentSelection ?
            normalizeText(selectEl.value || state.parentTracking.selectedStudentId)
          : "";
        const targetId = preferredId || current;
        selectEl.innerHTML = '<option value="">Select student</option>';
        students.forEach((student) => {
          const option = document.createElement("option");
          option.value = student.id;
          option.textContent = studentIdentityLabel(student, {
            preferEnglish: true,
            wrapName: true,
            includeStudentNumber: true,
          });
          if (normalizeText(student.id) === targetId) option.selected = true;
          selectEl.appendChild(option);
        });
        if (!normalizeText(selectEl.value) && students.length) {
          selectEl.value =
            targetId && students.find((entry) => normalizeText(entry.id) === targetId) ?
              targetId
            : normalizeText(students[0].id);
        }
        state.parentTracking.selectedStudentId = normalizeText(selectEl.value);
        return students;
      }

      function ensureParentTrackingFormDefaults({
        forceSummaryFromMemory = false,
      } = {}) {
        const selectedLevel = selectedParentTrackingLevel();
        const classDateEl = document.getElementById("pt_classDate");
        const classDayEl = document.getElementById("pt_classDay");
        const classLevelEl = document.getElementById("pt_classLevel");
        if (classDateEl && !normalizeText(classDateEl.value))
          classDateEl.value = localIsoDate();
        if (classDayEl) classDayEl.value = dayLabelFromIsoDate(classDateEl?.value);
        if (classLevelEl)
          classLevelEl.value = selectedLevel ? fullLevelLabel(selectedLevel) : "";
        renderParentTrackingTeacherOptions();
        applyParentTrackingLessonSummaryFromMemory({ force: forceSummaryFromMemory });
        applyParentTrackingLevelBasedRubricAvailability();
      }

      function levelMatchesParentReport(record, selectedLevel) {
        const targetLevel = resolveSystemLevelName(selectedLevel || "");
        if (!targetLevel) return true;
        const reportLevel = resolveSystemLevelName(record?.level || "");
        if (reportLevel && levelNamesMatch(reportLevel, targetLevel)) return true;
        const className = normalizeText(record?.className);
        if (!className) return false;
        if (levelNamesMatch(className, targetLevel)) return true;
        if (normalizeLower(className) === normalizeLower(fullLevelLabel(targetLevel)))
          return true;
        return false;
      }

      function parentTrackingReportRowsForStudent(
        student,
        selectedLevel = selectedParentTrackingLevel(),
      ) {
        const reports =
          Array.isArray(student?.parentReports) ? student.parentReports : [];
        const eaglesId = normalizeText(student?.eaglesId);
        const studentRefId = normalizeText(student?.id);
        const fullName = normalizeText(student?.profile?.fullName);
        const englishName = normalizeText(student?.profile?.englishName);
        const studentNumber = parsePositiveInteger(student?.studentNumber);
        return reports
          .filter((row) => levelMatchesParentReport(row, selectedLevel))
          .map((row) => ({
            ...row,
            studentRefId,
            eaglesId,
            fullName,
            englishName,
            studentNumber,
            teacherName: normalizeText(row?.teacherName || row?.approvedByUsername),
          }));
      }

      function resolveParentTrackingReportStudentRefId(row = {}, student = null) {
        return normalizeText(
          row?.studentRefId ||
          row?.student?.id ||
          student?.id ||
          "",
        );
      }

      function resolveParentTrackingReportLevel(row = {}, student = null) {
        return resolveSystemLevelName(
          row?.level ||
            row?.className ||
            student?.profile?.currentGrade ||
            "",
        );
      }

      async function populateParentTrackingFormFromReportRow(row = {}, student = null) {
        const reportId = normalizeText(row.id);
        if (reportId) document.getElementById("pt_reportId").value = reportId;

        const reportClassDate =
          normalizeText(row.classDate) ||
          (row.generatedAt ? String(row.generatedAt).slice(0, 10) : "");
        const reportClassDay = normalizeText(row.classDay);
        if (reportClassDate) {
          parentTrackingFieldSetValue("pt_classDate", reportClassDate);
          parentTrackingFieldSetValue(
            "pt_classDay",
            reportClassDay || dayLabelFromIsoDate(reportClassDate),
          );
        }

        const persistedTeacherName = normalizeText(row.teacherName);
        const persistedLessonSummary = normalizeText(row.lessonSummary);
        const persistedVisionStatus = normalizeText(row.visionStatus);
        const persistedHomeworkAnnouncement = normalizeText(row.homeworkAnnouncement);
        if (persistedTeacherName) {
          persistParentTrackingTeacherNames([
            persistedTeacherName,
            ...(state.parentTracking?.teacherNames || []),
          ]);
          renderParentTrackingTeacherOptions();
          parentTrackingFieldSetValue("pt_teacherName", persistedTeacherName);
        }
        if (persistedLessonSummary)
          parentTrackingFieldSetValue("pt_lessonSummary", persistedLessonSummary);
        setParentTrackingVisionStatus(persistedVisionStatus);
        parentTrackingFieldSetValue(
          "pt_participationPointsAward",
          row.participationPointsAward ?? "",
        );
        parentTrackingFieldSetValue("pt_comments", row.comments || "");
        if (persistedHomeworkAnnouncement) {
          parentTrackingFieldSetValue(
            "pt_homeworkAnnouncement",
            persistedHomeworkAnnouncement,
          );
        }
        applyParentTrackingRubricPayload(row.rubricPayload || null);
        resetParentTrackingManualMetricsTouched();

        const targetStudentRefId = resolveParentTrackingReportStudentRefId(row, student);
        let resolvedStudent =
          student && normalizeText(student.id) === targetStudentRefId ? student : null;
        if (!resolvedStudent && targetStudentRefId) {
          resolvedStudent = await loadParentTrackingStudentDetail(targetStudentRefId, { force: true });
        }
        if (resolvedStudent?.id) {
          state.parentTracking.studentDetailsByStudentId[resolvedStudent.id] = resolvedStudent;
          state.currentStudent = resolvedStudent;
          fillStudentForm(state.currentStudent);
          state.parentTracking.selectedStudentId = normalizeText(resolvedStudent.id);
          parentTrackingFieldSetValue("pt_studentRefId", normalizeText(resolvedStudent.id));
        } else if (targetStudentRefId) {
          state.parentTracking.selectedStudentId = targetStudentRefId;
          parentTrackingFieldSetValue("pt_studentRefId", targetStudentRefId);
        }

        const targetLevel = resolveParentTrackingReportLevel(row, resolvedStudent || student);
        if (targetLevel) {
          state.parentTracking.selectedLevel = targetLevel;
          parentTrackingFieldSetValue("pt_classLevel", fullLevelLabel(targetLevel));
          renderParentTrackingLevelTiles();
        }

        setActivePage("parent-tracking");
      }

      function renderParentTrackingReportRows(rows = [], student = null) {
        const rowsEl = document.getElementById("pt_reportRows");
        if (!rowsEl) return;
        const studentEaglesId = normalizeText(student?.eaglesId);
        state.tableRows.performance = Array.isArray(rows) ? [...rows] : [];
        const sortedRows = sortedPerformanceRows(state.tableRows.performance);
        const filteredRows = filterRowsForTable(
          "performance",
          sortedRows,
          reportRowSearchText,
        );
        const visibleIncomingRows = incomingPerformanceRows(filteredRows);
        state.visibleTableRows.performance = visibleIncomingRows;
        updateTableFilterSummary("performance");
        renderPerformanceStagedSection(filteredRows);
        if (!visibleIncomingRows.length) {
          rowsEl.innerHTML =
            '<tr><td colspan="6">No performance records for current filters.</td></tr>';
          applyTableColumnVisibility("performance");
          return;
        }

        rowsEl.innerHTML = "";
        visibleIncomingRows.forEach((row) => {
          const held = isPerformanceReportHeld(row.id);
          const workflowState = normalizeText(row.workflowState).toLowerCase();
          const approved = Boolean(normalizeText(row.approvedAt));
          const pending = Boolean(
            state.parentReportQueue.pendingStageQueueById?.[row.id],
          );
          const approveLabel = "Submit for Admin Review";
          const reportTeacher = normalizeText(row.teacherName || row.approvedByUsername || "-");
          const approvalStatus =
            held ? "On hold"
            : workflowState === "awaiting_admin_approval" ?
              "Awaiting Admin Approval"
            : workflowState === "incoming_admin_review" ?
              "Incoming Admin Review"
            : workflowState === "submitted_for_admin_review" ?
              "Submitted for Admin Review"
            : normalizeText(row.approvedAt) ?
              `Approved${normalizeText(row.approvedByUsername) ? ` by ${normalizeText(row.approvedByUsername)}` : ""}`
            : "Pending admin approval";
          const reportEaglesId = normalizeText(row.eaglesId || studentEaglesId);
          const tr = document.createElement("tr");
          tr.innerHTML = `
          <td data-performance-col="hold"><label class="small" for="pt_report_hold_${sanitizeDomIdPart(row.id)}">Hold</label><input type="checkbox" id="pt_report_hold_${sanitizeDomIdPart(row.id)}" name="pt_report_hold_${sanitizeDomIdPart(row.id)}" data-pt-report-hold="${escapeHtml(row.id)}"${held ? " checked" : ""}></td>
          <td data-performance-col="generatedAt">${escapeHtml(formatDate(row.generatedAt))}</td>
          <td data-performance-col="eaglesId">${escapeHtml(reportEaglesId)}</td>
          <td data-performance-col="teacherName">${escapeHtml(reportTeacher || "-")}</td>
          <td data-performance-col="approvalStatus">${escapeHtml(approvalStatus)}</td>
          <td data-performance-col="action" class="table-row-options-cell">
            <button type="button" class="portal-button portal-button-affirm" data-pt-report-edit="${row.id}">Edit</button>
            <button type="button" class="portal-button portal-button-affirm" data-pt-report-approve="${row.id}"${pending || approved || workflowState !== "draft_pr" ? " disabled" : ""}>${pending ? "Working..." : approved ? "Approved" : approveLabel}</button>
          </td>
        `;

          tr.querySelector(`[data-pt-report-edit="${row.id}"]`)?.addEventListener(
            "click",
            async () => {
              try {
                await populateParentTrackingFormFromReportRow(row, student);
                await syncParentTrackingForSelection({});
                setParentTrackingStatus("Performance record loaded for edit.");
              } catch (error) {
                handleError(error);
              }
            },
          );
          tr.querySelector(`[data-pt-report-approve="${row.id}"]`)?.addEventListener(
            "click",
            async () => {
              try {
                await populateParentTrackingFormFromReportRow(row, student);
                await queueParentTrackingEmail();
              } catch (error) {
                handleError(error);
              }
            },
          );

          tr.querySelector(`[data-pt-report-hold="${row.id}"]`)?.addEventListener(
            "change",
            (event) => {
              const target = event.target;
              const nextHeld = Boolean(target?.checked);
              setPerformanceReportHeld(row.id, nextHeld);
              renderParentTrackingReportRows(state.tableRows.performance, student);
              setParentTrackingStatus(
                nextHeld ? "Performance report placed on hold and kept in the approval list." : "Performance report released from hold.",
              );
              setStatus(
                nextHeld ? "Performance report held." : "Performance report released from hold.",
              );
            },
          );

          rowsEl.appendChild(tr);
        });
        applyTableColumnVisibility("performance");
      }

      async function deleteParentTrackingReport(recordId) {
        const selectedStudentRefId = normalizeText(
          document.getElementById("pt_studentRefId")?.value,
        );
        if (!selectedStudentRefId) throw new Error("Select a student first.");
        const result = await api(
          `/api/admin/students/${encodeURIComponent(selectedStudentRefId)}/reports/${encodeURIComponent(recordId)}`,
          {
            method: "DELETE",
          },
        );
        if (result?.student?.id) {
          state.parentTracking.studentDetailsByStudentId[result.student.id] =
            result.student;
          if (state.currentStudent?.id === result.student.id) {
            state.currentStudent = result.student;
            fillStudentForm(state.currentStudent);
          }
          renderParentTrackingReportRows(
            parentTrackingReportRowsForStudent(
              result.student,
              selectedParentTrackingLevel(),
            ),
          );
        } else {
          renderParentTrackingReportRows([]);
        }
        if (
          normalizeText(document.getElementById("pt_reportId")?.value) ===
          normalizeText(recordId)
        ) {
          document.getElementById("pt_reportId").value = "";
        }
        setPerformanceReportHeld(recordId, false);
        setParentTrackingStatus("Performance report deleted.");
        setStatus("Performance report deleted.");
      }

      async function syncParentTrackingForSelection({
        preferredAssignmentId = "",
      } = {}) {
        ensureParentTrackingFormDefaults({ forceSummaryFromMemory: false });
        const previousStudentRefId = normalizeText(
          state.parentTracking.selectedStudentId,
        );
        const selectedStudentRefId = normalizeText(
          document.getElementById("pt_studentRefId")?.value,
        );
        if (selectedStudentRefId !== previousStudentRefId) {
          parentTrackingFieldSetValue("pt_reportId", "");
          clearParentTrackingRubricInputs();
          applyParentTrackingRubricSummaryScores();
          resetParentTrackingManualMetricsTouched();
        }
        state.parentTracking.selectedStudentId = selectedStudentRefId;
        if (!selectedStudentRefId) {
          resetParentTrackingManualMetricsTouched();
          clearParentTrackingRubricInputs();
          clearParentTrackingComputedFields();
          renderParentTrackingReportRows([]);
          applyParentTrackingLevelBasedRubricAvailability();
          setParentTrackingStatus("Select a student to auto-fill report metrics.");
          return null;
        }

        const detail = await loadParentTrackingStudentDetail(selectedStudentRefId);
        if (!detail) {
          resetParentTrackingManualMetricsTouched();
          clearParentTrackingRubricInputs();
          clearParentTrackingComputedFields();
          renderParentTrackingReportRows([]);
          applyParentTrackingLevelBasedRubricAvailability();
          setParentTrackingStatus("Unable to load selected student details.", true);
          return null;
        }

        const classDate = normalizeText(document.getElementById("pt_classDate")?.value);
        const selectedLevel =
          selectedParentTrackingLevel() ||
          resolveSystemLevelName(detail?.profile?.currentGrade || "");
        if (selectedLevel) {
          state.parentTracking.selectedLevel = selectedLevel;
          parentTrackingFieldSetValue("pt_classLevel", fullLevelLabel(selectedLevel));
          renderParentTrackingLevelTiles();
        }

        applyParentTrackingLevelBasedRubricAvailability(detail);
        const metrics = parentTrackingMetricsForStudent(
          detail,
          selectedLevel,
          classDate,
        );
        renderParentTrackingMetrics(metrics);
        const recipients = parentTrackingRecipientsForStudent(detail);
        parentTrackingFieldSetValue("pt_recipients", recipients.join(", "));
        const homeworkBuckets = parentTrackingHomeworkBuckets(
          metrics,
          detail.id,
          classDate,
        );
        const currentHomeworkRows = homeworkBuckets.currentWeekHomework;
        const pastDueHomeworkRows = homeworkBuckets.pastDueHomework;
        renderParentTrackingCurrentRows(currentHomeworkRows, detail);
        renderParentTrackingOutstandingRows(pastDueHomeworkRows, detail);
        renderParentTrackingHomeworkAnnouncement(detail, metrics, classDate);
        renderParentTrackingReportRows(
          parentTrackingReportRowsForStudent(detail, selectedLevel),
          detail,
        );
        setParentTrackingStatus(
          `fullName=${normalizeText(detail?.profile?.fullName)} | eaglesId=${normalizeText(detail?.eaglesId)} | records=${metrics.records.length} | currentWeek=${currentHomeworkRows.length} | pastDue=${pastDueHomeworkRows.length}`,
        );

        if (normalizeText(preferredAssignmentId)) {
          const match = [...pastDueHomeworkRows, ...currentHomeworkRows].find(
            (entry) =>
              normalizeText(entry?.id) === normalizeText(preferredAssignmentId),
          );
          if (match) showParentTrackingAssignmentDetail(match, detail);
        }

        return {
          student: detail,
          metrics,
          recipients,
        };
      }

      async function refreshParentTracking(options = {}) {
        const {
          preserveStudentSelection = true,
          preferredStudentId = "",
          preferredAssignmentId = "",
        } = options;
        renderParentTrackingLevelTiles();
        ensureParentTrackingFormDefaults({ forceSummaryFromMemory: false });
        refreshParentTrackingStudentOptions({
          preserveStudentSelection,
          preferredStudentId,
        });
        if (state.activePage === "parent-tracking") {
          await syncParentTrackingForSelection({ preferredAssignmentId });
        }
      }

      async function resolveParentTrackingContext({
        includeStudentRefresh = true,
      } = {}) {
        const selectedLevel = selectedParentTrackingLevel();
        const selectedStudentRefId = normalizeText(
          document.getElementById("pt_studentRefId")?.value,
        );
        if (!selectedLevel) throw new Error("Select a class level first.");
        if (!selectedStudentRefId) throw new Error("Select a student first.");

        const syncResult =
          includeStudentRefresh ? await syncParentTrackingForSelection({}) : null;
        const student =
          syncResult?.student ||
          state.parentTracking.studentDetailsByStudentId[selectedStudentRefId] ||
          (await loadParentTrackingStudentDetail(selectedStudentRefId));
        if (!student) throw new Error("Unable to load student detail.");

        const classDate =
          normalizeText(document.getElementById("pt_classDate")?.value) ||
          localIsoDate();
        const classDay = dayLabelFromIsoDate(classDate);
        const teacherName = normalizeText(
          document.getElementById("pt_teacherName")?.value,
        );
        const lessonSummary = normalizeText(
          document.getElementById("pt_lessonSummary")?.value,
        );
        const visionStatus = parentTrackingVisionStatusValue();
        const homeworkAnnouncement = normalizeText(
          document.getElementById("pt_homeworkAnnouncement")?.value,
        );
        const comment = normalizeText(document.getElementById("pt_comments")?.value);

        if (!lessonSummary) throw new Error("Lesson summary is required.");

        const metrics =
          syncResult?.metrics ||
          parentTrackingMetricsForStudent(student, selectedLevel, classDate);
        const recipients = parentTrackingRecipientsForStudent(student);
        const className = fullLevelLabel(selectedLevel);
        const schoolYear = defaultAttendanceSchoolYear(classDate);
        const quarter = quarterFromIsoDate(classDate);
        const currentHomeworkRows = parentTrackingCurrentSnapshotRows(
          metrics,
          selectedStudentRefId,
          classDate,
        );
        const pastDueHomeworkRows = parentTrackingPastDueSnapshotRows(
          metrics,
          selectedStudentRefId,
          classDate,
        );
        const currentHomeworkLines = currentHomeworkRows.map((row, index) => {
          const due = normalizeText(row?.dueAt).slice(0, 10) || "-";
          const assignment =
            normalizeText(row?.assignmentName) || "(untitled homework)";
          const link = normalizeText(row?.deepLink);
          return `${index + 1}. ${assignment} (due ${due})${link ? ` | details ${link}` : ""}`;
        });
        const pastDueHomeworkLines = pastDueHomeworkRows.map((row, index) => {
          const due = normalizeText(row?.dueAt).slice(0, 10) || "-";
          const assignment =
            normalizeText(row?.assignmentName) || "(untitled homework)";
          const link = normalizeText(row?.deepLink);
          return `${index + 1}. ${assignment} (due ${due})${link ? ` | details ${link}` : ""}`;
        });

        const reportNotes = [
          `Teacher: ${teacherName || "-"}`,
          `Class date: ${classDate}`,
          `Class day: ${classDay || "-"}`,
          `Lesson summary: ${lessonSummary}`,
          `Vision status: ${visionStatus}`,
          currentHomeworkLines.length ?
            `Current week homework:\n${currentHomeworkLines.join("\n")}`
          : "Current week homework: none",
          pastDueHomeworkLines.length ?
            `Past due homework:\n${pastDueHomeworkLines.join("\n")}`
          : "Past due homework: none",
          `Homework snapshot: ${homeworkAnnouncement || "-"}`,
          comment ? `Teacher comment: ${comment}` : "",
        ]
          .filter(Boolean)
          .join("\n");

        return {
          student,
          studentRefId: selectedStudentRefId,
          selectedLevel,
          className,
          classDate,
          classDay,
          teacherName,
          lessonSummary,
          visionStatus,
          homeworkAnnouncement,
          comment,
          recipients,
          metrics,
          schoolYear,
          quarter,
          reportNotes,
        };
      }

      async function saveParentTrackingReport({ silent = false } = {}) {
        if (!canWriteData() && currentRoleName() !== "teacher") {
          throw new Error("Performance tracking updates are read-only for this role.");
        }
        const rawForm = {
          reportId: normalizeText(document.getElementById("pt_reportId")?.value),
          homeworkCompletionRate: normalizeText(
            document.getElementById("pt_homeworkCompletionRate")?.value,
          ),
          homeworkOnTimeRate: normalizeText(
            document.getElementById("pt_homeworkOnTimeRate")?.value,
          ),
          participationPointsAward: normalizeText(
            document.getElementById("pt_participationPointsAward")?.value,
          ),
          visionStatus: parentTrackingVisionStatusValue(),
          homeworkAnnouncement: normalizeText(
            document.getElementById("pt_homeworkAnnouncement")?.value,
          ),
          comment: normalizeText(document.getElementById("pt_comments")?.value),
        };
        const context = await resolveParentTrackingContext({
          includeStudentRefresh: false,
        });
        const rubricSummary = parentTrackingSummaryFallbackFromRubric();
        const rubricPayload = collectParentTrackingRubricPayload();
        const homeworkSnapshot = parentTrackingHomeworkSnapshotFromContext(
          context,
          rawForm.homeworkAnnouncement,
        );
        const recipientsSnapshot =
          Array.isArray(context.recipients) ?
            context.recipients.map((entry) => normalizeText(entry)).filter(Boolean)
          : [];
        const currentHomeworkAssignments = parentTrackingCurrentSnapshotRows(
          context.metrics,
          context.studentRefId,
          context.classDate,
        );
        const pastDueHomeworkAssignments = parentTrackingPastDueSnapshotRows(
          context.metrics,
          context.studentRefId,
          context.classDate,
        );
        const outstandingAssignments = pastDueHomeworkAssignments;
        const currentHomeworkLines = currentHomeworkAssignments.map((row, index) => {
          const due = normalizeText(row?.dueAt).slice(0, 10) || "-";
          const assignment =
            normalizeText(row?.assignmentName) || "(untitled homework)";
          const link = normalizeText(row?.deepLink);
          return `${index + 1}. ${assignment} | due ${due}${link ? ` | details ${link}` : ""}`;
        });
        const pastDueHomeworkLines = pastDueHomeworkAssignments.map((row, index) => {
          const due = normalizeText(row?.dueAt).slice(0, 10) || "-";
          const assignment =
            normalizeText(row?.assignmentName) || "(untitled homework)";
          const link = normalizeText(row?.deepLink);
          return `${index + 1}. ${assignment} | due ${due}${link ? ` | details ${link}` : ""}`;
        });
        const currentHomeworkSnapshot = {
          rows: currentHomeworkAssignments,
          lines: currentHomeworkLines,
        };
        const pastDueHomeworkSnapshot = {
          rows: pastDueHomeworkAssignments,
          lines: pastDueHomeworkLines,
        };
        const savedForm = {
          ...rawForm,
          behaviorScore: rubricSummary.behaviorScore,
          participationScore: rubricSummary.participationScore,
          inClassScore: normalizeParentTrackingScoreValue(
            context.metrics?.academicScore,
          ),
          homeworkCompletionRate: normalizeText(
            context.metrics?.homeworkCompletionRate ?? rawForm.homeworkCompletionRate,
          ),
          homeworkOnTimeRate: normalizeText(
            context.metrics?.homeworkOnTimeRate ?? rawForm.homeworkOnTimeRate,
          ),
          participationPointsAward: rawForm.participationPointsAward,
          visionStatus: normalizeParentTrackingVisionStatus(
            rawForm.visionStatus || context.visionStatus,
          ),
          lessonSummary: context.lessonSummary,
          classDate: context.classDate,
          classDay: context.classDay,
          teacherName: context.teacherName,
          comment:
            rawForm.comment || parentTrackingCommentFallbackFromRecommendations(),
          homeworkSnapshot,
          recipientsSnapshot,
          outstandingAssignments,
          currentHomeworkAssignments,
          pastDueHomeworkAssignments,
          currentHomeworkSnapshot,
          pastDueHomeworkSnapshot,
          rubricPayload,
        };

        const result = await api(
          `/api/admin/students/${encodeURIComponent(context.studentRefId)}/reports`,
          {
            method: "POST",
            body: {
              id: savedForm.reportId,
              className: context.className,
              schoolYear: context.schoolYear,
              quarter: context.quarter,
              homeworkCompletionRate: savedForm.homeworkCompletionRate,
              homeworkOnTimeRate: savedForm.homeworkOnTimeRate,
              behaviorScore: savedForm.behaviorScore,
              participationScore: savedForm.participationScore,
              inClassScore: savedForm.inClassScore,
              participationPointsAward: savedForm.participationPointsAward,
              comments: savedForm.comment,
              metaPayload: {
                classDate: savedForm.classDate,
                classDay: savedForm.classDay,
                teacherName: savedForm.teacherName,
                lessonSummary: savedForm.lessonSummary,
                visionStatus: savedForm.visionStatus,
                homeworkAnnouncement: savedForm.homeworkSnapshot?.homeworkAnnouncement,
                currentHomeworkStatus:
                  savedForm.homeworkSnapshot?.currentHomeworkStatus,
                currentHomeworkHeader:
                  savedForm.homeworkSnapshot?.currentHomeworkHeader,
                currentHomeworkSummary:
                  savedForm.homeworkSnapshot?.currentHomeworkSummary,
                currentHomeworkCount:
                  savedForm.homeworkSnapshot?.currentHomeworkCount,
                pastDueHomeworkCount: savedForm.homeworkSnapshot?.pastDueHomeworkCount,
                pastDueHomeworkSummary:
                  savedForm.homeworkSnapshot?.pastDueHomeworkSummary,
                recipients: savedForm.recipientsSnapshot,
                currentHomeworkAssignments: savedForm.currentHomeworkAssignments,
                pastDueHomeworkAssignments: savedForm.pastDueHomeworkAssignments,
                outstandingAssignments: savedForm.outstandingAssignments,
              },
              rubricPayload: savedForm.rubricPayload,
              level: context.selectedLevel,
            },
          },
        );

        if (result?.student?.id) {
          state.parentTracking.studentDetailsByStudentId[result.student.id] =
            result.student;
          renderParentTrackingReportRows(
            parentTrackingReportRowsForStudent(result.student, context.selectedLevel),
            result.student,
          );
          if (state.currentStudent?.id === result.student.id) {
            state.currentStudent = result.student;
            fillStudentForm(state.currentStudent);
          }
        } else {
          renderParentTrackingReportRows([]);
        }

        if (result?.report?.id)
          document.getElementById("pt_reportId").value = result.report.id;
        if (!silent) {
          const fullName = normalizeText(context.student.profile?.fullName);
          const eaglesId = normalizeText(context.student.eaglesId);
          setParentTrackingStatus(
            "Performance class report saved as draft.",
          );
          setStatus(
            `Performance report draft saved. fullName=${fullName} | eaglesId=${eaglesId}.`,
          );
          setParentTrackingSaveNotice(
            "Saved Performance Report",
            false,
            `Saved. fullName=${fullName} | eaglesId=${eaglesId}. Submit this draft for admin review when ready.`,
          );
        }
        return {
          ...context,
          savedForm,
          reportId: normalizeText(
            result?.report?.id ||
              document.getElementById("pt_reportId")?.value ||
              savedForm.reportId,
          ),
        };
      }

      async function queueParentTrackingEmail() {
        if (!canWriteData() && currentRoleName() !== "teacher") {
          throw new Error(
            "Performance report submission is read-only for this role.",
          );
        }
        const context = await saveParentTrackingReport({ silent: true });
        rememberParentTrackingTeacherName();
        rememberParentTrackingLessonSummary();
        const reportId =
          normalizeText(context.reportId) || normalizeText(context.savedForm?.reportId);
        if (!reportId) {
          throw new Error("Unable to resolve the saved performance report id.");
        }
        const result = await api(
          `/api/admin/students/${encodeURIComponent(normalizeText(context.studentRefId))}/reports/${encodeURIComponent(reportId)}/workflow`,
          {
            method: "POST",
            body: {
              action: "submit",
            },
          },
        );
        if (result?.student?.id) {
          state.parentTracking.studentDetailsByStudentId[result.student.id] = result.student;
          if (state.currentStudent?.id === result.student.id) {
            state.currentStudent = result.student;
            fillStudentForm(state.currentStudent);
          }
        }
        const fullName = normalizeText(context.student.profile?.fullName);
        const eaglesId = normalizeText(context.student.eaglesId);
        setParentTrackingStatus(
          "Performance report submitted for admin review.",
        );
        setStatus(
          `Performance report submitted for admin review. fullName=${fullName} | eaglesId=${eaglesId}.`,
        );
        setParentTrackingSaveNotice(
          "Submitted for Admin Review",
          false,
          "The report is now in the incoming PR review queue.",
        );
        await loadDashboardSummary();
        await loadParentReportQueue({ showAll: state.parentReportQueue.showAll });
        await syncParentTrackingForSelection({});
      }

      function clearParentTrackingForm() {
        resetParentTrackingManualMetricsTouched();
        parentTrackingFieldSetValue("pt_reportId", "");
        parentTrackingFieldSetValue("pt_studentRefId", "");
        parentTrackingFieldSetValue("pt_classDate", localIsoDate());
        parentTrackingFieldSetValue("pt_classDay", dayLabelFromIsoDate(localIsoDate()));
        parentTrackingFieldSetValue("pt_lessonSummary", "");
        setParentTrackingVisionStatus(PARENT_TRACKING_VISION_STATUS_DEFAULT);
        parentTrackingFieldSetValue("pt_comments", "");
        parentTrackingFieldSetValue("pt_participationPointsAward", "");
        state.parentTracking.activeRecommendationFieldName = "";
        clearParentTrackingActionShortcutInputs({ preserveStatus: true });
        setParentTrackingActionHelperStatus("");
        clearParentTrackingRubricInputs();
        clearParentTrackingComputedFields();
        applyParentTrackingLessonSummaryFromMemory({ force: true });
        applyParentTrackingLevelBasedRubricAvailability();
        setParentTrackingStatus("Performance tracking form cleared.");
        setParentTrackingSaveNotice("");
      }

      async function applyParentTrackingDeepLinkFromLocation() {
        const params = new URLSearchParams(window.location.search || "");
        const studentRefId = normalizeText(params.get("ptStudent"));
        const assignmentId = normalizeText(params.get("ptAssignment"));
        if (!studentRefId) return;
        await openParentTrackingAssignmentLink(studentRefId, assignmentId, {
          syncUrl: false,
        });
      }

      function sisConfigFormValues() {
        return normalizeSisConfig({
          runtime: {
            databaseUrl: document.getElementById("settingDatabaseUrl")?.value,
            redisUrl: document.getElementById("settingRedisUrl")?.value,
            sessionDriver: document.getElementById("settingSessionDriver")?.value,
            adminSessionTtlSeconds: document.getElementById("settingAdminSessionTtl")?.value,
            parentSessionTtlSeconds: document.getElementById("settingParentSessionTtl")?.value,
            studentSessionTtlSeconds: document.getElementById("settingStudentSessionTtl")?.value,
            redisConnectTimeoutMs: document.getElementById("settingRedisConnectTimeoutMs")?.value,
          },
          newsReports: {
            weeklyMinimumReports: document.getElementById("settingWeeklyMinimumReports")?.value,
            autoApproveEnabled: document.getElementById("settingNewsAutoApproveEnabled")?.checked,
            autoApproveDelayHours: document.getElementById("settingNewsAutoApproveDelayHours")?.value,
          },
        });
      }

      function applySisConfigToForm(config = state.sisConfig || DEFAULT_SIS_CONFIG) {
        const normalized = normalizeSisConfig(config);
        const runtime = normalized.runtime || DEFAULT_SIS_CONFIG.runtime;
        const newsReports = normalized.newsReports || DEFAULT_SIS_CONFIG.newsReports;
        const setValue = (id, value) => {
          const el = document.getElementById(id);
          if (!el) return;
          el.value = normalizeText(value);
        };
        setValue("settingDatabaseUrl", runtime.databaseUrl);
        setValue("settingRedisUrl", runtime.redisUrl);
        const driverEl = document.getElementById("settingSessionDriver");
        if (driverEl) driverEl.value = normalizeText(runtime.sessionDriver) || "auto";
        setValue("settingAdminSessionTtl", runtime.adminSessionTtlSeconds);
        setValue("settingParentSessionTtl", runtime.parentSessionTtlSeconds);
        setValue("settingStudentSessionTtl", runtime.studentSessionTtlSeconds);
        setValue("settingRedisConnectTimeoutMs", runtime.redisConnectTimeoutMs);
        setValue("settingWeeklyMinimumReports", newsReports.weeklyMinimumReports);
        const autoApproveEnabledEl = document.getElementById("settingNewsAutoApproveEnabled");
        if (autoApproveEnabledEl) autoApproveEnabledEl.checked = newsReports.autoApproveEnabled !== false;
        setValue("settingNewsAutoApproveDelayHours", newsReports.autoApproveDelayHours);
      }

      async function saveUiSettings() {
        if (!canManageSettings())
          throw new Error("Only roles with settings permission can update settings.");
        const multiSchool = Boolean(
          document.getElementById("settingMultiSchool")?.checked,
        );
        persistUiSettings({ ...state.uiSettings, multiSchool });
        const sisConfig = sisConfigFormValues();
        persistSisConfig(sisConfig);
        const result = await persistUiSettingsToServer(state.uiSettings, sisConfig, {
          notifyOnFailure: true,
        });
        if (result?.sisConfig) {
          persistSisConfig(result.sisConfig, result?.sisConfigMeta || null);
        }
        persistProfileFormConfig(state.profileFormConfig);
        applyUiSettings();
        setProfileLayoutStatus("Settings saved.");
        setStatus("Settings saved.");
      }

      async function resetUiSettings() {
        await hydrateUiSettingsFromServer();
        state.uiSettings = loadUiSettingsFromStorage();
        state.sisConfig = loadSisConfigFromStorage();
        applySisConfigToForm(state.sisConfig);
        state.profileFormConfig = loadProfileFormConfigFromStorage();
        renderProfileFormLayout();
        renderProfileInfoLayout(state.currentStudent);
        renderProfileFieldLayoutEditor();
        setProfileMode(state.profileMode);
        applyUiSettings();
        setProfileLayoutStatus("Layout loaded from saved settings.");
        setStatus("Settings reset to saved values.");
      }

      function studentSearchText(student = {}) {
        const profile = student?.profile || {};
        return [
          student?.eaglesId,
          student?.studentNumber,
          student?.email,
          profile?.studentEmail,
          profile?.fullName,
          profile?.englishName,
          profile?.motherName,
          profile?.fatherName,
          profile?.schoolName,
          shortLevelLabel(profile?.currentGrade),
        ]
          .map((entry) => normalizeSearchComparable(entry))
          .filter(Boolean)
          .join(" ");
      }

      function studentFullName(student = {}) {
        return normalizeText(student?.profile?.fullName || student?.fullName);
      }

      function studentEnglishName(student = {}) {
        return normalizeText(student?.profile?.englishName || student?.englishName);
      }

      function studentDisplayName(student = {}, { preferEnglish = false } = {}) {
        const fullName = studentFullName(student);
        const englishName = studentEnglishName(student);
        if (preferEnglish) return englishName || fullName;
        return fullName || englishName;
      }

      function studentDisplayNumber(student = {}) {
        const direct = parsePositiveInteger(student?.studentNumber);
        if (direct) return String(direct);
        const fromProfile = parsePositiveInteger(student?.profile?.studentNumber);
        if (fromProfile) return String(fromProfile);
        return "";
      }

      function studentIdentityLabel(
        student = {},
        { preferEnglish = false, wrapName = false, includeStudentNumber = false } = {},
      ) {
        const name = studentDisplayName(student, { preferEnglish });
        const eaglesId = normalizeText(student?.eaglesId);
        const studentNumber = studentDisplayNumber(student);
        const nameToken =
          name ?
            wrapName ? `(${name})`
            : name
          : "";
        const studentNumberToken =
          includeStudentNumber && studentNumber ? ` <${studentNumber}>` : "";
        return `${nameToken} ${eaglesId}${studentNumberToken}`.trim();
      }

      function scrollProfileSurfaceIntoView() {
        const profileSection = document.querySelector(
          '.page-section[data-page="profile"]',
        );
        if (
          !profileSection ||
          typeof profileSection.scrollIntoView !== "function"
        )
          return;
        window.requestAnimationFrame(() => {
          profileSection.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        });
      }

      function openStudentProfileFromList(studentRefId = "") {
        const id = normalizeText(studentRefId);
        if (!id) return;
        loadStudentDetail(id)
          .then(() => {
            setActivePage("profile");
            scrollProfileSurfaceIntoView();
            setStatus("Student loaded into Profile.");
          })
          .catch(handleError);
      }

      function normalizedTopSearchSortField(field = "") {
        const normalized = normalizeText(field);
        if (
          normalized === "eaglesId" ||
          normalized === "fullName" ||
          normalized === "level"
        )
          return normalized;
        return "fullName";
      }

      function normalizedTopSearchSortDir(value = "") {
        return normalizeLower(value) === "desc" ? "desc" : "asc";
      }

      function topSearchRowsSorted(rows = []) {
        const source = Array.isArray(rows) ? rows : [];
        const field = normalizedTopSearchSortField(state.topSearch?.sortField);
        const direction = normalizedTopSearchSortDir(state.topSearch?.sortDir);
        const sorted = [...source].sort((left, right) => {
          const leftFullName = studentFullName(left);
          const rightFullName = studentFullName(right);
          const leftId = normalizeText(left?.eaglesId || "");
          const rightId = normalizeText(right?.eaglesId || "");
          const leftLevel = normalizeText(left?.profile?.currentGrade || "");
          const rightLevel = normalizeText(right?.profile?.currentGrade || "");
          let comparison = 0;

          if (field === "eaglesId") {
            comparison = compareTableText(leftId, rightId);
            if (comparison === 0)
              comparison = compareTableText(leftFullName, rightFullName);
            if (comparison === 0)
              comparison = compareLevelLabels(leftLevel, rightLevel);
          } else if (field === "level") {
            comparison = compareLevelLabels(leftLevel, rightLevel);
            if (comparison === 0)
              comparison = compareTableText(leftFullName, rightFullName);
            if (comparison === 0) comparison = compareTableText(leftId, rightId);
          } else {
            comparison = compareTableText(leftFullName, rightFullName);
            if (comparison === 0) comparison = compareTableText(leftId, rightId);
            if (comparison === 0)
              comparison = compareLevelLabels(leftLevel, rightLevel);
          }

          return direction === "desc" ? -comparison : comparison;
        });
        return sorted;
      }

      function updateTopSearchSortIndicators() {
        const activeField = normalizedTopSearchSortField(state.topSearch?.sortField);
        const ascending =
          normalizedTopSearchSortDir(state.topSearch?.sortDir) === "asc";
        document
          .querySelectorAll("#topSearchResultsPanel th[data-top-search-sort]")
          .forEach((thEl) => {
            const field = normalizedTopSearchSortField(
              thEl.getAttribute("data-top-search-sort"),
            );
            const active = field === activeField;
            thEl.classList.toggle("sort-active-asc", active && ascending);
            thEl.classList.toggle("sort-active-desc", active && !ascending);
            thEl.setAttribute(
              "aria-sort",
              active ?
                ascending ? "ascending"
                : "descending"
              : "none",
            );
          });
      }

      function setTopSearchSort(field, { toggleIfSame = true } = {}) {
        const nextField = normalizedTopSearchSortField(field);
        const currentField = normalizedTopSearchSortField(state.topSearch?.sortField);
        const currentDir = normalizedTopSearchSortDir(state.topSearch?.sortDir);
        const sameField = nextField === currentField;
        state.topSearch.sortField = nextField;
        state.topSearch.sortDir =
          sameField && toggleIfSame ?
            currentDir === "asc" ?
              "desc"
            : "asc"
          : "asc";
        renderTopSearchResults(state.topSearch?.rows || []);
      }

      function toggleTopSearchExpanded() {
        state.topSearch.expanded = !Boolean(state.topSearch?.expanded);
        renderTopSearchResults(state.topSearch?.rows || []);
      }

      function bindTopSearchControls() {
        document
          .querySelectorAll("#topSearchResultsPanel th[data-top-search-sort]")
          .forEach((thEl) => {
            if (thEl.dataset.topSearchSortBound === "1") return;
            thEl.dataset.topSearchSortBound = "1";
            const onSort = () =>
              setTopSearchSort(thEl.getAttribute("data-top-search-sort"), {
                toggleIfSame: true,
              });
            thEl.addEventListener("click", onSort);
            thEl.addEventListener("keydown", (event) => {
              if (event.key !== "Enter" && event.key !== " ") return;
              event.preventDefault();
              onSort();
            });
          });
        const expandBtn = document.getElementById("topSearchExpandBtn");
        if (expandBtn && expandBtn.dataset.bound !== "1") {
          expandBtn.dataset.bound = "1";
          expandBtn.addEventListener("click", () => toggleTopSearchExpanded());
        }
        updateTopSearchSortIndicators();
      }

      function renderTopSearchResults(students = []) {
        const tbody = document.getElementById("topSearchRows");
        const countEl = document.getElementById("topSearchCount");
        const expandBtn = document.getElementById("topSearchExpandBtn");
        const boxEl = document.querySelector(
          "#topSearchResultsPanel .top-search-results-box",
        );
        if (!tbody || !countEl) return;
        const rows = Array.isArray(students) ? students : [];
        state.topSearch.rows = rows;
        tbody.innerHTML = "";
        if (expandBtn) expandBtn.classList.add("hidden");
        if (boxEl) boxEl.classList.remove("expanded");
        if (!rows.length) {
          tbody.innerHTML =
            '<tr><td colspan="5">No students match current top search scope.</td></tr>';
          countEl.textContent = "0 results";
          state.topSearch.expanded = false;
          updateTopSearchSortIndicators();
          return;
        }

        const collapsedRows = Math.max(
          1,
          Number.parseInt(String(state.topSearch?.collapsedRows || 12), 10) || 12,
        );
        const sortedRows = topSearchRowsSorted(rows);
        if (rows.length <= collapsedRows) state.topSearch.expanded = false;
        const showAll = Boolean(state.topSearch?.expanded);
        const visibleRows = showAll ? sortedRows : sortedRows.slice(0, collapsedRows);

        visibleRows.forEach((student) => {
          const tr = document.createElement("tr");
          tr.className = "top-search-row";
          if (state.currentStudent && state.currentStudent.id === student.id)
            tr.classList.add("active");
          const fullName = studentFullName(student);
          const englishName = studentEnglishName(student);
          const levelName = studentDisplayLevel(student);
          tr.innerHTML = `
          <td>${student.eaglesId || ""}</td>
          <td>${escapeHtml(fullName)}</td>
          <td>${escapeHtml(englishName)}</td>
          <td>${levelBadgeHtml(levelName, { variant: "standard" })}${studentEnrollmentWarningHtml(student)}</td>
          <td><button type="button" class="portal-button portal-button-info top-search-open-btn" data-button-tooltip="Open the selected student profile">Open Profile</button></td>
        `;
          const open = (event) => {
            if (event) event.stopPropagation();
            openStudentProfileFromList(student.id);
          };
          tr.addEventListener("click", open);
          tr.querySelector(".top-search-open-btn")?.addEventListener("click", open);
          tbody.appendChild(tr);
        });

        if (rows.length > collapsedRows && expandBtn) {
          expandBtn.classList.remove("hidden");
          expandBtn.textContent = showAll ? "Show Less" : `Show All (${rows.length})`;
        }
        if (showAll && boxEl) boxEl.classList.add("expanded");
        countEl.textContent =
          showAll || rows.length <= collapsedRows ?
            `${rows.length} results`
          : `${rows.length} results (showing ${visibleRows.length})`;
        updateTopSearchSortIndicators();
      }

      function renderStudents({ refreshLinkedControls = true } = {}) {
        const tbody = document.getElementById("studentRows");
        if (!(tbody instanceof HTMLElement)) return;
        tbody.innerHTML = "";

        const searchTerm = normalizeSearchComparable(
          document.getElementById("searchQ")?.value,
        );
        const visibleStudents = state.students.filter((student) => {
          if (!searchTerm) return true;
          return studentSearchText(student).includes(searchTerm);
        });

        visibleStudents.forEach((student) => {
          const tr = document.createElement("tr");
          if (state.currentStudent && state.currentStudent.id === student.id)
            tr.classList.add("active");
          const levelName = studentDisplayLevel(student);
          tr.innerHTML = `
          <td>${student.eaglesId || ""}</td>
          <td>${escapeHtml(studentFullName(student))}</td>
          <td>${escapeHtml(studentEnglishName(student))}</td>
          <td>${levelBadgeHtml(levelName, { variant: "standard" })}${studentEnrollmentWarningHtml(student)}</td>
          <td class="school-col-cell">${student.profile?.schoolName || ""}</td>
        `;
          tr.addEventListener("click", () => openStudentProfileFromList(student.id));
          tbody.appendChild(tr);
        });

        const studentCountEl = document.getElementById("studentCount");
        if (studentCountEl) studentCountEl.textContent = `${visibleStudents.length} students`;
        state.topSearch.rows = visibleStudents;
        renderTopSearchResults(visibleStudents);
        applyUiSettings();
        if (refreshLinkedControls) {
          refreshAssignmentStudentOptions();
          refreshAllTableSearchFilterControls();
          refreshParentTrackingStudentOptions({ preserveStudentSelection: true });
        }
      }

      function profileFieldLabel(field = {}) {
        return normalizeText(field?.labelVi || field?.labelEn || field?.key || "Field");
      }

      function profileFieldValueAsArray(value) {
        if (Array.isArray(value)) return normalizeTextArray(value);
        const text = normalizeText(value);
        if (!text) return [];
        if (text.includes("|")) return normalizeTextArray(text.split("|"));
        if (text.includes(",")) return normalizeTextArray(text.split(","));
        return [text];
      }

      function normalizeProfileFormFieldValue(field = {}, value = "") {
        const inputType = normalizeLower(field?.inputType);
        if (inputType === "checkbox") return profileFieldValueAsArray(value);
        if (Array.isArray(value)) return normalizeText(value[0]);
        return normalizeText(value);
      }

      function scalarFromProfileFormFieldValue(value = "") {
        if (Array.isArray(value)) return normalizeText(value[0]);
        return normalizeText(value);
      }

      function resolveProfileFieldValueForStudent(student = null, field = {}) {
        if (!student || typeof student !== "object") return "";
        const profile =
          student.profile && typeof student.profile === "object" ? student.profile : {};
        const normalizedFormPayload =
          (
            profile.normalizedFormPayload &&
            typeof profile.normalizedFormPayload === "object"
          ) ?
            profile.normalizedFormPayload
          : {};
        const rawFormPayload =
          profile.rawFormPayload && typeof profile.rawFormPayload === "object" ?
            profile.rawFormPayload
          : {};

        if (field.topLevelKey === "eaglesId") return normalizeText(student.eaglesId);
        if (field.topLevelKey === "studentNumber") {
          const direct = parsePositiveInteger(student.studentNumber);
          if (direct) return String(direct);
          return "";
        }
        if (field.topLevelKey === "email") return normalizeText(student.email);

        if (field.profileKey) {
          let value = profile[field.profileKey];
          if (field.profileKey === "studentEmail" && !normalizeText(value))
            value = normalizeText(student.email);
          if (field.profileKey === "currentGrade")
            value = resolveSystemLevelName(value);
          return value;
        }
        if (Object.prototype.hasOwnProperty.call(normalizedFormPayload, field.key)) {
          return normalizedFormPayload[field.key];
        }
        if (Object.prototype.hasOwnProperty.call(rawFormPayload, field.key)) {
          return rawFormPayload[field.key];
        }
        return "";
      }

      function formatProfileInfoValue(field = {}, rawValue = "") {
        const values = profileFieldValueAsArray(rawValue);
        if (normalizeLower(field.inputType) === "checkbox") return values.join(", ");
        if (Array.isArray(rawValue)) return values.join(", ");
        return normalizeText(rawValue);
      }

      function profileInfoHasValue(rawValue = "") {
        if (Array.isArray(rawValue))
          return profileFieldValueAsArray(rawValue).length > 0;
        return normalizeText(rawValue) !== "";
      }

      function profileInfoFieldPriority(field = {}) {
        const idSuffix = normalizeText(field?.idSuffix);
        return PROFILE_INFO_PRIMARY_ID_SUFFIXES.has(idSuffix) ? "primary" : "standard";
      }

      function profileInfoFieldSpan(field = {}, { hasValue = true } = {}) {
        const width = Math.max(
          1,
          Math.min(12, Number.parseInt(String(field?.width || 4), 10) || 4),
        );
        const inputType = normalizeLower(field?.inputType);
        const idSuffix = normalizeText(field?.idSuffix);
        if (inputType === "textarea" || inputType === "file") return 12;
        if (
          inputType === "checkbox" &&
          Array.isArray(field?.options) &&
          field.options.length >= 4
        )
          return 12;
        if (idSuffix === "studentPhoto") return 4;
        if (idSuffix === "fullName") return 6;
        if (idSuffix === "englishName") return 4;
        if (idSuffix === "currentGrade") return 4;
        if (idSuffix === "eaglesId" || idSuffix === "studentNumber") return 3;
        if (idSuffix === "parentsId") return 4;
        if (idSuffix === "schoolName") return 4;
        if (!hasValue) return Math.max(3, Math.min(6, width));
        return Math.max(3, Math.min(12, width));
      }

      function profileInfoSectionPriority(tabId = "", sectionLabel = "") {
        const tabToken = normalizeLower(tabId);
        const sectionToken = normalizeSearchComparable(sectionLabel);
        if (tabToken === "profile") {
          if (sectionToken.includes("thong tin cua nguoi hoc")) return 10;
          if (sectionToken.includes("lien he cua me")) return 20;
          if (sectionToken.includes("lien he cua ba")) return 30;
          if (sectionToken.includes("dia chi")) return 40;
        }
        if (tabToken === "medical") {
          if (sectionToken.includes("thi giac")) return 10;
          if (sectionToken.includes("thuoc uong")) return 20;
          if (sectionToken.includes("kho khan khi hoc")) return 30;
          if (sectionToken.includes("di ung")) return 40;
          if (sectionToken.includes("tiem chung")) return 50;
          if (sectionToken.includes("cham soc trong gio hoc")) return 60;
        }
        if (tabToken === "covid") return 10;
        if (tabToken === "submission") return 10;
        return 90;
      }

      function profileSummaryChipHtml(label = "", value = "") {
        return `
        <article class="profile-summary-chip card" data-surface-role="card">
          <p class="profile-summary-chip-label">${escapeHtml(label)}</p>
          <p class="profile-summary-chip-value">${value ? escapeHtml(value) : "No value"}</p>
        </article>
      `;
      }

      function renderProfileInfoSummary(student = state.currentStudent) {
        const summaryEl = document.getElementById("profileInfoDataSummary");
        if (!summaryEl) return;
        const enrollmentSelect = document.getElementById(
          "profileEnrollmentPeriodSelect",
        );

        const profile =
          student?.profile && typeof student.profile === "object" ?
            student.profile
          : {};
        const fullName = normalizeText(profile?.fullName);
        const englishName = normalizeText(profile?.englishName);
        const studentName = firstNonEmpty(
          fullName,
          englishName,
          normalizeText(student?.eaglesId),
          "No value",
        );
        const sublineParts = [];
        if (
          fullName &&
          englishName &&
          normalizeLower(fullName) !== normalizeLower(englishName)
        ) {
          sublineParts.push(`English: ${englishName}`);
        }
        const eaglesId = normalizeText(student?.eaglesId);
        if (eaglesId) sublineParts.push(`Eagles ID: ${eaglesId}`);
        const studentNumber =
          Number.parseInt(
            String(student?.studentNumber || profile?.studentNumber || ""),
            10,
          ) || null;
        if (studentNumber) sublineParts.push(`Student #: ${studentNumber}`);
        const subline =
          sublineParts.length ?
            sublineParts.join(" | ")
          : student?.id ?
            "No additional profile identifiers available."
          : "No student selected; Select a student row to review profile clusters.";
        const toolbarNoteEl = document.getElementById("profileInfoToolbarNote");

        const currentGrade = resolveSystemLevelName(profile?.currentGrade || "");
        const currentEnrollment =
          student?.currentEnrollment && typeof student.currentEnrollment === "object" ?
            student.currentEnrollment
          : null;
        const enrollmentStatus = normalizeText(currentEnrollment?.status || "")
          .toLowerCase();
        const statusLabel =
          enrollmentStatus === "unenrolled" ? "Unenrolled"
          : currentEnrollment ? "Enrolled"
          : "No enrollment";
        const currentSchoolYear = normalizeText(currentEnrollment?.schoolYear || "");
        const schoolName = normalizeText(profile?.schoolName);
        const motherContact = normalizeText(
          [profile?.motherName, profile?.motherPhone].filter(Boolean).join(" / "),
        );
        const fatherContact = normalizeText(
          [profile?.fatherName, profile?.fatherPhone].filter(Boolean).join(" / "),
        );

        if (enrollmentSelect) {
          const periods = Array.isArray(student?.enrollmentPeriods)
            ? student.enrollmentPeriods
            : [];
          const selectedPeriodId = normalizeText(
            student?.selectedEnrollmentPeriodId ||
              state.selectedEnrollmentPeriodId ||
              "",
          );
          enrollmentSelect.innerHTML =
            '<option value="">Current period</option>';
          periods.forEach((period) => {
            const option = document.createElement("option");
            option.value = normalizeText(period?.id);
            const labelParts = [
              normalizeText(period?.schoolYear),
              normalizeText(period?.level || period?.status || "Unassigned"),
              normalizeText(period?.status || "active"),
            ].filter(Boolean);
            option.textContent = labelParts.join(" | ");
            if (normalizeText(option.value) === selectedPeriodId) {
              option.selected = true;
            }
            enrollmentSelect.appendChild(option);
          });
        }

        summaryEl.innerHTML = `
        <article class="profile-summary-primary card" data-surface-role="card">
          <p class="profile-summary-kicker">Student Snapshot</p>
          <p class="profile-summary-name">${escapeHtml(studentName)}</p>
        </article>
        ${profileSummaryChipHtml("Status", statusLabel)}
        ${profileSummaryChipHtml("Class Level", currentGrade)}
        ${profileSummaryChipHtml("School Year", currentSchoolYear)}
        ${profileSummaryChipHtml("School", schoolName)}
        ${profileSummaryChipHtml("Primary Contact", motherContact)}
        ${profileSummaryChipHtml("Secondary Contact", fatherContact)}
      `;
        if (toolbarNoteEl) toolbarNoteEl.textContent = subline;
      }

      function renderProfileInfoItem(field = {}, rawValue = "") {
        const renderedValue = formatProfileInfoValue(field, rawValue);
        const hasValue = profileInfoHasValue(rawValue);
        const item = document.createElement("article");
        item.className = "profile-info-item card";
        item.dataset.surfaceRole = "card";
        item.dataset.priority = profileInfoFieldPriority(field);
        item.style.setProperty(
          "--profile-span",
          String(profileInfoFieldSpan(field, { hasValue })),
        );
        const labelEl = document.createElement("span");
        labelEl.className = "profile-info-label";
        labelEl.textContent = profileFieldLabel(field);

        const valueEl = document.createElement("span");
        valueEl.className = `profile-info-value${renderedValue ? "" : " profile-info-empty"}`;
        valueEl.textContent = renderedValue || "No value";

        item.appendChild(labelEl);
        item.appendChild(valueEl);
        return {
          item,
          hasValue,
          renderedValue,
        };
      }

      function setProfileMode(mode = "info") {
        const normalizedMode = normalizeLower(mode) === "edit" ? "edit" : "info";
        state.profileMode = normalizedMode;
        const editorShell = document.getElementById("profileEditorShell");
        const showInfo = normalizedMode === "info";
        [
          ".page-section[data-page=\"profile\"] > .profile-info-toolbar",
          ".page-section[data-page=\"profile\"] > .row",
          "#profileInfoDataSummary",
          ".profile-info-tabs",
        ].forEach((selector) => {
          document.querySelector(selector)?.classList.toggle("hidden", !showInfo);
        });
        if (editorShell)
          editorShell.classList.toggle("hidden", normalizedMode !== "edit");

        const editBtn = document.getElementById("profileEditInfoBtn");
        const refreshBtn = document.getElementById("profileRefreshInfoBtn");
        if (editBtn) editBtn.disabled = !state.currentStudent?.id || !canWriteData();
        if (refreshBtn) refreshBtn.disabled = !state.currentStudent?.id;
      }

      function setProfileLayoutStatus(message, isError = false) {
        const el = document.getElementById("profileFieldLayoutStatus");
        if (!el) return;
        el.style.color = isError ? "#bd2f2f" : "var(--portal-status-muted-text)";
        el.textContent = normalizeText(message);
      }

      function setProfileTabStatus(message, isError = false) {
        const el = document.getElementById("profileTabStatus");
        if (!el) return;
        el.style.color = isError ? "#bd2f2f" : "var(--portal-status-muted-text)";
        el.textContent = normalizeText(message);
      }

      function syncProfileFieldLayoutEditorMode() {
        const editor = document.querySelector(".profile-layout-editor");
        const expandBtn = document.getElementById("profileFieldLayoutExpandBtn");
        const expanded = Boolean(state.profileLayoutExpanded);
        editor?.classList.toggle("profile-layout-editor--expanded", expanded);
        if (expandBtn instanceof HTMLButtonElement) {
          expandBtn.setAttribute("aria-pressed", expanded ? "true" : "false");
          expandBtn.textContent = expanded ? "Collapse List" : "Expand List";
        }
      }

      function setProfileFieldLayoutEditorExpanded(expanded = false) {
        state.profileLayoutExpanded = Boolean(expanded);
        syncProfileFieldLayoutEditorMode();
        setProfileLayoutStatus(
          state.profileLayoutExpanded ?
            "Layout editor expanded to full-height mode."
          : "Layout editor returned to compact mode.",
        );
      }

      if (typeof window !== "undefined") {
        window.__SIS_PROFILE_LAYOUT_TOGGLE__ = () => {
          setProfileFieldLayoutEditorExpanded(!state.profileLayoutExpanded);
        };
      }

      function bindProfileTabKeyboardNav(navEl, activeTabId, onSelectTab) {
        if (!navEl) return;
        navEl.onkeydown = (event) => {
          const key = normalizeText(event?.key);
          if (!["ArrowRight", "ArrowLeft", "Home", "End"].includes(key)) return;

          const buttons = Array.from(
            navEl.querySelectorAll(
              "button[data-profile-tab], button[data-profile-info-tab]",
            ),
          );
          if (!buttons.length) return;

          const ids = buttons.map((button) =>
            normalizeText(button.dataset.profileTab || button.dataset.profileInfoTab),
          );
          const focusedButton =
            event?.target && typeof event.target.closest === "function" ?
              event.target.closest("button")
            : null;
          const focusedId = normalizeText(
            focusedButton?.dataset?.profileTab ||
              focusedButton?.dataset?.profileInfoTab ||
              activeTabId ||
              ids[0],
          );
          const focusedIndex = ids.includes(focusedId) ? ids.indexOf(focusedId) : 0;

          let nextIndex = focusedIndex;
          if (key === "ArrowRight") nextIndex = (focusedIndex + 1) % ids.length;
          else if (key === "ArrowLeft")
            nextIndex = (focusedIndex - 1 + ids.length) % ids.length;
          else if (key === "Home") nextIndex = 0;
          else if (key === "End") nextIndex = ids.length - 1;

          event.preventDefault();
          const nextButton = buttons[nextIndex];
          const nextId = ids[nextIndex];
          if (nextButton && typeof nextButton.focus === "function") nextButton.focus();
          if (nextId && typeof onSelectTab === "function") onSelectTab(nextId);
        };
      }

      function setFormValue(field, value) {
        const el = document.getElementById(`f_${field}`);
        if (!el) return;

        const inputType = normalizeLower(el?.dataset?.profileInputType);
        if (inputType === "checkbox" || inputType === "radio") {
          const values = profileFieldValueAsArray(value).map((entry) =>
            normalizeLower(entry),
          );
          const options = el.querySelectorAll(
            "input[type=checkbox], input[type=radio]",
          );
          options.forEach((option) => {
            const optionValue = normalizeLower(option.value);
            if (inputType === "radio")
              option.checked = values.length ? values[0] === optionValue : false;
            else option.checked = values.includes(optionValue);
          });
          return;
        }

        if ("value" in el) {
          if (Array.isArray(value)) el.value = normalizeText(value[0]);
          else el.value = value == null ? "" : String(value);
        }
      }

      function getFormValue(field) {
        const el = document.getElementById(`f_${field}`);
        if (!el) return "";

        const inputType = normalizeLower(el?.dataset?.profileInputType);
        if (inputType === "checkbox") {
          return Array.from(el.querySelectorAll("input[type=checkbox]:checked"))
            .map((node) => normalizeText(node.value))
            .filter(Boolean);
        }
        if (inputType === "radio") {
          const selected = el.querySelector("input[type=radio]:checked");
          return selected ? normalizeText(selected.value) : "";
        }

        return "value" in el ? normalizeText(el.value) : "";
      }

      function profileFieldAutocompleteValue(field = {}, inputType = "text") {
        const explicitValue = normalizeText(field?.autocomplete);
        if (explicitValue) return explicitValue;

        const normalizedType = normalizeLower(inputType || "text");
        if (normalizedType === "email") return "email";
        if (normalizedType === "password") return "new-password";
        if (normalizedType === "url") return "url";

        return "off";
      }

      function renderProfileFieldControl(field = {}) {
        const wrapper = document.createElement("div");
        wrapper.className = `profile-field card col-${Math.max(1, Math.min(12, Number(field.width || 4)))}`;
        wrapper.dataset.surfaceRole = "card";
        if (field.idSuffix === "schoolName") wrapper.id = "profileSchoolCol";
        const labelText = profileFieldLabel(field);
        const labelEl = document.createElement("label");
        labelEl.textContent = labelText;

        const controlId = `f_${field.idSuffix}`;
        const inputType = normalizeLower(field.inputType || "text");
        const autocompleteValue = profileFieldAutocompleteValue(field, inputType);

        if (inputType === "checkbox" || inputType === "radio") {
          const choiceWrap = document.createElement("div");
          choiceWrap.id = controlId;
          choiceWrap.dataset.profileInputType = inputType;
          choiceWrap.className = "profile-choice-grid";
          const options =
            Array.isArray(field.options) && field.options.length ?
              field.options
            : ["Yes", "No"];
          let firstOptionId = "";
          options.forEach((option, index) => {
            const item = document.createElement("div");
            item.className = "profile-choice-item card";
            item.dataset.surfaceRole = "card";
            const optionId = `${controlId}_${index}`;
            if (!firstOptionId) firstOptionId = optionId;
            const input = document.createElement("input");
            input.type = inputType;
            input.id = optionId;
            input.name = controlId;
            input.value = normalizeText(option);
            input.autocomplete = "off";
            const optionLabel = document.createElement("label");
            optionLabel.setAttribute("for", optionId);
            optionLabel.textContent = normalizeText(option);
            item.appendChild(input);
            item.appendChild(optionLabel);
            choiceWrap.appendChild(item);
          });
          labelEl.htmlFor = firstOptionId || controlId;
          wrapper.appendChild(labelEl);
          wrapper.appendChild(choiceWrap);
          return wrapper;
        }

        if (inputType === "textarea") {
          const textarea = document.createElement("textarea");
          textarea.id = controlId;
          textarea.autocomplete = autocompleteValue;
          if (field.placeholderVi) textarea.placeholder = field.placeholderVi;
          labelEl.htmlFor = controlId;
          wrapper.appendChild(labelEl);
          wrapper.appendChild(textarea);
          return wrapper;
        }

        if (inputType === "select" || inputType === "level-select") {
          const select = document.createElement("select");
          select.id = controlId;
          select.dataset.profileInputType = inputType;
          select.dataset.surfaceRole = "card";
          select.autocomplete = autocompleteValue;
          if (inputType === "level-select") {
            const option = document.createElement("option");
            option.value = "";
            option.textContent = "Select level";
            select.appendChild(option);
          } else {
            const placeholderOption = document.createElement("option");
            placeholderOption.value = "";
            placeholderOption.textContent = field.placeholderVi || "Select option";
            select.appendChild(placeholderOption);
            (field.options || []).forEach((optionValue) => {
              const option = document.createElement("option");
              option.value = normalizeText(optionValue);
              option.textContent = normalizeText(optionValue);
              select.appendChild(option);
            });
          }
          labelEl.htmlFor = controlId;
          wrapper.appendChild(labelEl);
          wrapper.appendChild(select);
          return wrapper;
        }

        if (inputType === "file") {
          const fileRow = document.createElement("div");
          fileRow.className = "profile-file-row";

          const storedInput = document.createElement("input");
          storedInput.id = controlId;
          storedInput.type = "text";
          storedInput.autocomplete = autocompleteValue;
          storedInput.placeholder = field.placeholderVi || "Stored file reference";

          const fileInput = document.createElement("input");
          fileInput.id = `${controlId}_file`;
          fileInput.type = "file";
          fileInput.autocomplete = "off";
          fileInput.addEventListener("change", () => {
            const names = Array.from(fileInput.files || [])
              .map((file) => normalizeText(file?.name))
              .filter(Boolean);
            storedInput.value = names.join(", ");
          });

          const caption = document.createElement("p");
          caption.className = "file-caption";
          caption.textContent =
            "Select a file to capture the filename reference in this profile.";

          fileRow.appendChild(storedInput);
          fileRow.appendChild(fileInput);
          labelEl.htmlFor = controlId;
          wrapper.appendChild(labelEl);
          wrapper.appendChild(fileRow);
          wrapper.appendChild(caption);
          return wrapper;
        }

        const input = document.createElement("input");
        input.id = controlId;
        if (inputType === "level-select") input.type = "text";
        else if (inputType === "password") input.type = "password";
        else if (["email", "number", "url"].includes(inputType)) input.type = inputType;
        else input.type = "text";
        input.autocomplete = autocompleteValue;
        if (field.placeholderVi) input.placeholder = field.placeholderVi;
        labelEl.htmlFor = controlId;
        wrapper.appendChild(labelEl);
        wrapper.appendChild(input);
        return wrapper;
      }

      function renderProfileFormLayout() {
        const navEl = document.getElementById("profileTabNav");
        const formEl = navEl?.closest("form");
        if (!navEl || !formEl) return;
        const actionsEl = formEl.querySelector(".actions.actions-4");
        if (!actionsEl) return;

        const fields = sortedProfileFields(false);
        navEl.innerHTML = "";
        formEl
          .querySelectorAll('[data-profile-tab-panel], [data-profile-panels-empty="1"]')
          .forEach((node) => node.remove());

        const tabIds = PROFILE_FORM_TABS.map((tab) => tab.id);
        const fieldsByTab = new Map(tabIds.map((tabId) => [tabId, []]));
        fields.forEach((field) => {
          if (!fieldsByTab.has(field.tabId)) fieldsByTab.set(field.tabId, []);
          fieldsByTab.get(field.tabId).push(field);
        });

        const tabs = PROFILE_FORM_TABS.filter(
          (tab) => (fieldsByTab.get(tab.id) || []).length > 0,
        );
        if (!tabs.length) {
          const empty = document.createElement("p");
          empty.className = "small";
          empty.dataset.profilePanelsEmpty = "1";
          empty.textContent = "No profile fields configured.";
          formEl.insertBefore(empty, actionsEl);
          return;
        }

        if (!tabs.some((tab) => tab.id === state.profileActiveTab))
          state.profileActiveTab = tabs[0].id;

        tabs.forEach((tab) => {
          const isActive = state.profileActiveTab === tab.id;
          const tabButtonId = `profileFormTab_${tab.id}`;
          const tabPanelId = `profileFormPanel_${tab.id}`;
          const button = document.createElement("button");
          button.type = "button";
          button.id = tabButtonId;
          button.className = `portal-button portal-button-primary profile-tab-button${isActive ? " active" : ""}`;
          button.setAttribute("role", "tab");
          button.setAttribute("aria-selected", isActive ? "true" : "false");
          button.setAttribute("aria-controls", tabPanelId);
          button.tabIndex = isActive ? 0 : -1;
          button.dataset.profileTab = tab.id;
          button.textContent = tab.label;
          button.addEventListener("click", () => {
            state.profileActiveTab = tab.id;
            renderProfileFormLayout();
          });
          navEl.appendChild(button);
        });
        bindProfileTabKeyboardNav(navEl, state.profileActiveTab, (nextTabId) => {
          state.profileActiveTab = nextTabId;
          renderProfileFormLayout();
        });

        tabs.forEach((tab) => {
          const isActive = state.profileActiveTab === tab.id;
          const panel = document.createElement("section");
          panel.id = `profileFormPanel_${tab.id}`;
          panel.className = `profile-tab-panel panel${isActive ? " active" : ""}`;
          panel.dataset.surfaceRole = "panel";
          panel.dataset.profileTabPanel = tab.id;
          panel.setAttribute("role", "tabpanel");
          panel.setAttribute("aria-labelledby", `profileFormTab_${tab.id}`);
          panel.hidden = !isActive;

          const sectionMap = new Map();
          (fieldsByTab.get(tab.id) || []).forEach((field) => {
            const sectionKey = normalizeText(field.sectionVi) || "General";
            if (!sectionMap.has(sectionKey)) sectionMap.set(sectionKey, []);
            sectionMap.get(sectionKey).push(field);
          });

          Array.from(sectionMap.entries()).forEach(([sectionLabel, sectionFields]) => {
            const group = document.createElement("section");
            group.className = "profile-field-group";
            const title = document.createElement("h3");
            title.textContent = sectionLabel;
            group.appendChild(title);
            const subtitleText = profileFormSectionSubtitle(sectionLabel);
            if (subtitleText) {
              const subtitle = document.createElement("p");
              subtitle.className = "small profile-field-group-subtitle";
              subtitle.textContent = subtitleText;
              group.appendChild(subtitle);
            }
            const row = document.createElement("div");
            row.className = "row";
            sectionFields.forEach((field) =>
              row.appendChild(renderProfileFieldControl(field)),
            );
            group.appendChild(row);
            panel.appendChild(group);
          });

          formEl.insertBefore(panel, actionsEl);
        });

        populateProfileLevelOptions();
        applyUiSettings();
        syncProfileFieldLayoutEditorMode();
        if (state.profileMode === "edit") {
          setProfileTabStatus(
            `${fields.length} fields rendered across ${tabs.length} tabs.`,
          );
        }
      }

      function profileFormSectionSubtitle(sectionLabel = "") {
        const label = normalizeText(sectionLabel);
        if (!label) return "";
        if (label === "Thông tin của người học") return "Student information";
        if (label === "Liên hệ của mẹ hoặc học sinh trưởng thành") return "Mother's information";
        if (label === "Liên hệ của ba") return "Father's information";
        if (label === "Địa chỉ") return "Address";
        return "";
      }

      function renderProfileInfoLayout(student = state.currentStudent) {
        const navEl = document.getElementById("profileInfoTabNav");
        const panelsEl = navEl?.parentElement;
        if (!navEl || !panelsEl) return;

        const fields = sortedProfileFields(false);
        navEl.innerHTML = "";
        panelsEl
          .querySelectorAll('[data-profile-info-panel], [data-profile-panels-empty="1"]')
          .forEach((node) => node.remove());

        const tabIds = PROFILE_FORM_TABS.map((tab) => tab.id);
        const fieldsByTab = new Map(tabIds.map((tabId) => [tabId, []]));
        fields.forEach((field) => {
          if (!fieldsByTab.has(field.tabId)) fieldsByTab.set(field.tabId, []);
          fieldsByTab.get(field.tabId).push(field);
        });

        const tabs = PROFILE_FORM_TABS.filter(
          (tab) => (fieldsByTab.get(tab.id) || []).length > 0,
        );
        if (!tabs.length) {
          renderProfileInfoSummary(student);
          const empty = document.createElement("p");
          empty.className = "small";
          empty.dataset.profilePanelsEmpty = "1";
          empty.textContent = "No profile fields configured.";
          panelsEl.appendChild(empty);
          setProfileTabStatus("No profile fields configured.", true);
          return;
        }

        if (!tabs.some((tab) => tab.id === state.profileActiveTab))
          state.profileActiveTab = tabs[0].id;

        tabs.forEach((tab) => {
          const isActive = state.profileActiveTab === tab.id;
          const tabButtonId = `profileInfoTab_${tab.id}`;
          const tabPanelId = `profileInfoPanel_${tab.id}`;
          const button = document.createElement("button");
          button.type = "button";
          button.id = tabButtonId;
          button.className = `portal-button portal-button-primary profile-tab-button${isActive ? " active" : ""}`;
          button.setAttribute("role", "tab");
          button.setAttribute("aria-selected", isActive ? "true" : "false");
          button.setAttribute("aria-controls", tabPanelId);
          button.tabIndex = isActive ? 0 : -1;
          button.dataset.profileInfoTab = tab.id;
          button.textContent = tab.label;
          button.addEventListener("click", () => {
            state.profileActiveTab = tab.id;
            renderProfileInfoLayout(student);
          });
          navEl.appendChild(button);
        });
        bindProfileTabKeyboardNav(navEl, state.profileActiveTab, (nextTabId) => {
          state.profileActiveTab = nextTabId;
          renderProfileInfoLayout(student);
        });

        tabs.forEach((tab) => {
          const isActive = state.profileActiveTab === tab.id;
          const panel = document.createElement("section");
          panel.id = `profileInfoPanel_${tab.id}`;
          panel.className = `profile-info-panel panel${isActive ? " active" : ""}`;
          panel.dataset.surfaceRole = "panel";
          panel.dataset.profileInfoPanel = tab.id;
          panel.setAttribute("role", "tabpanel");
          panel.setAttribute("aria-labelledby", `profileInfoTab_${tab.id}`);
          panel.hidden = !isActive;

          const sectionMap = new Map();
          (fieldsByTab.get(tab.id) || []).forEach((field) => {
            const sectionKey = normalizeText(field.sectionVi) || "General";
            if (!sectionMap.has(sectionKey)) sectionMap.set(sectionKey, []);
            sectionMap.get(sectionKey).push(field);
          });

          const sectionEntries = Array.from(sectionMap.entries()).sort(
            (left, right) => {
              const leftPriority = profileInfoSectionPriority(tab.id, left[0]);
              const rightPriority = profileInfoSectionPriority(tab.id, right[0]);
              if (leftPriority !== rightPriority) return leftPriority - rightPriority;
              return normalizeText(left[0]).localeCompare(
                normalizeText(right[0]),
                undefined,
                { sensitivity: "base" },
              );
            },
          );

          sectionEntries.forEach(([sectionLabel, sectionFields]) => {
            const group = document.createElement("section");
            group.className = "profile-info-group";

            const headingRow = document.createElement("div");
            headingRow.className = "profile-info-group-head";
            const title = document.createElement("h4");
            title.textContent = sectionLabel;
            const meta = document.createElement("p");
            meta.className = "profile-info-group-meta";
            meta.textContent = `${sectionFields.length} fields`;
            headingRow.appendChild(title);
            headingRow.appendChild(meta);
            group.appendChild(headingRow);

            const renderedRecords = sectionFields
              .map((field) => ({
                field,
                ...renderProfileInfoItem(
                  field,
                  resolveProfileFieldValueForStudent(student, field),
                ),
              }))
              .sort((left, right) => {
                if (left.hasValue !== right.hasValue) return left.hasValue ? -1 : 1;
                const leftPriority = left.item.dataset.priority === "primary" ? 0 : 1;
                const rightPriority = right.item.dataset.priority === "primary" ? 0 : 1;
                if (leftPriority !== rightPriority) return leftPriority - rightPriority;
                const leftSequence =
                  Number.parseInt(String(left?.field?.sequence || 0), 10) || 0;
                const rightSequence =
                  Number.parseInt(String(right?.field?.sequence || 0), 10) || 0;
                if (leftSequence !== rightSequence) return leftSequence - rightSequence;
                return normalizeText(left?.field?.key).localeCompare(
                  normalizeText(right?.field?.key),
                );
              });

            const grid = document.createElement("div");
            grid.className = "profile-info-grid";
            renderedRecords.forEach((entry) => {
              grid.appendChild(entry.item);
            });
            if (!renderedRecords.some((entry) => entry.hasValue)) {
              const note = document.createElement("p");
              note.className = "small profile-info-empty-note";
              note.textContent = "No populated values in this cluster yet.";
              group.appendChild(note);
            }
            group.appendChild(grid);

            panel.appendChild(group);
          });

          panelsEl.appendChild(panel);
        });

        renderProfileInfoSummary(student);
        const label = normalizeText(student?.profile?.fullName);
        setProfileTabStatus(
          label ?
            `Info view for ${label}.`
          : "No student selected. Use New Form to create a profile.",
        );
      }

      function renderProfileFieldLayoutEditor() {
        const tbody = document.getElementById("profileFieldLayoutRows");
        if (!tbody) return;
        const fields = sortedProfileFields(true);
        tbody.innerHTML = "";

        fields.forEach((field) => {
          const tr = document.createElement("tr");
          tr.dataset.profileFieldKey = field.key;
          tr.dataset.profileFieldLocked = field.locked ? "1" : "";
          tr.dataset.profileFieldCustom = field.isCustom ? "1" : "";
          tr.dataset.profileFieldProfileKey = field.profileKey || "";
          tr.dataset.profileFieldTopLevelKey = field.topLevelKey || "";

          const tabOptions = PROFILE_FORM_TABS.map(
            (tab) =>
              `<option value="${escapeHtml(tab.id)}"${tab.id === field.tabId ? " selected" : ""}>${escapeHtml(tab.label)}</option>`,
          ).join("");
          const inputTypeOptions = PROFILE_INPUT_TYPES.map(
            (type) =>
              `<option value="${escapeHtml(type)}"${type === field.inputType ? " selected" : ""}>${escapeHtml(type)}</option>`,
          ).join("");

          tr.innerHTML = `
          <td>${escapeHtml(field.key)}</td>
          <td><input type="text" name="profile-field-label-vi-${sanitizeDomIdPart(field.key)}" data-layout-key="labelVi" value="${escapeHtml(field.labelVi)}"></td>
          <td><select name="profile-field-input-type-${sanitizeDomIdPart(field.key)}" data-layout-key="inputType">${inputTypeOptions}</select></td>
          <td><select name="profile-field-tab-id-${sanitizeDomIdPart(field.key)}" data-layout-key="tabId">${tabOptions}</select></td>
          <td><input type="text" name="profile-field-section-vi-${sanitizeDomIdPart(field.key)}" data-layout-key="sectionVi" value="${escapeHtml(field.sectionVi)}"></td>
          <td><input type="number" name="profile-field-sequence-${sanitizeDomIdPart(field.key)}" min="1" step="1" data-layout-key="sequence" value="${Number(field.sequence || 0)}"></td>
          <td><input type="number" name="profile-field-width-${sanitizeDomIdPart(field.key)}" min="1" max="12" step="1" data-layout-key="width" value="${Number(field.width || 4)}"></td>
          <td><input type="checkbox" name="profile-field-enabled-${sanitizeDomIdPart(field.key)}" data-layout-key="enabled"${field.enabled ? " checked" : ""}></td>
          <td><input type="text" name="profile-field-placeholder-vi-${sanitizeDomIdPart(field.key)}" data-layout-key="placeholderVi" value="${escapeHtml(field.placeholderVi || "")}"></td>
          <td><input type="text" name="profile-field-options-${sanitizeDomIdPart(field.key)}" data-layout-key="options" value="${escapeHtml((field.options || []).join(" | "))}"></td>
          <td><button type="button" class="layout-delete-btn portal-button portal-button-danger" data-profile-layout-action="delete"${field.locked ? " disabled" : ""}>Delete</button></td>
        `;
          tbody.appendChild(tr);
        });
      }

      function applyProfileFieldLayoutChanges() {
        const tbody = document.getElementById("profileFieldLayoutRows");
        if (!tbody) return;
        const rows = Array.from(tbody.querySelectorAll("tr[data-profile-field-key]"));
        const fields = rows.map((row, index) =>
          normalizeProfileFieldDefinition(
            {
              key: row.dataset.profileFieldKey,
              idSuffix:
                profileFieldByKey(row.dataset.profileFieldKey)?.idSuffix ||
                row.dataset.profileFieldKey,
              labelVi: row.querySelector('[data-layout-key="labelVi"]')?.value,
              labelEn: profileFieldByKey(row.dataset.profileFieldKey)?.labelEn || "",
              tabId: row.querySelector('[data-layout-key="tabId"]')?.value,
              sectionVi: row.querySelector('[data-layout-key="sectionVi"]')?.value,
              sectionEn:
                profileFieldByKey(row.dataset.profileFieldKey)?.sectionEn || "",
              inputType: row.querySelector('[data-layout-key="inputType"]')?.value,
              placeholderVi: row.querySelector('[data-layout-key="placeholderVi"]')
                ?.value,
              options: parseProfileOptions(
                row.querySelector('[data-layout-key="options"]')?.value || "",
              ),
              profileKey: row.dataset.profileFieldProfileKey || "",
              topLevelKey: row.dataset.profileFieldTopLevelKey || "",
              sequence: row.querySelector('[data-layout-key="sequence"]')?.value,
              width: row.querySelector('[data-layout-key="width"]')?.value,
              enabled: Boolean(
                row.querySelector('[data-layout-key="enabled"]')?.checked,
              ),
              locked: row.dataset.profileFieldLocked === "1",
              isCustom: row.dataset.profileFieldCustom === "1",
            },
            (index + 1) * 10,
          ),
        );

        persistProfileFormConfig({ tabs: PROFILE_FORM_TABS, fields });
        renderProfileFormLayout();
        renderProfileInfoLayout();
        renderProfileFieldLayoutEditor();
        if (state.currentStudent?.id) fillStudentForm(state.currentStudent);
        setProfileLayoutStatus("Profile layout changes applied.");
        setStatus("Profile layout changes applied.");
      }

      function resetProfileFieldLayoutToDefault() {
        persistProfileFormConfig(buildDefaultProfileFormConfig());
        renderProfileFormLayout();
        renderProfileInfoLayout();
        renderProfileFieldLayoutEditor();
        if (state.currentStudent?.id) fillStudentForm(state.currentStudent);
        setProfileLayoutStatus("Profile layout reset to default.");
        setStatus("Profile layout reset to default.");
      }

      function createProfileFieldFromSettings() {
        const keyRaw = normalizeText(
          document.getElementById("profileFieldCreateKey")?.value,
        );
        if (!keyRaw) throw new Error("New field key is required.");
        const key = toProfileFieldIdSuffix(keyRaw);
        if (!key) throw new Error("New field key is invalid.");
        if (profileFieldByKey(key))
          throw new Error(`Field key "${key}" already exists.`);

        const type = normalizeProfileInputType(
          document.getElementById("profileFieldCreateType")?.value || "text",
          key,
        );
        const tabId = normalizeLower(
          document.getElementById("profileFieldCreateTab")?.value || "profile",
        );
        const labelVi =
          normalizeText(document.getElementById("profileFieldCreateLabelVi")?.value) ||
          key;
        const sectionVi = normalizeText(
          document.getElementById("profileFieldCreateSectionVi")?.value,
        );
        const options = parseProfileOptions(
          document.getElementById("profileFieldCreateOptions")?.value || "",
        );
        const placeholderVi = normalizeText(
          document.getElementById("profileFieldCreatePlaceholderVi")?.value,
        );
        const width = Number(
          document.getElementById("profileFieldCreateWidth")?.value || 4,
        );
        const sequenceRaw = Number(
          document.getElementById("profileFieldCreateSequence")?.value,
        );
        const sequence =
          Number.isFinite(sequenceRaw) && sequenceRaw > 0 ?
            sequenceRaw
          : nextProfileFieldSequence(sortedProfileFields(true));

        const fields = sortedProfileFields(true);
        const knownSuffixes = new Set(
          fields.map((field) => normalizeLower(field.idSuffix)),
        );
        let idSuffix = toProfileFieldIdSuffix(key);
        let suffixIndex = 2;
        while (knownSuffixes.has(normalizeLower(idSuffix))) {
          idSuffix = `${toProfileFieldIdSuffix(key)}${suffixIndex}`;
          suffixIndex += 1;
        }

        fields.push(
          normalizeProfileFieldDefinition(
            {
              key,
              idSuffix,
              labelVi,
              labelEn: "",
              tabId,
              sectionVi,
              sectionEn: "",
              inputType: type,
              placeholderVi,
              options,
              profileKey: "",
              topLevelKey: "",
              sequence,
              width,
              enabled: true,
              isCustom: true,
            },
            sequence,
          ),
        );

        persistProfileFormConfig({ tabs: PROFILE_FORM_TABS, fields });
        renderProfileFormLayout();
        renderProfileInfoLayout();
        renderProfileFieldLayoutEditor();
        if (state.currentStudent?.id) fillStudentForm(state.currentStudent);
        setProfileLayoutStatus(`Created field: ${key}`);
        setStatus(`Created profile field: ${key}`);
      }

      function deleteProfileFieldFromLayout(key = "") {
        const target = profileFieldByKey(key);
        if (!target) return;
        if (target.locked)
          throw new Error(`Field "${key}" is locked and cannot be deleted.`);
        if (!confirm(`Delete profile field "${key}"?`)) return;
        const nextFields = sortedProfileFields(true).filter(
          (field) => normalizeText(field.key) !== normalizeText(key),
        );
        persistProfileFormConfig({ tabs: PROFILE_FORM_TABS, fields: nextFields });
        renderProfileFormLayout();
        renderProfileInfoLayout();
        renderProfileFieldLayoutEditor();
        if (state.currentStudent?.id) fillStudentForm(state.currentStudent);
        setProfileLayoutStatus(`Deleted field: ${key}`);
        setStatus(`Deleted profile field: ${key}`);
      }

      function clearStudentForm({ refreshStudentList = true, hydrateNextStudentNumber = true } = {}) {
        state.currentStudent = null;
        state.tableRows.attendance = [];
        state.tableRows.performance = [];
        state.tableRows.grades = [];
        state.tableRows.reports = [];
        state.visibleTableRows.attendance = [];
        state.visibleTableRows.performance = [];
        state.visibleTableRows.grades = [];
        state.visibleTableRows.reports = [];
        profileFieldIdList(true).forEach((field) => setFormValue(field, ""));
        const nextNumericId = nextStudentNumericId();
        setFormValue("studentNumber", nextNumericId);
        if (hydrateNextStudentNumber) {
          hydrateNextStudentNumberFromApi().catch((error) => {
            if (error && (error.status === 401 || error.status === 404 || error.status === 503)) return;
            handleError(error);
          });
        }
        applyLevelThemeToSections("");
        const attendanceIdEl = document.getElementById("a_id");
        const gradeIdEl = document.getElementById("g_id");
        const reportIdEl = document.getElementById("r_id");
        const attendanceRowsEl = document.getElementById("attendanceRows");
        const gradeRowsEl = document.getElementById("gradeRows");
        const reportRowsEl = document.getElementById("reportRows");
        if (attendanceIdEl) attendanceIdEl.value = "";
        if (gradeIdEl) gradeIdEl.value = "";
        if (reportIdEl) reportIdEl.value = "";
        if (attendanceRowsEl) attendanceRowsEl.innerHTML = "";
        if (gradeRowsEl) gradeRowsEl.innerHTML = "";
        if (reportRowsEl) reportRowsEl.innerHTML = "";
        applyDefaultGradeAndReportSchoolYears(true);
        renderGradePulseChart([]);
        renderProfileInfoLayout(null);
        setProfileMode(state.profileMode);
        updateOverviewStudentSummary();
        if (refreshStudentList) renderStudents();
      }

      function fillStudentForm(student) {
        cacheStudentDetail(student);
        const p = student.profile || {};
        syncSystemLevelNames([normalizeLevelName(p.currentGrade)]);

        sortedProfileFields(true).forEach((field) => {
          const value = resolveProfileFieldValueForStudent(student, field);
          setFormValue(field.idSuffix, value);
        });

        applyLevelThemeToSections(
          resolveSystemLevelName(p.currentGrade || getFormValue("currentGrade")),
        );
        renderProfileInfoLayout(student);
        setProfileMode(state.profileMode);
        const activeAdminDataTable = adminDataTableKeyForPage(state.activePage);
        if (activeAdminDataTable) {
          loadAdminDataRowsForTable(activeAdminDataTable).catch(handleError);
        } else {
          renderAttendanceRows(student.attendanceRecords || []);
          renderGradeRows(student.gradeRecords || []);
          renderReportRows(student.parentReports || []);
        }
        updateOverviewStudentSummary();
      }

      function collectStudentPayload() {
        const baseProfile =
          (
            state.currentStudent?.profile &&
            typeof state.currentStudent.profile === "object"
          ) ?
            { ...state.currentStudent.profile }
          : {};
        const normalizedFormPayload =
          (
            baseProfile.normalizedFormPayload &&
            typeof baseProfile.normalizedFormPayload === "object"
          ) ?
            { ...baseProfile.normalizedFormPayload }
          : {};
        const rawFormPayload =
          baseProfile.rawFormPayload && typeof baseProfile.rawFormPayload === "object" ?
            { ...baseProfile.rawFormPayload }
          : {};

        const profile = {
          ...baseProfile,
          sourceFormId: "admin-manual",
          sourceUrl: "admin/students",
        };

        let eaglesId = normalizeText(state.currentStudent?.eaglesId || "");
        let studentNumber = parsePositiveInteger(state.currentStudent?.studentNumber);
        let email = normalizeText(state.currentStudent?.email || "");

        sortedProfileFields(false).forEach((field) => {
          const fieldValue = normalizeProfileFormFieldValue(
            field,
            getFormValue(field.idSuffix),
          );
          normalizedFormPayload[field.key] = fieldValue;
          rawFormPayload[field.key] = fieldValue;

          if (field.profileKey) {
            if (PROFILE_ARRAY_PROFILE_KEYS.has(field.profileKey)) {
              profile[field.profileKey] = normalizeTextArray(fieldValue);
            } else {
              profile[field.profileKey] = scalarFromProfileFormFieldValue(fieldValue);
            }
          }

          if (field.topLevelKey === "eaglesId")
            eaglesId = scalarFromProfileFormFieldValue(fieldValue);
          if (field.topLevelKey === "studentNumber")
            studentNumber = parsePositiveInteger(fieldValue);
          if (field.topLevelKey === "email")
            email = scalarFromProfileFormFieldValue(fieldValue);
        });

        if (normalizeText(profile.currentGrade))
          profile.currentGrade = resolveSystemLevelName(profile.currentGrade);
        if (normalizeText(profile.studentEmail) && !email)
          email = normalizeText(profile.studentEmail);
        if (!normalizeText(profile.studentEmail) && email) profile.studentEmail = email;

        profile.normalizedFormPayload = normalizedFormPayload;
        profile.rawFormPayload = rawFormPayload;

        return {
          studentNumber: studentNumber || null,
          eaglesId: normalizeText(eaglesId),
          email: normalizeText(email),
          profile,
        };
      }

      async function loadFilters() {
        const data = await api("/api/admin/filters");
        const levelSelect = document.getElementById("filterLevel");
        const schoolSelect = document.getElementById("filterSchool");
        const currentLevelValue = normalizeText(levelSelect?.value || "");
        const currentLevel =
          currentLevelValue === "__UNENROLLED_ONLY__" ?
            "__UNENROLLED_ONLY__"
          : resolveSystemLevelName(currentLevelValue);
        const currentSchool = normalizeText(schoolSelect?.value);

        if (levelSelect)
          levelSelect.innerHTML = '<option value="">All levels</option>';
        const configuredSchoolName = normalizeText(state.uiSettings?.schoolProfile?.schoolName);
        const singleSchoolMode = state.uiSettings?.multiSchool !== true && Boolean(configuredSchoolName);
        if (schoolSelect) {
          schoolSelect.innerHTML = singleSchoolMode ?
            `<option value="${escapeHtml(configuredSchoolName)}">${escapeHtml(configuredSchoolName)}</option>`
            : '<option value="">All schools</option>';
          if (singleSchoolMode) schoolSelect.value = configuredSchoolName;
        }

        const filterLevels = (data.levels || []).map((entry) =>
          normalizeLevelName(entry),
        );
        syncSystemLevelNames(filterLevels);
        const levelList = collectKnownLevelNames([
          currentLevel === "__UNENROLLED_ONLY__" ? "" : currentLevel,
          ...filterLevels,
        ]);

        levelList.forEach((level) => {
          const option = document.createElement("option");
          option.value = resolveSystemLevelName(level);
          option.textContent = shortLevelLabel(level);
          if (levelNamesMatch(option.value, currentLevel)) option.selected = true;
          if (levelSelect) levelSelect.appendChild(option);
        });
        if (levelSelect) {
          const unenrolledOption = document.createElement("option");
          unenrolledOption.value = "__UNENROLLED_ONLY__";
          unenrolledOption.textContent = "Unenrolled only";
          if (normalizeText(currentLevel) === "__UNENROLLED_ONLY__")
            unenrolledOption.selected = true;
          levelSelect.appendChild(unenrolledOption);
        }
        (singleSchoolMode ? [configuredSchoolName] : (data.schools || [])).forEach((school) => {
          const option = document.createElement("option");
          option.value = school;
          option.textContent = school;
          if (singleSchoolMode || normalizeLower(option.value) === normalizeLower(currentSchool))
            option.selected = true;
          if (schoolSelect) schoolSelect.appendChild(option);
        });

        populateProfileLevelOptions();
        populateAssignmentLevelOptions();
        populateAttendanceLevelStyleOptions();
        refreshAllTableSearchFilterControls();
        syncAttendanceLevelEditorInputs();
        applyUiSettings();
        renderTopSearchStudentOptions();
        updateTopSearchScopeHint();
        await refreshAttendanceLanding({
          reloadRows:
            state.activePage === "attendance" ||
            state.activePage === "attendance-admin",
        });
        await refreshParentTracking({ preserveStudentSelection: true });
      }

      async function loadStudents() {
        const qInput = normalizeText(document.getElementById("searchQ")?.value || "");
        const qRaw = normalizeTopSearchQuery(qInput);
        const levelControlValue = normalizeText(
          document.getElementById("filterLevel")?.value || "",
        );
        const levelRaw =
          levelControlValue === "__UNENROLLED_ONLY__" ?
            "__UNENROLLED_ONLY__"
          : resolveSystemLevelName(levelControlValue);
        const schoolRaw = normalizeText(
          document.getElementById("filterSchool")?.value || "",
        );
        const includeUnenrolled = Boolean(
          document.getElementById("includeUnenrolled")?.checked,
        );

        const q = encodeURIComponent(qRaw);
        const level = encodeURIComponent(levelRaw);
        const school = encodeURIComponent(schoolRaw);
        const includeParam = includeUnenrolled ? "&includeUnenrolled=true" : "";

        const data = await api(
          `/api/admin/students?q=${q}&level=${level}&school=${school}${includeParam}`,
        );
        let students = Array.isArray(data?.items) ? data.items : [];
        if (qRaw && students.length === 0) {
          const fallback = await api(
            `/api/admin/students?q=&level=${level}&school=${school}&take=1000${includeParam}`,
          );
          students = Array.isArray(fallback?.items) ? fallback.items : [];
        }
        let missingEaglesId = 0;
        let missingStudentNumber = 0;
        const studentsWithIdentity = students.filter((student) => {
          const hasEaglesId = Boolean(normalizeText(student?.eaglesId));
          if (!hasEaglesId) {
            missingEaglesId += 1;
            return false;
          }
          const hasNumberKey = hasStudentNumberKey(student);
          const hasStudentNumber = Boolean(
            parsePositiveInteger(student?.studentNumber),
          );
          if (hasNumberKey && !hasStudentNumber) {
            missingStudentNumber += 1;
            return false;
          }
          return true;
        });
        const droppedCount = students.length - studentsWithIdentity.length;
        if (droppedCount > 0) {
          const problems = [];
          if (missingEaglesId > 0) problems.push(`missing eaglesId=${missingEaglesId}`);
          if (missingStudentNumber > 0)
            problems.push(`missing studentNumber=${missingStudentNumber}`);
          setStatus(
            `Data integrity error: ${droppedCount} student row(s) excluded (${problems.join(", ") || "identity invalid"}).`,
            true,
          );
        }
        state.topStudentScope = {
          query: qRaw,
          level: levelRaw,
          school: schoolRaw,
          includeUnenrolled,
        };
        state.students = studentsWithIdentity;
        if (!qRaw && !levelRaw && !schoolRaw && !includeUnenrolled) {
          state.dashboardStudents = state.students;
        }
        syncSystemLevelNames(
          state.students.map((student) =>
            normalizeLevelName(student?.profile?.currentGrade || ""),
          ),
        );
        renderStudents();
        renderTopSearchStudentOptions();
        updateTopSearchScopeHint();

        if (state.currentStudent) {
          const exists = state.students.find(
            (entry) => entry.id === state.currentStudent.id,
          );
          if (!exists) clearStudentForm();
        }
        await refreshAttendanceLanding({
          reloadRows:
            state.activePage === "attendance" ||
            state.activePage === "attendance-admin",
        });
        const activeAdminDataTable = adminDataTableKeyForPage(state.activePage);
        if (activeAdminDataTable) await loadAdminDataRowsForTable(activeAdminDataTable);
        await refreshParentTracking({ preserveStudentSelection: true });
        if (state.dashboardSummary) renderDashboardSummary(state.dashboardSummary);
      }

      async function clearTopControls() {
        const searchEl = document.getElementById("searchQ");
        const levelEl = document.getElementById("filterLevel");
        const schoolEl = document.getElementById("filterSchool");
        const includeUnenrolledEl = document.getElementById("includeUnenrolled");
        const familyPhoneEl = document.getElementById("familyPhone");
        const familyResultEl = document.getElementById("familyResult");

        if (searchEl) searchEl.value = "";
        if (levelEl) levelEl.value = "";
        if (schoolEl) schoolEl.value = "";
        if (includeUnenrolledEl) includeUnenrolledEl.checked = false;
        if (familyPhoneEl) familyPhoneEl.value = "";
        if (familyResultEl) familyResultEl.textContent = "No family lookup yet.";

        if (canReadData()) {
          await loadStudents();
        } else {
          state.topStudentScope = { query: "", level: "", school: "", includeUnenrolled: false };
          renderStudents();
          renderTopSearchStudentOptions();
          updateTopSearchScopeHint();
        }
        setStatus("Search and filter form cleared.");
      }

      async function loadStudentDetail(studentRefId, enrollmentPeriodId = "") {
        const params = new URLSearchParams();
        if (normalizeText(enrollmentPeriodId)) {
          params.set("enrollmentPeriodId", normalizeText(enrollmentPeriodId));
        }
        const student = await api(
          `/api/admin/students/${encodeURIComponent(studentRefId)}${params.size ? `?${params.toString()}` : ""}`,
        );
        if (!normalizeText(student?.eaglesId))
          throw new Error(
            "Data integrity error: eaglesId is required for student records.",
          );
        if (
          hasStudentNumberKey(student) &&
          !parsePositiveInteger(student?.studentNumber)
        ) {
          throw new Error(
            "Data integrity error: studentNumber is required for student records.",
          );
        }
        state.selectedEnrollmentPeriodId = normalizeText(
          student?.selectedEnrollmentPeriodId || enrollmentPeriodId || "",
        );
        state.currentStudent = student;
        cacheStudentDetail(student);
        if (student?.id)
          state.parentTracking.studentDetailsByStudentId[student.id] = student;
        syncSystemLevelNames([
          normalizeLevelName(student?.profile?.currentGrade || ""),
        ]);
        fillStudentForm(student);
        renderStudents();
      }

      async function saveStudent() {
        const payload = collectStudentPayload();
        if (!payload.eaglesId) throw new Error("eaglesId is required");

        if (state.currentStudent && state.currentStudent.id) {
          const result = await api(
            `/api/admin/students/${encodeURIComponent(state.currentStudent.id)}`,
            {
              method: "PUT",
              body: payload,
            },
          );
          state.currentStudent = result.student;
        } else {
          const result = await api("/api/admin/students", {
            method: "POST",
            body: payload,
          });
          state.currentStudent = result.student;
        }

        await loadFilters();
        await loadStudents();
        if (state.currentStudent?.id) await loadStudentDetail(state.currentStudent.id);
        setProfileMode("info");
        renderProfileInfoLayout(state.currentStudent);
        setStatus(
          studentNeedsEnrollment(state.currentStudent) ?
            "Student saved. Warning: no enrollment or class assigned; use Include unenrolled to find this student."
          : "Student saved.",
        );
      }

      async function deleteCurrentStudent() {
        const id = selectedStudentId();
        if (!id) throw new Error("Select a student first");
        if (!confirm("Delete this student and linked records?")) return;

        await api(`/api/admin/students/${encodeURIComponent(id)}`, {
          method: "DELETE",
        });
        clearStudentForm({ refreshStudentList: false });
        setProfileMode("info");
        await loadFilters();
        await loadStudents();
        setStatus("Student deleted.");
      }

      function parseDelimited(text, delimiter) {
        const rows = [];
        let row = [];
        let value = "";
        let inQuotes = false;

        for (let i = 0; i < text.length; i += 1) {
          const char = text[i];
          const next = text[i + 1];

          if (char === '"') {
            if (inQuotes && next === '"') {
              value += '"';
              i += 1;
            } else {
              inQuotes = !inQuotes;
            }
            continue;
          }

          if (!inQuotes && char === delimiter) {
            row.push(value);
            value = "";
            continue;
          }

          if (!inQuotes && (char === "\n" || char === "\r")) {
            if (char === "\r" && next === "\n") i += 1;
            row.push(value);
            value = "";
            if (row.some((cell) => normalizeText(cell))) rows.push(row);
            row = [];
            continue;
          }

          value += char;
        }

        if (value || row.length) {
          row.push(value);
          if (row.some((cell) => normalizeText(cell))) rows.push(row);
        }

        return rows;
      }

      function arrayBufferToBase64(arrayBuffer) {
        const bytes = new Uint8Array(arrayBuffer);
        let binary = "";
        const chunkSize = 0x8000;
        for (let i = 0; i < bytes.length; i += chunkSize) {
          const chunk = bytes.subarray(i, i + chunkSize);
          binary += String.fromCharCode(...chunk);
        }
        return btoa(binary);
      }

      function decodeUtf8TextFromArrayBuffer(
        arrayBuffer,
        contextLabel = "Upload file",
      ) {
        try {
          const decoded = new TextDecoder("utf-8", { fatal: true }).decode(arrayBuffer);
          return decoded.charCodeAt(0) === 0xfeff ? decoded.slice(1) : decoded;
        } catch (error) {
          void error;
          throw new Error(`${contextLabel} must be UTF-8 encoded`);
        }
      }

      function detectImportFormat(fileName) {
        const lower = normalizeText(fileName).toLowerCase();
        if (lower.endsWith(".xlsx")) return "xlsx";
        if (lower.endsWith(".xls")) return "xls";
        if (lower.endsWith(".tsv")) return "tsv";
        return "csv";
      }

      async function importSpreadsheet() {
        const fileInput = document.getElementById("importFile");
        const file = fileInput.files[0];
        if (!file) throw new Error("Choose a CSV/TSV/XLSX file first");

        const format = detectImportFormat(file.name);
        let result = null;

        if (format === "xlsx" || format === "xls") {
          const arrayBuffer = await file.arrayBuffer();
          const fileDataBase64 = arrayBufferToBase64(arrayBuffer);
          result = await api("/api/admin/students/import", {
            method: "POST",
            body: {
              fileName: file.name,
              format,
              fileDataBase64,
            },
          });
        } else {
          const arrayBuffer = await file.arrayBuffer();
          const text = decodeUtf8TextFromArrayBuffer(
            arrayBuffer,
            `${format.toUpperCase()} import file`,
          );
          const delimiter = format === "tsv" ? "\t" : ",";
          const matrix = parseDelimited(text, delimiter);
          if (!matrix.length) throw new Error("Import file is empty");

          const headers = matrix[0].map((cell) => normalizeText(cell));
          const rows = matrix.slice(1).map((line) => {
            const row = {};
            headers.forEach((header, index) => {
              row[header || `col_${index + 1}`] = normalizeText(line[index] || "");
            });
            return row;
          });

          result = await api("/api/admin/students/import", {
            method: "POST",
            body: { rows },
          });
        }

        await loadFilters();
        await loadStudents();
        const autoIdCount = Number(result?.autoFilledEaglesIds || 0);
        const autoNumberCount = Number(result?.autoFilledStudentNumbers || 0);
        const autoFillSummary =
          autoIdCount || autoNumberCount ?
            `, autoFilledEaglesIds=${autoIdCount}, autoFilledStudentNumbers=${autoNumberCount}`
          : "";
        setStatus(
          `Import completed: processed=${result.processed}, created=${result.created}, updated=${result.updated}, failed=${result.failed}${autoFillSummary}`,
        );
      }

      async function downloadImportTemplate() {
        const response = await fetch(
          resolveApiUrl("/api/admin/students/import-template.xlsx"),
          {
            credentials: "include",
          },
        );

        if (!response.ok) {
          let message = `HTTP ${response.status}`;
          try {
            const payload = await response.json();
            if (payload && payload.error) message = payload.error;
          } catch (error) {
            void error;
          }
          const apiError = new Error(message);
          apiError.status = response.status;
          throw apiError;
        }

        const blob = await response.blob();
        const downloadUrl = URL.createObjectURL(blob);
        const link = document.createElement("a");
        const disposition = response.headers.get("content-disposition") || "";
        const suggestedName = parseFilenameFromDisposition(disposition);
        link.href = downloadUrl;
        link.download = suggestedName || "student-import-template.xlsx";
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(downloadUrl);
        setStatus("Import template downloaded.");
      }

      function attendancePayload() {
        return {
          id: normalizeText(document.getElementById("a_id").value),
          className: normalizeText(document.getElementById("a_className").value),
          schoolYear: normalizeText(document.getElementById("a_schoolYear").value),
          quarter: normalizeText(document.getElementById("a_quarter").value),
          attendanceDate: normalizeText(document.getElementById("a_date").value),
          status: normalizeText(document.getElementById("a_status").value),
          comments: normalizeText(document.getElementById("a_comments").value),
          level: resolveSystemLevelName(
            state.attendanceLanding?.selectedLevel || getFormValue("currentGrade"),
          ),
        };
      }

      function attendanceStudentSource() {
        // Attendance input/admin should always use the full roster source,
        // independent from top-search scope used on other pages.
        return baseStudentSource();
      }

      function attendanceLevelTileConfig(levelName) {
        const canonicalLevel = resolveSystemLevelName(levelName);
        const theme = getLevelTheme(canonicalLevel);
        const configStore = state.attendanceLanding?.tileConfigByLevel || {};
        const configKeys = levelTileStyleKeys(canonicalLevel);
        const matchedKey = configKeys.find((key) =>
          Object.prototype.hasOwnProperty.call(configStore, key),
        );
        const raw = matchedKey ? configStore[matchedKey] || {} : {};
        const hasCustomTitle = Object.prototype.hasOwnProperty.call(raw, "title");
        const title =
          hasCustomTitle ? normalizeText(raw.title) : fullLevelLabel(canonicalLevel);
        const bgColor =
          parseHexRgb(normalizeText(raw.bgColor)) ?
            normalizeText(raw.bgColor)
          : theme.color;
        const imageDataUrl = normalizeText(raw.imageDataUrl);
        const assetKey = normalizeText(raw.assetKey);
        return {
          title,
          bgColor,
          assetKey,
          imageDataUrl: assetKey
            ? `${ADMIN_ASSETS_PATH}/raw/${encodeURIComponent(assetKey)}`
            : imageDataUrl,
        };
      }

      function setAttendanceLevelStyleStatus(message) {
        const statusEl = document.getElementById("attendanceLevelStyleStatus");
        if (!statusEl) return;
        statusEl.textContent =
          normalizeText(message) || "Select a level to edit global tile style.";
      }

      function selectedAttendanceLevelStyleLevel() {
        const selectEl = document.getElementById("attendanceLevelStyleLevel");
        if (!selectEl) return "";
        const selected = resolveSystemLevelName(
          selectEl.value || state.levelTileStyleEditor?.selectedLevel || "",
        );
        return selected;
      }

      function populateAttendanceLevelStyleOptions(levels = collectAttendanceLevelNames()) {
        const selectEl = document.getElementById("attendanceLevelStyleLevel");
        if (!selectEl) return;
        const current = selectedAttendanceLevelStyleLevel();
        const values = collectAttendanceLevelNames([
          current,
          ...(Array.isArray(levels) ? levels : []),
        ]).filter(Boolean);
        selectEl.innerHTML = '<option value="">Select level</option>';
        values.forEach((levelName) => {
          const option = document.createElement("option");
          option.value = levelName;
          option.textContent = fullLevelLabel(levelName);
          if (levelNamesMatch(levelName, current)) option.selected = true;
          selectEl.appendChild(option);
        });
      }

      function selectedAttendanceLevelStudents() {
        const selectedLevel = resolveSystemLevelName(
          state.attendanceLanding?.selectedLevel || "",
        );
        if (!selectedLevel) return [];
        return attendanceStudentSource()
          .filter((student) =>
            [
              student?.profile?.currentGrade,
              student?.profile?.classLevel,
              student?.profile?.level,
              student?.currentGrade,
              student?.classLevel,
              student?.level,
              student?.className,
            ].some((value) => levelNamesMatch(value || "", selectedLevel)),
          )
          .sort((left, right) =>
            studentDisplayName(left, { preferEnglish: true }).localeCompare(
              studentDisplayName(right, { preferEnglish: true }),
            ),
          );
      }

      function parseTardyMinutesFromAttendanceComment(value) {
        const text = normalizeLower(value);
        if (!text) return 0;
        const minuteMatch = text.match(
          /(\d{1,3})\s*\+?\s*(?:m|min|mins|minute|minutes)\b/,
        );
        if (minuteMatch && minuteMatch[1])
          return Number.parseInt(minuteMatch[1], 10) || 0;
        const numericMatch = text.match(/\b(\d{1,3})\b/);
        if (numericMatch && numericMatch[1])
          return Number.parseInt(numericMatch[1], 10) || 0;
        return 0;
      }

      function attendanceChoiceFromRecord(record) {
        const status = normalizeLower(record?.status);
        if (status === "absent") return "absent";
        if (status === "late") {
          const minutes = parseTardyMinutesFromAttendanceComment(
            record?.comments || "",
          );
          return minutes >= 30 ? "tardy30" : "tardy10";
        }
        return "present";
      }

      function attendanceChoiceToRecord(choice) {
        if (choice === "absent") return { status: "absent", comments: "" };
        if (choice === "tardy30") return { status: "late", comments: "tardy 30m" };
        if (choice === "tardy10") return { status: "late", comments: "tardy 10m" };
        return { status: "present", comments: "" };
      }

      function attendanceRecordForDate(records, dateIso) {
        const target = normalizeText(dateIso);
        if (!target) return null;
        const source = Array.isArray(records) ? records : [];
        for (let i = 0; i < source.length; i += 1) {
          const rowDate = normalizeText(source[i]?.attendanceDate).slice(0, 10);
          if (rowDate === target) return source[i];
        }
        return null;
      }

      function attendanceStatsFromRecords(records = []) {
        const totals = (Array.isArray(records) ? records : []).reduce(
          (totals, row) => {
            const status = normalizeLower(row?.status);
            if (status === "absent") {
              totals.absent += 1;
              return totals;
            }
            if (status === "late") {
              const minutes = parseTardyMinutesFromAttendanceComment(
                row?.comments || "",
              );
              totals.present += 1;
              if (minutes >= 30) totals.tardy30 += 1;
              else totals.tardy10 += 1;
              return totals;
            }
            if (status === "present") totals.present += 1;
            return totals;
          },
          { present: 0, absent: 0, tardy10: 0, tardy30: 0 },
        );
        const totalTardy = totals.tardy10 + totals.tardy30;
        const totalTracked = totals.present + totals.absent;
        return {
          ...totals,
          totalTardy,
          totalTracked,
          presentPercent: totalTracked > 0 ? (totals.present / totalTracked) * 100 : 0,
          tardyPercent: totalTracked > 0 ? (totalTardy / totalTracked) * 100 : 0,
        };
      }

      function updateAttendanceQuarterWarning() {
        const warningEl = document.getElementById("attendanceQuarterWarning");
        if (!warningEl) return;
        const dateValue = normalizeText(document.getElementById("a_date")?.value).slice(0, 10);
        const formQuarter = normalizeLower(document.getElementById("a_quarter")?.value);
        const expectedQuarter = normalizeLower(quarterFromIsoDate(dateValue));
        const mismatch = Boolean(expectedQuarter && formQuarter && expectedQuarter !== formQuarter);
        warningEl.classList.toggle("hidden", !mismatch);
        warningEl.textContent = mismatch ?
          `Warning: ${dateValue} is in ${expectedQuarter}, but this form is set to ${formQuarter}.` : "";
        warningEl.style.color = mismatch ? "#bd2f2f" : "";
      }

      function ensureAttendanceLandingFormDefaults() {
        const stored = loadAttendanceFormContextFromStorage();
        const dateEl = document.getElementById("a_date");
        const yearEl = document.getElementById("a_schoolYear");
        const quarterEl = document.getElementById("a_quarter");
        if (!normalizeText(state.attendanceLanding?.selectedLevel) && stored.selectedLevel) {
          state.attendanceLanding.selectedLevel = resolveSystemLevelName(stored.selectedLevel);
        }
        if (dateEl) dateEl.value = attendanceTodayIsoDate();
        const classDate = normalizeText(
          dateEl?.value || attendanceTodayIsoDate(),
        ).slice(0, 10);
        if (yearEl) yearEl.value = defaultAttendanceSchoolYear(classDate);
        if (quarterEl) quarterEl.value = quarterFromIsoDate(classDate);
        updateAttendanceQuarterWarning();
        persistAttendanceFormContext();
      }

      function setAttendanceSaveResult(message = "", isError = false) {
        const resultEl = document.getElementById("attendanceSaveResult");
        if (!resultEl) return;
        resultEl.style.color = isError ? "#bd2f2f" : "";
        resultEl.textContent = normalizeText(message);
      }

      function setAttendanceSaveBusy(isBusy, processed = 0, total = 0) {
        state.attendanceLanding.saveBusy = Boolean(isBusy);
        const button = document.getElementById("attendanceLandingSaveAllBtn");
        if (!button) return;
        button.disabled = Boolean(isBusy);
        button.setAttribute("aria-busy", String(Boolean(isBusy)));
        button.textContent = isBusy ? `Saving ${processed}/${total}...` : "Save All";
      }

      function syncAttendanceLevelEditorInputs() {
        const selectedLevel = selectedAttendanceLevelStyleLevel();
        const titleEl = document.getElementById("attendanceLevelTitle");
        const colorEl = document.getElementById("attendanceLevelColor");
        const imageEl = document.getElementById("attendanceLevelImage");
        if (!titleEl || !colorEl) return;
        state.levelTileStyleEditor.selectedLevel = selectedLevel;
        if (!selectedLevel) {
          titleEl.value = "";
          colorEl.value = "#002786";
          if (imageEl) imageEl.value = "";
          setAttendanceLevelStyleStatus("Select a level to edit global tile style.");
          return;
        }
        const config = attendanceLevelTileConfig(selectedLevel);
        titleEl.value = config.title;
        colorEl.value = config.bgColor;
        if (imageEl) imageEl.value = "";
        setAttendanceLevelStyleStatus(
          `Editing tile style: ${fullLevelLabel(selectedLevel)}.`,
        );
      }

      function renderAttendanceLevelTiles() {
        if (!hasLiveDom()) return;
        const tileTargets = [
          {
            tilesEl: document.getElementById("attendanceLevelTiles"),
            hintEl: document.getElementById("attendanceLevelPanelHint"),
          },
          {
            tilesEl: document.getElementById("attendanceAdminLevelTiles"),
            hintEl: document.getElementById("attendanceAdminLevelPanelHint"),
          },
        ].filter((entry) => Boolean(entry.tilesEl));
        if (!tileTargets.length) return;

        const levels = collectAttendanceLevelNames();
        if (!levels.length) {
          populateAttendanceLevelStyleOptions([]);
          syncAttendanceLevelEditorInputs();
          tileTargets.forEach(({ tilesEl, hintEl }) => {
            tilesEl.innerHTML = "";
            if (hintEl) hintEl.textContent = "No levels found.";
          });
          return;
        }
        populateAttendanceLevelStyleOptions(levels);
        const selectedLevel = resolveSystemLevelName(
          state.attendanceLanding?.selectedLevel || "",
        );
        const hasSelected =
          Boolean(selectedLevel) &&
          levels.some((level) => levelNamesMatch(level, selectedLevel));
        state.attendanceLanding.selectedLevel = hasSelected ? selectedLevel : "";

        tileTargets.forEach(({ tilesEl, hintEl }) => {
          tilesEl.innerHTML = "";
          levels.forEach((level) => {
            const canonicalLevel = resolveSystemLevelName(level);
            const config = attendanceLevelTileConfig(canonicalLevel);
            const theme = getLevelTheme(canonicalLevel);
            const tile = document.createElement("button");
            tile.type = "button";
            tile.className = "attendance-level-tile";
            if (levelNamesMatch(canonicalLevel, state.attendanceLanding.selectedLevel))
              tile.classList.add("active");
            tile.setAttribute("data-level", canonicalLevel);
            tile.setAttribute("aria-label", fullLevelLabel(canonicalLevel));
            tile.style.backgroundColor = config.bgColor;
            tile.style.color = theme.textColor;
            tile.style.borderColor = theme.borderColor;
            tile.style.setProperty("--attendance-level-title-color", theme.textColor);
            tile.style.setProperty("--attendance-level-title-bg", tileTitleBackground(theme));
            if (config.imageDataUrl) {
              const safeUrl = config.imageDataUrl.replace(/"/g, "%22");
              tile.style.backgroundImage = `url("${safeUrl}")`;
            } else {
              tile.style.backgroundImage = "none";
            }
            const safeTitle = normalizeText(config.title);
            tile.innerHTML =
              safeTitle ?
                `<span class="attendance-level-tile-title">${escapeHtml(safeTitle)}</span>`
              : "";
            tile.addEventListener("click", () => {
              if (
                levelNamesMatch(state.attendanceLanding.selectedLevel, canonicalLevel)
              )
                return;
              state.attendanceLanding.selectedLevel = canonicalLevel;
              state.attendanceLanding.selectionsByStudentId = {};
              persistAttendanceFormContext();
              renderAttendanceLevelTiles();
              refreshAttendanceLanding({ reloadRows: true }).catch(handleError);
            });
            tilesEl.appendChild(tile);
          });

          if (hintEl)
            hintEl.textContent = `Loaded ${levels.length} levels. Select one to begin.`;
        });
        syncAttendanceLevelEditorInputs();
      }

      function renderAttendanceLandingSummary(
        students = selectedAttendanceLevelStudents(),
      ) {
        if (!hasLiveDom()) return;
        const summaryEl = document.getElementById("attendanceLandingSummary");
        if (!summaryEl) return;
        const selectedLevel = resolveSystemLevelName(
          state.attendanceLanding?.selectedLevel || "",
        );
        if (!selectedLevel) {
          summaryEl.textContent = "Select a class level and set statuses.";
          return;
        }

        const totals = students.reduce(
          (acc, student) => {
            const choice =
              state.attendanceLanding.selectionsByStudentId[student.id] || "absent";
            if (choice === "absent") acc.absent += 1;
            else if (choice === "tardy10") {
              acc.tardy10 += 1;
              acc.present += 1;
            } else if (choice === "tardy30") {
              acc.tardy30 += 1;
              acc.present += 1;
            } else acc.present += 1;
            return acc;
          },
          { present: 0, absent: 0, tardy10: 0, tardy30: 0 },
        );
        const readOnlySuffix = canWriteData() ? "" : " | read-only for current role";
        const totalTracked = totals.present + totals.absent;
        const totalTardy = totals.tardy10 + totals.tardy30;
        const presentPercentText = formatPercent(
          totalTracked > 0 ? (totals.present / totalTracked) * 100 : 0,
        );
        const tardyPercentText = formatPercent(
          totalTracked > 0 ? (totalTardy / totalTracked) * 100 : 0,
        );
        summaryEl.classList.toggle("attendance-state-readonly", !canWriteData());
        summaryEl.textContent = `${fullLevelLabel(selectedLevel)} | students=${students.length} | present=${totals.present} (${presentPercentText}) | absent=${totals.absent} | tardy10=${totals.tardy10} | tardy30=${totals.tardy30} | totalTardy=${totalTardy} (${tardyPercentText})${readOnlySuffix}`;
      }

      async function hydrateAttendanceLandingDetails(students = []) {
        const source = Array.isArray(students) ? students : [];
        const missing = source.filter(
          (student) =>
            student?.id &&
            !state.attendanceLanding.studentDetailsByStudentId[student.id],
        );
        if (!missing.length) return;

        await Promise.all(
          missing.map(async (student) => {
            try {
              const detail = await api(`/api/admin/students/${encodeURIComponent(student.id)}`);
              if (detail && detail.id)
                state.attendanceLanding.studentDetailsByStudentId[student.id] = detail;
              else
                state.attendanceLanding.studentDetailsByStudentId[student.id] = {
                  ...student,
                  attendanceRecords: [],
                };
            } catch (error) {
              state.attendanceLanding.studentDetailsByStudentId[student.id] = {
                ...student,
                attendanceRecords: [],
              };
              void error;
            }
          }),
        );
      }

      function renderAttendanceLandingRows(
        students = selectedAttendanceLevelStudents(),
      ) {
        if (!hasLiveDom()) return;
        const rowsEl = document.getElementById("attendanceLandingRows");
        const labelEl = document.getElementById("attendanceSelectedLevelLabel");
        if (!rowsEl) return;
        const selectedLevel = resolveSystemLevelName(
          state.attendanceLanding?.selectedLevel || "",
        );

        if (labelEl) {
          labelEl.textContent =
            selectedLevel ?
              `Attendance Input: ${fullLevelLabel(selectedLevel)}`
            : "Attendance Input";
        }
        if (!students.length) {
          rowsEl.innerHTML =
            '<tr><td colspan="2">No students in this class level.</td></tr>';
          renderAttendanceLandingSummary([]);
          return;
        }

        const canWrite = canWriteData();
        rowsEl.innerHTML = "";
        students.forEach((student) => {
          const selectedChoice =
            state.attendanceLanding.selectionsByStudentId[student.id] || "absent";
          const safeStudentId = escapeHtml(student.id || "");
          const groupName = `att-status-${safeStudentId}`;

          const tr = document.createElement("tr");
          tr.innerHTML = `
          <td>
            <div class="attendance-row-name">${escapeHtml(studentDisplayName(student, { preferEnglish: true }))}</div>
            <div class="attendance-row-id">${escapeHtml(student?.eaglesId || "")}</div>
          </td>
          <td>
            <div class="attendance-radio-group">
              ${ATTENDANCE_STATUS_CHOICES.map((choice) => {
                const checked = choice === selectedChoice ? "checked" : "";
                const disabled = canWrite ? "" : "disabled";
                const label =
                  choice === "absent" ? "Absent"
                  : choice === "present" ? "Present"
                  : choice === "tardy10" ? "Tardy10"
                  : "Tardy30";
                return `<label class="attendance-radio-option"><input type="radio" name="${groupName}" value="${choice}" data-student-id="${safeStudentId}" ${checked} ${disabled}>${label}</label>`;
              }).join("")}
            </div>
          </td>
        `;

          tr.querySelectorAll(`input[name="${groupName}"]`).forEach((inputEl) => {
            inputEl.addEventListener("change", () => {
              const choice = normalizeLower(inputEl.value);
              if (!ATTENDANCE_STATUS_CHOICES.includes(choice)) return;
              state.attendanceLanding.selectionsByStudentId[student.id] = choice;
              renderAttendanceLandingSummary(students);
            });
          });
          rowsEl.appendChild(tr);
        });

        renderAttendanceLandingSummary(students);
      }

      function renderAttendanceAdminRiskSignals() {
        if (!hasLiveDom()) return;
        const summaryEl = document.getElementById("attendanceAdminRiskSummary");
        const rowsEl = document.getElementById("attendanceAdminRiskStudents");
        if (!summaryEl && !rowsEl) return;

        const selectedLevel = resolveSystemLevelName(
          state.attendanceLanding?.selectedLevel || "",
        );
        if (!selectedLevel) {
          if (summaryEl)
            summaryEl.textContent =
              "Select a class level to view attendance risk signals.";
          if (rowsEl)
            rowsEl.textContent =
              "Select a class level to view attendance risk signals.";
          return;
        }

        const allRiskRows =
          Array.isArray(state.dashboardSummary?.attendanceRiskWeek?.students) ?
            state.dashboardSummary.attendanceRiskWeek.students
          : [];
        const levelRiskRows = allRiskRows.filter((row) =>
          levelNamesMatch(row?.level || "", selectedLevel),
        );
        if (summaryEl) {
          summaryEl.textContent = `${fullLevelLabel(selectedLevel)} | attendanceRisk=${levelRiskRows.length} (week)`;
        }
        if (rowsEl) rowsEl.textContent = buildAttendanceRiskLines(levelRiskRows);
      }

      function renderAttendanceAdminRows(students = selectedAttendanceLevelStudents()) {
        if (!hasLiveDom()) return;
        const rowsEl = document.getElementById("attendanceAdminRows");
        const labelEl = document.getElementById("attendanceAdminSelectedLevelLabel");
        const summaryEl = document.getElementById("attendanceAdminSummary");
        if (!rowsEl) return;
        const selectedLevel = resolveSystemLevelName(
          state.attendanceLanding?.selectedLevel || "",
        );

        if (labelEl) {
          labelEl.textContent =
            selectedLevel ?
              `Per-Student Attendance Stats: ${fullLevelLabel(selectedLevel)}`
            : "Per-Student Attendance Stats";
        }
        if (!selectedLevel) {
          rowsEl.innerHTML = '<tr><td colspan="7">Select a class level.</td></tr>';
          if (summaryEl) summaryEl.textContent = "Select a class level to view stats.";
          renderAttendanceAdminRiskSignals();
          return;
        }
        if (!students.length) {
          rowsEl.innerHTML =
            '<tr><td colspan="7">No students in this class level.</td></tr>';
          if (summaryEl)
            summaryEl.textContent = `${fullLevelLabel(selectedLevel)} | students=0`;
          renderAttendanceAdminRiskSignals();
          return;
        }

        const totals = { present: 0, absent: 0, tardy10: 0, tardy30: 0 };
        rowsEl.innerHTML = "";
        students.forEach((student) => {
          const detail =
            state.attendanceLanding.studentDetailsByStudentId[student.id] || student;
          const stats = attendanceStatsFromRecords(detail?.attendanceRecords || []);
          totals.present += stats.present;
          totals.absent += stats.absent;
          totals.tardy10 += stats.tardy10;
          totals.tardy30 += stats.tardy30;
          const tr = document.createElement("tr");
          tr.innerHTML = `
          <td>
            <div class="attendance-row-name">${escapeHtml(studentDisplayName(student, { preferEnglish: true }))}</div>
            <div class="attendance-row-id">${escapeHtml(student?.eaglesId || "")}</div>
          </td>
          <td class="attendance-cell-num">${stats.present}</td>
          <td class="attendance-cell-num">${stats.absent}</td>
          <td class="attendance-cell-num">${stats.tardy10}</td>
          <td class="attendance-cell-num">${stats.tardy30}</td>
          <td class="attendance-cell-num">${formatPercent(stats.presentPercent)}</td>
          <td class="attendance-cell-num">${formatPercent(stats.tardyPercent)}</td>
        `;
          rowsEl.appendChild(tr);
        });

        if (summaryEl) {
          const totalTracked = totals.present + totals.absent;
          const totalTardy = totals.tardy10 + totals.tardy30;
          const presentPercentText = formatPercent(
            totalTracked > 0 ? (totals.present / totalTracked) * 100 : 0,
          );
          const tardyPercentText = formatPercent(
            totalTracked > 0 ? (totalTardy / totalTracked) * 100 : 0,
          );
          summaryEl.textContent = `${fullLevelLabel(selectedLevel)} | students=${students.length} | present=${totals.present} (${presentPercentText}) | absent=${totals.absent} | tardy10=${totals.tardy10} | tardy30=${totals.tardy30} | totalTardy=${totalTardy} (${tardyPercentText})`;
        }
        renderAttendanceAdminRiskSignals();
      }

      async function refreshAttendanceLandingRows({ hydrate = false } = {}) {
        if (!hasLiveDom()) return;
        const rowsEl = document.getElementById("attendanceLandingRows");
        const classEl = document.getElementById("a_className");
        const dateValue = normalizeText(document.getElementById("a_date")?.value);
        const selectedLevel = resolveSystemLevelName(
          state.attendanceLanding?.selectedLevel || "",
        );
        const students = selectedAttendanceLevelStudents();

        if (classEl && selectedLevel) classEl.value = fullLevelLabel(selectedLevel);
        if (!rowsEl) return;
        if (!selectedLevel) {
          rowsEl.innerHTML = '<tr><td colspan="2">Select a class level.</td></tr>';
          renderAttendanceLandingSummary([]);
          renderAttendanceAdminRows([]);
          return;
        }
        // A fresh page has no detail cache.  Load it before deriving the radio
        // selections: rendering defaults first made saved attendance look blank
        // after a reload, because the later fetch only re-rendered those defaults.
        if (hydrate) await hydrateAttendanceLandingDetails(students);
        students.forEach((student) => {
          if (state.attendanceLanding.selectionsByStudentId[student.id]) return;
          if (!dateValue) {
            state.attendanceLanding.selectionsByStudentId[student.id] = "absent";
            return;
          }
          const detail =
            state.attendanceLanding.studentDetailsByStudentId[student.id] || student;
          const dayRecord = attendanceRecordForDate(
            detail?.attendanceRecords || [],
            dateValue,
          );
          state.attendanceLanding.selectionsByStudentId[student.id] =
            dayRecord ? attendanceChoiceFromRecord(dayRecord) : "absent";
        });
        renderAttendanceLandingRows(students);
        renderAttendanceAdminRows(students);
      }

      async function refreshAttendanceLanding({ reloadRows = false } = {}) {
        if (!hasLiveDom()) return;
        renderAttendanceLevelTiles();
        if (
          state.activePage !== "attendance" &&
          state.activePage !== "attendance-admin" &&
          !reloadRows
        )
          return;
        await refreshAttendanceLandingRows({ hydrate: Boolean(reloadRows) });
      }

      async function refreshDashboardSummaryAfterAttendanceChange() {
        if (!state.authUser) return;
        try {
          await loadDashboardSummary();
        } catch (error) {
          void error;
        }
      }

      async function saveAttendanceLandingForSelectedLevel() {
        if (state.attendanceLanding.saveBusy) return;
        if (!canWriteData())
          throw new Error("Attendance updates are read-only for this role.");
        const selectedLevel = resolveSystemLevelName(
          state.attendanceLanding?.selectedLevel || "",
        );
        if (!selectedLevel) throw new Error("Select a class level first.");

        const payload = attendancePayload();
        if (!payload.className) throw new Error("Class is required.");
        if (!payload.schoolYear) throw new Error("School year is required.");
        if (!payload.quarter) throw new Error("Quarter is required.");
        if (!payload.attendanceDate) throw new Error("Date is required.");

        const students = selectedAttendanceLevelStudents();
        if (!students.length)
          throw new Error("No students found for this class level.");
        await hydrateAttendanceLandingDetails(students);

        let saved = 0;
        let corrected = 0;
        let unchanged = 0;
        const total = students.length;
        const scopeLabel = `${fullLevelLabel(selectedLevel)}, ${formatDate(payload.attendanceDate)}`;
        setAttendanceSaveResult(`Saving 0/${total} for ${scopeLabel}...`);
        setAttendanceSaveBusy(true, 0, total);
        try {
          for (let i = 0; i < students.length; i += 1) {
            const student = students[i];
            const choice =
              state.attendanceLanding.selectionsByStudentId[student.id] || "absent";
            const mapped = attendanceChoiceToRecord(choice);
            const detail =
              state.attendanceLanding.studentDetailsByStudentId[student.id] || student;
            const existing = attendanceRecordForDate(
              detail?.attendanceRecords || [],
              payload.attendanceDate,
            );
            const previousChoice = existing ? attendanceChoiceFromRecord(existing) : "";
            const sameClass =
              normalizeLower(existing?.className || "") ===
              normalizeLower(payload.className || "");
            const sameQuarter =
              normalizeLower(existing?.quarter || "") ===
              normalizeLower(payload.quarter || "");
            const sameYear =
              normalizeLower(existing?.schoolYear || "") ===
              normalizeLower(payload.schoolYear || "");
            if (
              existing &&
              previousChoice === choice &&
              sameClass &&
              sameQuarter &&
              sameYear
            ) {
              unchanged += 1;
              setAttendanceSaveBusy(true, i + 1, total);
              continue;
            }

            let result;
            try {
              result = await api(
                `/api/admin/students/${encodeURIComponent(student.id)}/attendance`,
                {
                  method: "POST",
                  body: {
                    id: existing?.id || "",
                    className: payload.className,
                    schoolYear: payload.schoolYear,
                    quarter: payload.quarter,
                    attendanceDate: payload.attendanceDate,
                    status: mapped.status,
                    comments: mapped.comments,
                    level: selectedLevel,
                  },
                },
              );
            } catch (error) {
              const studentLabel = studentDisplayName(student, { preferEnglish: true }) || normalizeText(student?.eaglesId) || "this student";
              const message = `Attendance could not be saved for ${studentLabel} — ${scopeLabel}. ${error?.message || String(error)}`;
              setAttendanceSaveResult(message, true);
              throw new Error(message);
            }
            if (result?.student?.id) {
              state.attendanceLanding.studentDetailsByStudentId[student.id] =
                result.student;
              if (state.currentStudent?.id === result.student.id) {
                state.currentStudent = result.student;
                fillStudentForm(state.currentStudent);
              }
            }
            if (existing) corrected += 1;
            else saved += 1;
            setAttendanceSaveBusy(true, i + 1, total);
          }

          await refreshAttendanceLandingRows({ hydrate: false });
          await refreshDashboardSummaryAfterAttendanceChange();
          persistAttendanceFormContext();
          const summary = saved || corrected ?
            `Saved ${saved}; corrected ${corrected}; unchanged ${unchanged} — ${scopeLabel}.` :
            `No changes — all ${unchanged} records already match — ${scopeLabel}.`;
          setAttendanceSaveResult(summary);
          setStatus(summary);
        } finally {
          setAttendanceSaveBusy(false);
        }
      }

      async function applyAttendanceLevelTileStyle() {
        const selectedLevel = selectedAttendanceLevelStyleLevel();
        if (!selectedLevel) throw new Error("Select a class level first.");
        const levelKeys = levelTileStyleKeys(selectedLevel);
        const levelKey = levelKeys[0];
        if (!levelKey)
          throw new Error("Could not resolve a style key for this class level.");
        const current = attendanceLevelTileConfig(selectedLevel);
        const titleValue = normalizeText(
          document.getElementById("attendanceLevelTitle")?.value,
        );
        const colorInput = normalizeText(
          document.getElementById("attendanceLevelColor")?.value,
        );
        const bgColor = parseHexRgb(colorInput) ? colorInput : current.bgColor;
        const pendingImageDataUrl = normalizeText(state.levelTileStyleEditor?.pendingImageDataUrl);
        let assetKey = current.assetKey;
        let imageDataUrl = current.assetKey ? "" : current.imageDataUrl;
        if (pendingImageDataUrl) {
          assetKey = `class-level-${levelNameKey(selectedLevel)}`;
          await saveAttendanceTileAsset(assetKey, pendingImageDataUrl, selectedLevel);
          imageDataUrl = "";
        }
        const nextConfig = { ...(state.attendanceLanding.tileConfigByLevel || {}) };
        levelKeys.forEach((key) => {
          delete nextConfig[key];
        });
        nextConfig[levelKey] = {
          title: titleValue,
          bgColor,
          assetKey,
          imageDataUrl,
        };
        await persistAttendanceLevelTileConfig(nextConfig);
        state.levelTileStyleEditor.pendingImageDataUrl = "";
        const imageInput = document.getElementById("attendanceLevelImage");
        if (imageInput) imageInput.value = "";
        renderAllClassLevelTiles();
        setAttendanceLevelStyleStatus(
          `Updated global tile style: ${fullLevelLabel(selectedLevel)}.`,
        );
        setStatus(
          `Global class-level tile style updated: ${fullLevelLabel(selectedLevel)}.`,
        );
      }

      async function clearAttendanceLevelTileImage() {
        const selectedLevel = selectedAttendanceLevelStyleLevel();
        if (!selectedLevel) throw new Error("Select a class level first.");
        const levelKeys = levelTileStyleKeys(selectedLevel);
        const levelKey = levelKeys[0];
        if (!levelKey)
          throw new Error("Could not resolve a style key for this class level.");
        const current = attendanceLevelTileConfig(selectedLevel);
        const nextConfig = { ...(state.attendanceLanding.tileConfigByLevel || {}) };
        levelKeys.forEach((key) => {
          delete nextConfig[key];
        });
        nextConfig[levelKey] = {
          title: current.title,
          bgColor: current.bgColor,
          assetKey: "",
          imageDataUrl: "",
        };
        await persistAttendanceLevelTileConfig(nextConfig);
        state.levelTileStyleEditor.pendingImageDataUrl = "";
        const imageInput = document.getElementById("attendanceLevelImage");
        if (imageInput) imageInput.value = "";
        renderAllClassLevelTiles();
        setAttendanceLevelStyleStatus(
          `Removed image: ${fullLevelLabel(selectedLevel)}.`,
        );
        setStatus(
          `Global class-level tile image removed: ${fullLevelLabel(selectedLevel)}.`,
        );
      }

      async function resetAttendanceLevelTileStyle() {
        const selectedLevel = selectedAttendanceLevelStyleLevel();
        if (!selectedLevel) throw new Error("Select a class level first.");
        const levelKeys = levelTileStyleKeys(selectedLevel);
        const nextConfig = { ...(state.attendanceLanding.tileConfigByLevel || {}) };
        levelKeys.forEach((key) => {
          delete nextConfig[key];
        });
        await persistAttendanceLevelTileConfig(nextConfig);
        state.levelTileStyleEditor.pendingImageDataUrl = "";
        const imageInput = document.getElementById("attendanceLevelImage");
        if (imageInput) imageInput.value = "";
        renderAllClassLevelTiles();
        setAttendanceLevelStyleStatus(
          `Reset global tile style: ${fullLevelLabel(selectedLevel)}.`,
        );
        setStatus(
          `Global class-level tile style reset: ${fullLevelLabel(selectedLevel)}.`,
        );
      }

      function handleAttendanceLevelImageUpload(event) {
        const inputEl = event?.target;
        if (!(inputEl instanceof HTMLInputElement)) return;
        const file = inputEl.files && inputEl.files[0];
        if (!file) {
          state.levelTileStyleEditor.pendingImageDataUrl = "";
          return;
        }
        const fileName = normalizeLower(file.name);
        const mime = normalizeLower(file.type);
        const allowedMime = ["image/png", "image/jpeg", "image/webp", "image/svg+xml"];
        const allowedExt = [".png", ".jpg", ".jpeg", ".webp", ".svg"];
        const isAllowedType =
          allowedMime.includes(mime) ||
          allowedExt.some((ext) => fileName.endsWith(ext));
        if (!isAllowedType) {
          inputEl.value = "";
          state.levelTileStyleEditor.pendingImageDataUrl = "";
          throw new Error("Only PNG, JPG, WEBP, or SVG images are supported.");
        }

        const reader = new FileReader();
        reader.onload = () => {
          state.levelTileStyleEditor.pendingImageDataUrl = normalizeText(reader.result);
          const selectedLevel = selectedAttendanceLevelStyleLevel();
          setAttendanceLevelStyleStatus(
            selectedLevel ?
              `Image ready for ${fullLevelLabel(selectedLevel)}. Click Apply Global Style.`
            : "Image loaded. Select a level and click Apply Global Style.",
          );
          setStatus("Global tile image loaded. Click Apply Global Style to save.");
        };
        reader.onerror = () => {
          state.levelTileStyleEditor.pendingImageDataUrl = "";
          inputEl.value = "";
          setStatus("Unable to read image file.", true);
        };
        reader.readAsDataURL(file);
      }

      function clearAttendanceForm() {
        document.getElementById("a_id").value = "";
        document.getElementById("a_className").value = "";
        document.getElementById("a_date").value = attendanceTodayIsoDate();
        syncAttendanceDateDerivedFields();
        ensureAttendanceLandingFormDefaults();
        document.getElementById("a_status").value = "absent";
        document.getElementById("a_comments").value = "";
        state.attendanceLanding.selectionsByStudentId = {};
        renderAttendanceLandingSummary(selectedAttendanceLevelStudents());
        renderAttendanceLandingRows(selectedAttendanceLevelStudents());
        renderAttendanceAdminRows(selectedAttendanceLevelStudents());
        persistAttendanceFormContext();
      }

      async function saveAttendance() {
        const id = selectedStudentId();
        if (!id) throw new Error("Select a student first");
        const payload = attendancePayload();
        const result = await api(
          `/api/admin/students/${encodeURIComponent(id)}/attendance`,
          {
            method: "POST",
            body: payload,
          },
        );
        state.currentStudent = result.student;
        fillStudentForm(state.currentStudent);
        document.getElementById("a_id").value = "";
        await refreshDashboardSummaryAfterAttendanceChange();
        setStatus("Attendance record saved.");
      }

      async function deleteAttendance(recordId) {
        const id = selectedStudentId();
        const result = await api(
          `/api/admin/students/${encodeURIComponent(id)}/attendance/${encodeURIComponent(recordId)}`,
          {
            method: "DELETE",
          },
        );
        setTableRecordArchived("attendance", recordId, false);
        state.currentStudent = result.student;
        fillStudentForm(state.currentStudent);
        await refreshDashboardSummaryAfterAttendanceChange();
        setStatus("Attendance record deleted.");
      }

      function renderAttendanceRows(rows) {
        const tbody = document.getElementById("attendanceRows");
        tbody.innerHTML = "";
        state.tableRows.attendance = Array.isArray(rows) ? [...rows] : [];
        const sortedRows = sortedAttendanceRows(state.tableRows.attendance);
        const filteredRows = filterRowsForTable(
          "attendance",
          sortedRows,
          attendanceRowSearchText,
        );
        state.visibleTableRows.attendance = filteredRows;
        updateTableFilterSummary("attendance");
        filteredRows.forEach((row) => {
          const archived = isTableRecordArchived("attendance", row.id);
          const studentNumberText =
            row?.studentNumber === null || row?.studentNumber === undefined ?
              ""
            : escapeHtml(String(row.studentNumber));
          const tr = document.createElement("tr");
          tr.innerHTML = `
          <td class="attendance-col-student-number" data-attendance-col="studentNumber">${studentNumberText}</td>
          <td data-attendance-col="eaglesId">${escapeHtml(row.eaglesId || "")}</td>
          <td data-attendance-col="fullName">${escapeHtml(row.fullName || "")}</td>
          <td data-attendance-col="englishName">${escapeHtml(row.englishName || "")}</td>
          <td data-attendance-col="attendanceDate">${escapeHtml(formatDate(row.attendanceDate))}</td>
          <td data-attendance-col="weekNumber">${rowWeekNumber("attendance", row) ? `Week ${rowWeekNumber("attendance", row)}` : "-"}</td>
          <td data-attendance-col="className">${row.className || ""}</td>
          <td data-attendance-col="quarter">${row.quarter || ""}</td>
          <td data-attendance-col="status">${row.status || ""}</td>
          <td data-attendance-col="comments">${row.comments || ""}</td>
          <td class="table-row-options-cell">
            <details class="row-options-menu">
              <summary class="row-options-trigger portal-button portal-button-primary portal-button-compact tbm01">Actions</summary>
              <div class="row-options-dropdown">
                <button type="button" class="portal-button portal-button-affirm portal-button-compact" data-edit="${row.id}">Edit</button>
                <button type="button" class="portal-button portal-button-info portal-button-compact" data-archive="${row.id}">${archived ? "Restore" : "Archive"}</button>
                <button type="button" class="portal-button portal-button-danger portal-button-compact" data-del="${row.id}">Delete</button>
              </div>
            </details>
          </td>
        `;
          tr.querySelector(`[data-edit="${row.id}"]`).addEventListener("click", () => {
            document.getElementById("a_id").value = row.id;
            document.getElementById("a_className").value = row.className || "";
            document.getElementById("a_schoolYear").value = row.schoolYear || "";
            document.getElementById("a_quarter").value = row.quarter || "";
            document.getElementById("a_date").value =
              row.attendanceDate ? String(row.attendanceDate).slice(0, 10) : "";
            document.getElementById("a_status").value = row.status || "present";
            document.getElementById("a_comments").value = row.comments || "";
            setActivePage("attendance");
          });
          tr.querySelector(`[data-archive="${row.id}"]`).addEventListener(
            "click",
            () => {
              const nextArchived = !isTableRecordArchived("attendance", row.id);
              setTableRecordArchived("attendance", row.id, nextArchived);
              renderAttendanceRows(state.tableRows.attendance);
              setStatus(
                nextArchived ?
                  "Attendance record archived."
                : "Attendance record restored.",
              );
            },
          );
          tr.querySelector(`[data-del="${row.id}"]`).addEventListener("click", () =>
            deleteAttendance(row.id).catch(handleError),
          );
          tbody.appendChild(tr);
        });
        if (!filteredRows.length) {
          tbody.innerHTML =
            '<tr><td colspan="11">No attendance rows match current search/archive filters.</td></tr>';
        }
        applyAttendanceColumnVisibility();
      }

      function gradePayload() {
        return {
          id: normalizeText(document.getElementById("g_id").value),
          className: normalizeText(document.getElementById("g_className").value),
          schoolYear: normalizeText(document.getElementById("g_schoolYear").value),
          quarter: normalizeText(document.getElementById("g_quarter").value),
          assignmentName: normalizeText(
            document.getElementById("g_assignmentName").value,
          ),
          dueAt: normalizeText(document.getElementById("g_dueAt").value),
          submittedAt: normalizeText(document.getElementById("g_submittedAt").value),
          score: normalizeText(document.getElementById("g_score").value),
          maxScore: normalizeText(document.getElementById("g_maxScore").value),
          homeworkCompleted: toBoolOrNull(
            document.getElementById("g_homeworkCompleted").value,
          ),
          homeworkOnTime: toBoolOrNull(
            document.getElementById("g_homeworkOnTime").value,
          ),
          behaviorScore: normalizeText(
            document.getElementById("g_behaviorScore").value,
          ),
          participationScore: normalizeText(
            document.getElementById("g_participationScore").value,
          ),
          inClassScore: normalizeText(document.getElementById("g_inClassScore").value),
          comments: normalizeText(document.getElementById("g_comments").value),
          level: resolveSystemLevelName(getFormValue("currentGrade")),
        };
      }

      function currentAdminSchoolYear() {
        return normalizeText(gradeChartCurrentSchoolYear());
      }

      function applyDefaultGradeAndReportSchoolYears(force = false) {
        const currentSchoolYear = currentAdminSchoolYear();
        if (!currentSchoolYear) return;
        const gradeYearEl = document.getElementById("g_schoolYear");
        const reportYearEl = document.getElementById("r_schoolYear");
        if (
          gradeYearEl instanceof HTMLInputElement &&
          (force || !normalizeText(gradeYearEl.value))
        ) {
          gradeYearEl.value = currentSchoolYear;
        }
        if (
          reportYearEl instanceof HTMLInputElement &&
          (force || !normalizeText(reportYearEl.value))
        ) {
          reportYearEl.value = currentSchoolYear;
        }
      }

      function clearGradeForm() {
        document.getElementById("g_id").value = "";
        document.getElementById("g_className").value = "";
        applyDefaultGradeAndReportSchoolYears(true);
        document.getElementById("g_quarter").value = currentQuarterFromToday();
        document.getElementById("g_assignmentName").value = "";
        document.getElementById("g_dueAt").value = "";
        document.getElementById("g_submittedAt").value = "";
        document.getElementById("g_score").value = "";
        document.getElementById("g_maxScore").value = "";
        document.getElementById("g_homeworkCompleted").value = "";
        document.getElementById("g_homeworkOnTime").value = "";
        document.getElementById("g_behaviorScore").value = "";
        document.getElementById("g_participationScore").value = "";
        document.getElementById("g_inClassScore").value = "";
        document.getElementById("g_comments").value = "";
      }

      async function saveGrade() {
        const id = selectedStudentId();
        if (!id) throw new Error("Select a student first");
        const result = await api(
          `/api/admin/students/${encodeURIComponent(id)}/grades`,
          {
            method: "POST",
            body: gradePayload(),
          },
        );
        state.currentStudent = result.student;
        fillStudentForm(state.currentStudent);
        document.getElementById("g_id").value = normalizeText(result.record?.id);
        setStatus("Grade record saved.");
      }

      async function deleteGrade(recordId) {
        const id = selectedStudentId();
        const result = await api(
          `/api/admin/students/${encodeURIComponent(id)}/grades/${encodeURIComponent(recordId)}`,
          {
            method: "DELETE",
          },
        );
        setTableRecordArchived("grades", recordId, false);
        state.currentStudent = result.student;
        fillStudentForm(state.currentStudent);
        setStatus("Grade record deleted.");
      }

      function renderGradeRows(rows) {
        const tbody = document.getElementById("gradeRows");
        tbody.innerHTML = "";
        state.tableRows.grades = Array.isArray(rows) ? [...rows] : [];
        const sortedRows = sortedGradeRows(state.tableRows.grades);
        const filteredRows = filterRowsForTable(
          "grades",
          sortedRows,
          gradeRowSearchText,
        );
        state.visibleTableRows.grades = filteredRows;
        updateTableFilterSummary("grades");
        filteredRows.forEach((row) => {
          const archived = isTableRecordArchived("grades", row.id);
          const studentNumberText =
            row?.studentNumber === null || row?.studentNumber === undefined ?
              ""
            : escapeHtml(String(row.studentNumber));
          const tr = document.createElement("tr");
          tr.innerHTML = `
          <td class="table-col-student-number" data-grades-col="studentNumber">${studentNumberText}</td>
          <td data-grades-col="eaglesId">${escapeHtml(row.eaglesId || "")}</td>
          <td data-grades-col="fullName">${escapeHtml(row.fullName || "")}</td>
          <td data-grades-col="englishName">${escapeHtml(row.englishName || "")}</td>
          <td data-grades-col="dueAt">${escapeHtml(formatDate(row.dueAt))}</td>
          <td data-grades-col="weekNumber">${rowWeekNumber("grades", row) ? `Week ${rowWeekNumber("grades", row)}` : "-"}</td>
          <td data-grades-col="className">${row.className || ""}</td>
          <td data-grades-col="assignmentName">${row.assignmentName || ""}</td>
          <td data-grades-col="score">${row.score ?? ""}/${row.maxScore ?? ""}</td>
          <td data-grades-col="homeworkCompleted">${
            row.homeworkCompleted === true ? "Yes"
            : row.homeworkCompleted === false ? "No"
            : ""
          }</td>
          <td data-grades-col="behaviorScore">${row.behaviorScore ?? ""}</td>
          <td data-grades-col="participationScore">${row.participationScore ?? ""}</td>
          <td data-grades-col="inClassScore">${row.inClassScore ?? ""}</td>
          <td class="table-row-options-cell">
            <details class="row-options-menu">
              <summary class="row-options-trigger portal-button portal-button-primary portal-button-compact tbm01">Actions</summary>
              <div class="row-options-dropdown">
                <button type="button" class="portal-button portal-button-affirm portal-button-compact" data-edit="${row.id}">Edit</button>
                <button type="button" class="portal-button portal-button-info portal-button-compact" data-archive="${row.id}">${archived ? "Restore" : "Archive"}</button>
                <button type="button" class="portal-button portal-button-danger portal-button-compact" data-del="${row.id}">Delete</button>
              </div>
            </details>
          </td>
        `
          tr.querySelector(`[data-edit="${row.id}"]`).addEventListener("click", () => {
            document.getElementById("g_id").value = row.id;
            document.getElementById("g_className").value = row.className || "";
            document.getElementById("g_schoolYear").value =
              row.schoolYear || currentAdminSchoolYear();
            document.getElementById("g_quarter").value = row.quarter || "";
            document.getElementById("g_assignmentName").value =
              row.assignmentName || "";
            document.getElementById("g_dueAt").value =
              row.dueAt ? String(row.dueAt).slice(0, 10) : "";
            document.getElementById("g_submittedAt").value =
              row.submittedAt ? String(row.submittedAt).slice(0, 10) : "";
            document.getElementById("g_score").value = row.score ?? "";
            document.getElementById("g_maxScore").value = row.maxScore ?? "";
            document.getElementById("g_homeworkCompleted").value =
              row.homeworkCompleted === null ? "" : String(row.homeworkCompleted);
            document.getElementById("g_homeworkOnTime").value =
              row.homeworkOnTime === null ? "" : String(row.homeworkOnTime);
            document.getElementById("g_behaviorScore").value = row.behaviorScore ?? "";
            document.getElementById("g_participationScore").value =
              row.participationScore ?? "";
            document.getElementById("g_inClassScore").value = row.inClassScore ?? "";
            document.getElementById("g_comments").value = row.comments || "";
            setActivePage("grades");
          });
          tr.querySelector(`[data-archive="${row.id}"]`).addEventListener(
            "click",
            () => {
              const nextArchived = !isTableRecordArchived("grades", row.id);
              setTableRecordArchived("grades", row.id, nextArchived);
              renderGradeRows(state.tableRows.grades);
              setStatus(
                nextArchived ? "Grade record archived." : "Grade record restored.",
              );
            },
          );
          tr.querySelector(`[data-del="${row.id}"]`).addEventListener("click", () =>
            deleteGrade(row.id).catch(handleError),
          );
          tbody.appendChild(tr);
        });
        if (!filteredRows.length) {
          tbody.innerHTML =
            '<tr><td colspan="14">No grade rows match current search/archive filters.</td></tr>';
        }
        applyTableColumnVisibility("grades");
        renderGradePulseChart(filteredRows);
      }

      function reportPayload() {
        return {
          id: normalizeText(document.getElementById("r_id").value),
          className: normalizeText(document.getElementById("r_className").value),
          schoolYear: normalizeText(document.getElementById("r_schoolYear").value),
          quarter: normalizeText(document.getElementById("r_quarter").value),
          homeworkCompletionRate: normalizeText(
            document.getElementById("r_homeworkCompletionRate").value,
          ),
          homeworkOnTimeRate: normalizeText(
            document.getElementById("r_homeworkOnTimeRate").value,
          ),
          behaviorScore: normalizeText(
            document.getElementById("r_behaviorScore").value,
          ),
          participationScore: normalizeText(
            document.getElementById("r_participationScore").value,
          ),
          inClassScore: normalizeText(document.getElementById("r_inClassScore").value),
          participationPointsAward: normalizeText(
            document.getElementById("r_participationPointsAward").value,
          ),
          comments: normalizeText(document.getElementById("r_comments").value),
          level: resolveSystemLevelName(getFormValue("currentGrade")),
        };
      }

      function clearReportForm() {
        document.getElementById("r_id").value = "";
        document.getElementById("r_className").value = "";
        applyDefaultGradeAndReportSchoolYears(true);
        document.getElementById("r_quarter").value = currentQuarterFromToday();
        document.getElementById("r_homeworkCompletionRate").value = "";
        document.getElementById("r_homeworkOnTimeRate").value = "";
        document.getElementById("r_behaviorScore").value = "";
        document.getElementById("r_participationScore").value = "";
        document.getElementById("r_inClassScore").value = "";
        document.getElementById("r_participationPointsAward").value = "";
        document.getElementById("r_comments").value = "";
      }

      async function saveReport() {
        const id = selectedStudentId();
        if (!id) throw new Error("Select a student first");
        const result = await api(
          `/api/admin/students/${encodeURIComponent(id)}/reports`,
          {
            method: "POST",
            body: reportPayload(),
          },
        );
        state.currentStudent = result.student;
        fillStudentForm(state.currentStudent);
        document.getElementById("r_id").value = "";
        setStatus("Performance report saved.");
      }

      async function generateReport() {
        const id = selectedStudentId();
        if (!id) throw new Error("Select a student first");
        const result = await api(
          `/api/admin/students/${encodeURIComponent(id)}/reports/generate`,
          {
            method: "POST",
            body: reportPayload(),
          },
        );
        state.currentStudent = result.student;
        fillStudentForm(state.currentStudent);
        setStatus("Performance report generated from grade records.");
      }

      function parseFilenameFromDisposition(value) {
        const text = normalizeText(value);
        if (!text) return "";
        const utf8Match = text.match(/filename\\*=UTF-8''([^;]+)/i);
        if (utf8Match && utf8Match[1]) return decodeURIComponent(utf8Match[1]);
        const quotedMatch = text.match(/filename=\"([^\"]+)\"/i);
        if (quotedMatch && quotedMatch[1]) return quotedMatch[1];
        const plainMatch = text.match(/filename=([^;]+)/i);
        if (plainMatch && plainMatch[1]) return plainMatch[1].trim();
        return "";
      }

      async function downloadReportCard() {
        const id = selectedStudentId();
        if (!id) throw new Error("Select a student first");

        const params = new URLSearchParams();
        const className = normalizeText(document.getElementById("r_className").value);
        const schoolYear = normalizeText(document.getElementById("r_schoolYear").value);
        const quarter = normalizeText(document.getElementById("r_quarter").value);
        if (className) params.set("className", className);
        if (schoolYear) params.set("schoolYear", schoolYear);
        if (quarter) params.set("quarter", quarter);

        const endpoint = `/api/admin/students/${encodeURIComponent(id)}/report-card.pdf${params.size ? `?${params.toString()}` : ""}`;
        const response = await fetch(resolveApiUrl(endpoint), {
          credentials: "include",
        });

        if (!response.ok) {
          let message = `HTTP ${response.status}`;
          try {
            const payload = await response.json();
            if (payload && payload.error) message = payload.error;
          } catch (error) {
            void error;
          }
          const apiError = new Error(message);
          apiError.status = response.status;
          throw apiError;
        }

        const blob = await response.blob();
        const downloadUrl = URL.createObjectURL(blob);
        const link = document.createElement("a");
        const disposition = response.headers.get("content-disposition") || "";
        const suggestedName = parseFilenameFromDisposition(disposition);
        link.href = downloadUrl;
        link.download = suggestedName || "student-report-card.pdf";
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(downloadUrl);
        setStatus("PDF report card downloaded.");
      }

      async function deleteReport(recordId) {
        const id = selectedStudentId();
        const result = await api(
          `/api/admin/students/${encodeURIComponent(id)}/reports/${encodeURIComponent(recordId)}`,
          {
            method: "DELETE",
          },
        );
        setTableRecordArchived("reports", recordId, false);
        state.currentStudent = result.student;
        fillStudentForm(state.currentStudent);
        setStatus("Performance report deleted.");
      }

      function renderReportRows(rows) {
        const tbody = document.getElementById("reportRows");
        tbody.innerHTML = "";
        state.tableRows.reports = Array.isArray(rows) ? [...rows] : [];
        const sortedRows = sortedReportRows(state.tableRows.reports);
        const filteredRows = filterRowsForTable(
          "reports",
          sortedRows,
          reportRowSearchText,
        );
        state.visibleTableRows.reports = filteredRows;
        updateTableFilterSummary("reports");
        filteredRows.forEach((row) => {
          const archived = isTableRecordArchived("reports", row.id);
          const studentNumberText =
            row?.studentNumber === null || row?.studentNumber === undefined ?
              ""
            : escapeHtml(String(row.studentNumber));
          const tr = document.createElement("tr");
          tr.innerHTML = `
          <td class="table-col-student-number" data-reports-col="studentNumber">${studentNumberText}</td>
          <td data-reports-col="eaglesId">${escapeHtml(row.eaglesId || "")}</td>
          <td data-reports-col="fullName">${escapeHtml(row.fullName || "")}</td>
          <td data-reports-col="englishName">${escapeHtml(row.englishName || "")}</td>
          <td data-reports-col="generatedAt">${escapeHtml(formatDate(row.generatedAt))}</td>
          <td data-reports-col="weekNumber">${rowWeekNumber("reports", row) ? `Week ${rowWeekNumber("reports", row)}` : "-"}</td>
          <td data-reports-col="className">${row.className || ""}</td>
          <td data-reports-col="quarter">${row.quarter || ""}</td>
          <td data-reports-col="homeworkCompletionRate">${row.homeworkCompletionRate ?? ""}</td>
          <td data-reports-col="homeworkOnTimeRate">${row.homeworkOnTimeRate ?? ""}</td>
          <td data-reports-col="behaviorScore">${row.behaviorScore ?? ""}</td>
          <td data-reports-col="participationScore">${row.participationScore ?? ""}</td>
          <td data-reports-col="inClassScore">${row.inClassScore ?? ""}</td>
          <td class="table-row-options-cell">
            <details class="row-options-menu">
              <summary class="row-options-trigger portal-button portal-button-primary portal-button-compact tbm01">Actions</summary>
              <div class="row-options-dropdown">
                <button type="button" class="portal-button portal-button-affirm portal-button-compact" data-edit="${row.id}">Edit</button>
                <button type="button" class="portal-button portal-button-info portal-button-compact" data-archive="${row.id}">${archived ? "Restore" : "Archive"}</button>
                <button type="button" class="portal-button portal-button-danger portal-button-compact" data-del="${row.id}">Delete</button>
              </div>
            </details>
          </td>
        `
          tr.querySelector(`[data-edit="${row.id}"]`).addEventListener("click", () => {
            document.getElementById("r_id").value = row.id;
            document.getElementById("r_className").value = row.className || "";
            document.getElementById("r_schoolYear").value =
              row.schoolYear || currentAdminSchoolYear();
            document.getElementById("r_quarter").value = row.quarter || "";
            document.getElementById("r_homeworkCompletionRate").value =
              row.homeworkCompletionRate ?? "";
            document.getElementById("r_homeworkOnTimeRate").value =
              row.homeworkOnTimeRate ?? "";
            document.getElementById("r_behaviorScore").value = row.behaviorScore ?? "";
            document.getElementById("r_participationScore").value =
              row.participationScore ?? "";
            document.getElementById("r_inClassScore").value = row.inClassScore ?? "";
            document.getElementById("r_participationPointsAward").value =
              row.participationPointsAward ?? "";
            document.getElementById("r_comments").value = row.comments || "";
          });
          tr.querySelector(`[data-archive="${row.id}"]`).addEventListener(
            "click",
            () => {
              const nextArchived = !isTableRecordArchived("reports", row.id);
              setTableRecordArchived("reports", row.id, nextArchived);
              renderReportRows(state.tableRows.reports);
              setStatus(
                nextArchived ? "Report record archived." : "Report record restored.",
              );
            },
          );
          tr.querySelector(`[data-del="${row.id}"]`).addEventListener("click", () =>
            deleteReport(row.id).catch(handleError),
          );
          tbody.appendChild(tr);
        });
        if (!filteredRows.length) {
          tbody.innerHTML =
            '<tr><td colspan="14">No report rows match current search/archive filters.</td></tr>';
        }
        applyTableColumnVisibility("reports");
      }

      async function lookupFamilyPhone() {
        const phone = normalizeText(document.getElementById("familyPhone").value);
        if (!phone) throw new Error("Enter family emergency phone");
        setActivePage("family");
        const familyResultEl = document.getElementById("familyResult");
        const result = await api(
          `/api/admin/family?phone=${encodeURIComponent(phone)}`,
        );
        if (!result.items || !result.items.length) {
          if (familyResultEl)
            familyResultEl.textContent =
              "No related students found for that emergency phone.";
          setStatus("No related students found for that emergency phone.");
          return;
        }
        const summary = result.items
          .map(
            (row) => `${normalizeText(row.eaglesId)} - ${normalizeText(row.fullName)}`,
          )
          .join("\n");
        if (familyResultEl) familyResultEl.textContent = summary;
        setStatus(`Family matches (${result.total}):\n${summary}`);
      }

      function clearFamilyLookupResult() {
        const familyPhoneEl = document.getElementById("familyPhone");
        const familyResultEl = document.getElementById("familyResult");
        if (familyPhoneEl) familyPhoneEl.value = "";
        if (familyResultEl) familyResultEl.textContent = "No family lookup yet.";
        setStatus("Family lookup form cleared.");
      }

      function handleError(error) {
        if (error && error.status === 401) {
          const loginVisible = !document
            .getElementById("authPanel")
            ?.classList.contains("hidden");
          if (loginVisible) {
            setStatus(error.message || "Invalid username or password.", true);
            return;
          }
          logout(false);
          setStatus("Session expired. Please login again.", true);
          return;
        }
        setStatus(error.message || String(error), true);
      }

      function scheduleIdleTask(task, timeout = 1200) {
        const runner = () => {
          try {
            return Promise.resolve(task());
          } catch (error) {
            handleError(error);
            return Promise.resolve();
          }
        };
        const execute = () => {
          void runner().catch(handleError);
        };
        if (typeof window.requestIdleCallback === "function") {
          window.requestIdleCallback(execute, { timeout });
          return;
        }
        window.setTimeout(execute, 0);
      }

      function scheduleIdleTaskSeries(tasks = [], { timeout = 1200 } = {}) {
        const queue = Array.isArray(tasks) ? tasks.filter((task) => typeof task === "function") : [];
        if (!queue.length) return;
        const runNext = () => {
          const nextTask = queue.shift();
          if (!nextTask) return;
          scheduleIdleTask(async () => {
            await nextTask();
            if (queue.length) runNext();
          }, timeout);
        };
        runNext();
      }

      /* PERF-CONTRACT: ADMIN-DEFERRED-HYDRATION
       * This scheduler protects first paint and TBT. New dashboard work must
       * be measured before moving it ahead of this boundary. */
      function scheduleAfterFirstPaint(task, timeout = 2000) {
        if (IS_JSDOM_ENV) {
          void Promise.resolve().then(task).catch(handleError);
          return;
        }
        const afterPaint = () => scheduleIdleTask(task, timeout);
        if (typeof window.requestAnimationFrame === "function") {
          window.requestAnimationFrame(() => window.requestAnimationFrame(afterPaint));
          return;
        }
        window.setTimeout(afterPaint, 0);
      }

      /* PERF-CONTRACT: ADMIN-ISLAND-IMPORTS
       * Island files are separate assets, but this boundary is what keeps
       * their evaluation and network discovery out of the dashboard first
       * paint. Move an import earlier only with authenticated Lighthouse proof. */
      function scheduleAdminIslandImport(factory, timeout = 1800, requiredPage = "") {
        return new Promise((resolve, reject) => {
          let settled = false;
          let retryTimer = null;
          const pageActivated = () => runWhenPageIsReady();
          const runWhenPageIsReady = () => {
            if (settled) return;
            if (
              requiredPage &&
              !requiredPage.split("|").includes(normalizePageSlug(state.activePage))
            ) return;
            settled = true;
            if (retryTimer) window.clearInterval(retryTimer);
            document.removeEventListener("sis-admin-page-activated", pageActivated);
            Promise.resolve().then(factory).then(resolve, reject);
          };
          document.addEventListener("sis-admin-page-activated", pageActivated);
          retryTimer = window.setInterval(runWhenPageIsReady, 250);
          scheduleAfterFirstPaint(runWhenPageIsReady, timeout);
        });
      }

      async function bootAfterLogin() {
        await window.SIS_PORTAL_PREFERENCES?.migrate?.();
        rehydratePreferenceBackedState();
        window.SIS_PORTAL_THEME?.initTheme?.("light");
        const bootConfigTasks = [];
        if (canManagePermissions()) {
          bootConfigTasks.push(async () => {
            await loadRolePermissions();
            showUserPanel();
          });
        }
        const activePage = normalizePageSlug(state.activePage);
        const pageNeedsStudentList = new Set([
          "student-admin",
          "attendance",
          "attendance-admin",
          "assignments",
          "assignments-data",
          "grades",
          "grades-data",
          "grades-tabulator",
          "parent-tracking",
          "performance-data",
          "performance-engagement",
          "reports",
        ]).has(activePage);
        const pageNeedsFilters = pageNeedsStudentList || activePage === "news-reports";
        if (activePage === "assignments" || activePage === "assignments-data") {
          bootConfigTasks.push(async () => {
            await loadAssignmentTemplatesFromServer({
              migrateLegacy: true,
            });
            renderAssignmentTemplates();
          });
        }

        const isOverview = activePage === "overview";
        const isProfilePage = activePage === "profile";
        const isAssignmentPage = activePage === "assignments" || activePage === "assignments-data";
        const isParentTrackingPage = activePage === "parent-tracking";
        const isAttendancePage = activePage === "attendance" || activePage === "attendance-admin";
        const runCompatibilityStartup = IS_JSDOM_ENV;

        showUserPanel();
        applyUiSettings();
        if (isAssignmentPage || runCompatibilityStartup) {
          renderAssignmentTemplates();
          renderAssignmentDraftItems();
          renderAssignmentExerciseOptions();
        }
        clearUserForm();
        if (canManageUsers() && activePage === "users") {
          scheduleAfterFirstPaint(() => loadUsers().catch(handleError), 3000);
        } else {
          state.adminUsers = [];
          renderUserRows();
        }
        if (!canReadData()) {
          state.students = [];
          renderStudents();
        }
        if (isAssignmentPage || runCompatibilityStartup) renderAssignmentDraftItems();
        if (isParentTrackingPage || runCompatibilityStartup) {
          initializeParentTrackingScoreSelects();
          initializeParentTrackingScoreLegendPopovers();
          renderParentTrackingTeacherOptions();
        }
        clearStudentForm({
          refreshStudentList: false,
          hydrateNextStudentNumber: isProfilePage || activePage === "student-admin",
        });
        const nextPage =
          isPageAllowedForCurrentRole(state.activePage) ?
            normalizePageSlug(state.activePage)
          : roleStartPage();
        setActivePage(nextPage, {
          syncUrl: shouldSyncPagePathInHistory(),
          historyMode: "replace",
        });

        if (isAttendancePage || runCompatibilityStartup) ensureAttendanceLandingFormDefaults();

        if (canReadData()) {
          scheduleAfterFirstPaint(async () => {
            await hydrateUiSettingsFromServer();
            applyUiSettings();
          }, 2500);
        }

        if (bootConfigTasks.length) {
          bootConfigTasks.forEach((task) => scheduleAfterFirstPaint(task, 2500));
        }

        if (canReadData()) {
          const dataHydrationTasks = [];
          if (pageNeedsStudentList) {
            dataHydrationTasks.push(() => loadStudents());
          }
          if (pageNeedsFilters) {
            dataHydrationTasks.push(() => loadFilters().catch(handleError));
          }
          if (isOverview) {
            dataHydrationTasks.push(async () => {
              await loadDashboardSummary();
              if (
                !state.dashboardLevelCompletionRows.length &&
                Array.isArray(state.assignmentTemplates) &&
                state.assignmentTemplates.length
              ) {
                await loadDashboardStudents();
              }
              renderHubConnectionStatus();
              renderServiceControlCard();
            });
            dataHydrationTasks.push(() => loadIncomingExerciseResults({ showAll: false }));
          }
          if (isAssignmentPage || (runCompatibilityStartup && !isOverview)) {
            dataHydrationTasks.push(() => loadExerciseTitles().catch(handleError));
          }
          if (isOverview || (runCompatibilityStartup && isAssignmentPage)) {
            // Overview content is already present in the shell and must
            // hydrate as soon as auth succeeds so below-fold panels paint.
            void Promise.all(dataHydrationTasks.map((task) => task())).catch(handleError);
          } else {
            dataHydrationTasks.forEach((task) => scheduleAfterFirstPaint(task, 5000));
          }

          void Promise.all([
            probeHubConnection({ notify: false, paint: true }),
            loadServiceControlStatus({ notify: false, paint: true }),
          ]).catch(handleError);
        }
        if (isParentTrackingPage || runCompatibilityStartup) await applyParentTrackingDeepLinkFromLocation();
      }

      // Keep non-shell decoration out of the authenticated startup task.
      // These helpers only enhance controls after the shell is usable.
      scheduleAfterFirstPaint(() => {
        installButtonPressFeedback();
        initializeButtonTooltips();
        wireSharedButtonDecoration();
        wireRowOptionsDropdownLayout();
      }, 3000);

      document.querySelectorAll("[data-menu-toggle]").forEach((toggleBtn) => {
        toggleBtn.addEventListener("click", () => {
          const groupName = normalizeText(toggleBtn.getAttribute("data-menu-toggle"));
          const parentGroup = toggleBtn.closest("[data-menu-group]");
          if (!groupName || !parentGroup) return;
          if (parentGroup.classList.contains("expanded")) {
            parentGroup.classList.remove("expanded");
            toggleBtn.setAttribute("aria-expanded", "false");
            return;
          }
          updateMenuExpansion(groupName);
        });
      });

      document.querySelectorAll("[data-page-link]").forEach((linkEl) => {
        linkEl.addEventListener("click", (event) => {
          const pageSlug = normalizeText(linkEl.getAttribute("data-page-link"));
          if (!pageSlug) return;
          if (isStaticAdminPreviewMode()) {
            event.preventDefault();
            setActivePage(pageSlug);
            return;
          }
          if (IS_JSDOM_ENV) {
            event.preventDefault();
            setActivePage(pageSlug);
            return;
          }
          if (
            event.defaultPrevented ||
            event.button !== 0 ||
            event.metaKey ||
            event.ctrlKey ||
            event.shiftKey ||
            event.altKey
          )
            return;
          setActivePage(pageSlug, { syncUrl: false });
        });
      });

      const menuToggleBtnEl = document.getElementById("menuToggleBtn");
      const floatingMenuBtnEl = document.getElementById("floatingMenuBtn");
      const menuBackdropEl = document.getElementById("menuBackdrop");
      refreshMenuLinkTargets();
      applyDesktopMenuCollapsedPreference();
      document.body.classList.remove("menu-open");
      updateMenuToggleButtonLabel();
      const toggleNavigationMenu = () => {
        document.body.classList.toggle("menu-open");
        updateMenuToggleButtonLabel();
      };
      menuToggleBtnEl?.addEventListener("click", toggleNavigationMenu);
      floatingMenuBtnEl?.addEventListener("click", toggleNavigationMenu);
      menuBackdropEl?.addEventListener("click", () => {
        document.body.classList.remove("menu-open");
        updateMenuToggleButtonLabel();
      });

      document.addEventListener("click", (event) => {
        if (!document.body.classList.contains("menu-open")) return;
        const sidebarEl = document.querySelector(".app-sidebar");
        const target = event.target;
        if (!(target instanceof Element)) return;
        if (sidebarEl?.contains(target)) return;
        if (menuToggleBtnEl?.contains(target)) return;
        if (floatingMenuBtnEl?.contains(target)) return;
        document.body.classList.remove("menu-open");
        updateMenuToggleButtonLabel();
      });

      window.addEventListener("resize", () => {
        applyDesktopMenuCollapsedPreference();
        updateMenuToggleButtonLabel();
      });

      window.addEventListener("popstate", () => {
        const pageFromQuery = pageSlugFromLocationSearch(window.location.search);
        if (pageFromQuery) {
          setActivePage(pageFromQuery, { syncUrl: false });
          return;
        }
        const pageFromPath = pageSlugFromLocationPathname(window.location.pathname);
        if (!pageFromPath) return;
        setActivePage(pageFromPath, { syncUrl: false });
      });

      bindById("loginForm", "submit", (event) => {
        event.preventDefault();
        login().catch(handleError);
      });
      bindById("schoolSetupWarningCloseBtn", "click", () => closeSchoolSetupWarningModal());
      bindById("schoolSetupWarningOpenBtn", "click", () => closeSchoolSetupWarningModal());
      bindById("schoolSetupWarningAutoFixBtn", "click", async () => {
        const statusEl = document.getElementById("schoolSetupWarningModalActionStatus");
        try {
          if (statusEl) statusEl.textContent = "Generating explicit quarter rows and saving...";
          await recoverSchoolSetupFromWarning();
          schoolSetupWarningAcknowledged = false;
          renderSchoolSetupAccessWarning();
          if (statusEl) statusEl.textContent = "School setup was recovered and saved.";
        } catch (error) {
          if (statusEl) statusEl.textContent = error?.message || "Recovery failed. Open School Setup to correct it manually.";
          handleError(error);
        }
      });
      bindById("schoolSetupWarningSyncBtn", "click", async () => {
        const statusEl = document.getElementById("schoolSetupWarningModalActionStatus");
        try {
          if (statusEl) statusEl.textContent = "Running System Config Sync...";
          await runSisConfigRepair();
          if (statusEl) statusEl.textContent = "Config sync completed. Reloading school setup status...";
          await hydrateUiSettingsFromServer();
          schoolSetupWarningAcknowledged = false;
          renderSchoolSetupAccessWarning();
        } catch (error) {
          if (statusEl) statusEl.textContent = error?.message || "Config sync failed. Contact an administrator.";
          handleError(error);
        }
      });
      document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && !document.getElementById("schoolSetupWarningModal")?.classList.contains("hidden")) {
          closeSchoolSetupWarningModal();
        }
      });
      document
        .getElementById("loginClearBtn")
        ?.addEventListener("click", () => clearLoginForm());
      bindById("logoutBtn", "click", () => logout().catch(handleError));
      document
        .getElementById("sidebarLogoutBtn")
        ?.addEventListener("click", () => logout().catch(handleError));
      const liveNameSearch = (() => {
        let timer = null;
        return () => {
          if (timer) window.clearTimeout(timer);
          timer = window.setTimeout(() => {
            timer = null;
            if (!hasLiveDom()) return;
            renderStudents();
          }, SEARCH_INPUT_DEBOUNCE_MS);
        };
      })();
      bindById("searchQ", "input", () => liveNameSearch());
      bindById("searchBtn", "click", () => {
        Promise.all([loadStudents(), loadFilters()]).catch(handleError);
      });
      bindById("clearFiltersBtn", "click", () => clearTopControls().catch(handleError));
      bindById("filterLevel", "change", () => loadStudents().catch(handleError));
      bindById("includeUnenrolled", "change", () => loadStudents().catch(handleError));
      bindById("filterSchool", "change", () => loadStudents().catch(handleError));
      bindById("profileEnrollmentPeriodSelect", "change", (event) => {
        const target = event?.target;
        const studentRefId = normalizeText(state.currentStudent?.id || "");
        if (!(target instanceof HTMLSelectElement) || !studentRefId) return;
        loadStudentDetail(studentRefId, target.value).catch(handleError);
      });
      DATA_TABLE_KEYS.forEach((tableKey) => {
        const config = tableFilterFieldConfig(tableKey);
        if (!config) return;
        const levelEl = document.getElementById(config.level);
        const studentEl = document.getElementById(config.student);
        const dateFromEl = document.getElementById(config.dateFrom);
        const dateToEl = document.getElementById(config.dateTo);
        const weekEl = document.getElementById(config.weekNumber);

        levelEl?.addEventListener("change", () => {
          setTableFilterValue(tableKey, "level", levelEl.value);
          refreshTableSearchFilterControls(tableKey);
          rerenderSortedTable(tableKey);
        });

        studentEl?.addEventListener("change", () => {
          setTableFilterValue(tableKey, "studentRefId", studentEl.value);
          rerenderSortedTable(tableKey);
        });

        const applyDateRange = () => {
          let fromIso = normalizeText(dateFromEl?.value).slice(0, 10);
          let toIso = normalizeText(dateToEl?.value).slice(0, 10);
          if (fromIso && toIso && compareIsoDateText(fromIso, toIso) > 0) {
            const swapped = fromIso;
            fromIso = toIso;
            toIso = swapped;
            if (dateFromEl) dateFromEl.value = fromIso;
            if (dateToEl) dateToEl.value = toIso;
          }
          setTableFilterValue(tableKey, "dateFrom", fromIso);
          setTableFilterValue(tableKey, "dateTo", toIso);
          rerenderSortedTable(tableKey);
        };
        dateFromEl?.addEventListener("change", applyDateRange);
        dateToEl?.addEventListener("change", applyDateRange);
        weekEl?.addEventListener("input", () => {
          setTableFilterValue(tableKey, "weekNumber", weekEl.value);
          rerenderSortedTable(tableKey);
        });
      });
      

      if (IS_JSDOM_ENV) {
        activateAdminFallback("bindNewsReviewIslandFallback");
      } else {
        void scheduleAdminIslandImport(() => import("/web-asset/admin/news-review-island.mjs"), 1800, "news-reports")
          .then((mod) =>
            mod.initNewsReviewIsland({
              document,
              onNewsReviewStatusChange(status) {
                setNewsReviewFilterValues({ status });
                loadNewsReviewQueue().catch(handleError);
              },
              onNewsReviewCheckChange(setAction) {
                setNewsReviewFilterValues({ setAction });
                loadNewsReviewQueue().catch(handleError);
              },
              onNewsReviewLevelChange(level, studentRefId = "") {
                setNewsReviewFilterValues({ level, studentRefId });
                loadNewsReviewQueue().catch(handleError);
              },
              onNewsReviewStudentChange(studentRefId) {
                setNewsReviewFilterValues({ studentRefId });
                loadNewsReviewQueue().catch(handleError);
              },
              onNewsReviewDateRangeChange(dateFrom, dateTo) {
                setNewsReviewFilterValues({ dateFrom, dateTo });
                loadNewsReviewQueue().catch(handleError);
              },
              onNewsReviewQueryChange(query) {
                setNewsReviewFilterValues({ query });
                loadNewsReviewQueue().catch(handleError);
              },
              onNewsReviewRefresh() {
                loadNewsReviewQueue({ notify: true }).catch(handleError);
              },
              onNewsReviewClearFilters() {
                state.newsReview.filters = normalizeNewsReviewFilters({
                  status: "all",
                  setAction: "all",
                  level: "",
                  studentRefId: "",
                  dateFrom: "",
                  dateTo: "",
                  query: "",
                  take: state.newsReview?.filters?.take || 200,
                });
                refreshNewsReviewFilterControls();
                loadNewsReviewQueue({ notify: true }).catch(handleError);
              },
              onNewsReviewApproveQueue() {
                applyNewsReviewBulkApprove().catch(handleError);
              },
              onNewsReviewOpenWeekSet(weekSetId, reportId = "") {
                if (!weekSetId) return;
                openNewsReviewViewerByWeekSetId(weekSetId, { reportId }).catch(handleError);
              },
              onNewsReviewCloseViewer() {
                closeNewsReviewViewer();
              },
              onNewsReviewEditViewer() {
                const activeReport = newsReviewViewerCurrentItem();
                if (!activeReport) return;
                setNewsReviewViewerEditMode(!state.newsReview.viewerEditMode);
              },
              onNewsReviewSaveViewer() {
                applyNewsReviewAction(
                  normalizeText(newsReviewViewerCurrentItem()?.id),
                  "save",
                  {
                    keepViewerOpen: true,
                  },
                ).catch(handleError);
              },
              onNewsReviewShiftViewer(direction) {
                shiftNewsReviewViewer(direction);
              },
              onNewsReviewApplyViewerAction(action) {
                applyNewsReviewViewerAction(action).catch(handleError);
              },
            }),
          )
          .catch((error) => {
            handleError(error);
            activateAdminFallback("bindNewsReviewIslandFallback");
            return null;
          });
      }
      bindAllTableColumnVisibilityControls();
      document.addEventListener("click", (event) => {
        const target = event?.target;
        if (!(target instanceof Element)) return;
        const buttonEl = target.closest("#studentTextZoomDownBtn, #studentTextZoomUpBtn, #studentTextZoomResetBtn");
        if (!(buttonEl instanceof HTMLButtonElement)) return;
        const action = buttonEl.id === "studentTextZoomDownBtn"
          ? "decrease"
          : buttonEl.id === "studentTextZoomUpBtn"
            ? "increase"
            : "reset";
        if (!["decrease", "increase", "reset"].includes(action)) return;
        updateGlobalTextZoom(action);
      });
      document.getElementById("hubPingBtn")?.addEventListener("click", () => {
        probeHubConnection({ notify: true }).catch(handleError);
      });
      document
        .getElementById("exerciseMailerServiceRefreshBtn")
        ?.addEventListener("click", () => {
          loadServiceControlStatus({ notify: true }).catch(handleError);
        });
      document
        .getElementById("exerciseMailerRestartBtn")
        ?.addEventListener("click", () => {
          restartServiceControl().catch(handleError);
        });
      document
        .getElementById("overviewRuntimeRestartBtn")
        ?.addEventListener("click", () => {
          syncAndRestartServiceControl().catch(handleError);
        });
      bindById("refreshBtn", "click", async () => {
        try {
          await loadFilters();
          await loadStudents();
          await loadDashboardStudents();
          await loadDashboardSummary();
          await loadQueueHub({ notify: false });
          await loadServiceControlStatus({ notify: false });
          await loadIncomingExerciseResults({
            showAll: state.incomingExerciseQueue.showAll,
          });
          await loadParentReportQueue({ showAll: state.parentReportQueue.showAll });
          if (state.activePage === "news-reports")
            await loadNewsReviewQueue({ notify: false });
          await loadExerciseTitles();
          await probeHubConnection({ notify: false });
          setStatus("Data refreshed.");
        } catch (error) {
          handleError(error);
        }
      });
      bindById("familyBtn", "click", () => lookupFamilyPhone().catch(handleError));
      bindById("familyClearResultBtn", "click", () => clearFamilyLookupResult());
      bindById("userNewBtn", "click", () => {
        clearUserForm();
        setStatus("New user form ready.");
      });
      bindById("userClearBtn", "click", () => {
        clearUserForm();
        setStatus("User form cleared.");
      });
      bindById("userForm", "submit", (event) => {
        event.preventDefault();
        saveAdminUser().catch(handleError);
      });
      bindById("userRefreshBtn", "click", () => {
        loadUsers()
          .then(() => setStatus("User list refreshed."))
          .catch(handleError);
      });
      bindById("userDeleteBtn", "click", () => deleteAdminUser().catch(handleError));
      bindById("permissionsReloadBtn", "click", () => {
        loadRolePermissions()
          .then(() => setStatus("Role permissions reloaded."))
          .catch(handleError);
      });
      bindById("permissionsSaveBtn", "click", () => saveRolePermissions().catch(handleError));
      bindById("permissionsResetBtn", "click", () => resetRolePermissionsEditor());

      function bindProfileIslandFallback() {
        bindById("newBtn", "click", () => {
          clearStudentForm();
          setProfileMode("edit");
          setStatus("New student form ready.");
        });
        bindById("studentClearBtn", "click", () => {
          clearStudentForm();
          setProfileMode("edit");
          setStatus("Student form cleared.");
        });
        bindById("saveBtn", "click", () => saveStudent().catch(handleError));
        bindById("deleteBtn", "click", () => deleteCurrentStudent().catch(handleError));
        document.getElementById("profileEditInfoBtn")?.addEventListener("click", () => {
          if (!state.currentStudent?.id) {
            setStatus("Select a student first to edit.", true);
            return;
          }
          fillStudentForm(state.currentStudent);
          setProfileMode("edit");
          setStatus("Editing selected student profile.");
        });
        document.getElementById("profileCreateInfoBtn")?.addEventListener("click", () => {
          clearStudentForm();
          setProfileMode("edit");
          setStatus("New student form ready.");
        });
        document
          .getElementById("profileRefreshInfoBtn")
          ?.addEventListener("click", () => {
            if (!state.currentStudent?.id) {
              renderProfileInfoLayout(null);
              setStatus("No student selected.");
              return;
            }
            loadStudentDetail(state.currentStudent.id).catch(handleError);
          });
        document.getElementById("profileBackToInfoBtn")?.addEventListener("click", () => {
          if (state.currentStudent?.id) fillStudentForm(state.currentStudent);
          else renderProfileInfoLayout(null);
          setProfileMode("info");
          setStatus("Returned to info view.");
        });
        document
          .querySelector('.page-section[data-page="profile"]')
          ?.addEventListener("change", (event) => {
            const target = event?.target;
            if (!(target instanceof Element)) return;
            if (target.id !== "f_currentGrade") return;
            applyLevelThemeToSections(target.value);
          });
        document
          .getElementById("profileEditorForm")
          ?.addEventListener("submit", (event) => {
            event.preventDefault();
          });
      }

      if (IS_JSDOM_ENV) {
        bindProfileIslandFallback();
      } else {
        void scheduleAdminIslandImport(() => import("/web-asset/admin/profile-island.mjs"), 1800, "profile")
          .then((mod) =>
            mod.initProfileIsland({
              document,
              onProfileNewStudent() {
                clearStudentForm();
                setProfileMode("edit");
                setStatus("New student form ready.");
              },
              onProfileClearStudent() {
                clearStudentForm();
                setProfileMode("edit");
                setStatus("Student form cleared.");
              },
              onProfileSaveStudent() {
                saveStudent().catch(handleError);
              },
              onProfileDeleteStudent() {
                deleteCurrentStudent().catch(handleError);
              },
              onProfileEditInfo() {
                if (!state.currentStudent?.id) {
                  setStatus("Select a student first to edit.", true);
                  return;
                }
                fillStudentForm(state.currentStudent);
                setProfileMode("edit");
                setStatus("Editing selected student profile.");
              },
              onProfileCreateInfo() {
                clearStudentForm();
                setProfileMode("edit");
                setStatus("New student form ready.");
              },
              onProfileRefreshInfo() {
                if (!state.currentStudent?.id) {
                  renderProfileInfoLayout(null);
                  setStatus("No student selected.");
                  return;
                }
                loadStudentDetail(state.currentStudent.id).catch(handleError);
              },
              onProfileBackToInfo() {
                if (state.currentStudent?.id) fillStudentForm(state.currentStudent);
                else renderProfileInfoLayout(null);
                setProfileMode("info");
                setStatus("Returned to info view.");
              },
              onProfileCurrentGradeChange(value) {
                applyLevelThemeToSections(value);
              },
              onProfileEditorSubmit(event) {
                event.preventDefault();
              },
            }),
          )
          .catch((error) => {
            handleError(error);
            bindProfileIslandFallback();
            return null;
          });
      }

      const previewSchoolSetupFromInputs = () => {
        const draftSetup = previewSchoolSetupFromInputsData();
        if (!draftSetup) {
          return;
        }
        const draftProfile = draftSchoolProfileFromInputs({
          fallbackProfile: schoolProfileState(),
        });
        const draftNewsValidation = draftNewsReportValidationFromInputs({
          fallbackValidation: newsReportValidationState(),
        });
        state.uiSettings = {
          ...state.uiSettings,
          schoolSetup: draftSetup,
        };
        renderSchoolSetupPanel({
          setup: draftSetup,
          profile: draftProfile,
          newsReportValidation: draftNewsValidation,
          message: "Quarter preview updated.",
        });
      };
      

      if (IS_JSDOM_ENV) {
        activateAdminFallback("bindSchoolSetupBrandingFallback");
      } else {
        void scheduleAdminIslandImport(() => import("/web-asset/admin/school-setup-branding-island.mjs"), 1800, "school-setup|settings")
          .then((mod) =>
            mod.initSchoolSetupBrandingIsland({
              document,
              onSchoolSetupPreviewChange() {
                previewSchoolSetupFromInputs();
              },
              onSchoolSetupAutoFill() {
                try {
                  autoFillSchoolSetupFromInputs();
                  setStatus("Quarter rows auto-filled.");
                } catch (error) {
                  const draft = schoolSetupDraftForRender();
                  renderSchoolSetupPanel({
                    setup: draft.setup,
                    profile: draft.profile,
                    newsReportValidation: draft.newsReportValidation,
                    message: error.message || "Unable to auto-fill quarter rows.",
                    isError: true,
                  });
                  setStatus(error.message || "Unable to auto-fill quarter rows.", true);
                }
              },
              onSchoolSetupLogoChange(event) {
                handleSchoolSetupLogoUpload(event).catch((error) => {
                  const draft = schoolSetupDraftForRender();
                  renderSchoolSetupPanel({
                    setup: draft.setup,
                    profile: draft.profile,
                    newsReportValidation: draft.newsReportValidation,
                    message: error.message || "Unable to process school logo.",
                    isError: true,
                  });
                  setStatus(error.message || "Unable to process school logo.", true);
                });
              },
              onSchoolSetupLogoClear() {
                try {
                  clearSchoolSetupLogoDraft();
                  setStatus("School logo cleared from draft.");
                } catch (error) {
                  setStatus(error.message || "Unable to clear school logo draft.", true);
                }
              },
              onSchoolSetupSave() {
                saveSchoolSetupFromInputs({ notify: true })
                  .then(() => {
                    syncAttendanceDateDerivedFields();
                    rerenderSortedTable("attendance");
                    rerenderSortedTable("performance");
                    rerenderSortedTable("grades");
                    rerenderSortedTable("reports");
                  })
                  .catch(handleError);
              },
              onSchoolSetupReset() {
                resetUiSettings()
                  .then(() => {
                    const logoFileEl = document.getElementById("schoolSetupLogoFile");
                    if (logoFileEl) logoFileEl.value = "";
                    syncAttendanceDateDerivedFields();
                    setStatus("School setup reloaded from saved values.");
                  })
                  .catch(handleError);
              },
              onProfileFieldLayoutApply() {
                try {
                  applyProfileFieldLayoutChanges();
                } catch (error) {
                  handleError(error);
                }
              },
              onProfileFieldLayoutReset() {
                try {
                  resetProfileFieldLayoutToDefault();
                } catch (error) {
                  handleError(error);
                }
              },
              onProfileFieldLayoutRefresh() {
                renderProfileFieldLayoutEditor();
                setProfileLayoutStatus("Layout editor reloaded.");
              },
              onProfileFieldCreate() {
                try {
                  createProfileFieldFromSettings();
                } catch (error) {
                  handleError(error);
                }
              },
              onProfileFieldLayoutRowDelete(profileFieldKey) {
                deleteProfileFieldFromLayout(profileFieldKey);
              },
            }),
          )
          .catch((error) => {
            handleError(error);
            activateAdminFallback("bindSchoolSetupBrandingFallback");
            return null;
          });
      }

      function bindReportSettingsFallback() {
        bindById("importBtn", "click", () => importSpreadsheet().catch(handleError));
        bindById("importTemplateBtn", "click", () =>
          downloadImportTemplate().catch(handleError),
        );
        bindById("settingsSaveBtn", "click", () => saveUiSettings().catch(handleError));
        bindById("settingsResetBtn", "click", () => resetUiSettings().catch(handleError));
        bindById("reportSaveBtn", "click", () => saveReport().catch(handleError));
        bindById("reportGenerateBtn", "click", () => generateReport().catch(handleError));
        bindById("reportCardBtn", "click", () => downloadReportCard().catch(handleError));
        bindById("reportClearBtn", "click", () => {
          clearReportForm();
          setStatus("Report form cleared.");
        });
        bindById("reportSortField", "change", () => {
          applySortState(
            "reports",
            normalizeText(document.getElementById("reportSortField").value) ||
              "generatedAt",
            { toggleIfSame: false, resetDirOnFieldChange: false },
          );
          rerenderSortedTable("reports");
        });
        bindById("reportSortDirBtn", "click", () => {
          const currentField =
            normalizeText(state.tableSort?.reports?.field) || "generatedAt";
          applySortState("reports", currentField, {
            toggleIfSame: true,
            resetDirOnFieldChange: false,
          });
          rerenderSortedTable("reports");
        });
        const applyReportDataSearch = () => {
          setTableSearchTerm(
            "reports",
            document.getElementById("reportDataSearch").value,
          );
          rerenderSortedTable("reports");
        };
        bindById("reportDataSearch", "input", applyReportDataSearch);
        bindById("reportArchiveToggleBtn", "click", () => {
          try {
            toggleTableArchivedView("reports");
          } catch (error) {
            handleError(error);
          }
        });
        bindById("reportExportXlsxBtn", "click", () => {
          exportVisibleTableRowsToXlsx("reports").catch(handleError);
        });
        bindById("reportPrintPdfBtn", "click", () => {
          try {
            printVisibleTableRowsPdf("reports");
          } catch (error) {
            handleError(error);
          }
        });
      }

      if (IS_JSDOM_ENV) {
        bindReportSettingsFallback();
      } else {
        void scheduleAdminIslandImport(() => import("/web-asset/admin/report-settings-island.mjs"), 1800, "report-settings|settings|reports")
          .then((mod) =>
            mod.initReportSettingsIsland({
              document,
              onImportSpreadsheet() {
                importSpreadsheet().catch(handleError);
              },
              onImportTemplate() {
                downloadImportTemplate().catch(handleError);
              },
              onSettingsSave() {
                saveUiSettings().catch(handleError);
              },
              onSettingsReset() {
                resetUiSettings().catch(handleError);
              },
              onReportSave() {
                saveReport().catch(handleError);
              },
              onReportGenerate() {
                generateReport().catch(handleError);
              },
              onReportCard() {
                downloadReportCard().catch(handleError);
              },
              onReportClear() {
                clearReportForm();
                setStatus("Report form cleared.");
              },
              onReportSortFieldChange(value) {
                applySortState("reports", normalizeText(value) || "generatedAt", {
                  toggleIfSame: false,
                  resetDirOnFieldChange: false,
                });
                rerenderSortedTable("reports");
              },
              onReportSortDirToggle() {
                const currentField =
                  normalizeText(state.tableSort?.reports?.field) || "generatedAt";
                applySortState("reports", currentField, {
                  toggleIfSame: true,
                  resetDirOnFieldChange: false,
                });
                rerenderSortedTable("reports");
              },
              onReportDataSearchInput(value) {
                setTableSearchTerm("reports", value);
                rerenderSortedTable("reports");
              },
              onReportArchiveToggle() {
                try {
                  toggleTableArchivedView("reports");
                } catch (error) {
                  handleError(error);
                }
              },
              onReportExportXlsx() {
                exportVisibleTableRowsToXlsx("reports").catch(handleError);
              },
              onReportPrintPdf() {
                try {
                  printVisibleTableRowsPdf("reports");
                } catch (error) {
                  handleError(error);
                }
              },
            }),
          )
          .catch((error) => {
            handleError(error);
            bindReportSettingsFallback();
            return null;
          });
      }

      

      if (IS_JSDOM_ENV) {
        activateAdminFallback("bindAssignmentControlsFallback");
        const assignmentSaveTemplateBtn = document.getElementById("assignmentSaveTemplateBtn");
        if (assignmentSaveTemplateBtn) {
          assignmentSaveTemplateBtn.addEventListener("click", () => {
            saveAssignmentTemplate().catch(handleError);
          });
          assignmentSaveTemplateBtn.dataset.sisAssignmentSaveBound = "true";
        }
      } else {
        void scheduleAdminIslandImport(() => import("/web-asset/admin/assignment-controls-island.mjs"), 1800, "assignments|assignments-data")
          .then((mod) =>
            mod.initAssignmentControlsIsland({
              document,
              onAssignLevelChange() {
                refreshAssignmentStudentOptions();
                renderAssignmentLevelTiles();
              },
              onAssignAssignedAtChange() {
                const dueEl = document.getElementById("assignDueAt");
                if (!normalizeText(dueEl?.value)) {
                  if (dueEl)
                    dueEl.value = nextSundayIsoDate(
                      document.getElementById("assignAssignedAt").value,
                    );
                }
              },
              onAssignmentExerciseSelectChange() {
                const selectEl = document.getElementById("assignmentExerciseSelect");
                const urlEl = document.getElementById("assignmentExerciseUrl");
                if (!selectEl || !urlEl) return;
                const selectedOption = selectEl.options[selectEl.selectedIndex];
                const suggestedUrl = normalizeText(selectedOption?.dataset?.url);
                if (suggestedUrl) urlEl.value = suggestedUrl;
              },
              onAssignmentAddItem() {
                try {
                  addAssignmentDraftItem();
                } catch (error) {
                  handleError(error);
                }
              },
              onAssignmentLoadTitles() {
                const q = normalizeText(
                  document.getElementById("assignmentExerciseSelect").value,
                );
                loadExerciseTitles(q).catch(handleError);
              },
              onAssignmentReloadTemplates() {
                loadAssignmentTemplatesFromServer()
                  .then(() => {
                    renderAssignmentTemplates();
                    setAssignmentStatus("Assignments reloaded.");
                  })
                  .catch(handleError);
              },
              onAssignmentSortFieldChange(value) {
                applySortState("assignments", normalizeText(value) || "dueAt", {
                  toggleIfSame: false,
                  resetDirOnFieldChange: false,
                });
                rerenderSortedTable("assignments");
              },
              onAssignmentSortDirToggle() {
                const currentField =
                  normalizeText(state.tableSort?.assignments?.field) || "dueAt";
                applySortState("assignments", currentField, {
                  toggleIfSame: true,
                  resetDirOnFieldChange: false,
                });
                rerenderSortedTable("assignments");
              },
              onAssignmentDataSearchInput(value) {
                setTableSearchTerm("assignments", value);
                rerenderSortedTable("assignments");
              },
              onAssignmentArchiveToggle() {
                try {
                  toggleTableArchivedView("assignments");
                } catch (error) {
                  handleError(error);
                }
              },
              onAssignmentExportXlsx() {
                exportVisibleTableRowsToXlsx("assignments").catch(handleError);
              },
              onAssignmentPrintPdf() {
                try {
                  printVisibleTableRowsPdf("assignments");
                } catch (error) {
                  handleError(error);
                }
              },
              onAssignmentSaveTemplate() {
                saveAssignmentTemplate().catch(handleError);
              },
              onAssignmentDeleteTemplate() {
                deleteAssignmentTemplate().catch(handleError);
              },
              onAssignmentSend() {
                sendAssignmentAnnouncement().catch(handleError);
              },
              onAssignmentReset() {
                resetAssignmentForm();
              },
              onLevelReminderSend() {
                sendLevelReminders(
                  normalizeText(
                    document.getElementById("levelReminderMode").value || "selected",
                  ),
                ).catch(handleError);
              },
              onLevelReminderSendAll() {
                sendLevelReminders("all").catch(handleError);
              },
              onLevelReminderClear() {
                clearLevelReminderForm();
              },
              onLevelDetailClose() {
                closeLevelDetailPanel();
              },
            }),
          )
          .catch((error) => {
            handleError(error);
            activateAdminFallback("bindAssignmentControlsFallback");
            return null;
          });
      }

      

      if (IS_JSDOM_ENV) {
        activateAdminFallback("bindParentTrackingIslandFallback");
      } else {
        void scheduleAdminIslandImport(() => import("/web-asset/admin/parent-tracking-island.mjs"), 1800, "parent-tracking")
          .then((mod) =>
            mod.initParentTrackingIsland({
              document,
              onParentTrackingClassDateChange() {
                const classDate = normalizeText(document.getElementById("pt_classDate").value);
                parentTrackingFieldSetValue("pt_classDay", dayLabelFromIsoDate(classDate));
                resetParentTrackingManualMetricsTouched();
                applyParentTrackingLessonSummaryFromMemory({ force: true });
                syncParentTrackingForSelection({}).catch(handleError);
              },
              onParentTrackingStudentRefChange() {
                resetParentTrackingManualMetricsTouched();
                syncParentTrackingForSelection({}).catch(handleError);
              },
              onParentTrackingTeacherChange() {
                rememberParentTrackingTeacherName();
              },
              onParentTrackingLessonSummaryInput() {
                rememberParentTrackingLessonSummary();
              },
              onParentTrackingRecommendationFocus(fieldName) {
                rememberParentTrackingRecommendationFocus(fieldName);
              },
              onParentTrackingRubricChange() {
                applyParentTrackingRubricSummaryScores();
              },
              onParentTrackingRubricInput() {
                applyParentTrackingRubricSummaryScores();
              },
              onParentTrackingActionInsert() {
                insertParentTrackingActionShortcut();
              },
              onParentTrackingActionClear() {
                clearParentTrackingActionShortcutInputs();
              },
              onParentTrackingSave() {
                saveParentTrackingReport().catch(handleError);
              },
              onParentTrackingQueueSend() {
                queueParentTrackingEmail().catch(handleError);
              },
              onParentTrackingClear() {
                clearParentTrackingForm();
                refreshParentTracking({ preserveStudentSelection: true }).catch(handleError);
              },
              onPerformanceQueueExpand() {
                const nextShowAll = !state.parentReportQueue.showAll;
                loadParentReportQueue({ showAll: nextShowAll }).catch(handleError);
              },
              onOverviewIncomingExerciseExpand() {
                const nextShowAll = !state.incomingExerciseQueue.showAll;
                loadIncomingExerciseResults({ showAll: nextShowAll }).catch(handleError);
              },
              onOverviewIncomingExerciseRefresh() {
                loadIncomingExerciseResults({
                  showAll: state.incomingExerciseQueue.showAll,
                }).catch(handleError);
              },
              onPerformanceQueueRefresh() {
                loadParentReportQueue({ showAll: state.parentReportQueue.showAll }).catch(
                  handleError,
                );
              },
              onPerformanceQueueSendAll() {
                sendAllQueuedParentReports().catch(handleError);
              },
              onPerformanceQueueSendSelected() {
                sendSelectedQueuedParentReports().catch(handleError);
              },
              onPerformanceQueueUnqueueSelected() {
                unqueueSelectedQueuedParentReports().catch(handleError);
              },
              onPerformanceQueueDeleteSelected() {
                deleteSelectedQueuedParentReports().catch(handleError);
              },
              onPerformanceQueueSelectAll(event) {
                const target = event?.target;
                setParentQueueSelectionForVisibleRows(
                  Boolean(target?.checked),
                  state.parentReportQueue.items,
                );
                renderPerformanceQueueSection({
                  total: state.parentReportQueue.total,
                  hasMore: state.parentReportQueue.hasMore,
                  items: state.parentReportQueue.items,
                });
              },
              onPerformanceStagedRefresh() {
                loadParentReportQueue({ showAll: state.parentReportQueue.showAll })
                  .then(() => {
                    renderPerformanceStagedSection(state.visibleTableRows?.performance || []);
                    setStatus("Staged performance reports reloaded.");
                  })
                  .catch(handleError);
              },
              onParentQueueClose() {
                closeParentQueueModal();
              },
              onParentQueuePrev() {
                if (state.parentReportQueue.modalIndex <= 0) return;
                state.parentReportQueue.modalIndex -= 1;
                renderParentQueueModal();
              },
              onParentQueueNext() {
                const total =
                  Array.isArray(state.parentReportQueue?.items) ?
                    state.parentReportQueue.items.length
                  : 0;
                if (state.parentReportQueue.modalIndex >= total - 1) return;
                state.parentReportQueue.modalIndex += 1;
                renderParentQueueModal();
              },
              onParentQueueHold() {
                holdParentQueueModalItem().catch(handleError);
              },
              onParentQueueEdit() {
                editParentQueueModalItem().catch(handleError);
              },
              onParentQueueRequeue() {
                requeueParentQueueModalItem().catch(handleError);
              },
              onParentQueueSendAll() {
                sendAllQueuedParentReports().catch(handleError);
              },
              onParentQueueModalClick(event) {
                const target = event.target;
                if (!(target instanceof Element)) return;
                if (target.id !== "parentQueueModal") return;
                closeParentQueueModal();
              },
            }),
          )
          .catch((error) => {
            handleError(error);
            activateAdminFallback("bindParentTrackingIslandFallback");
            return null;
          });
      }

      

      if (IS_JSDOM_ENV) {
        activateAdminFallback("bindAttendanceGradeControlsFallback");
      } else {
        void scheduleAdminIslandImport(() => import("/web-asset/admin/attendance-grade-controls-island.mjs"), 1800, "attendance|attendance-admin|grades|grades-data|grades-tabulator|reports|performance-data|performance-engagement|settings")
          .then((mod) =>
            mod.initAttendanceGradeControlsIsland({
              document,
              onAttendanceLevelStyleLevelChange() {
                state.levelTileStyleEditor.pendingImageDataUrl = "";
                syncAttendanceLevelEditorInputs();
              },
              onAttendanceSave() {
                saveAttendance().catch(handleError);
              },
              onAttendanceLandingSaveAll() {
                saveAttendanceLandingForSelectedLevel().catch(handleError);
              },
              onAttendanceLandingReload() {
                refreshAttendanceLanding({ reloadRows: true }).catch(handleError);
              },
              onAttendanceLevelApply() {
                applyAttendanceLevelTileStyle().catch(handleError);
              },
              onAttendanceLevelClearImage() {
                clearAttendanceLevelTileImage().catch(handleError);
              },
              onAttendanceLevelReset() {
                resetAttendanceLevelTileStyle().catch(handleError);
              },
              onAttendanceLevelImageChange(event) {
                try {
                  handleAttendanceLevelImageUpload(event);
                } catch (error) {
                  handleError(error);
                }
              },
              onAttendanceDateChange() {
                syncAttendanceDateDerivedFields();
                state.attendanceLanding.selectionsByStudentId = {};
                refreshAttendanceLandingRows({ hydrate: false }).catch(handleError);
              },
              onAttendanceQuarterChange() {
                updateAttendanceQuarterWarning();
              },
              onAttendanceClear() {
                clearAttendanceForm();
                setStatus("Attendance form cleared.");
              },
              onAttendanceSortFieldChange(value) {
                applySortState("attendance", normalizeText(value) || "attendanceDate", {
                  toggleIfSame: false,
                  resetDirOnFieldChange: false,
                });
                rerenderSortedTable("attendance");
              },
              onAttendanceSortDirToggle() {
                const currentField =
                  normalizeText(state.tableSort?.attendance?.field) || "attendanceDate";
                applySortState("attendance", currentField, {
                  toggleIfSame: true,
                  resetDirOnFieldChange: false,
                });
                rerenderSortedTable("attendance");
              },
              onAttendanceDataSearchInput(value) {
                setTableSearchTerm("attendance", value);
                rerenderSortedTable("attendance");
              },
              onAttendanceArchiveToggle() {
                try {
                  toggleTableArchivedView("attendance");
                } catch (error) {
                  handleError(error);
                }
              },
              onAttendanceExportXlsx() {
                exportVisibleTableRowsToXlsx("attendance").catch(handleError);
              },
              onAttendancePrintPdf() {
                try {
                  printVisibleTableRowsPdf("attendance");
                } catch (error) {
                  handleError(error);
                }
              },
              onPerformanceSortFieldChange(value) {
                applySortState("performance", normalizeText(value) || "generatedAt", {
                  toggleIfSame: false,
                  resetDirOnFieldChange: false,
                });
                rerenderSortedTable("performance");
              },
              onPerformanceSortDirToggle() {
                const currentField =
                  normalizeText(state.tableSort?.performance?.field) || "generatedAt";
                applySortState("performance", currentField, {
                  toggleIfSame: true,
                  resetDirOnFieldChange: false,
                });
                rerenderSortedTable("performance");
              },
              onPerformanceDataSearchInput(value) {
                setTableSearchTerm("performance", value);
                rerenderSortedTable("performance");
              },
              onPerformanceArchiveToggle() {
                try {
                  toggleTableArchivedView("performance");
                } catch (error) {
                  handleError(error);
                }
              },
              onPerformanceExportXlsx() {
                exportVisibleTableRowsToXlsx("performance").catch(handleError);
              },
              onPerformancePrintPdf() {
                try {
                  printVisibleTableRowsPdf("performance");
                } catch (error) {
                  handleError(error);
                }
              },
              onGradeSave() {
                saveGrade().catch(handleError);
              },
              onGradeClear() {
                clearGradeForm();
                setStatus("Grade form cleared.");
              },
              onGradeSortFieldChange(value) {
                applySortState("grades", normalizeText(value) || "dueAt", {
                  toggleIfSame: false,
                  resetDirOnFieldChange: false,
                });
                rerenderSortedTable("grades");
              },
              onGradeSortDirToggle() {
                const currentField = normalizeText(state.tableSort?.grades?.field) || "dueAt";
                applySortState("grades", currentField, {
                  toggleIfSame: true,
                  resetDirOnFieldChange: false,
                });
                rerenderSortedTable("grades");
              },
              onGradeDataSearchInput(value) {
                setTableSearchTerm("grades", value);
                rerenderSortedTable("grades");
              },
              onGradeArchiveToggle() {
                try {
                  toggleTableArchivedView("grades");
                } catch (error) {
                  handleError(error);
                }
              },
              onGradeExportXlsx() {
                exportVisibleTableRowsToXlsx("grades").catch(handleError);
              },
              onGradePrintPdf() {
                try {
                  printVisibleTableRowsPdf("grades");
                } catch (error) {
                  handleError(error);
                }
              },
              onOpenTabulatorGrades() {
                window.location.assign(buildGradesTabulatorLaunchUrl());
              },
              onGradeChartLaneOpen(laneKey) {
                openGradeChartModalForLaneKey(laneKey);
              },
              onGradeChartModalClose() {
                closeGradeChartModal();
              },
              onGradeChartModalBackdropClick(event) {
                if (event.target === event.currentTarget) closeGradeChartModal();
              },
              onGradeChartPeriodChange(period) {
                setGradeChartState({
                  period: normalizedGradeChartPeriod(period),
                });
                applyGradeChartCurrentSchoolYearDefault();
                applyGradeChartCurrentQuarterDefault();
                renderGradePulseChart(state.visibleTableRows?.grades || []);
              },
              onGradeChartGroupByChange(value) {
                setGradeChartState({ groupBy: value || "class" });
                renderGradePulseChart(state.visibleTableRows?.grades || []);
              },
              onGradeChartQuarterChange(value) {
                setGradeChartState({ quarter: value || "" });
                renderGradePulseChart(state.visibleTableRows?.grades || []);
              },
              onGradeChartSchoolYearChange(value) {
                setGradeChartState({
                  schoolYear: value || gradeChartCurrentSchoolYear(),
                });
                renderGradePulseChart(state.visibleTableRows?.grades || []);
              },
              onGradeChartCustomRangeChange(customFrom, customTo) {
                setGradeChartState({ customFrom, customTo });
                renderGradePulseChart(state.visibleTableRows?.grades || []);
              },
            }),
          )
          .catch((error) => {
            handleError(error);
            activateAdminFallback("bindAttendanceGradeControlsFallback");
            return null;
          });
      }

      function buildGradesTabulatorLaunchUrl() {
        const chart = gradeChartState();
        const currentSchoolYear = normalizeText(gradeChartCurrentSchoolYear());
        const selectedSchoolYear = normalizeGradeChartOperationalSchoolYear(
          chart.schoolYear,
        );
        const selectedQuarter = quarterKey(chart.quarter);
        const selectedPeriod = normalizedGradeChartPeriod(chart.period);
        const customFrom = normalizeText(chart.customFrom).slice(0, 10);
        const customTo = normalizeText(chart.customTo).slice(0, 10);
        const period =
          selectedPeriod === "custom" && !customFrom && !customTo
            ? "sytd"
            : selectedPeriod;
        const params = new URLSearchParams();
        if (currentSchoolYear) params.set("currentSchoolYear", currentSchoolYear);
        if (selectedSchoolYear) params.set("schoolYear", selectedSchoolYear);
        if (selectedQuarter) params.set("quarter", selectedQuarter);
        if (period) params.set("period", period);
        if (period === "custom") {
          if (customFrom) params.set("customFrom", customFrom);
          if (customTo) params.set("customTo", customTo);
        }
        const targetHref =
          isStaticAdminPreviewMode() ?
            "/web-asset/admin/grades-tabulator.html"
          : buildPageNavigationHref("grades-tabulator");
        const targetUrl = window.location.protocol.startsWith("http") ?
            new URL(targetHref, window.location.origin)
          : new URL("grades-tabulator.html", window.location.href);
        const targetParams = targetUrl.searchParams;
        if (shouldPreserveAdminApiOriginParam())
          targetParams.set("apiOrigin", ADMIN_API_ORIGIN);
        params.forEach((value, key) => {
          targetParams.set(key, value);
        });
        targetUrl.search = targetParams.toString();
        return `${targetUrl.pathname}${targetUrl.search}${targetUrl.hash}`;
      }
      function bindQueueHubIslandFallback() {
        const queueHubPanelsEl = document.getElementById("queueHubPanels");
        queueHubPanelsEl?.addEventListener("click", (event) => {
          const target = event?.target;
          if (!(target instanceof Element)) return;
          const openBtn = target.closest(
            "a[data-queue-hub-open-panel][data-queue-hub-open-index]",
          );
          if (!(openBtn instanceof HTMLAnchorElement)) return;
          event.preventDefault();
          const panelId = normalizeText(
            openBtn.getAttribute("data-queue-hub-open-panel"),
          );
          const rowIndex =
            Number.parseInt(
              normalizeText(openBtn.getAttribute("data-queue-hub-open-index")),
              10,
            ) || 0;
          openQueueHubItem(panelId, rowIndex).catch(handleError);
        });
        document
          .getElementById("queueHubRefreshBtn")
          ?.addEventListener("click", () => {
            loadQueueHub({ notify: true }).catch(handleError);
          });
        document
          .getElementById("queueHubSaveOrderBtn")
          ?.addEventListener("click", () => {
            saveQueueHubPanelOrder().catch(handleError);
          });
        document
          .getElementById("queueHubResetOrderBtn")
          ?.addEventListener("click", () => {
            try {
              resetQueueHubPanelOrder();
            } catch (error) {
              handleError(error);
            }
          });
      }

      function bindOverviewNewsQueueIslandFallback() {
        document
          .getElementById("overviewNewsQueueShowAllBtn")
          ?.addEventListener("click", () => {
            toggleOverviewNewsQueueShowAll().catch(handleError);
          });
        document
          .getElementById("overviewNewsQueueRefreshBtn")
          ?.addEventListener("click", () => {
            loadQueueHub({ notify: true }).catch(handleError);
          });
        document
          .getElementById("overviewNewsQueueOpenBtn")
          ?.addEventListener("click", () => {
            setActivePage("news-reports");
          });
        document
          .getElementById("overviewNewsQueueQueueHubBtn")
          ?.addEventListener("click", () => {
            setActivePage("queue-hub");
          });
      }

      async function toggleOverviewNewsQueueShowAll() {
        const panel = state.queueHub?.panelsById?.["news-report-review"];
        if (panel?.deferred) await loadQueueHub({ notify: false, compact: false });
        state.queueHub.overviewNewsQueueShowAll =
          !state.queueHub.overviewNewsQueueShowAll;
        renderOverviewNewsQueueSection();
      }

      if (IS_JSDOM_ENV) {
        bindQueueHubIslandFallback();
        bindOverviewNewsQueueIslandFallback();
      } else {
        void scheduleAdminIslandImport(() => import("/web-asset/admin/queue-hub-island.mjs"), 1800, "queue-hub")
          .then((mod) =>
            mod.initQueueHubIsland({
              document,
              onQueueHubItemOpen(panelId, rowIndex) {
                openQueueHubItem(panelId, rowIndex).catch(handleError);
              },
              onQueueHubRefresh() {
                loadQueueHub({ notify: true }).catch(handleError);
              },
              onQueueHubSaveOrder() {
                saveQueueHubPanelOrder().catch(handleError);
              },
              onQueueHubResetOrder() {
                try {
                  resetQueueHubPanelOrder();
                } catch (error) {
                  handleError(error);
                }
              },
            }),
          )
          .catch((error) => {
            handleError(error);
            bindQueueHubIslandFallback();
            return null;
          });
        void scheduleAdminIslandImport(() => import("/web-asset/admin/overview-news-queue-island.mjs"), 1800, "overview")
          .then((mod) =>
            mod.initOverviewNewsQueueIsland({
              document,
              onOverviewNewsQueueRefresh() {
                loadQueueHub({ notify: true }).catch(handleError);
              },
              onOverviewNewsQueueOpen() {
                setActivePage("news-reports");
              },
              onOverviewNewsQueueQueueHub() {
                setActivePage("queue-hub");
              },
              onOverviewNewsQueueShowAll() {
                toggleOverviewNewsQueueShowAll().catch(handleError);
              },
            }),
          )
          .catch((error) => {
            handleError(error);
            bindOverviewNewsQueueIslandFallback();
            return null;
          });
      }

      state.rolePermissions = normalizeRolePermissionsMap(
        defaultRolePermissionsConfig(),
      );
      state.authRolePolicy = getCurrentRolePolicy();
      renderHubConnectionStatus();
      renderServiceControlCard();
      scheduleAfterFirstPaint(() => {
        bindColumnSortHeaderEvents();
        bindPerformanceEngagementSortHeaderEvents();
        bindTopSearchControls();
        applyGlobalTextZoom();
        updateTableSortButtonLabels();
        updateTableHeaderSortIndicators();
        applyAllTableColumnVisibility();
        renderPermissionsEditor();
        updateNavigationAccess();
        updateTrackingDataSubmenuVisibility();
        updateArchiveToggleButtons();
        if ((IS_JSDOM_ENV && !isStaticAdminPreviewMode()) ||
            (isStaticAdminPreviewMode() && ADMIN_API_ORIGIN)) {
          probeHubConnection({ notify: false }).catch(() => {});
        }
      }, 1200);
      const activeStartupPage = normalizePageSlug(state.activePage);
      const activePageIdleTasks = [];
      if (IS_JSDOM_ENV || activeStartupPage === "profile") {
        activePageIdleTasks.push(() => {
          renderProfileFormLayout();
          renderProfileInfoLayout();
          renderProfileFieldLayoutEditor();
          setProfileMode("info");
          populateProfileLevelOptions();
        });
      }
      if (IS_JSDOM_ENV || activeStartupPage === "school-setup" || activeStartupPage === "settings") {
        activePageIdleTasks.push(() => {
          renderProfileFieldLayoutEditor();
          populateAttendanceLevelStyleOptions();
          syncAttendanceLevelEditorInputs();
        });
      }
      if (IS_JSDOM_ENV || activeStartupPage === "assignments" || activeStartupPage === "assignments-data") {
        activePageIdleTasks.push(() => {
          populateAssignmentLevelOptions();
          refreshAssignmentStudentOptions();
          renderAssignmentTemplates();
          renderAssignmentDraftItems();
          renderAssignmentExerciseOptions();
        });
      }
      if (IS_JSDOM_ENV || activeStartupPage === "attendance" || activeStartupPage === "attendance-admin") {
        activePageIdleTasks.push(() => {
          populateAttendanceLevelStyleOptions();
          syncAttendanceLevelEditorInputs();
          refreshAttendanceLanding({ reloadRows: false }).catch(() => {});
        });
      }
      if (IS_JSDOM_ENV || activeStartupPage === "parent-tracking") {
        activePageIdleTasks.push(() => {
          renderParentTrackingTeacherOptions();
          refreshParentTracking({ preserveStudentSelection: true }).catch(() => {});
        });
      }
      if (IS_JSDOM_ENV || activeStartupPage !== "overview") {
        activePageIdleTasks.push(() => {
          populateProfileLevelOptions();
          refreshAllTableSearchFilterControls();
          renderTopSearchStudentOptions();
          updateTopSearchScopeHint();
        });
      }
      scheduleIdleTaskSeries(activePageIdleTasks);
      if (isStaticAdminPreviewMode() && !ADMIN_API_ORIGIN) {
        setAuthBootstrapping(true);
        showLogin();
        setStatus(staticPreviewHelpMessage(), true);
      } else {
        const initialAuthState = window.__SIS_ADMIN_INITIAL_AUTH__;
        const runAuthBootstrap = () => {
          setAuthBootstrapping(true);
          const authBootstrap = window.__SIS_ADMIN_AUTH_BOOTSTRAP__;
          const authBootstrapArgs = {
            api,
            state,
            showLogin,
            showApp,
            setStatus,
            handleError,
            bootAfterLogin,
            isStaticAdminPreviewMode,
            ADMIN_API_ORIGIN,
            staticPreviewHelpMessage,
            currentRoleName,
            normalizeRolePolicy,
            getCurrentRolePolicy,
          };
          if (typeof authBootstrap === "function") {
            Promise.resolve(authBootstrap(authBootstrapArgs)).catch(handleError);
          } else {
            void import("/web-asset/admin/student-admin-bootstrap.mjs")
              .then((mod) => mod.runStudentAdminAuthBootstrap(authBootstrapArgs))
              .catch(handleError);
          }
        };
        if (initialAuthState && typeof initialAuthState === "object") {
          if (initialAuthState.authenticated) {
            state.authUser = initialAuthState.user || null;
            state.authRolePolicy = normalizeRolePolicy(
              currentRoleName(),
              initialAuthState.rolePolicy,
              getCurrentRolePolicy(),
            );
            showApp();
            setStatus("Loading dashboard...");
            bootAfterLogin()
              .then(() => {
                setStatus(
                  `Authenticated as ${state.authUser?.username || "admin"}. Student admin loaded.`,
                );
              })
              .catch(handleError);
          } else {
            // A failed/slow server-side session peek is not proof that the
            // browser cookie is invalid. Verify the cookie with the auth API.
            runAuthBootstrap();
          }
        } else {
          runAuthBootstrap();
        }
      }
    
