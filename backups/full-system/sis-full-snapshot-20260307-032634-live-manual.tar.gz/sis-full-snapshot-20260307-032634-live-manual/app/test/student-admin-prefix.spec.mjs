// test/student-admin-prefix.spec.mjs
import test from "node:test"
import assert from "node:assert/strict"

process.env.NODE_ENV = "test"
process.env.EXERCISE_MAILER_ORIGIN = "*"
process.env.EXERCISE_STORE_ENABLED = "false"
process.env.EXERCISE_STORE_REQUIRED = "false"
process.env.STUDENT_INTAKE_STORE_ENABLED = "false"
process.env.STUDENT_ADMIN_STORE_ENABLED = "false"
process.env.STUDENT_ADMIN_API_PREFIX = "/api/sis-admin"
process.env.STUDENT_ADMIN_USER = "admin"
process.env.STUDENT_ADMIN_PASS = "admin-pass-123"
process.env.MAILER_DEBUG = "false"

function makeMockTransport() {
  return {
    verify(cb) {
      setImmediate(() => cb(null, true))
    },
    async sendMail() {
      return { messageId: "mock-id" }
    },
  }
}

async function fetchLocal(port, pathname, init = {}) {
  return fetch(`http://127.0.0.1:${port}${pathname}`, init)
}

let server
let port
let sessionCookie = ""

test("start server for custom admin prefix", async () => {
  const { startExerciseMailer } = await import(process.cwd() + "/server/exercise-mailer.mjs")
  server = await startExerciseMailer({ transporter: makeMockTransport(), port: 0 })
  await new Promise((resolve) => server.once("listening", resolve))
  port = server.address().port
  assert.ok(Number.isInteger(port) && port > 0)
})

test("GET /admin/students injects custom API prefix into HTML", async () => {
  const res = await fetchLocal(port, "/admin/students")
  assert.equal(res.status, 200)
  const html = await res.text()
  assert.match(html, /__SIS_ADMIN_API_PREFIX/i)
  assert.match(html, /"\/api\/sis-admin"/i)
})

test("GET /admin/students/reports includes page slug config", async () => {
  const res = await fetchLocal(port, "/admin/students/reports")
  assert.equal(res.status, 200)
  const html = await res.text()
  assert.match(html, /__SIS_ADMIN_PAGE_SLUG/i)
  assert.match(html, /"reports"/i)
})

test("POST /api/sis-admin/auth/login works with custom prefix", async () => {
  const res = await fetchLocal(port, "/api/sis-admin/auth/login", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ username: "admin", password: "admin-pass-123" }),
  })
  assert.equal(res.status, 200)
  const setCookie = res.headers.get("set-cookie") || ""
  assert.match(setCookie, /student_admin_sid=/i)
  sessionCookie = setCookie.split(";")[0]
  assert.ok(sessionCookie.length > 20)
})

test("custom-prefix regex route matches report-card path", async () => {
  const res = await fetchLocal(port, "/api/sis-admin/students/abc/report-card.pdf", {
    headers: { Cookie: sessionCookie },
  })
  assert.equal(res.status, 503)
  const body = await res.json()
  assert.match(body.error, /store is disabled/i)
})

test("old /api/admin path is not treated as admin when prefix changed", async () => {
  const res = await fetchLocal(port, "/api/admin/students", {
    headers: { Cookie: sessionCookie },
  })
  assert.equal(res.status, 404)
})

test("shutdown custom-prefix server", async () => {
  await new Promise((resolve) => server.close(resolve))
})
